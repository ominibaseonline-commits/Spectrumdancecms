/* =========================================================
 *  QR ENQUIRY  (QR form  ->  Google Sheet  ->  CMS)
 *  Ye hissa attendance script ke saath jud kar chalta hai (same script, same URL).
 *  Public link:  <web app url>?page=enquiry
 *
 *  Flow:
 *   1) Student form bharta hai (Name, Phone, DOB, Interested For, Address, Hear About, Why Learn)  -> qenqSubmit()  -> "QrEnquiries" tab me ek row
 *      (Source hamesha "Office Visit" - kyunki QR office me hi scan hota hai)
 *   2) CMS har ~10 sec me qenq_version dekhta hai (bahut chhota check). Number badla ho to
 *      qenq_list se sirf nayi rows leta hai aur turant apne local storage (IndexedDB) me save kar leta hai.
 *   3) CMS ne jo ek baar le liya wo dobara nahi aata (har row ka seq number hota hai).
 *   4) Google Sheet me rows sirf 7 din rehti hain, phir apne aap delete ho jati hain (sheet khali rahe).
 *      CMS me enquiry kabhi isse delete nahi hoti - wo sirf admin ke Delete dabane par hatti hai.
 *
 *  Sab naye functions ka naam qenq... se shuru hota hai, taaki attendance / admission ke naam se na takraein.
 * ========================================================= */

var SHEET_QENQ = 'QrEnquiries';
var QENQ_HEADERS = ['EnqId', 'Seq', 'Time', 'TimeMs', 'Name', 'Phone', 'Course', 'Source', 'DOB', 'Address', 'HearAbout', 'WhyLearn'];
var QENQ_SOURCE = 'Office Visit';
var QENQ_MAX_ROWS = 3000;         // 7 din me isse zyada aaye to nayi enquiry nahi leta (sheet bhaari na ho)
var QENQ_RATE_PER_MIN = 40;       // poore form par ek minute me max submissions
var QENQ_PHONE_TRIES = 5;         // ek number se 10 minute me max koshish
var QENQ_DUP_MS = 10 * 60 * 1000; // same number + same course 10 minute me dobara aaye to ignore (double tap)
var QENQ_LIST_MAX = 200;          // CMS ko ek baar me itni rows
var QENQ_HTML = __QENQ_HTML__;

/* ---------------------------------------------------------
 *  SHEET + CONFIG
 * --------------------------------------------------------- */
function qenqSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(SHEET_QENQ);
  if (!sh) {
    sh = ensureSheet_(ss, SHEET_QENQ, QENQ_HEADERS);
    sh.getRange('F:F').setNumberFormat('@'); // phone number text rahe
  } else if (sh.getLastColumn() < QENQ_HEADERS.length) {
    // Purani sheet (8 column): naye columns (DOB, Address, HearAbout, WhyLearn) jod do. Purani rows jaisi hain waisi rehti hain.
    if (sh.getMaxColumns() < QENQ_HEADERS.length) sh.insertColumnsAfter(sh.getMaxColumns(), QENQ_HEADERS.length - sh.getMaxColumns());
    sh.getRange(1, 1, 1, QENQ_HEADERS.length).setValues([QENQ_HEADERS]).setFontWeight('bold');
    sh.getRange(1, 9, sh.getMaxRows(), QENQ_HEADERS.length - 8).setNumberFormat('@');
  }
  return sh;
}

function qenqStr_(v, max) {
  var s = String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim();
  s = s.replace(/^[=+\-@]+/, '').trim();   // Sheet me formula na ban sake
  return s.slice(0, max);
}

function qenqEmptyCfg_() { return { open: false, courses: [], hearOptions: [], whyOptions: [] }; }

// Purani saved config me hearOptions / whyOptions nahi hote - unhe khaali list maan lo
function qenqNormCfg_(cfg) {
  cfg = cfg || qenqEmptyCfg_();
  cfg.courses = cfg.courses || [];
  cfg.hearOptions = cfg.hearOptions || [];
  cfg.whyOptions = cfg.whyOptions || [];
  return cfg;
}

// Dropdown list saaf karke (duplicate / khaali hata kar) wapas deta hai
function qenqCleanList_(src, maxItems) {
  var out = [];
  var seen = {};
  src = src || [];
  for (var i = 0; i < src.length && out.length < maxItems; i++) {
    var c = qenqStr_(src[i], 80);
    if (c && !seen[c.toLowerCase()]) { seen[c.toLowerCase()] = true; out.push(c); }
  }
  return out;
}

// Config sheet ki key "qenqCfg" me CMS ka bheja hua (open / band + course list) rakha hota hai.
function qenqCfg_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('qenqcfg');
  if (c) { try { return qenqNormCfg_(JSON.parse(c)); } catch (e) {} }
  var cfg = qenqEmptyCfg_();
  try { var raw = readConfig_().qenqCfg; if (raw) cfg = JSON.parse(raw); } catch (e) {}
  cfg = qenqNormCfg_(cfg);
  try { cache.put('qenqcfg', JSON.stringify(cfg), 300); } catch (e) {}
  return cfg;
}

function qenqSaveConfig_(body) {
  var courses = qenqCleanList_(body.courses, 100);
  var hearOptions = qenqCleanList_(body.hearOptions, 50);
  var whyOptions = qenqCleanList_(body.whyOptions, 50);
  writeConfigKey_('qenqCfg', JSON.stringify({ open: body.open === true, courses: courses, hearOptions: hearOptions, whyOptions: whyOptions }));
  CacheService.getScriptCache().remove('qenqcfg');
  qenqSheet_(); // tab pehle se bana ho
  return { success: true, ver: qenqVer_() };
}

/* ---------------------------------------------------------
 *  VERSION = sabse naye row ka seq number (CMS bina list mange pata kar leta hai kuch aaya ya nahi)
 * --------------------------------------------------------- */
function qenqVer_() { return Number(getProp_('qenqSeq', '0')); }
function qenqNextSeq_() {
  var next = qenqVer_() + 1;
  setProp_('qenqSeq', String(next));
  return next;
}

/* ---------------------------------------------------------
 *  PUBLIC PAGE  (google.script.run se: qenqInit, qenqSubmit)
 *  Ye functions koi bhi chala sakta hai, isliye inme sirf public cheezein hain.
 * --------------------------------------------------------- */
function qenqPage_() {
  return HtmlService.createHtmlOutput(QENQ_HTML)
    .setTitle('Enquiry')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function qenqInit() {
  var cfg = qenqCfg_();
  var base = getConfigCached_();
  var open = cfg.open === true && cfg.courses.length > 0;
  if (!open) return { open: false, noCourses: cfg.open === true, businessName: base.businessName, logo: getLogoCached_() };
  return { open: true, businessName: base.businessName, logo: getLogoCached_(), courses: cfg.courses, hearOptions: cfg.hearOptions, whyOptions: cfg.whyOptions };
}

function qenqSubmit(data) {
  try {
    if (!data || typeof data !== 'object') return { ok: false, message: 'Request sahi nahi hai.' };
    if (data._hp) return { ok: true };   // honeypot: bot ko "success" dikhao, par kuch save nahi hota
    var cfg = qenqCfg_();
    if (!cfg.open) return { ok: false, message: 'Enquiry form abhi band hai.' };

    // cid = student ke phone ne banaya unique id. Net slow hone par same enquiry dobara aaye to dobara row nahi banti.
    var cid = String(data.cid == null ? '' : data.cid).replace(/[^A-Za-z0-9]/g, '').slice(0, 24);
    if (cid.length < 8) cid = '';
    if (cid && CacheService.getScriptCache().get('qenqcid_' + cid)) return { ok: true };

    var name = qenqStr_(data.name, 60);
    var phone = String(data.phone == null ? '' : data.phone).replace(/\D/g, '');
    if (phone.length === 12 && phone.indexOf('91') === 0) phone = phone.slice(2);
    var course = qenqStr_(data.course, 80);
    if (!name) return { ok: false, message: 'Apna naam likhein.' };
    if (!/^\d{10}$/.test(phone)) return { ok: false, message: 'Phone number 10 digit ka hona chahiye.' };
    if (cfg.courses.indexOf(course) < 0) return { ok: false, message: 'Ye course ab available nahi hai. Page refresh karke dobara chunein.' };

    // Optional fields: Date of Birth, Address, How Did You Hear About Us?, Why Do You Want To Learn?
    var dob = String(data.dob == null ? '' : data.dob).trim();
    if (dob) {
      var dm = /^(\d{4})-(\d{2})-(\d{2})$/.exec(dob);
      var dobMs = dm ? new Date(Number(dm[1]), Number(dm[2]) - 1, Number(dm[3])).getTime() : NaN;
      if (!dm || isNaN(dobMs) || Number(dm[1]) < 1900 || dobMs > Date.now()) return { ok: false, message: 'Date of Birth sahi nahi hai.' };
    }
    var address = qenqStr_(data.address, 200);
    var hearAbout = qenqStr_(data.hearAbout, 80);
    var whyLearn = qenqStr_(data.whyLearn, 80);
    if (hearAbout && cfg.hearOptions.indexOf(hearAbout) < 0) return { ok: false, message: 'How did you hear about us: ye option ab available nahi hai. Page refresh karke dobara chunein.' };
    if (whyLearn && cfg.whyOptions.indexOf(whyLearn) < 0) return { ok: false, message: 'Why do you want to learn: ye option ab available nahi hai. Page refresh karke dobara chunein.' };

    var cache = CacheService.getScriptCache();
    var minKey = 'qenqrate_' + Math.floor(Date.now() / 60000);
    var n = Number(cache.get(minKey) || 0);
    if (n >= QENQ_RATE_PER_MIN) return { ok: false, message: 'Abhi bahut zyada requests aa rahi hain. Thodi der baad try karein.' };
    cache.put(minKey, String(n + 1), 120);

    var pk = 'qenqph_' + phone;
    var tries = Number(cache.get(pk) || 0);
    if (tries >= QENQ_PHONE_TRIES) return { ok: false, message: 'Is number se bahut baar koshish ho chuki hai. 10 minute baad dobara try karein.' };
    cache.put(pk, String(tries + 1), 600);

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(15000)) return { ok: false, message: 'Server busy hai. Dobara try karein.' };
    try {
      var sh = qenqSheet_();
      var last = sh.getLastRow();
      if (last - 1 >= QENQ_MAX_ROWS) return { ok: false, message: 'Abhi enquiry nahi li ja sakti. Owner se sampark karein.' };

      var nowMs = Date.now();
      // Same cid pehle hi sheet me hai (cache se nikal gaya ho tab bhi) -> dobara nahi likhna
      if (cid && last >= 2) {
        var idFrom = Math.max(2, last - 59);
        var ids = sh.getRange(idFrom, 1, last - idFrom + 1, 1).getValues();
        for (var j = 0; j < ids.length; j++) { if (String(ids[j][0]) === 'QE-' + cid) return { ok: true }; }
      }
      // Double tap / dobara submit: pichli 30 rows me same number + course 10 min ke andar ho to naya row nahi banta
      if (last >= 2) {
        var from = Math.max(2, last - 29);
        var recent = sh.getRange(from, 4, last - from + 1, 4).getValues(); // TimeMs, Name, Phone, Course
        for (var i = 0; i < recent.length; i++) {
          if (String(recent[i][2]) === phone && String(recent[i][3]) === course && nowMs - Number(recent[i][0]) < QENQ_DUP_MS) {
            return { ok: true };
          }
        }
      }

      var id = cid ? ('QE-' + cid) : ('QE-' + Utilities.formatDate(new Date(nowMs), TZ, 'yyMMddHHmmss') + '-' + Math.floor(1000 + Math.random() * 9000));
      var stamp = Utilities.formatDate(new Date(nowMs), TZ, "yyyy-MM-dd'T'HH:mm:ss");
      var seq = qenqNextSeq_();
      sh.appendRow([id, seq, stamp, nowMs, name, phone, course, QENQ_SOURCE, dob, address, hearAbout, whyLearn]);
      if (cid) { try { CacheService.getScriptCache().put('qenqcid_' + cid, '1', 21600); } catch (x) {} }
      return { ok: true };
    } finally {
      try { lock.releaseLock(); } catch (x) {}
    }
  } catch (err) {
    return { ok: false, message: 'Kuch gadbad ho gayi. Dobara try karein.' };
  } finally {
    qenqMaybeCleanup_();
  }
}

/* ---------------------------------------------------------
 *  CMS ACTIONS  (ADMIN_KEY ke saath - doGet / doPost me pehle hi check ho chuka hota hai)
 * --------------------------------------------------------- */
function qenqGet_(p) {
  if (p.action === 'qenq_version') return { success: true, ver: qenqVer_() };
  if (p.action === 'qenq_list') return qenqList_(Number(p.since) || 0);
  return { success: false, error: 'unknown action' };
}

function qenqPost_(body) {
  if (body.action === 'qenq_config') return qenqSaveConfig_(body);
  return { success: false, error: 'unknown action' };
}

// DOB sheet me text ('YYYY-MM-DD') hi rehta hai; agar kabhi Date ban gayi ho to bhi wapas same format me
function qenqDobStr_(v) {
  if (!v) return '';
  if (Object.prototype.toString.call(v) === '[object Date]') return Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  return String(v).slice(0, 10);
}

// "since" ke baad ki sirf nayi rows (seq ke hisaab se, purani pehle)
function qenqList_(since) {
  if (qenqVer_() === since) return { success: true, ver: since, items: [], more: false }; // kuch naya nahi: sheet padhe bina turant jawab
  var sh = qenqSheet_();
  var last = sh.getLastRow();
  var items = [];
  var more = false;
  if (last >= 2) {
    var rows = sh.getRange(2, 1, last - 1, QENQ_HEADERS.length).getValues();
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      var seq = Number(r[1]) || 0;
      if (seq <= since) continue;
      items.push({
        id: String(r[0]), seq: seq, ms: Number(r[3]) || 0,
        name: String(r[4]), phone: String(r[5]), course: String(r[6]), source: String(r[7] || QENQ_SOURCE),
        dob: qenqDobStr_(r[8]), address: String(r[9] || ''), hearAbout: String(r[10] || ''), whyLearn: String(r[11] || '')
      });
    }
    items.sort(function (a, b) { return a.seq - b.seq; });
    if (items.length > QENQ_LIST_MAX) { items = items.slice(0, QENQ_LIST_MAX); more = true; }
  }
  return { success: true, ver: qenqVer_(), items: items, more: more };
}

/* ---------------------------------------------------------
 *  7 DIN BAAD AUTO DELETE (sirf Google Sheet se; CMS ka data nahi chhuta)
 *  Roz raat attendance ki safai ke saath chalta hai (cleanupOldAttendance_ isse bulata hai).
 *  Timer na bhi ho to din ki pehli enquiry ke saath bhi safai ho jati hai.
 * --------------------------------------------------------- */
function qenqCleanup_() {
  var sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(SHEET_QENQ);
  if (!sh || sh.getLastRow() < 2) return 0;
  var cutoff = Date.now() - KEEP_DAYS * 86400000;
  var last = sh.getLastRow();
  var times = sh.getRange(2, 4, last - 1, 1).getValues();
  var removed = 0;
  // rows time ke hisaab se upar se neeche chalti hain, isliye purani rows hamesha upar milti hain
  var start = -1, runs = [];
  for (var i = 0; i < times.length; i++) {
    var old = Number(times[i][0]) > 0 && Number(times[i][0]) < cutoff;
    if (old && start < 0) start = i;
    if (!old && start >= 0) { runs.push([start, i - 1]); start = -1; }
  }
  if (start >= 0) runs.push([start, times.length - 1]);
  for (var r = runs.length - 1; r >= 0; r--) {
    var count = runs[r][1] - runs[r][0] + 1;
    // Sheet me kam se kam ek non-frozen row bachni chahiye, warna delete fail ho jata hai
    if (sh.getMaxRows() - count < 2) sh.insertRowsAfter(sh.getMaxRows(), 50);
    sh.deleteRows(runs[r][0] + 2, count);
    removed += count;
  }
  return removed;
}

function qenqMaybeCleanup_() {
  try {
    var day = today_();
    if (getProp_('qenqCleanDay', 'x') === day) return;
    setProp_('qenqCleanDay', day);
    qenqCleanup_();
  } catch (e) {}
}

/* ---------------------------------------------------------
 *  SIRF TEST KE LIYE (CMS jodne se pehle page check karna ho to)
 *  Function list se qenqTestSetup chuno -> Run. Phir <web app url>?page=enquiry kholo.
 *  CMS jab apna config bhejta hai to ye test config apne aap badal jata hai.
 * --------------------------------------------------------- */
function qenqTestSetup() {
  qenqSaveConfig_({ open: true, courses: ['Dance', 'Zumba', 'Fitness'], hearOptions: ['Instagram', 'Friend / Reference'], whyOptions: ['Hobby', 'Fitness', 'Career'] });
  return 'OK - ab ?page=enquiry kholo';
}
