// Enquiry section — shared logic: types, option lists (Course / Query Source),
// editable WhatsApp message templates, and helpers.
// Everything the admin can change (courses, sources, messages) is saved in the
// normal settings store, so it is included in the JSON backup automatically.

import { getSetting, saveSetting, getAllCategories, getAllEnquiries, deleteEnquiry } from './indexedDB';

export type EnquiryStatus = 'interested' | 'not_interested' | 'immediately';

export interface Enquiry {
  id: string;
  name: string;
  phone: string;
  course: string;
  source: string;
  status: EnquiryStatus;
  followUpDate?: string;   // 'YYYY-MM-DD' (optional)
  followUpNote?: string;   // optional
  followUpDone?: boolean;  // legacy flag (old "Done" button) - treated as no longer pending
  converted?: 'demo' | 'admission'; // set when the admin presses "Converted" in Follow-Up
  convertedAt?: string;    // ISO - when it was marked converted
  admissionAt?: string;    // ISO - when it became "admission" (starts the 5-day auto-delete)
  createdAt: string;       // ISO
  fromQr?: boolean;        // came from the QR Enquiry form (student filled it in the office)
  qrPending?: boolean;     // still waiting in the QR Enquiry tab (cleared by Switch to Follow-Up / Convert)
  dob?: string;            // 'YYYY-MM-DD' (optional) - Date of Birth
  address?: string;        // optional
  hearAbout?: string;      // optional - "How Did You Hear About Us?" (list: Settings -> Enquiry Settings)
  whyLearn?: string;       // optional - "Why Do You Want To Learn?" (list: Settings -> Enquiry Settings)
}

// Admission enquiries are removed automatically this many days after they became "admission"
export const ADMISSION_KEEP_DAYS = 5;

// In the Follow-Up section = has a follow-up date, not removed/finished, and not converted
export const isPendingFollowUp = (e: Enquiry) => !!e.followUpDate && !e.followUpDone && !e.converted;

export const daysLeftToDelete = (e: Enquiry): number => {
  if (e.converted !== 'admission' || !e.admissionAt) return ADMISSION_KEEP_DAYS;
  const elapsed = (Date.now() - new Date(e.admissionAt).getTime()) / 86400000;
  return Math.max(0, Math.ceil(ADMISSION_KEEP_DAYS - elapsed));
};

// Deletes admission enquiries older than ADMISSION_KEEP_DAYS. Returns the remaining list.
export async function purgeExpiredEnquiries(): Promise<Enquiry[]> {
  const all: Enquiry[] = (await getAllEnquiries()) || [];
  const keep: Enquiry[] = [];
  for (const e of all) {
    const expired = e.converted === 'admission' && !!e.admissionAt &&
      Date.now() - new Date(e.admissionAt).getTime() >= ADMISSION_KEEP_DAYS * 86400000;
    if (expired) { try { await deleteEnquiry(e.id); } catch { keep.push(e); } }
    else keep.push(e);
  }
  return keep;
}

// "Save karte hi WhatsApp message bhejo" tick - stays exactly as the admin left it (default: OFF)
const SEND_WA_KEY = 'enquirySendWhatsApp';
export async function getSendWhatsApp(): Promise<boolean> {
  return (await getSetting(SEND_WA_KEY)) === true;
}
export const saveSendWhatsApp = (v: boolean) => saveSetting(SEND_WA_KEY, v);

export const STATUS_OPTIONS: { value: EnquiryStatus; label: string; short: string; chip: string }[] = [
  { value: 'interested', label: '🟢 Interested', short: 'Interested', chip: 'bg-green-100 text-green-800' },
  { value: 'immediately', label: '⚡ Immediately', short: 'Immediately', chip: 'bg-orange-100 text-orange-800' },
  { value: 'not_interested', label: '🔴 Not Interested', short: 'Not Interested', chip: 'bg-red-100 text-red-800' },
];

export const statusInfo = (status: string) =>
  STATUS_OPTIONS.find((s) => s.value === status) || STATUS_OPTIONS[0];

// ---------------------------------------------------------------------------
// Course / Query Source lists (Settings -> Enquiry Settings)
// ---------------------------------------------------------------------------
const COURSES_KEY = 'enquiryCourses';
const SOURCES_KEY = 'enquirySources';

export const DEFAULT_SOURCES = ['Call', 'Office Visit', 'Instagram', 'Facebook', 'Reference', 'Walk-in', 'Other'];

export async function getEnquiryCourses(): Promise<string[]> {
  const saved = await getSetting(COURSES_KEY);
  if (Array.isArray(saved)) return saved;
  // First time: start from the Categories the admin already created (they can edit freely after)
  try {
    const cats = await getAllCategories();
    const names = (cats || []).map((c: any) => String(c.name || '').trim()).filter(Boolean);
    return Array.from(new Set(names));
  } catch {
    return [];
  }
}
// Fired when the admin changes the course list, so the QR Enquiry form (Google Sheet) gets the new list too
export const ENQUIRY_COURSES_EVENT = 'enquiryCoursesUpdated';
export const saveEnquiryCourses = async (list: string[]) => {
  await saveSetting(COURSES_KEY, list);
  window.dispatchEvent(new CustomEvent(ENQUIRY_COURSES_EVENT));
};

export async function getEnquirySources(): Promise<string[]> {
  const saved = await getSetting(SOURCES_KEY);
  return Array.isArray(saved) ? saved : DEFAULT_SOURCES;
}
export const saveEnquirySources = (list: string[]) => saveSetting(SOURCES_KEY, list);

// "How Did You Hear About Us?" and "Why Do You Want To Learn?" dropdown lists (Settings -> Enquiry Settings).
// Same lists are shown in the manual Add Enquiry form and in the QR Enquiry form.
const HEAR_KEY = 'enquiryHearAbout';
const WHY_KEY = 'enquiryWhyLearn';
export const DEFAULT_HEAR_ABOUT = ['Instagram', 'Facebook', 'Google Search', 'Friend / Reference', 'Banner / Hoarding', 'Walk-in', 'Other'];
export const DEFAULT_WHY_LEARN = ['Hobby', 'Fitness', 'Career', 'Stage Performance', 'Stress Relief', 'Other'];

export async function getEnquiryHearAbout(): Promise<string[]> {
  const saved = await getSetting(HEAR_KEY);
  return Array.isArray(saved) ? saved : DEFAULT_HEAR_ABOUT;
}
export const saveEnquiryHearAbout = async (list: string[]) => {
  await saveSetting(HEAR_KEY, list);
  window.dispatchEvent(new CustomEvent(ENQUIRY_COURSES_EVENT)); // QR form (Google Sheet) ko bhi nayi list mil jaye
};

export async function getEnquiryWhyLearn(): Promise<string[]> {
  const saved = await getSetting(WHY_KEY);
  return Array.isArray(saved) ? saved : DEFAULT_WHY_LEARN;
}
export const saveEnquiryWhyLearn = async (list: string[]) => {
  await saveSetting(WHY_KEY, list);
  window.dispatchEvent(new CustomEvent(ENQUIRY_COURSES_EVENT));
};

// ---------------------------------------------------------------------------
// WhatsApp message templates (editable in Campaign -> Enquiry Messages)
// ---------------------------------------------------------------------------
export type EnquiryTemplateKind = 'add' | 'list' | 'followup' | 'qr';

const TEMPLATE_KEYS: Record<EnquiryTemplateKind, string> = {
  add: 'enquiryAddTemplate',
  list: 'enquiryListTemplate',
  followup: 'enquiryFollowUpTemplate',
  qr: 'enquiryQrTemplate',
};

export const DEFAULT_ENQUIRY_TEMPLATES: Record<EnquiryTemplateKind, string> = {
  add:
`Hello {{studentName}},
Thank you for your enquiry about {{course}} classes at {{studioName}}.
Please reply or call us to confirm your seat.`,
  list:
`Hello {{studentName}},
Your seat is on hold and may be released within 24 hours.
Please reply to confirm.`,
  followup:
`Hello {{studentName}},
Regarding your enquiry for {{course}} classes.
Please confirm today - reply or call us.`,
  qr:
`Hello {{studentName}},
Thank you for visiting {{studioName}} and showing interest in {{course}} classes.
Our team will share the batch timings and fees with you. Please reply here if you have any questions.`,
};

export const ENQUIRY_PLACEHOLDERS = ['{{studentName}}', '{{course}}', '{{studioName}}'];

export async function getEnquiryTemplate(kind: EnquiryTemplateKind): Promise<string> {
  const saved = await getSetting(TEMPLATE_KEYS[kind]);
  return saved || DEFAULT_ENQUIRY_TEMPLATES[kind];
}
export const saveEnquiryTemplate = (kind: EnquiryTemplateKind, text: string) =>
  saveSetting(TEMPLATE_KEYS[kind], text);

export async function buildEnquiryMessage(kind: EnquiryTemplateKind, enquiry: Pick<Enquiry, 'name' | 'course'>, studioName: string): Promise<string> {
  const template = await getEnquiryTemplate(kind);
  const values: Record<string, string> = {
    studentName: enquiry.name || '',
    course: enquiry.course || '',
    studioName: studioName || '',
  };
  let out = template;
  Object.entries(values).forEach(([k, v]) => { out = out.split(`{{${k}}}`).join(v); });
  return out;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
// Returns a clean 10-digit number, or '' if it isn't valid
export function normalizePhone(input: string): string {
  let digits = String(input || '').replace(/\D/g, '');
  if (digits.length === 12 && digits.startsWith('91')) digits = digits.slice(2);
  if (digits.length === 11 && digits.startsWith('0')) digits = digits.slice(1);
  return /^\d{10}$/.test(digits) ? digits : '';
}

export function openWhatsApp(phone: string, text: string) {
  const clean = normalizePhone(phone);
  if (!clean) return false;
  window.open(`https://wa.me/91${clean}?text=${encodeURIComponent(text)}`, '_blank');
  return true;
}

// Local-date helpers ('YYYY-MM-DD'), so "today" matches the admin's own calendar day
export const toDateStr = (d: Date) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
export const todayStr = () => toDateStr(new Date());
export const addDaysStr = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return toDateStr(d);
};

export const formatDateTime = (iso: string) => {
  if (!iso) return '';
  const d = new Date(iso);
  if (isNaN(d.getTime())) return '';
  const date = d.toLocaleDateString('en-GB');
  const time = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit', hour12: false });
  return `${date} ${time}`;
};

export const formatDateOnly = (dateStr: string) => {
  if (!dateStr) return '';
  const d = new Date(dateStr + 'T00:00:00');
  return isNaN(d.getTime()) ? dateStr : d.toLocaleDateString('en-GB');
};

// ---------------------------------------------------------------------------
// Repeat enquiries (same Name + same Phone as an earlier enquiry)
// The newer enquiry is still saved as usual - it only gets a warning + "View Old Details".
// Nothing extra is stored: this is worked out from the enquiries already in local storage.
// ---------------------------------------------------------------------------
const nameKey = (v?: string) => (v || '').trim().toLowerCase().replace(/\s+/g, ' ');
const repeatKey = (e: Enquiry) => {
  const phone = normalizePhone(e.phone);
  const name = nameKey(e.name);
  return phone && name ? `${phone}|${name}` : '';
};

export const REPEAT_WARNING = 'Warning: this user has enquired before.';

/** Map of enquiry id -> earlier enquiries (newest first) with the same name + phone. Only repeat enquiries get an entry. */
export function buildRepeatMap(all: Enquiry[]): Map<string, Enquiry[]> {
  const groups = new Map<string, Enquiry[]>();
  for (const e of all) {
    const k = repeatKey(e);
    if (!k) continue;
    const g = groups.get(k);
    if (g) g.push(e); else groups.set(k, [e]);
  }
  const out = new Map<string, Enquiry[]>();
  groups.forEach((g) => {
    if (g.length < 2) return;
    g.sort((a, b) => (a.createdAt || '').localeCompare(b.createdAt || '') || a.id.localeCompare(b.id));
    for (let i = 1; i < g.length; i++) out.set(g[i].id, g.slice(0, i).reverse());
  });
  return out;
}

/** Which section of the Enquiry page an enquiry is sitting in right now */
export function enquirySection(e: Enquiry, qrOn: boolean): { label: string; cls: string } {
  if (e.converted === 'admission') return { label: 'Converted → Admission', cls: 'bg-green-100 text-green-800' };
  if (e.converted === 'demo') return { label: 'Converted → Demo', cls: 'bg-blue-100 text-blue-800' };
  if (isPendingFollowUp(e)) return { label: 'Follow-Up', cls: 'bg-purple-100 text-purple-800' };
  if (qrOn && e.qrPending) return { label: 'QR Enquiry', cls: 'bg-orange-100 text-orange-800' };
  return { label: 'Enquiry List', cls: 'bg-gray-100 text-gray-800' };
}
