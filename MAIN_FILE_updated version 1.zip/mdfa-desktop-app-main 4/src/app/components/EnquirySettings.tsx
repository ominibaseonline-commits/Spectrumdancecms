import { useState, useEffect, type ReactNode } from 'react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { toast } from 'sonner';
import { Plus, X, BookOpen, Share2, Info, Megaphone, HelpCircle } from 'lucide-react';
import { QrEnquirySettings } from './QrEnquirySettings';
import {
  getEnquiryCourses, saveEnquiryCourses, getEnquirySources, saveEnquirySources, DEFAULT_SOURCES,
  getEnquiryHearAbout, saveEnquiryHearAbout, DEFAULT_HEAR_ABOUT,
  getEnquiryWhyLearn, saveEnquiryWhyLearn, DEFAULT_WHY_LEARN,
} from '../lib/enquiries';

// Settings -> Enquiry Settings
// The admin builds the "Select Course" and "Query Source" dropdown lists used in
// the Enquiry section. Changes are saved instantly and show up in the Add Enquiry form.
export function EnquirySettings() {
  const [courses, setCourses] = useState<string[]>([]);
  const [sources, setSources] = useState<string[]>([]);
  const [hearList, setHearList] = useState<string[]>([]);
  const [whyList, setWhyList] = useState<string[]>([]);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    Promise.all([getEnquiryCourses(), getEnquirySources(), getEnquiryHearAbout(), getEnquiryWhyLearn()]).then(([c, s, h, w]) => {
      setCourses(c);
      setSources(s);
      setHearList(h);
      setWhyList(w);
      setLoaded(true);
    });
  }, []);

  if (!loaded) return <p className="text-sm text-gray-500">Loading...</p>;

  return (
    <div className="space-y-6">
      <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
        <h3 className="flex items-center gap-2 mb-2"><Info className="w-5 h-5 text-orange-600" /> Enquiry Settings</h3>
        <p className="text-sm text-gray-600">
          Courses (Interested For), "How Did You Hear About Us?" and "Why Do You Want To Learn?" options added here appear in <strong>Enquiry → Add Enquiry</strong> and in the <strong>QR Enquiry</strong> form. Deleting one does not change old enquiries. Edit WhatsApp messages in <strong>Campaign → Enquiry Messages</strong>.
        </p>
      </Card>

      <ListEditor
        icon={<BookOpen className="w-5 h-5 text-orange-600" />}
        title="Courses (Interested For)"
        items={courses}
        placeholder="e.g. Dance, Zumba, Fitness..."
        emptyText="Abhi koi course nahi hai. Upar se add karein."
        onChange={async (list) => { setCourses(list); await saveEnquiryCourses(list); }}
      />

      <ListEditor
        icon={<Megaphone className="w-5 h-5 text-orange-600" />}
        title="How Did You Hear About Us? (dropdown)"
        items={hearList}
        placeholder="e.g. Instagram, Friend, Banner..."
        emptyText="Abhi koi option nahi hai. Khaali rakhne par ye dropdown QR form me nahi dikhega."
        onChange={async (list) => { setHearList(list); await saveEnquiryHearAbout(list); }}
        resetLabel="Default list laao"
        onReset={async () => { setHearList(DEFAULT_HEAR_ABOUT); await saveEnquiryHearAbout(DEFAULT_HEAR_ABOUT); toast.success('Default options set ho gaye'); }}
      />

      <ListEditor
        icon={<HelpCircle className="w-5 h-5 text-orange-600" />}
        title="Why Do You Want To Learn? (dropdown)"
        items={whyList}
        placeholder="e.g. Hobby, Fitness, Career..."
        emptyText="Abhi koi option nahi hai. Khaali rakhne par ye dropdown QR form me nahi dikhega."
        onChange={async (list) => { setWhyList(list); await saveEnquiryWhyLearn(list); }}
        resetLabel="Default list laao"
        onReset={async () => { setWhyList(DEFAULT_WHY_LEARN); await saveEnquiryWhyLearn(DEFAULT_WHY_LEARN); toast.success('Default options set ho gaye'); }}
      />

      {/* QR Enquiry: ON/OFF + QR / link (same Google script jo Management & Setup me hai) */}
      <QrEnquirySettings />

    </div>
  );
}

function ListEditor({ icon, title, items, placeholder, emptyText, onChange, resetLabel, onReset }: {
  icon: ReactNode; title: string; items: string[]; placeholder: string; emptyText: string;
  onChange: (list: string[]) => Promise<void>;
  resetLabel?: string; onReset?: () => Promise<void>;
}) {
  const [value, setValue] = useState('');

  const add = async () => {
    const v = value.trim();
    if (!v) return;
    if (items.some((i) => i.toLowerCase() === v.toLowerCase())) {
      toast.error(`"${v}" pehle se list me hai!`);
      return;
    }
    await onChange([...items, v]);
    setValue('');
    toast.success(`"${v}" add ho gaya`);
  };

  const remove = async (item: string) => {
    await onChange(items.filter((i) => i !== item));
    toast.success(`"${item}" hata diya`);
  };

  return (
    <div className="bg-white rounded-lg border p-4 space-y-3">
      <div className="flex items-center justify-between gap-2">
        <h4 className="flex items-center gap-2">{icon} {title}</h4>
        {onReset && <Button size="sm" variant="outline" onClick={onReset}>{resetLabel}</Button>}
      </div>
      <div className="flex gap-2">
        <Input
          value={value}
          placeholder={placeholder}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); add(); } }}
        />
        <Button onClick={add} className="bg-orange-500 hover:bg-orange-600 text-white whitespace-nowrap">
          <Plus className="w-4 h-4 mr-1" /> Add
        </Button>
      </div>
      {items.length === 0 ? (
        <p className="text-sm text-gray-500">{emptyText}</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {items.map((item) => (
            <span key={item} className="inline-flex items-center gap-1.5 bg-orange-50 border border-orange-200 text-orange-800 rounded-full pl-3 pr-1.5 py-1 text-sm">
              {item}
              <button type="button" onClick={() => remove(item)} title="Delete" className="rounded-full hover:bg-orange-200 p-0.5">
                <X className="w-3.5 h-3.5" />
              </button>
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
