# 🚀 Quick Start - Google Sheet License System

## ✅ **System Status: FULLY IMPLEMENTED**

---

## 📋 **Quick Reference**

### **Google Apps Script API**
```
URL: https://script.google.com/macros/s/AKfycbzmqyeF0io_3tVYX0lEC6dTYYEZxPZplGLYiO9_l1n-l8yRvGOgiXj8F8PzOvxW_PI6yA/exec

Action: verify_license
Parameters: key, domain
```

### **License Key Format**
```
Valid: AMS-XXXX-XXXX-XXXX
Valid: MDA-XXXX-XXXX
Example: AMS-PZALUFX-C7ZN
```

---

## 👨‍💼 **For Admin (You)**

### **Add New Customer:**

1. Open Google Sheet
2. Add new row:
   ```
   License Key: AMS-NEW1-2025-JUNE
   Business: Customer Name
   Expiry Date: 2025-07-03 (1 month from now)
   Status: active
   ```
3. Send license key to customer via WhatsApp/Email
4. Done! Customer will activate

### **Renew License:**

1. Customer pays ₹500
2. Open Google Sheet
3. Find customer's row
4. Update: Expiry Date = +30 days
5. Done! Auto-extends within 30 min

### **Suspend License:**

1. Open Google Sheet
2. Find customer's row  
3. Change: Status = "revoked"
4. Done! System locks on next sync

---

## 👤 **For Customer**

### **First Time Setup:**

1. Open app
2. See "Enter License Key" screen
3. Type license key (get from admin)
4. Click "Activate License"
5. Login and use!

### **Monthly Renewal:**

1. Pay monthly fee to admin
2. Wait 30 minutes
3. System auto-extends
4. Continue working!

---

## 🔧 **Common Tasks**

### **Check License Status:**
```
Open app → Login page
See license badge: "🔑 X days"
```

### **Test License:**
```
1. Add test entry in Google Sheet:
   License: AMS-TEST-1234-TEST
   Expiry: Tomorrow's date
   Status: active

2. Open app
3. Enter: AMS-TEST-1234-TEST
4. Should activate!
```

### **Bulk Extend (+15 days):**
```
Google Sheet Formula:
=F2+15
(Where F is Expiry Date column)

Copy formula down, paste values
```

---

## ⚡ **Files Modified**

```
✅ /src/app/lib/googleSheetLicense.ts (NEW)
✅ /src/app/components/LicenseKeyInput.tsx (NEW)
✅ /src/app/App.tsx (MODIFIED)
✅ /src/app/components/LoginPage.tsx (MODIFIED)
```

---

## 🎯 **How It Works**

```
User opens app
    ↓
Checks for license key
    ↓
If NOT found → Show license input
If found → Validate from Google Sheet
    ↓
If Valid → Show login page
If Expired → Lock system
    ↓
Auto-validates every 30 min
```

---

## 📞 **Customer Support Template**

```
🎉 Your License Key

License: [KEY]
Valid Until: [DATE]
Business: [NAME]

Setup:
1. Open app
2. Enter license key above
3. Click "Activate"
4. Done!

Help: [Your Number]
```

---

## 🚨 **Emergency Commands**

### **Force Revalidation:**
```
Customer: Clear browser cache + reload
Or: Re-enter license key
```

### **Reset License Data:**
```javascript
// In browser console:
localStorage.clear();
location.reload();
```

---

## ✨ **Key Features**

✅ Remote license management
✅ Auto-sync every 30 minutes  
✅ Offline support (7 days)
✅ No manual visits needed
✅ Instant activation
✅ Automatic renewal
✅ Bulk operations
✅ Domain locking (optional)

---

**Need detailed guide?** → See `GOOGLE_SHEET_LICENSE_SETUP.md`

**System is LIVE! 🚀**
