# Spectrum — Online Admission (mail + automatic ID card)

## Kya badla
- **Online form ka design** ab Spectrum jaisa hai (banner header, purple/gold sections, rules popup, camera/gallery photo).
  Form ke columns phir bhi **CMS ke Admission Form Layout** se aate hain: jo column CMS me ON hai wahi form me, mail me aur PDF me aata hai.
  **Registration No. form / ID card / mail me nahi hota** (wo CMS me approve karte time banta hai, jaise pehle).
- **Submit karte hi**: student ka **ID card apne aap ban jata hai** (front + back), photo Google Drive me jati hai,
  request CMS ke **Online Admission** me aa jati hai.
- **Mail**: student ko (form PDF + ID card) aur admin ko (same PDF + alert). Header = Spectrum banner.
- **Approve** par pura data (aur photo) Admission Form me bhar jata hai, baaki sab pehle jaisa.
- Payment wala page isme **nahi** joda gaya.

## Setup (ek baar)
1. CMS → Settings → Online Admission → **Email Settings**: Student/Admin mail ON, **Admin Email** likho → Save.
2. CMS → Attendance Setup me dikha hua **naya code** poora copy karke Apps Script me paste karo (purana hata ke).
3. Apps Script me function list se **`admAuthorize`** chuno → **Run** → Mail aur Drive ki permission **Allow** karo.
4. Deploy → Manage deployments → Edit (pencil) → Version: **New version** → Deploy. (Link wahi rahega.)
5. CMS me **Test mail bhejein** dabao. Admin email par banner wala sample mail + PDF aana chahiye.
6. Online Admission ON karke link/QR kholo aur ek test admission karo.

## Dhyan rakhne ki baatein
- Mail us Google account se jati hai jisse script deploy hui hai. Free Gmail: ~100 mail/din, Workspace: ~1500/din.
  Dono mail (student + admin) ginti me aate hain: ek admission = 2 mail.
- Student ko mail tabhi jati hai jab **Student ko mail bhejein = ON**. Tab online form me **Email zaroori** ho jata hai
  (layout me Email hidden ho tab bhi).
- Spam rokne ke liye: ek email par ghante me max 2 mail, honeypot, rate limit.
- Admin Approve karne se pehle hi student ko ID card mil jata hai (aur reject karne par bhi uske paas rehta hai).
- Naye columns jodne ke liye bas CMS ke Admission Form Layout me column ON karo; form, mail, PDF apne aap update ho jate hain
  (Online Admission settings me "Form update karein" dabana ho sakta hai).
- Banner / ID card images badalni ho to `src/app/lib/assets/admTheme.ts` me; ID card ka design/address/phone
  `src/app/lib/onlineAdmissionPage.html` ke `idcardFront` / `idcardBack` me.

## Files
- `src/app/lib/onlineAdmissionPage.html` — public form + ID card
- `src/app/lib/onlineAdmissionScript.gs` — Apps Script (save, Drive photo, mail, PDF, test mail)
- `src/app/lib/assets/admTheme.ts` — Spectrum banner/ID card images
- `src/app/lib/onlineAdmission.ts`, `attendance.ts` — config (photo + mail), theme jodna
- `src/app/components/OnlineAdmissionSettings.tsx` (mail settings), `OnlineAdmissionRequests.tsx`, `OfflineAdmission.tsx` (photo auto-fill)

## Payment receipt mail + Discount / Dues Date + 5-digit Reg No
- **Online request Approve -> Admission Form me payment bharke Save** karte hi student ko **Payment Receipt mail (PDF)** jati hai
  (Total, Extra charges, Discount %, Paid, Dues, "Pay Dues By" date, Payment Mode, non-refundable note).
  Mail tabhi jati hai jab **Student ko mail bhejein = ON** ho aur student ka email ho. Script update ke baad naya code paste + **New version Deploy** zaroori hai (`adm_receipt` action).
- **Discount** aur **Dues Date** (Payment.html jaisa): Admission Form me Discount daalo, dues bachne par "Pay Dues By" date aati hai.
  Dues = (Total + Extra Charges) - Paid - Discount. Student List me *Discount* aur *Pay Dues By* columns, Fees Management me dues date, Dashboard batch popup me bhi dikhta hai.
  Dues WhatsApp message me `{{duesDate}}` lagana ho to Campaign -> Auto Reminders -> Dues Reminder me likh sakte hain.
- **Registration No** 5 digit, serial, **26100** se shuru. Agla = Student List ka sabse bada 5-digit Reg No + 1 (deactivated bhi ginte hain, sirf *delete* hone par number wapas milta hai). Admin khud badal sakta hai (sirf 5 digit, duplicate nahi).
- Dashboard -> Today's Batch Activity -> batch par click: search bar ke neeche Batch Time, columns Reg No / Name / Mobile / Admission Date / Duration / Dues (+WhatsApp) / Expiry (expired = red).
