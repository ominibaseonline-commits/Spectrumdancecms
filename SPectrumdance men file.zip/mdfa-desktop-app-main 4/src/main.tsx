import { createRoot } from "react-dom/client";
  import App from "./app/App.tsx";
  import "./styles/index.css";
  import { initTheme } from "./app/lib/theme";

  // Desktop app me confirm()/alert() popup ka title "Ominibase CMS" ho (browser me normal popup hi chalta hai)
  const desk = (window as any).desktopApp;
  if (desk?.confirmSync) {
    window.confirm = (m?: string) => !!desk.confirmSync(m ?? '');
    window.alert = (m?: any) => { desk.alertSync(m ?? ''); };
  }

  initTheme(); // saved theme / dark mode is applied before the first screen is drawn

  createRoot(document.getElementById("root")!).render(<App />);
