import { useState } from 'react';
import { Sun, Moon, Check, ChevronUp, ChevronDown, RotateCcw } from 'lucide-react';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { toast } from 'sonner';
import {
  COLOR_THEMES,
  DASH_SECTIONS,
  DEFAULT_DASHBOARD_LAYOUT,
  DEFAULT_THEME_PREFS,
  getDashboardLayout,
  getThemePrefs,
  saveDashboardLayout,
  saveThemePrefs,
  DashboardLayout,
  DashSectionId,
  ThemeMode,
} from '../lib/theme';

/**
 * Settings -> Theme: light/dark mode, colour theme (applies to the whole CMS) and the dashboard
 * layout (which sections show and in what order). Everything applies/saves instantly.
 */
export function ThemeSettings() {
  const [prefs, setPrefs] = useState(getThemePrefs);
  const [layout, setLayout] = useState<DashboardLayout>(getDashboardLayout);

  const updatePrefs = (next: typeof prefs) => {
    setPrefs(next);
    saveThemePrefs(next);
  };

  const updateLayout = (next: DashboardLayout) => {
    setLayout(next);
    saveDashboardLayout(next);
  };

  const toggleSection = (id: DashSectionId, show: boolean) => {
    updateLayout({ ...layout, hidden: show ? layout.hidden.filter((h) => h !== id) : [...layout.hidden, id] });
  };

  const move = (id: DashSectionId, dir: -1 | 1) => {
    const i = layout.order.indexOf(id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= layout.order.length) return;
    const order = [...layout.order];
    [order[i], order[j]] = [order[j], order[i]];
    updateLayout({ ...layout, order });
  };

  const modeBtn = (mode: ThemeMode, label: string, Icon: any) => {
    const active = prefs.mode === mode;
    return (
      <button
        type="button"
        onClick={() => updatePrefs({ ...prefs, mode })}
        className={`flex-1 flex items-center justify-center gap-2 rounded-lg border-2 px-4 py-3 transition-colors ${
          active ? 'border-orange-500 bg-orange-50 text-orange-700' : 'border-gray-200 hover:bg-gray-50'
        }`}
      >
        <Icon className="w-5 h-5" />
        <span>{label}</span>
        {active && <Check className="w-4 h-4" />}
      </button>
    );
  };

  return (
    <div className="space-y-8">
      {/* Light / Dark */}
      <section className="space-y-3">
        <div>
          <h3>Mode</h3>
          <p className="text-sm text-gray-500">Dark mode poore CMS ko dark kar deta hai.</p>
        </div>
        <div className="flex gap-3 max-w-md">
          {modeBtn('light', 'Light', Sun)}
          {modeBtn('dark', 'Dark', Moon)}
        </div>
      </section>

      {/* Colour theme */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h3>Colour Theme</h3>
            <p className="text-sm text-gray-500">Chuna hua theme poore CMS mein lagta hai (sidebar, buttons, highlights, background).</p>
          </div>
          <Button variant="outline" size="sm" onClick={() => updatePrefs({ ...prefs, colorTheme: DEFAULT_THEME_PREFS.colorTheme })}>
            <RotateCcw className="w-4 h-4 mr-1" /> Default theme
          </Button>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3">
          {COLOR_THEMES.map((t) => {
            const active = prefs.colorTheme === t.id;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => updatePrefs({ ...prefs, colorTheme: t.id })}
                className={`text-left rounded-xl border-2 overflow-hidden transition-shadow hover:shadow-md ${active ? 'border-gray-900 shadow-md' : 'border-gray-200'}`}
              >
                {/* little preview of the sidebar header + page background */}
                <div style={{ backgroundColor: t.bg }} className="p-3">
                  <div style={{ backgroundColor: t.brand }} className="h-5 rounded-md" />
                  <div className="mt-2 flex gap-1.5">
                    <div className="h-6 flex-1 rounded bg-white/80" />
                    <div style={{ backgroundColor: t.brand }} className="h-6 w-6 rounded opacity-80" />
                  </div>
                </div>
                <div className="px-3 py-2 flex items-center justify-between gap-2">
                  <span className="text-sm">{t.name}</span>
                  {active && <Check className="w-4 h-4 shrink-0" />}
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Dashboard layout */}
      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3 flex-wrap">
          <div>
            <h3>Dashboard Sections</h3>
            <p className="text-sm text-gray-500">Switch se section dikhao/chhupao, aur arrow se upar-niche karo.</p>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => { updateLayout({ order: [...DEFAULT_DASHBOARD_LAYOUT.order], hidden: [] }); toast.success('Dashboard layout default par aa gaya'); }}
          >
            <RotateCcw className="w-4 h-4 mr-1" /> Default layout
          </Button>
        </div>
        <div className="rounded-xl border divide-y max-w-2xl">
          {layout.order.map((id, index) => {
            const meta = DASH_SECTIONS.find((s) => s.id === id)!;
            const shown = !layout.hidden.includes(id);
            return (
              <div key={id} className="flex items-center gap-3 px-4 py-3">
                <Switch checked={shown} onCheckedChange={(v) => toggleSection(id, !!v)} />
                <div className={`flex-1 min-w-0 ${shown ? '' : 'opacity-50'}`}>
                  <p className="leading-tight">{meta.label}</p>
                  <p className="text-xs text-gray-500">{meta.hint}</p>
                </div>
                <Button variant="outline" size="icon" disabled={index === 0} onClick={() => move(id, -1)} aria-label={`${meta.label} upar`}>
                  <ChevronUp className="w-4 h-4" />
                </Button>
                <Button variant="outline" size="icon" disabled={index === layout.order.length - 1} onClick={() => move(id, 1)} aria-label={`${meta.label} niche`}>
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>
            );
          })}
        </div>
        <p className="text-xs text-gray-500">Attendance aur Enquiry agar side-by-side (ek ke baad ek) rakhe ho to dono ek hi line mein dikhte hain.</p>
      </section>
    </div>
  );
}
