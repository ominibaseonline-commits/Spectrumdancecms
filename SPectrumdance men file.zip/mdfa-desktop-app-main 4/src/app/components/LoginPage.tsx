import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { Smartphone, Monitor, Shield, Gift, KeyRound, CheckCircle2, AlertTriangle } from 'lucide-react';
import { getAdminCredentials, getStudents } from '../lib/storageAdapter';
import { resetAdminPasswordWithLicense, DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD } from '../lib/adminReset';
import { useBusinessName } from '../contexts/BusinessContext';
import { formatExpiryDateDisplay, getDaysUntilExpiryFromDate, extractExpiryDate, isLifetimeLicense, GoogleSheetLicenseData } from '../lib/googleSheetLicense';

interface LoginPageProps {
  onLogin: (user: any, type: 'admin' | 'student') => void;
  licenseInfo?: GoogleSheetLicenseData | null;
  // Emergency only: server kisi dusri license key ka hai -> "Naya License Key Add Karo" option dikhao
  emergencyKeyOption?: boolean;
  onEmergencyNewKey?: () => void;
}

export function LoginPage({ onLogin, licenseInfo, emergencyKeyOption, onEmergencyNewKey }: LoginPageProps) {
  const { businessName } = useBusinessName();
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [studentUserId, setStudentUserId] = useState('');
  const [studentPassword, setStudentPassword] = useState('');
  const [isMobile, setIsMobile] = useState(false);
  const [defaultTab, setDefaultTab] = useState('admin');
  const [showAdminButton, setShowAdminButton] = useState(false);
  const [showForgotConfirm, setShowForgotConfirm] = useState(false);
  const [showResetSuccess, setShowResetSuccess] = useState(false);
  const [resetLicenseKey, setResetLicenseKey] = useState('');
  const [resetError, setResetError] = useState('');
  const [resetBusy, setResetBusy] = useState(false);

  useEffect(() => {
    // Detect if device is mobile
    const checkDevice = () => {
      const userAgent = navigator.userAgent.toLowerCase();
      const mobileKeywords = ['android', 'iphone', 'ipad', 'ipod', 'mobile', 'ios'];
      const isMobileDevice = mobileKeywords.some(keyword => userAgent.includes(keyword));
      
      setIsMobile(isMobileDevice);
      setDefaultTab(isMobileDevice ? 'student' : 'admin');
      setShowAdminButton(isMobileDevice);
    };

    checkDevice();
  }, []);

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get admin credentials using storage adapter
    const adminCreds = await getAdminCredentials();

    if (adminEmail === adminCreds.email && adminPassword === adminCreds.password) {
      toast.success('Admin Login Successful!');
      onLogin({ email: adminEmail, type: 'admin' }, 'admin');
    } else {
      toast.error('Invalid Admin Credentials!');
    }
  };

  // "Forgot Password" — license key daalni padti hai. Key sahi hone par hi
  // admin email/password default (admin@1234 / admin@1234) par reset hota hai
  // (Supabase me bhi), aur baaki saare logged-in devices apne aap logout ho jate hain.
  // Students, payments, batches wagairah ka data touch nahi hota.
  const openForgot = () => {
    setResetLicenseKey('');
    setResetError('');
    setShowForgotConfirm(true);
  };

  const handleResetPassword = async () => {
    setResetError('');
    setResetBusy(true);
    try {
      const result = await resetAdminPasswordWithLicense(resetLicenseKey);
      if (!result.ok) {
        setResetError(result.message);
        return;
      }
      setShowForgotConfirm(false);
      setResetLicenseKey('');
      setShowResetSuccess(true);
    } finally {
      setResetBusy(false);
    }
  };

  const handleStudentLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Get students using storage adapter
    const students = await getStudents();
    
    // Check with userId/password OR email/password
    const student = students.find((s: any) => {
      const matchesUserId = s.userId === studentUserId && s.password === studentPassword;
      const matchesEmail = s.email === studentUserId && s.password === studentPassword;
      const matchesMobile = s.mobile === studentUserId && s.password === studentPassword;
      
      return (matchesUserId || matchesEmail || matchesMobile) && s.status !== 'blocked';
    });

    if (student) {
      toast.success('Student Login Successful!');
      onLogin(student, 'student');
    } else {
      toast.error('Invalid Credentials or Account Blocked!');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ backgroundColor: 'var(--app-bg)' }}>
      <div className="w-full max-w-md">
        <div className="text-center mb-8" style={{ backgroundColor: 'var(--brand)', padding: '24px', borderRadius: '8px' }}>
          <h1 className="text-white">{businessName}</h1>
          {isMobile && (
            <div className="mt-2 flex items-center justify-center gap-2 text-white text-sm">
              <Smartphone className="w-4 h-4" />
              <span>Mobile Device Detected</span>
            </div>
          )}
        </div>

        {/* License Info Display */}
        {licenseInfo && licenseInfo.success && (() => {
          const isDemo = (licenseInfo.plan || '').toLowerCase() === 'demo';

          // Demo licenses: show a "Demo" badge PLUS expiry date + days remaining,
          // so the user knows exactly how many days are left before the demo locks.
          if (isDemo) {
            const demoExpiryStr = extractExpiryDate(licenseInfo);
            const demoDaysLeft = demoExpiryStr ? getDaysUntilExpiryFromDate(demoExpiryStr) : 0;
            return (
              <div className={`mb-4 p-3 rounded-lg border text-sm ${
                demoDaysLeft <= 2 ? 'bg-orange-50 border-orange-300' : 'bg-blue-50 border-blue-300'
              }`}>
                <div className="flex items-center gap-2 mb-2">
                  <Shield className={`w-4 h-4 ${demoDaysLeft <= 2 ? 'text-orange-600' : 'text-blue-600'}`} />
                  <span className="font-semibold">License Status</span>
                </div>
                <div className="space-y-1 text-xs">
                  {licenseInfo.business_name && (
                    <div className="flex justify-between">
                      <span>Business:</span>
                      <span className="font-semibold">{licenseInfo.business_name}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Plan:</span>
                    <span className="font-semibold text-blue-700 flex items-center gap-1"><Gift className="h-3.5 w-3.5" /> Demo</span>
                  </div>
                  {demoExpiryStr && (
                    <div className="flex justify-between">
                      <span>Demo Valid Till:</span>
                      <span className="font-semibold">{formatExpiryDateDisplay(demoExpiryStr)}</span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span>Days Remaining:</span>
                    <span className={`font-semibold ${demoDaysLeft <= 2 ? 'text-orange-600' : 'text-blue-700'}`}>
                      {demoDaysLeft > 0 ? `${demoDaysLeft} din` : 'Expired'}
                    </span>
                  </div>
                </div>
              </div>
            );
          }

          const expiryStr = extractExpiryDate(licenseInfo);
          const lifetime = isLifetimeLicense(licenseInfo);
          const daysLeft = lifetime ? 99999 : (expiryStr ? getDaysUntilExpiryFromDate(expiryStr) : 0);
          return (
          <div className={`mb-4 p-3 rounded-lg border text-sm ${
            daysLeft <= 7 ? 'bg-orange-50 border-orange-300' : 'bg-green-50 border-green-300'
          }`}>
            <div className="flex items-center gap-2 mb-2">
              <Shield className={`w-4 h-4 ${daysLeft <= 7 ? 'text-orange-600' : 'text-green-600'}`} />
              <span className="font-semibold">License Status</span>
            </div>
            <div className="space-y-1 text-xs">
              {licenseInfo.business_name && (
                <div className="flex justify-between">
                  <span>Business:</span>
                  <span className="font-semibold">{licenseInfo.business_name}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span>Expires:</span>
                <span className="font-semibold">{lifetime ? 'Lifetime' : formatExpiryDateDisplay(expiryStr)}</span>
              </div>
              <div className="flex justify-between">
                <span>Days Remaining:</span>
                <span className={`font-semibold ${daysLeft <= 7 ? 'text-orange-600' : 'text-green-600'}`}>
                  {lifetime ? 'Unlimited' : (expiryStr ? `${Math.max(daysLeft, 0)} days` : 'N/A')}
                </span>
              </div>
            </div>
          </div>
          );
        })()}
        
        <Card>
          <CardHeader>
            <CardTitle>Login</CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAdminLogin} className="space-y-4">
              <div>
                <Label htmlFor="admin-email">Email</Label>
                <Input
                  id="admin-email"
                  type="email"
                  placeholder="Enter admin email"
                  value={adminEmail}
                  onChange={(e) => setAdminEmail(e.target.value)}
                  required
                />
              </div>
              <div>
                <Label htmlFor="admin-password">Password</Label>
                <Input
                  id="admin-password"
                  type="password"
                  placeholder="Enter password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  required
                />
              </div>
              <Button type="submit" className="w-full">Login as Admin</Button>
              <button
                type="button"
                onClick={openForgot}
                className="w-full text-center text-sm text-muted-foreground hover:text-foreground underline"
              >
                Forgot Password?
              </button>
            </form>
          </CardContent>
        </Card>

        {/* EMERGENCY ONLY: license key badli gayi / server kisi dusri key ka hai */}
        {emergencyKeyOption && onEmergencyNewKey && (
          <div className="mt-4 p-4 rounded-lg border-2 border-red-300 bg-red-50 text-sm">
            <div className="flex items-center gap-2 font-semibold text-red-700 mb-1">
              <AlertTriangle className="w-4 h-4" /> Emergency: License match nahi hua
            </div>
            <p className="text-xs text-red-800 mb-3">
              Ye server kisi dusri license key ka hai. Aapka data is device par safe hai aur app chalta rahega.
              Agar aapko naya license key mila hai to niche se add karein, warna service provider se contact karein.
            </p>
            <Button type="button" variant="outline" className="w-full" onClick={onEmergencyNewKey}>
              <KeyRound className="w-4 h-4 mr-2" /> Naya License Key Add Karo (Admin Only)
            </Button>
          </div>
        )}
      </div>

      {/* Confirm reset */}
      <Dialog open={showForgotConfirm} onOpenChange={setShowForgotConfirm}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <KeyRound className="w-5 h-5 text-orange-600" />
              Reset Admin Password?
            </DialogTitle>
          </DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void handleResetPassword();
            }}
          >
            <div className="space-y-3 text-sm">
              <p>Admin password reset karne ke liye apni <strong>License Key</strong> daalein.</p>
              <div>
                <Label htmlFor="reset-license-key">License Key</Label>
                <Input
                  id="reset-license-key"
                  type="text"
                  placeholder="Enter license key"
                  value={resetLicenseKey}
                  onChange={(e) => {
                    setResetLicenseKey(e.target.value);
                    setResetError('');
                  }}
                  autoComplete="off"
                  autoFocus
                />
                {resetError && <p className="text-red-600 text-xs mt-1">{resetError}</p>}
              </div>
              <p className="text-muted-foreground">
                Password default par reset ho jayega. Aapka data (students, payments, batches) safe rahega.
                Isi license key se jude baaki saare devices par login apne aap logout ho jayega.
              </p>
            </div>
            <div className="flex gap-2 justify-end mt-4">
              <Button type="button" variant="outline" onClick={() => setShowForgotConfirm(false)} disabled={resetBusy}>
                Cancel
              </Button>
              <Button type="submit" disabled={resetBusy || !resetLicenseKey.trim()}>
                {resetBusy ? 'Checking...' : 'Reset Password'}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Reset success — shows the new default credentials */}
      <Dialog open={showResetSuccess} onOpenChange={setShowResetSuccess}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
              Password Reset Successful
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-2 text-sm">
            <p>Please log in using the credentials below:</p>
            <div className="bg-muted rounded-lg p-3 space-y-1">
              <div className="flex justify-between"><span>Email:</span><span className="font-mono font-semibold">{DEFAULT_ADMIN_EMAIL}</span></div>
              <div className="flex justify-between"><span>Password:</span><span className="font-mono font-semibold">{DEFAULT_ADMIN_PASSWORD}</span></div>
            </div>
            <p className="text-muted-foreground text-xs">For security, please set a new password from Settings after logging in.</p>
          </div>
          <Button
            className="w-full mt-2"
            onClick={() => {
              setAdminEmail(DEFAULT_ADMIN_EMAIL);
              setAdminPassword(DEFAULT_ADMIN_PASSWORD);
              setShowResetSuccess(false);
            }}
          >
            OK
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
