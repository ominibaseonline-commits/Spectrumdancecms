import { compressPhotoToTarget } from '../lib/imageCompress';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Plus, Edit, Trash2, User, Upload, MessageCircle, FileText, IndianRupee } from 'lucide-react';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { getAllTeachers, saveTeacher, deleteTeacher, getAllLocations } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';

const PAYMENT_STORAGE_KEY = 'teacher_payments';

const getTeacherPayments = () => {
  try { return JSON.parse(localStorage.getItem(PAYMENT_STORAGE_KEY) || '[]'); } catch { return []; }
};
const saveTeacherPayments = (payments: any[]) => {
  localStorage.setItem(PAYMENT_STORAGE_KEY, JSON.stringify(payments));
};

export function TeacherManagement() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const [teachers, setTeachers] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<any>(null);
  const [selectedTeacher, setSelectedTeacher] = useState<any>(null);
  const [showPhotoDialog, setShowPhotoDialog] = useState(false);
  const [selectedPhoto, setSelectedPhoto] = useState('');
  const [showPaymentDialog, setShowPaymentDialog] = useState(false);
  const [showPaymentHistoryDialog, setShowPaymentHistoryDialog] = useState(false);
  const [teacherPayments, setTeacherPayments] = useState<any[]>([]);
  const [paymentForm, setPaymentForm] = useState({
    amount: '',
    paymentDate: new Date().toISOString().split('T')[0],
    fromDate: '',
    toDate: '',
    note: '',
    paymentMode: 'Cash'
  });

  const [formData, setFormData] = useState<any>({
    id: '', name: '', mobile: '', dob: '', gender: '', email: '', address: '',
    location: '', specialization: '', photo: '', userId: '', password: '', status: 'active',
    paymentType: 'Monthly', paymentAmount: '', paymentDueDate: ''
  });

  const { matchesLocation } = useLocationFilter();
  useEffect(() => { loadData(); }, []);
  const visibleTeachers = teachers.filter((t: any) => matchesLocation(t.location));

  const loadData = async () => {
    const teachersData = await getAllTeachers();
    const locationsData = await getAllLocations();
    setTeachers(teachersData);
    setLocations(locationsData);
  };

  const handleAddTeacher = () => {
    setFormData({ id: '', name: '', mobile: '', dob: '', gender: '', email: '', address: '', location: '', specialization: '', photo: '', userId: '', password: '', status: 'active', paymentType: 'Monthly', paymentAmount: '', paymentDueDate: '' });
    setEditingTeacher(null);
    setShowAddDialog(true);
  };

  const handleEditTeacher = (teacher: any) => { setFormData(teacher); setEditingTeacher(teacher); setShowAddDialog(true); };

  const handleSaveTeacher = async () => {
    if (!formData.name || !formData.mobile) { toast.error('Please fill required fields'); return; }
    try {
      await saveTeacher({ ...formData, id: formData.id || `TCH-${Date.now()}-${formData.mobile}` });
      toast.success(editingTeacher ? 'Teacher updated!' : 'Teacher added!');
      setShowAddDialog(false);
      await loadData();
    } catch (error) { toast.error('Failed to save teacher'); }
  };

  const handleDeleteTeacher = async (id: string) => {
    if (!confirm('Are you sure?')) return;
    try { await deleteTeacher(id); await loadData(); toast.success('Teacher deleted!'); } catch { toast.error('Failed to delete'); }
  };

  const openPaymentDialog = (teacher: any) => {
    setSelectedTeacher(teacher);
    setPaymentForm({ amount: teacher.paymentAmount || '', paymentDate: new Date().toISOString().split('T')[0], fromDate: '', toDate: '', note: '', paymentMode: 'Cash' });
    setShowPaymentDialog(true);
  };

  const openPaymentHistory = (teacher: any) => {
    setSelectedTeacher(teacher);
    const allPayments = getTeacherPayments();
    setTeacherPayments(allPayments.filter((p: any) => p.teacherId === teacher.id));
    setShowPaymentHistoryDialog(true);
  };

  const handleSavePayment = () => {
    if (!paymentForm.amount || !paymentForm.fromDate || !paymentForm.toDate) {
      toast.error('Please fill amount and date range');
      return;
    }
    const allPayments = getTeacherPayments();
    const newPayment = {
      id: Date.now(),
      teacherId: selectedTeacher.id,
      teacherName: selectedTeacher.name,
      ...paymentForm
    };
    saveTeacherPayments([...allPayments, newPayment]);

    // Update teacher dues
    const paid = parseFloat(paymentForm.amount) || 0;
    const totalDue = parseFloat(selectedTeacher.paymentAmount) || 0;
    const existingPaid = parseFloat(selectedTeacher.totalPaid || '0');
    const newTotalPaid = existingPaid + paid;
    const dues = Math.max(0, totalDue - (newTotalPaid % totalDue || 0));
    saveTeacher({ ...selectedTeacher, totalPaid: newTotalPaid, dues });

    toast.success('Payment saved!');
    setShowPaymentDialog(false);
    loadData();
  };

  const handleWhatsAppPayment = (payment: any) => {
    if (!selectedTeacher?.mobile) { toast.error('Mobile not found!'); return; }
    const formatDate = (d: string) => d ? new Date(d).toLocaleDateString('en-GB') : 'N/A';
    const msg = `*${businessName.toUpperCase()}*\n*Teacher Payment Receipt*\n\nTeacher: ${selectedTeacher.name}\nMobile: ${selectedTeacher.mobile}\n\nPayment Date: ${formatDate(payment.paymentDate)}\nPeriod: ${formatDate(payment.fromDate)} - ${formatDate(payment.toDate)}\nAmount Paid: ₹${payment.amount}\nPayment Mode: ${payment.paymentMode}\n${payment.note ? `Note: ${payment.note}` : ''}\n\nThank you!`;
    window.open(`https://wa.me/91${selectedTeacher.mobile}?text=${encodeURIComponent(msg)}`, '_blank');
  };

  const handlePrintPaymentReport = async (teacher: any) => {
    const allPayments = getTeacherPayments().filter((p: any) => p.teacherId === teacher.id);
    const formatDate = (d: string) => d ? new Date(d).toLocaleDateString('en-GB') : 'N/A';
    const totalPaid = allPayments.reduce((s: number, p: any) => s + (parseFloat(p.amount) || 0), 0);
    const html = `<!DOCTYPE html><html><head><title>${teacher.name} - Teacher Payment Report</title>
    <style>body{font-family:Arial;padding:30px;} .header{background:#E8630A;padding:15px;text-align:center;color:white;} table{width:100%;border-collapse:collapse;margin-top:15px;} th,td{border:1px solid #ddd;padding:8px;text-align:left;} th{background:#FCE6D4;}</style></head>
    <body>${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Teacher Payment Report')}
    <h3>${teacher.name} | ${teacher.mobile} | ${teacher.location || 'N/A'}</h3>
    <p>Payment Type: ${teacher.paymentType || 'N/A'} | Monthly Amount: ₹${teacher.paymentAmount || 0} | Total Paid: ₹${totalPaid}</p>
    <table><tr><th>Date</th><th>Period</th><th>Amount</th><th>Mode</th><th>Note</th></tr>
    ${allPayments.map((p: any) => `<tr><td>${formatDate(p.paymentDate)}</td><td>${formatDate(p.fromDate)} - ${formatDate(p.toDate)}</td><td>₹${p.amount}</td><td>${p.paymentMode}</td><td>${p.note || '-'}</td></tr>`).join('')}
    </table>
    ${buildBrandingFooter({ businessName, businessPhone })}
    </body></html>`;
    await printDocument(html, `${teacher.name}_Payment_Report`);
  };

  const formatDate = (d: string) => d ? new Date(d).toLocaleDateString('en-GB') : 'N/A';

  const isPaymentDueSoon = (teacher: any) => {
    if (!teacher.paymentDueDate) return false;
    const due = new Date(teacher.paymentDueDate);
    const today = new Date();
    const diff = Math.ceil((due.getTime() - today.getTime()) / (1000*60*60*24));
    return diff >= 0 && diff <= 3;
  };

  const isPaymentOverdue = (teacher: any) => {
    if (!teacher.paymentDueDate) return false;
    return new Date(teacher.paymentDueDate) < new Date();
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Teacher Management</CardTitle>
            <Button onClick={handleAddTeacher}><Plus className="w-4 h-4 mr-2" />Add Teacher</Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Photo</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead>
                  <TableHead>Location</TableHead><TableHead>Payment Type</TableHead>
                  <TableHead>Monthly Amount</TableHead><TableHead>Due Date</TableHead>
                  <TableHead>Total Paid</TableHead><TableHead>Status</TableHead><TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {visibleTeachers.length > 0 ? teachers.map((teacher, index) => !matchesLocation(teacher.location) ? null : (
                  <TableRow key={index} className={isPaymentOverdue(teacher) ? 'bg-red-50' : isPaymentDueSoon(teacher) ? 'bg-yellow-50' : ''}>
                    <TableCell>
                      {teacher.photo ? (
                        <img src={teacher.photo} alt={teacher.name} className="w-12 h-12 rounded-full object-cover cursor-pointer" onClick={() => { setSelectedPhoto(teacher.photo); setShowPhotoDialog(true); }} />
                      ) : (
                        <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center"><User className="w-6 h-6 text-gray-400" /></div>
                      )}
                    </TableCell>
                    <TableCell className="font-medium">{teacher.name}</TableCell>
                    <TableCell>{teacher.mobile}</TableCell>
                    <TableCell>{teacher.location || 'N/A'}</TableCell>
                    <TableCell>{teacher.paymentType || 'N/A'}</TableCell>
                    <TableCell>₹{teacher.paymentAmount || 0}</TableCell>
                    <TableCell className={isPaymentOverdue(teacher) ? 'text-red-600 font-bold' : isPaymentDueSoon(teacher) ? 'text-orange-600' : ''}>
                      {teacher.paymentDueDate ? formatDate(teacher.paymentDueDate) : 'N/A'}
                      {isPaymentOverdue(teacher) && <span className="ml-1 text-xs bg-red-100 text-red-700 px-1 rounded">Overdue</span>}
                    </TableCell>
                    <TableCell>₹{teacher.totalPaid || 0}</TableCell>
                    <TableCell><span className={teacher.status === 'active' ? 'text-green-600' : 'text-red-600'}>{teacher.status}</span></TableCell>
                    <TableCell>
                      <div className="flex gap-1 flex-wrap">
                        <Button size="sm" variant="outline" onClick={() => handleEditTeacher(teacher)} title="Edit"><Edit className="w-3 h-3" /></Button>
                        <Button size="sm" variant="outline" onClick={() => openPaymentDialog(teacher)} title="Add Payment"><IndianRupee className="w-3 h-3 text-green-600" /></Button>
                        <Button size="sm" variant="outline" onClick={() => openPaymentHistory(teacher)} title="Payment History"><FileText className="w-3 h-3 text-blue-600" /></Button>
                        <Button size="sm" variant="outline" onClick={() => handlePrintPaymentReport(teacher)} title="Print Report"><FileText className="w-3 h-3" /></Button>
                        <Button size="sm" variant="outline" onClick={() => { if (teacher.mobile) window.open(`https://wa.me/91${teacher.mobile}`, '_blank'); }} title="WhatsApp"><MessageCircle className="w-3 h-3 text-green-600" /></Button>
                        <Button size="sm" variant="outline" onClick={() => handleDeleteTeacher(teacher.id)} title="Delete"><Trash2 className="w-3 h-3 text-red-500" /></Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow><TableCell colSpan={10} className="text-center text-gray-500 py-8">No teachers added yet</TableCell></TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Add/Edit Teacher Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{editingTeacher ? 'Edit Teacher' : 'Add Teacher'}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div><Label>Name *</Label><Input value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} placeholder="Teacher name" /></div>
              <div><Label>Mobile *</Label><Input value={formData.mobile} onChange={(e) => setFormData({...formData, mobile: e.target.value.replace(/\D/g,'').slice(0,10)})} placeholder="10-digit mobile" maxLength={10} /></div>
              <div><Label>Date of Birth</Label><Input type="date" value={formData.dob} onChange={(e) => setFormData({...formData, dob: e.target.value})} /></div>
              <div><Label>Email</Label><Input type="email" value={formData.email} onChange={(e) => setFormData({...formData, email: e.target.value})} /></div>
              <div><Label>Address</Label><Input value={formData.address} onChange={(e) => setFormData({...formData, address: e.target.value})} /></div>
              <div><Label>Specialization</Label><Input value={formData.specialization} onChange={(e) => setFormData({...formData, specialization: e.target.value})} /></div>
              <div>
                <Label>Location</Label>
                <Select value={formData.location} onValueChange={(v) => setFormData({...formData, location: v})}>
                  <SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger>
                  <SelectContent>{locations.map((l) => (<SelectItem key={l.name} value={l.name}>{l.name}</SelectItem>))}</SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Gender</Label>
              <div className="flex gap-4 mt-2">
                {['Male','Female','Other'].map((g) => (
                  <div key={g} className="flex items-center gap-2"><Checkbox checked={formData.gender === g} onCheckedChange={() => setFormData({...formData, gender: g})} /><span>{g}</span></div>
                ))}
              </div>
            </div>

            {/* Photo */}
            <div>
              <Label>Photo</Label>
              <div className="flex items-center gap-2">
                <Input type="file" accept="image/*" onChange={(e) => { const f = e.target.files?.[0]; if (f) { compressPhotoToTarget(f).then((photo) => setFormData((prev: any) => ({...prev, photo}))).catch(() => {}); } e.target.value = ''; }} className="hidden" id="teacher-photo" />
                <label htmlFor="teacher-photo" className="cursor-pointer flex items-center gap-2 px-4 py-2 border rounded hover:bg-gray-50"><Upload className="w-4 h-4" /><span>{formData.photo ? 'Change Photo' : 'Upload Photo'}</span></label>
                {formData.photo && <img src={formData.photo} alt="Preview" className="w-10 h-10 rounded-full object-cover" />}
              </div>
            </div>

            {/* Payment Settings */}
            <div className="p-4 bg-blue-50 rounded-lg border border-blue-200 space-y-3">
              <h4 className="font-semibold text-blue-800 flex items-center gap-1.5"><IndianRupee className="w-4 h-4" /> Payment Settings</h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Payment Type</Label>
                  <Select value={formData.paymentType} onValueChange={(v) => setFormData({...formData, paymentType: v})}>
                    <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Monthly">Monthly</SelectItem>
                      <SelectItem value="Per Class">Per Class</SelectItem>
                      <SelectItem value="Per Batch">Per Batch</SelectItem>
                      <SelectItem value="Percentage">Percentage (%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Amount (₹)</Label>
                  <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                    <Input type="number" className="pl-8" value={formData.paymentAmount} onChange={(e) => setFormData({...formData, paymentAmount: e.target.value})} placeholder="0" />
                  </div>
                </div>
                <div>
                  <Label>Payment Date</Label>
                  <Input type="date" value={formData.paymentDueDate} onChange={(e) => setFormData({...formData, paymentDueDate: e.target.value})} />
                </div>
              </div>
            </div>

            <Button onClick={handleSaveTeacher} className="w-full">{editingTeacher ? 'Update Teacher' : 'Add Teacher'}</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Payment Dialog */}
      <Dialog open={showPaymentDialog} onOpenChange={setShowPaymentDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Add Payment — {selectedTeacher?.name}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-3 bg-gray-50 rounded text-sm">
              <p>Payment Type: <strong>{selectedTeacher?.paymentType}</strong></p>
              <p>Monthly Amount: <strong>₹{selectedTeacher?.paymentAmount || 0}</strong></p>
              <p>Total Paid so far: <strong>₹{selectedTeacher?.totalPaid || 0}</strong></p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>From Date *</Label>
                <Input type="date" value={paymentForm.fromDate} onChange={(e) => setPaymentForm({...paymentForm, fromDate: e.target.value})} />
              </div>
              <div>
                <Label>To Date *</Label>
                <Input type="date" value={paymentForm.toDate} onChange={(e) => setPaymentForm({...paymentForm, toDate: e.target.value})} />
              </div>
            </div>
            <div>
              <Label>Amount Paid *</Label>
              <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                <Input type="number" className="pl-8" value={paymentForm.amount} onChange={(e) => setPaymentForm({...paymentForm, amount: e.target.value})} placeholder="0" />
              </div>
            </div>
            <div>
              <Label>Payment Date</Label>
              <Input type="date" value={paymentForm.paymentDate} onChange={(e) => setPaymentForm({...paymentForm, paymentDate: e.target.value})} />
            </div>
            <div>
              <Label>Payment Mode</Label>
              <div className="flex gap-4 mt-2">
                {['Cash','Online'].map((m) => (
                  <div key={m} className="flex items-center gap-2"><Checkbox checked={paymentForm.paymentMode === m} onCheckedChange={() => setPaymentForm({...paymentForm, paymentMode: m})} /><span>{m}</span></div>
                ))}
              </div>
            </div>
            <div>
              <Label>Note</Label>
              <Input value={paymentForm.note} onChange={(e) => setPaymentForm({...paymentForm, note: e.target.value})} placeholder="Optional note" />
            </div>
            <Button onClick={handleSavePayment} className="w-full">Save Payment</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment History Dialog */}
      <Dialog open={showPaymentHistoryDialog} onOpenChange={setShowPaymentHistoryDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Payment History — {selectedTeacher?.name}</DialogTitle></DialogHeader>
          <div className="mb-3 p-3 bg-gray-50 rounded text-sm flex gap-6">
            <span>Monthly Amount: <strong>₹{selectedTeacher?.paymentAmount || 0}</strong></span>
            <span>Total Paid: <strong className="text-green-600">₹{teacherPayments.reduce((s, p) => s + (parseFloat(p.amount)||0), 0)}</strong></span>
          </div>
          {teacherPayments.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow><TableHead>Payment Date</TableHead><TableHead>Period</TableHead><TableHead>Amount</TableHead><TableHead>Mode</TableHead><TableHead>Note</TableHead><TableHead>Actions</TableHead></TableRow>
              </TableHeader>
              <TableBody>
                {teacherPayments.map((p, i) => (
                  <TableRow key={i}>
                    <TableCell>{formatDate(p.paymentDate)}</TableCell>
                    <TableCell>{formatDate(p.fromDate)} - {formatDate(p.toDate)}</TableCell>
                    <TableCell className="text-green-600 font-semibold">₹{p.amount}</TableCell>
                    <TableCell>{p.paymentMode}</TableCell>
                    <TableCell>{p.note || '-'}</TableCell>
                    <TableCell>
                      <Button size="sm" variant="outline" onClick={() => handleWhatsAppPayment(p)}><MessageCircle className="w-3 h-3 text-green-600" /></Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-center text-gray-500 py-8">No payment history found</p>
          )}
        </DialogContent>
      </Dialog>

      {/* Photo Dialog */}
      <Dialog open={showPhotoDialog} onOpenChange={setShowPhotoDialog}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Teacher Photo</DialogTitle></DialogHeader>
          {selectedPhoto && <div className="flex justify-center"><img src={selectedPhoto} alt="Teacher" className="max-w-full max-h-[70vh] object-contain rounded-lg" /></div>}
        </DialogContent>
      </Dialog>
    </div>
  );
}
