import { useEffect, useMemo, useRef, useState } from 'react';
import { toast } from 'sonner';
import { ArrowDown, ArrowUp, ImageUp, Plus, RotateCcw, Save, Trash2 } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { useFormLayout } from '../lib/formLayout';
import {
  ID_CARD_BASE_FIELDS, ID_CARD_CSS, ID_CARD_TEMPLATES, IdCardSettings as Settings,
  buildIdCardAssets, compressIdCardBanner, defaultIdCardSettings, loadIdCardSettings,
  normalizeIdCardSettings, renderIdCardSide, saveIdCardSettings, getIdCardBanner,
} from '../lib/idCard';
import { pushOnlineAdmissionConfig } from '../lib/onlineAdmission';

// Preview me photo ki jagah ek halka silhouette
const SAMPLE_PHOTO =
  'data:image/svg+xml;utf8,' +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#e8e8ee"/><circle cx="50" cy="38" r="18" fill="#b8b8c4"/><path d="M14 100c4-26 24-36 36-36s32 10 36 36z" fill="#b8b8c4"/></svg>'
  );

const CONTACT_TYPES: { v: string; label: string }[] = [
  { v: 'address', label: 'Address' },
  { v: 'phone', label: 'Phone' },
  { v: 'instagram', label: 'Instagram' },
  { v: 'email', label: 'Email' },
  { v: 'website', label: 'Website' },
];

const selectCls = 'h-9 w-full rounded-md border border-input bg-white px-2 text-sm';

export function IdCardSettings() {
  const [s, setS] = useState<Settings | null>(null);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { fields: layoutFields } = useFormLayout();

  useEffect(() => { loadIdCardSettings().then(setS); }, []);

  const change = (patch: Partial<Settings>) => {
    setS((prev) => (prev ? { ...prev, ...patch } : prev));
    setDirty(true);
  };

  // Card par aane layak CMS columns: base list + Admission Form me jo ON hain (extra / custom bhi)
  const pickable = useMemo(() => {
    const out = ID_CARD_BASE_FIELDS.map((f) => ({ ...f }));
    const have = new Set(out.map((f) => f.id));
    (layoutFields || []).forEach((f) => {
      if (f.visible && f.type !== 'photo' && !have.has(f.id) && f.id !== 'name' && f.id !== 'dues' && !/Amount|duration/i.test(f.id)) {
        out.push({ id: f.id, label: f.label });
        have.add(f.id);
      }
    });
    return out;
  }, [layoutFields]);

  const preview = useMemo(() => {
    if (!s) return { front: '', back: '' };
    const sample: any = {
      name: 'Student Name', mobile: '9876543210', dob: '2005-04-12', gender: 'Female', category: 'Dance', subCategory: 'Hip Hop',
      batchTime: '5:00 To 6:00 Pm', location: 'Patna', admissionDate: new Date().toISOString().slice(0, 10), expiryDate: '2027-04-12',
      address: '12 Main Road, Patna', email: 'student@mail.com', regNo: '26135', guardianName: 'Guardian Name', guardianRelation: 'Father',
      alternateMobile: '9876500000', aadhaarNumber: '123412341234', customFields: {},
    };
    pickable.forEach((f) => { if (sample[f.id] === undefined) sample.customFields[f.id] = 'Sample'; });
    const assets = buildIdCardAssets(s, SAMPLE_PHOTO);
    return {
      front: renderIdCardSide('front', s, sample, assets, 'pv-front'),
      back: renderIdCardSide('back', s, sample, assets, 'pv-back'),
    };
  }, [s, pickable]);

  if (!s) return <Card className="p-6 text-sm text-gray-500">Loading...</Card>;

  const save = async () => {
    setSaving(true);
    try {
      const clean = await saveIdCardSettings(normalizeIdCardSettings(s));
      setS(clean);
      setDirty(false);
      let online = '';
      try {
        await pushOnlineAdmissionConfig(true);
        online = ' Online admission form me bhi update ho gaya.';
      } catch {
        online = ' (Online admission form abhi update nahi ho paya — internet / Google Script check karke dobara Save karein.)';
      }
      toast.success('ID Card settings save ho gayi.' + online);
    } catch (e: any) {
      toast.error('Save nahi hua: ' + (e?.message || 'error'));
    } finally {
      setSaving(false);
    }
  };

  const reset = () => {
    if (!window.confirm('ID Card ko wapas default (Spectrum) design par laayein? Save karne tak kuch nahi badlega.')) return;
    const d = defaultIdCardSettings();
    setS({ ...d, enabled: s.enabled });
    setDirty(true);
  };

  const onBanner = async (file?: File) => {
    if (!file) return;
    try {
      change({ bannerImage: await compressIdCardBanner(file) });
    } catch {
      toast.error('Image padhi nahi ja saki. Dusri image chunein.');
    }
  };

  // ---- front rows ----
  const setRow = (i: number, patch: any) => change({ frontRows: s.frontRows.map((r, k) => (k === i ? { ...r, ...patch } : r)) });
  const moveRow = (i: number, d: number) => {
    const j = i + d;
    if (j < 0 || j >= s.frontRows.length) return;
    const rows = [...s.frontRows];
    [rows[i], rows[j]] = [rows[j], rows[i]];
    change({ frontRows: rows });
  };
  const addRow = () => {
    const used = new Set(s.frontRows.map((r) => r.id));
    const next = pickable.find((f) => !used.has(f.id));
    if (!next) return toast.error('Aur koi column bacha nahi.');
    change({ frontRows: [...s.frontRows, { id: next.id, label: next.label }] });
  };
  const pickRowField = (i: number, id: string) => {
    const f = pickable.find((x) => x.id === id);
    setRow(i, { id, label: f?.label || id });
  };

  // ---- contacts ----
  const setContact = (i: number, patch: any) => change({ contacts: s.contacts.map((c, k) => (k === i ? { ...c, ...patch } : c)) });

  const showFront = s.sides !== 'back';
  const showBack = s.sides !== 'front';

  return (
    <div className="space-y-4">
      <Card className="p-4 space-y-4">
        <div className="flex items-center justify-between gap-4">
          <div>
            <h3 className="font-semibold">Student ID Card</h3>
            <p className="text-sm text-gray-600">
              ON rakhne par Admission Saved popup me <b>ID Card</b> button aata hai (PDF + WhatsApp) aur online admission form submit hone par card student ko jata hai.
              OFF karne par dono jagah se card hat jata hai.
            </p>
          </div>
          <Switch checked={s.enabled} onCheckedChange={(v) => change({ enabled: v })} />
        </div>
        {!s.enabled && <p className="text-sm rounded-md bg-amber-50 border border-amber-200 p-2 text-amber-800">ID Card abhi OFF hai. Neeche ka design save rahega, bas card kahin nahi banega.</p>}
      </Card>

      <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,560px)]">
        <div className="space-y-4">
          <Card className="p-4 space-y-3">
            <h4 className="font-semibold">Card type</h4>
            <div className="flex flex-wrap gap-2">
              {([['both', 'Front + Back'], ['front', 'Sirf Front'], ['back', 'Sirf Back']] as const).map(([v, label]) => (
                <Button key={v} type="button" size="sm" variant={s.sides === v ? 'default' : 'outline'} onClick={() => change({ sides: v })}>{label}</Button>
              ))}
            </div>

            <h4 className="font-semibold pt-2">Template (rang)</h4>
            <div className="flex flex-wrap gap-2">
              {Object.entries(ID_CARD_TEMPLATES).map(([key, t]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => change({ template: key })}
                  className={`flex items-center gap-2 rounded-md border px-2 py-1.5 text-sm ${s.template === key ? 'border-orange-500 bg-orange-50' : 'border-gray-300 bg-white'}`}
                >
                  <span className="inline-block h-5 w-5 rounded-full border" style={{ background: `linear-gradient(135deg, ${t.dark} 55%, ${t.a1} 55%)` }} />
                  {t.name}
                </button>
              ))}
            </div>

            <h4 className="font-semibold pt-2">Header banner image</h4>
            <div className="flex items-center gap-3">
              <img src={getIdCardBanner(s)} alt="banner" className="h-14 w-32 rounded border object-cover bg-gray-100" />
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { onBanner(e.target.files?.[0]); e.target.value = ''; }} />
              <Button type="button" size="sm" variant="outline" onClick={() => fileRef.current?.click()}><ImageUp className="w-4 h-4 mr-1" /> Image badlein</Button>
              {s.bannerImage && <Button type="button" size="sm" variant="ghost" onClick={() => change({ bannerImage: '' })}>Default</Button>}
            </div>
            <p className="text-xs text-gray-500">Image card ke upar (255 × 107 size me) fit hoti hai aur apne aap chhoti (30 KB) ho jati hai.</p>

            <div className="grid gap-3 sm:grid-cols-2 pt-2">
              <div><Label>Card heading</Label><Input value={s.title} maxLength={30} onChange={(e) => change({ title: e.target.value })} placeholder="STUDENT ID CARD" /></div>
              <div><Label>Front tagline</Label><Input value={s.tagline} maxLength={30} onChange={(e) => change({ tagline: e.target.value })} placeholder="Dance is Life" /></div>
            </div>
            <div className="flex items-center justify-between"><Label>Student photo dikhayein</Label><Switch checked={s.showPhoto} onCheckedChange={(v) => change({ showPhoto: v })} /></div>
            <div className="flex items-center justify-between"><Label>Peeche halki dancer image (watermark)</Label><Switch checked={s.showDancer} onCheckedChange={(v) => change({ showDancer: v })} /></div>
          </Card>

          {showFront && (
            <Card className="p-4 space-y-3">
              <h4 className="font-semibold">Front — kaun sa column kahan</h4>
              <p className="text-xs text-gray-500">Upar se neeche isi order me card par aayenge (max 6). Jis column ki value khali hogi wo card par nahi dikhega.</p>
              {s.frontRows.map((r, i) => (
                <div key={i} className="grid grid-cols-[minmax(0,1fr)_minmax(0,1fr)_auto] gap-2 items-center">
                  <select className={selectCls} value={r.id} onChange={(e) => pickRowField(i, e.target.value)}>
                    {!pickable.some((f) => f.id === r.id) && <option value={r.id}>{r.id}</option>}
                    {pickable.map((f) => <option key={f.id} value={f.id}>{f.label}</option>)}
                  </select>
                  <Input value={r.label} maxLength={24} onChange={(e) => setRow(i, { label: e.target.value })} placeholder="Card par naam" />
                  <div className="flex gap-1">
                    <Button type="button" size="icon" variant="outline" className="h-9 w-9" onClick={() => moveRow(i, -1)} disabled={i === 0}><ArrowUp className="w-4 h-4" /></Button>
                    <Button type="button" size="icon" variant="outline" className="h-9 w-9" onClick={() => moveRow(i, 1)} disabled={i === s.frontRows.length - 1}><ArrowDown className="w-4 h-4" /></Button>
                    <Button type="button" size="icon" variant="outline" className="h-9 w-9 text-red-600" onClick={() => change({ frontRows: s.frontRows.filter((_, k) => k !== i) })}><Trash2 className="w-4 h-4" /></Button>
                  </div>
                </div>
              ))}
              <Button type="button" size="sm" variant="outline" onClick={addRow} disabled={s.frontRows.length >= 6}><Plus className="w-4 h-4 mr-1" /> Column add karein</Button>
              <p className="text-xs text-gray-500">Admission Form Layout me jo extra / custom fields ON hain wo bhi yaha list me aate hain. Online form me "Reg No" wahi number dikhta hai jo form par dikh raha hota hai.</p>
            </Card>
          )}

          {showBack && (
            <Card className="p-4 space-y-3">
              <h4 className="font-semibold">Back — contact aur baaki details</h4>
              {s.contacts.map((c, i) => (
                <div key={i} className="grid grid-cols-[110px_minmax(0,1fr)_auto] gap-2 items-center">
                  <select className={selectCls} value={c.type} onChange={(e) => setContact(i, { type: e.target.value })}>
                    {CONTACT_TYPES.map((t) => <option key={t.v} value={t.v}>{t.label}</option>)}
                  </select>
                  <Input value={c.text} maxLength={120} onChange={(e) => setContact(i, { text: e.target.value })} />
                  <Button type="button" size="icon" variant="outline" className="h-9 w-9 text-red-600" onClick={() => change({ contacts: s.contacts.filter((_, k) => k !== i) })}><Trash2 className="w-4 h-4" /></Button>
                </div>
              ))}
              <Button type="button" size="sm" variant="outline" disabled={s.contacts.length >= 3} onClick={() => change({ contacts: [...s.contacts, { type: 'phone', text: '' }] })}><Plus className="w-4 h-4 mr-1" /> Contact line add karein (max 3)</Button>

              <div className="grid gap-3 sm:grid-cols-2 pt-2">
                <div><Label>Tagline line 1</Label><Input value={s.backLines[0] || ''} maxLength={24} onChange={(e) => change({ backLines: [e.target.value, s.backLines[1] || ''] })} /></div>
                <div><Label>Tagline line 2</Label><Input value={s.backLines[1] || ''} maxLength={24} onChange={(e) => change({ backLines: [s.backLines[0] || '', e.target.value] })} /></div>
                <div><Label>Founder / Sign naam</Label><Input value={s.founderName} maxLength={30} onChange={(e) => change({ founderName: e.target.value })} /></div>
                <div><Label>Founder designation</Label><Input value={s.founderTitle} maxLength={24} onChange={(e) => change({ founderTitle: e.target.value })} /></div>
              </div>

              <div className="flex items-center justify-between pt-2"><Label>QR code dikhayein</Label><Switch checked={s.qrEnabled} onCheckedChange={(v) => change({ qrEnabled: v })} /></div>
              {s.qrEnabled && (
                <div className="grid gap-3 sm:grid-cols-3">
                  <div className="sm:col-span-3"><Label>QR kholne par kaun si website / link</Label><Input value={s.qrUrl} maxLength={200} onChange={(e) => change({ qrUrl: e.target.value })} placeholder="https://..." /></div>
                  <div><Label>QR ke bagal ka naam</Label><Input value={s.qrTitle} maxLength={24} onChange={(e) => change({ qrTitle: e.target.value })} /></div>
                  <div className="sm:col-span-2"><Label>QR ke neeche text</Label><Input value={s.qrSub} maxLength={28} onChange={(e) => change({ qrSub: e.target.value })} /></div>
                </div>
              )}

              <Label className="block pt-2">Neeche ke 3 shabd (kam karne ke liye khali chhod dein)</Label>
              <div className="grid gap-2 sm:grid-cols-3">
                {[0, 1, 2].map((i) => (
                  <Input key={i} value={s.values[i] || ''} maxLength={16} onChange={(e) => { const v = [0, 1, 2].map((k) => (k === i ? e.target.value : s.values[k] || '')); change({ values: v }); }} />
                ))}
              </div>
            </Card>
          )}
        </div>

        <div className="space-y-3">
          <Card className="p-4 lg:sticky lg:top-4">
            <h4 className="font-semibold mb-3">Live preview</h4>
            <style>{ID_CARD_CSS}</style>
            <div className="flex flex-wrap justify-center gap-4">
              {showFront && <div dangerouslySetInnerHTML={{ __html: preview.front }} />}
              {showBack && <div dangerouslySetInnerHTML={{ __html: preview.back }} />}
            </div>
          </Card>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 sticky bottom-2 bg-white/90 backdrop-blur rounded-lg border p-3">
        <Button onClick={save} disabled={saving || !dirty}><Save className="w-4 h-4 mr-2" />{saving ? 'Save ho raha hai...' : 'Save'}</Button>
        <Button variant="outline" onClick={reset}><RotateCcw className="w-4 h-4 mr-2" /> Default design</Button>
        {dirty && <span className="text-sm text-amber-700 self-center">Unsaved changes</span>}
      </div>
    </div>
  );
}
