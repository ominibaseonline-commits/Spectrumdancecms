import { useState, useEffect, useMemo, useCallback, type ReactNode } from 'react';
import { Card, CardContent } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Tabs, TabsList, TabsTrigger, TabsContent } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { toast } from 'sonner';
import { Plus, ClipboardList, BellRing, Search, X, Save, MessageCircle, Pencil, Trash2, AlarmClock, CheckCircle2, CalendarDays, Phone, UserCheck, MinusCircle, Repeat, AlertTriangle, QrCode } from 'lucide-react';
import { useBusinessName } from '../contexts/BusinessContext';
import { saveEnquiry, deleteEnquiry } from '../lib/indexedDB';
import {
  Enquiry, EnquiryStatus, STATUS_OPTIONS, statusInfo,
  getEnquiryCourses, getEnquirySources, buildEnquiryMessage,
  normalizePhone, openWhatsApp, todayStr, addDaysStr, toDateStr, formatDateTime, formatDateOnly,
  isPendingFollowUp, purgeExpiredEnquiries, daysLeftToDelete, ADMISSION_KEEP_DAYS, getSendWhatsApp, saveSendWhatsApp,
  buildRepeatMap,
} from '../lib/enquiries';
import { RepeatNotice, OldEnquiryDialog } from './OldEnquiryDetails';
import { useQrEnquiryEnabled, QR_ENQUIRY_NEW_EVENT } from '../lib/qrEnquiry';

const PAGE_SIZE = 50;

// small pill used for the Status / Course filters
function Chip({ active, onClick, children }: { active: boolean; onClick: () => void; children: ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`px-3 py-1 rounded-full text-sm border transition-colors ${
        active ? 'bg-[var(--brand)] text-white border-[var(--brand)]' : 'bg-white text-gray-700 border-gray-300 hover:bg-[var(--app-bg)]'
      }`}
    >
      {children}
    </button>
  );
}

function StatusBadge({ status }: { status: string }) {
  const info = statusInfo(status);
  return <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${info.chip}`}>{info.label}</span>;
}

export function EnquiryManagement() {
  const { businessName } = useBusinessName();
  const [tab, setTab] = useState('add');
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  // QR Enquiry inbox: enquiries filled by students through the QR form that the admin has not acted on yet
  const [qrEnquiries, setQrEnquiries] = useState<Enquiry[]>([]);
  const qrOn = useQrEnquiryEnabled();
  const [courses, setCourses] = useState<string[]>([]);
  const [sources, setSources] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<Enquiry | null>(null);
  // WhatsApp tick lives here (not inside the Add tab) so it never resets when switching tabs/pages
  const [sendWA, setSendWAState] = useState(false);
  useEffect(() => { getSendWhatsApp().then(setSendWAState); }, []);
  const setSendWA = (v: boolean) => { setSendWAState(v); saveSendWhatsApp(v); };

  const loadAll = useCallback(async () => {
    try {
      // admission enquiries older than 5 days are removed here automatically
      const [list, c, s] = await Promise.all([purgeExpiredEnquiries(), getEnquiryCourses(), getEnquirySources()]);
      list.sort((a: Enquiry, b: Enquiry) => (b.createdAt || '').localeCompare(a.createdAt || ''));
      // While QR Enquiry is ON, un-actioned QR enquiries live in the QR Enquiry tab only.
      // If it is switched OFF they simply show up in the normal Enquiry List again (nothing is lost).
      const inbox = (e: Enquiry) => qrOn && !!e.qrPending;
      setQrEnquiries(list.filter(inbox));
      setEnquiries(list.filter((e: Enquiry) => !inbox(e)));
      setCourses(c);
      setSources(s);
    } catch (error) {
      console.error('Error loading enquiries:', error);
      toast.error('Enquiries load nahi ho paayi');
    } finally {
      setLoading(false);
    }
  }, [qrOn]);

  useEffect(() => { loadAll(); }, [loadAll]);

  // A new QR enquiry reached this computer -> show it at once
  useEffect(() => {
    window.addEventListener(QR_ENQUIRY_NEW_EVENT, loadAll);
    return () => window.removeEventListener(QR_ENQUIRY_NEW_EVENT, loadAll);
  }, [loadAll]);

  // QR Enquiry switched OFF while its tab is open -> go back to Add Enquiry
  useEffect(() => { if (!qrOn && tab === 'qr') setTab('add'); }, [qrOn, tab]);

  // Follow-Up badge = how many people must be called TODAY
  const followUpCount = useMemo(() => {
    const t = todayStr();
    return enquiries.filter((e) => isPendingFollowUp(e) && e.followUpDate === t).length;
  }, [enquiries]);
  const convertedCount = useMemo(() => enquiries.filter((e) => !!e.converted).length, [enquiries]);

  const sendWhatsApp = async (kind: 'add' | 'list' | 'followup' | 'qr', e: Enquiry) => {
    const text = await buildEnquiryMessage(kind, e, businessName);
    if (!openWhatsApp(e.phone, text)) toast.error('Sahi mobile number nahi mila!');
  };

  return (
    <div className="p-6">
      <Card className="overflow-hidden">
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList className={`w-full grid ${qrOn ? 'grid-cols-5' : 'grid-cols-4'} h-auto rounded-none`}>
            <TabsTrigger value="add" className="flex items-center gap-1.5 py-2.5"><Plus className="w-4 h-4" /> Add Enquiry</TabsTrigger>
            <TabsTrigger value="list" className="flex items-center gap-1.5 py-2.5">
              <ClipboardList className="w-4 h-4" /> Enquiry List
              <span className="ml-1 text-xs bg-[var(--brand)] text-white rounded-full px-2 py-0.5">{enquiries.length}</span>
            </TabsTrigger>
            <TabsTrigger value="followup" className="flex items-center gap-1.5 py-2.5">
              <BellRing className="w-4 h-4" /> Follow-Up
              <span className="ml-1 text-xs bg-[var(--brand)] text-white rounded-full px-2 py-0.5">{followUpCount}</span>
            </TabsTrigger>
            <TabsTrigger value="converted" className="flex items-center gap-1.5 py-2.5">
              <UserCheck className="w-4 h-4" /> Converted
              <span className="ml-1 text-xs bg-[var(--brand)] text-white rounded-full px-2 py-0.5">{convertedCount}</span>
            </TabsTrigger>
            {qrOn && (
              <TabsTrigger value="qr" className="flex items-center gap-1.5 py-2.5">
                <QrCode className="w-4 h-4" /> QR Enquiry
                <span className="ml-1 text-xs bg-[var(--brand)] text-white rounded-full px-2 py-0.5">{qrEnquiries.length}</span>
              </TabsTrigger>
            )}
          </TabsList>

          <CardContent className="pt-6">
            <TabsContent value="add">
              <AddEnquiryTab
                courses={courses}
                sources={sources}
                enquiries={[...enquiries, ...qrEnquiries]}
                businessName={businessName}
                sendWA={sendWA}
                setSendWA={setSendWA}
                onSaved={async (goToList) => { await loadAll(); if (goToList) setTab('list'); }}
              />
            </TabsContent>
            <TabsContent value="list">
              <EnquiryListTab
                enquiries={enquiries}
                courses={courses}
                loading={loading}
                onEdit={setEditing}
                onWhatsApp={(e) => sendWhatsApp('list', e)}
                onChanged={loadAll}
              />
            </TabsContent>
            <TabsContent value="followup">
              <FollowUpTab
                enquiries={enquiries}
                courses={courses}
                onEdit={setEditing}
                onWhatsApp={(e) => sendWhatsApp('followup', e)}
                onChanged={loadAll}
              />
            </TabsContent>
            <TabsContent value="converted">
              <ConvertedTab
                enquiries={enquiries}
                onEdit={setEditing}
                onWhatsApp={(e) => sendWhatsApp('list', e)}
                onChanged={loadAll}
              />
            </TabsContent>
            {qrOn && (
              <TabsContent value="qr">
                <QrEnquiryTab
                  enquiries={qrEnquiries}
                  allEnquiries={[...enquiries, ...qrEnquiries]}
                  qrOn={qrOn}
                  onWhatsApp={(e) => sendWhatsApp('qr', e)}
                  onChanged={loadAll}
                />
              </TabsContent>
            )}
          </CardContent>
        </Tabs>
      </Card>

      <EnquiryEditDialog
        enquiry={editing}
        courses={courses}
        sources={sources}
        onClose={() => setEditing(null)}
        onChanged={async () => { setEditing(null); await loadAll(); }}
        onWhatsApp={(e) => sendWhatsApp('list', e)}
      />
    </div>
  );
}

// ============================================================================
// Add Enquiry
// ============================================================================
function AddEnquiryTab({ courses, sources, enquiries, businessName, sendWA, setSendWA, onSaved }: {
  courses: string[]; sources: string[]; enquiries: Enquiry[]; businessName: string;
  sendWA: boolean; setSendWA: (v: boolean) => void;
  onSaved: (goToList: boolean) => Promise<void>;
}) {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [course, setCourse] = useState('');
  const [source, setSource] = useState('');
  const [status, setStatus] = useState<EnquiryStatus>('interested');
  const [followUpDate, setFollowUpDate] = useState('');
  const [followUpNote, setFollowUpNote] = useState('');
  const [saving, setSaving] = useState(false);
  // same phone number already saved -> popup with the old details
  const [dup, setDup] = useState<{ matches: Enquiry[]; pending: Enquiry; exact: boolean } | null>(null);

  const norm = (v?: string) => (v || '').trim().toLowerCase();

  // Actually writes the enquiry (called directly, or from the duplicate popup's "Add" button)
  const saveNow = async (enquiry: Enquiry) => {
    setSaving(true);
    try {
      await saveEnquiry(enquiry);
      toast.success('Enquiry save ho gayi!');

      // Thank-you WhatsApp message to the student (only when the tick is ON)
      if (sendWA) {
        const text = await buildEnquiryMessage('add', enquiry, businessName);
        openWhatsApp(enquiry.phone, text);
      }

      setName(''); setPhone(''); setCourse(''); setSource('');
      setStatus('interested'); setFollowUpDate(''); setFollowUpNote('');
      setDup(null);
      await onSaved(false);
    } catch (error) {
      console.error('Error saving enquiry:', error);
      toast.error('Enquiry save nahi ho paayi');
    } finally {
      setSaving(false);
    }
  };

  const handleSave = async () => {
    if (!name.trim()) { toast.error('Student ka naam likhein!'); return; }
    if (!/^\d{10}$/.test(phone)) { toast.error('Phone No sirf 10 digit ka hona chahiye!'); return; }
    if (!course) { toast.error('Course select karein!'); return; }
    if (!source) { toast.error('Query Source select karein!'); return; }

    const enquiry: Enquiry = {
      id: `enq_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      name: name.trim(),
      phone,
      course,
      source,
      status,
      followUpDate: followUpDate || undefined,
      followUpNote: followUpNote.trim() || undefined,
      followUpDone: false,
      createdAt: new Date().toISOString(),
    };

    const matches = enquiries.filter((e) => normalizePhone(e.phone) === phone);
    if (matches.length > 0) {
      // Everything identical (name, course, source, status, follow-up) -> not allowed again
      const exact = matches.some((m) =>
        norm(m.name) === norm(enquiry.name) && norm(m.course) === norm(enquiry.course) &&
        norm(m.source) === norm(enquiry.source) && m.status === enquiry.status &&
        (m.followUpDate || '') === (enquiry.followUpDate || '') && norm(m.followUpNote) === norm(enquiry.followUpNote));
      setDup({ matches, pending: enquiry, exact });
      return;
    }
    await saveNow(enquiry);
  };

  return (
    <div className="space-y-4 w-full">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <Label>Student Name *</Label>
          <Input className="mt-1" value={name} onChange={(e) => setName(e.target.value)} placeholder="Student Name" />
        </div>
        <div>
          <Label>Phone No *</Label>
          <Input className="mt-1" inputMode="numeric" value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, '').slice(0, 10))} placeholder="10 digit Phone No" maxLength={10} />
          {phone.length > 0 && phone.length < 10 && <p className="text-xs text-red-500 mt-1">{phone.length}/10 digit</p>}
        </div>
      </div>

      <div>
        <Label>Select Course *</Label>
        <Select value={course} onValueChange={setCourse}>
          <SelectTrigger className="mt-1"><SelectValue placeholder="-- Select Course --" /></SelectTrigger>
          <SelectContent>
            {courses.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
        {courses.length === 0 && (
          <p className="text-xs text-orange-600 mt-1">Abhi koi course nahi hai — Settings → Enquiry Settings me course add karein.</p>
        )}
      </div>

      <div>
        <Label>Query Source (Query kaha se aayi?) *</Label>
        <Select value={source} onValueChange={setSource}>
          <SelectTrigger className="mt-1"><SelectValue placeholder="-- Query Kaha Se Aayi? (Source) --" /></SelectTrigger>
          <SelectContent>
            {sources.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
          </SelectContent>
        </Select>
        {sources.length === 0 && (
          <p className="text-xs text-orange-600 mt-1">Abhi koi source nahi hai — Settings → Enquiry Settings me add karein.</p>
        )}
      </div>

      <div>
        <Label>Status</Label>
        <Select value={status} onValueChange={(v) => setStatus(v as EnquiryStatus)}>
          <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
          <SelectContent>
            {STATUS_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="border-2 border-dashed border-[var(--brand)]/50 bg-[var(--app-bg)]/40 rounded-lg p-4 space-y-3">
        <div>
          <Label className="flex items-center gap-1.5 text-[#c2570f]"><CalendarDays className="w-4 h-4" /> Follow-Up Date (Optional)</Label>
          <Input className="mt-1 bg-white" type="date" value={followUpDate} onChange={(e) => setFollowUpDate(e.target.value)} />
        </div>
        <div>
          <Label className="flex items-center gap-1.5 text-[#c2570f]"><Pencil className="w-4 h-4" /> Follow-Up Note (Optional)</Label>
          <Input className="mt-1 bg-white" value={followUpNote} onChange={(e) => setFollowUpNote(e.target.value)} placeholder="e.g. Monday aayenge, fees discuss karni hai" />
        </div>
      </div>

      <div className="flex items-center gap-2">
        <Checkbox id="enq-send-wa" checked={sendWA} onCheckedChange={(c) => setSendWA(c === true)} />
        <Label htmlFor="enq-send-wa" className="cursor-pointer text-sm">Save karte hi student ko WhatsApp message bhejo</Label>
      </div>

      <Button onClick={handleSave} disabled={saving} className="w-full bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white h-11">
        <Save className="w-4 h-4 mr-2" /> {saving ? 'Saving...' : 'Save Enquiry'}
      </Button>

      {/* Same phone number already saved */}
      <Dialog open={!!dup} onOpenChange={(o) => { if (!o) setDup(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><AlertTriangle className="w-5 h-5 text-[var(--brand)]" /> Ye number pehle se saved hai</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-600">
              <strong>{dup?.pending.phone}</strong> number se pehle ye enquiry save hai:
            </p>
            {dup?.matches.map((m) => (
              <div key={m.id} className="border rounded-lg p-3 bg-[var(--app-bg)]/40 text-sm space-y-1">
                <div className="flex items-center flex-wrap gap-2">
                  <span className="font-semibold">{m.name}</span>
                  <StatusBadge status={m.status} />
                  {m.converted && <span className="text-xs px-2 py-0.5 rounded-full bg-purple-100 text-purple-800">{m.converted === 'demo' ? 'Demo' : 'Admission'}</span>}
                </div>
                <div className="text-gray-600">Course: {m.course} &nbsp;|&nbsp; Source: {m.source}</div>
                <div className="text-gray-600">Enquiry: {formatDateTime(m.createdAt)}</div>
                {m.followUpDate && <div className="text-gray-600">Follow-up: {formatDateOnly(m.followUpDate)}</div>}
                {m.followUpNote && <div className="text-gray-600 italic">📝 {m.followUpNote}</div>}
              </div>
            ))}
            {dup?.exact ? (
              <p className="text-sm text-red-600 bg-red-50 rounded px-3 py-2">Naam, course aur baaki sab details bilkul same hain, isliye ye dobara add nahi ho sakti.</p>
            ) : (
              <p className="text-sm text-gray-600">Nayi enquiry ({dup?.pending.name} — {dup?.pending.course}) add karni hai?</p>
            )}
            <div className="flex gap-2 pt-1">
              {!dup?.exact && (
                <Button className="flex-1 bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white" disabled={saving} onClick={() => dup && saveNow(dup.pending)}>
                  <Plus className="w-4 h-4 mr-1" /> Add
                </Button>
              )}
              <Button variant="outline" className="flex-1" onClick={() => setDup(null)}>{dup?.exact ? 'Close' : 'Cancel'}</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================================
// Enquiry List
// ============================================================================
function EnquiryListTab({ enquiries, courses, loading, onEdit, onWhatsApp, onChanged }: {
  enquiries: Enquiry[]; courses: string[]; loading: boolean;
  onEdit: (e: Enquiry) => void; onWhatsApp: (e: Enquiry) => void; onChanged: () => Promise<void>;
}) {
  const handleDelete = async (e: Enquiry) => {
    if (!window.confirm(`${e.name} ki enquiry delete karni hai? Ye wapas nahi aayegi.`)) return;
    await deleteEnquiry(e.id);
    toast.success('Enquiry delete ho gayi');
    await onChanged();
  };
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | EnquiryStatus>('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [page, setPage] = useState(1);

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 250);
    return () => clearTimeout(t);
  }, [searchInput]);
  useEffect(() => { setPage(1); }, [search, statusFilter, courseFilter, dateFrom, dateTo]);

  // course chips = admin's course list + any older course still present in the data
  const courseChips = useMemo(() => {
    const set = new Set(courses);
    enquiries.forEach((e) => e.course && set.add(e.course));
    return Array.from(set);
  }, [courses, enquiries]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return enquiries.filter((e) => {
      if (statusFilter !== 'all' && e.status !== statusFilter) return false;
      if (courseFilter !== 'all' && e.course !== courseFilter) return false;
      if (dateFrom || dateTo) {
        const d = toDateStr(new Date(e.createdAt));
        if (dateFrom && d < dateFrom) return false;
        if (dateTo && d > dateTo) return false;
      }
      if (q && !(e.name?.toLowerCase().includes(q) || e.phone?.includes(q) || e.course?.toLowerCase().includes(q) || e.source?.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [enquiries, search, statusFilter, courseFilter, dateFrom, dateTo]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const cur = Math.min(page, totalPages);
  const rows = filtered.slice((cur - 1) * PAGE_SIZE, cur * PAGE_SIZE);

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
        <Input className="pl-10" placeholder="Search Name, Phone, Course..." value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
      </div>

      <div className="flex flex-wrap gap-2">
        <Chip active={statusFilter === 'all'} onClick={() => setStatusFilter('all')}>All Status</Chip>
        {STATUS_OPTIONS.map((s) => (
          <Chip key={s.value} active={statusFilter === s.value} onClick={() => setStatusFilter(s.value)}>{s.label}</Chip>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Chip active={courseFilter === 'all'} onClick={() => setCourseFilter('all')}>All Course</Chip>
        {courseChips.map((c) => (
          <Chip key={c} active={courseFilter === c} onClick={() => setCourseFilter(c)}>{c}</Chip>
        ))}
      </div>

      <div className="flex flex-wrap items-center gap-2 text-sm">
        <CalendarDays className="w-4 h-4 text-gray-500" /> <span>Enquiry Date:</span>
        <Input type="date" className="w-40" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
        <span>se</span>
        <Input type="date" className="w-40" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
        {(dateFrom || dateTo) && (
          <Button size="sm" variant="outline" className="text-red-600 border-red-300" onClick={() => { setDateFrom(''); setDateTo(''); }}>
            <X className="w-3.5 h-3.5 mr-1" /> Clear
          </Button>
        )}
      </div>

      <div className="overflow-x-auto border rounded-lg">
        <Table>
          <TableHeader>
            <TableRow className="bg-[var(--app-bg)] hover:bg-[var(--app-bg)]">
              {['Name', 'Phone', 'Course', 'Source', 'Status', 'Actions'].map((h) => (
                <TableHead key={h} className="text-gray-800">{h}</TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.length > 0 ? rows.map((e) => (
              <TableRow key={e.id}>
                <TableCell>
                  <div className="font-medium">{e.name}</div>
                  <div className="text-xs text-gray-500">{formatDateTime(e.createdAt)}</div>
                </TableCell>
                <TableCell>{e.phone}</TableCell>
                <TableCell>{e.course}</TableCell>
                <TableCell>{e.source}</TableCell>
                <TableCell><StatusBadge status={e.status} /></TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-green-500/90 hover:bg-green-600 text-white" onClick={() => onWhatsApp(e)}>WA</Button>
                    <Button size="sm" className="bg-blue-500/90 hover:bg-blue-600 text-white" onClick={() => onEdit(e)}>
                      <Pencil className="w-3 h-3 mr-1" /> View
                    </Button>
                    <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => handleDelete(e)}>
                      <Trash2 className="w-3 h-3 mr-1" /> Delete
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            )) : (
              <TableRow>
                <TableCell colSpan={6} className="text-center py-8 text-gray-500">
                  {loading ? 'Loading enquiries...' : enquiries.length === 0 ? 'Abhi koi enquiry nahi hai. "Add Enquiry" se pehli enquiry add karein.' : 'Koi enquiry match nahi hui.'}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {filtered.length > 0 && (
        <div className="flex items-center justify-between flex-wrap gap-2">
          <p className="text-sm text-gray-500">
            Showing {(cur - 1) * PAGE_SIZE + 1}-{Math.min(cur * PAGE_SIZE, filtered.length)} of {filtered.length.toLocaleString()} enquiries
          </p>
          <div className="flex items-center gap-2">
            <Button size="sm" variant="outline" disabled={cur <= 1} onClick={() => setPage(1)}>First</Button>
            <Button size="sm" variant="outline" disabled={cur <= 1} onClick={() => setPage(cur - 1)}>Previous</Button>
            <span className="text-sm">Page {cur} of {totalPages.toLocaleString()}</span>
            <Button size="sm" variant="outline" disabled={cur >= totalPages} onClick={() => setPage(cur + 1)}>Next</Button>
            <Button size="sm" variant="outline" disabled={cur >= totalPages} onClick={() => setPage(totalPages)}>Last</Button>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// Follow-Up
// ============================================================================
function FollowUpTab({ enquiries, courses, onEdit, onWhatsApp, onChanged }: {
  enquiries: Enquiry[]; courses: string[];
  onEdit: (e: Enquiry) => void; onWhatsApp: (e: Enquiry) => void; onChanged: () => Promise<void>;
}) {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | EnquiryStatus>('all');
  const [courseFilter, setCourseFilter] = useState('all');
  const [snoozing, setSnoozing] = useState<Enquiry | null>(null);
  const [snoozeDate, setSnoozeDate] = useState('');
  const [converting, setConverting] = useState<Enquiry | null>(null);

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 250);
    return () => clearTimeout(t);
  }, [searchInput]);

  const courseChips = useMemo(() => {
    const set = new Set(courses);
    enquiries.forEach((e) => e.course && set.add(e.course));
    return Array.from(set);
  }, [courses, enquiries]);

  const today = todayStr();
  const pending = useMemo(() => {
    const q = search.trim().toLowerCase();
    return enquiries.filter((e) => {
      if (!isPendingFollowUp(e)) return false;
      if (statusFilter !== 'all' && e.status !== statusFilter) return false;
      if (courseFilter !== 'all' && e.course !== courseFilter) return false;
      if (q && !(e.name?.toLowerCase().includes(q) || e.phone?.includes(q) || e.course?.toLowerCase().includes(q))) return false;
      return true;
    });
  }, [enquiries, search, statusFilter, courseFilter]);

  const sortByDate = (a: Enquiry, b: Enquiry) => (a.followUpDate as string).localeCompare(b.followUpDate as string);
  const todayList = pending.filter((e) => e.followUpDate === today).sort(sortByDate);
  const overdue = pending.filter((e) => (e.followUpDate as string) < today).sort(sortByDate);
  const upcoming = pending.filter((e) => (e.followUpDate as string) > today).sort(sortByDate);

  // Converted -> popup asks Demo or Admission, then the enquiry moves to the Converted tab
  const convertTo = async (kind: 'demo' | 'admission') => {
    if (!converting) return;
    const now = new Date().toISOString();
    await saveEnquiry({ ...converting, converted: kind, convertedAt: now, admissionAt: kind === 'admission' ? now : undefined });
    toast.success(kind === 'admission'
      ? `${converting.name} — Admission! ${ADMISSION_KEEP_DAYS} din baad enquiry se auto-delete ho jayegi.`
      : `${converting.name} — Demo me Converted section me chali gayi.`);
    setConverting(null);
    await onChanged();
  };

  // Remove from follow-up: follow-up date/note cleared, enquiry stays in Enquiry List
  const removeFollowUp = async (e: Enquiry) => {
    if (!window.confirm(`${e.name} ko Follow-Up se hatana hai? (Enquiry List me rahegi)`)) return;
    await saveEnquiry({ ...e, followUpDate: undefined, followUpNote: undefined, followUpDone: false });
    toast.success(`${e.name} follow-up se hat gayi`);
    await onChanged();
  };

  const applySnooze = async (date: string) => {
    if (!snoozing || !date) return;
    await saveEnquiry({ ...snoozing, followUpDate: date, followUpDone: false });
    toast.success(`Follow-up ${formatDateOnly(date)} ko shift ho gaya`);
    setSnoozing(null);
    setSnoozeDate('');
    await onChanged();
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
        <Input className="pl-10" placeholder="Search Name, Phone, Course..." value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
      </div>
      <div className="flex flex-wrap gap-2">
        <Chip active={statusFilter === 'all'} onClick={() => setStatusFilter('all')}>All Status</Chip>
        {STATUS_OPTIONS.map((s) => (
          <Chip key={s.value} active={statusFilter === s.value} onClick={() => setStatusFilter(s.value)}>{s.label}</Chip>
        ))}
      </div>
      <div className="flex flex-wrap gap-2">
        <Chip active={courseFilter === 'all'} onClick={() => setCourseFilter('all')}>All Course</Chip>
        {courseChips.map((c) => (
          <Chip key={c} active={courseFilter === c} onClick={() => setCourseFilter(c)}>{c}</Chip>
        ))}
      </div>

      {todayList.length === 0 ? (
        <div className="flex items-center gap-2 bg-green-600/90 text-white rounded-md px-4 py-3 font-medium">
          <CheckCircle2 className="w-5 h-5" /> Aaj ke liye koi follow-up nahi!
        </div>
      ) : (
        <FollowUpSection title={`Aaj ke follow-ups — ${todayList.length}`} tone="blue" items={todayList} onEdit={onEdit} onWhatsApp={onWhatsApp} onSnooze={(e) => { setSnoozing(e); setSnoozeDate(''); }} onConverted={setConverting} onRemove={removeFollowUp} />
      )}

      {overdue.length > 0 && (
        <FollowUpSection title={`⚠️ Overdue — ${overdue.length} baaki hain (date nikal gayi)`} tone="red" items={overdue} onEdit={onEdit} onWhatsApp={onWhatsApp} onSnooze={(e) => { setSnoozing(e); setSnoozeDate(''); }} onConverted={setConverting} onRemove={removeFollowUp} />
      )}

      {upcoming.length > 0 && (
        <FollowUpSection title={`📅 Upcoming — ${upcoming.length}`} tone="gray" items={upcoming} onEdit={onEdit} onWhatsApp={onWhatsApp} onSnooze={(e) => { setSnoozing(e); setSnoozeDate(''); }} onConverted={setConverting} onRemove={removeFollowUp} />
      )}

      {pending.length === 0 && (
        <p className="text-center text-gray-500 py-6 text-sm">Koi pending follow-up nahi hai. Enquiry add/edit karte waqt Follow-Up Date daalne par yaha dikhegi.</p>
      )}

      {/* Converted -> Demo or Admission */}
      <Dialog open={!!converting} onOpenChange={(o) => { if (!o) setConverting(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><UserCheck className="w-4 h-4" /> Converted — {converting?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-600">Ye student kya hua?</p>
            <div className="grid grid-cols-2 gap-2">
              <Button className="h-12 bg-blue-500/90 hover:bg-blue-600 text-white" onClick={() => convertTo('demo')}>Demo</Button>
              <Button className="h-12 bg-green-600/90 hover:bg-green-700 text-white" onClick={() => convertTo('admission')}>Admission</Button>
            </div>
            <p className="text-xs text-gray-500">Admission chunne par enquiry {ADMISSION_KEEP_DAYS} din baad apne aap delete ho jayegi.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Snooze dialog */}
      <Dialog open={!!snoozing} onOpenChange={(o) => { if (!o) setSnoozing(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><AlarmClock className="w-4 h-4" /> Snooze — {snoozing?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-600">Follow-up kab karna hai?</p>
            <div className="grid grid-cols-3 gap-2">
              <Button variant="outline" onClick={() => applySnooze(addDaysStr(1))}>Kal</Button>
              <Button variant="outline" onClick={() => applySnooze(addDaysStr(3))}>3 din baad</Button>
              <Button variant="outline" onClick={() => applySnooze(addDaysStr(7))}>1 hafta baad</Button>
            </div>
            <div>
              <Label>Ya apni date chunein</Label>
              <Input className="mt-1" type="date" min={today} value={snoozeDate} onChange={(e) => setSnoozeDate(e.target.value)} />
            </div>
            <Button className="w-full bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white" disabled={!snoozeDate} onClick={() => applySnooze(snoozeDate)}>Save Date</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function FollowUpSection({ title, tone, items, onEdit, onWhatsApp, onSnooze, onConverted, onRemove }: {
  title: string; tone: 'red' | 'blue' | 'gray'; items: Enquiry[];
  onEdit: (e: Enquiry) => void; onWhatsApp: (e: Enquiry) => void; onSnooze: (e: Enquiry) => void;
  onConverted: (e: Enquiry) => void; onRemove: (e: Enquiry) => void;
}) {
  // Only the first 50 cards are drawn at once (a long overdue list stays light)
  const [limit, setLimit] = useState(50);
  const head = tone === 'red' ? 'bg-red-500/90' : tone === 'blue' ? 'bg-blue-500/90' : 'bg-gray-500/90';
  const border = tone === 'red' ? 'border-red-600' : tone === 'blue' ? 'border-blue-600' : 'border-gray-400';
  return (
    <div className="space-y-2">
      <div className={`${head} text-white rounded-md px-4 py-2.5 font-medium`}>{title}</div>
      {items.slice(0, limit).map((e) => (
        <div key={e.id} className={`border-l-4 ${border} bg-white rounded-md shadow-sm p-3 space-y-2`}>
          <div className="flex items-center flex-wrap gap-2">
            <span className="font-semibold text-base">{e.name}</span>
            <span className="text-gray-500">— {e.course}</span>
            <StatusBadge status={e.status} />
          </div>
          <div className="text-sm text-gray-600 flex items-center flex-wrap gap-x-3 gap-y-1">
            <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {e.phone}</span>
            <span>| {e.source}</span>
            <span>| Enquiry: {formatDateTime(e.createdAt)}</span>
            <span className="font-medium text-gray-800">| Follow-up: {formatDateOnly(e.followUpDate as string)}</span>
          </div>
          {e.followUpNote && (
            <div className="bg-yellow-50 text-orange-700 italic text-sm rounded px-3 py-1.5">📝 {e.followUpNote}</div>
          )}
          <div className="flex flex-wrap gap-2">
            <Button size="sm" className="bg-green-500/90 hover:bg-green-600 text-white" onClick={() => onWhatsApp(e)}><MessageCircle className="w-3.5 h-3.5 mr-1" /> WA Message</Button>
            <Button size="sm" className="bg-blue-500/90 hover:bg-blue-600 text-white" onClick={() => onEdit(e)}><Pencil className="w-3.5 h-3.5 mr-1" /> Edit</Button>
            <Button size="sm" className="bg-purple-500/90 hover:bg-purple-600 text-white" onClick={() => onSnooze(e)}><AlarmClock className="w-3.5 h-3.5 mr-1" /> Snooze</Button>
            <Button size="sm" className="bg-green-600/90 hover:bg-green-700 text-white" onClick={() => onConverted(e)}><UserCheck className="w-3.5 h-3.5 mr-1" /> Converted</Button>
            <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => onRemove(e)}><MinusCircle className="w-3.5 h-3.5 mr-1" /> Remove from Follow-Up</Button>
          </div>
        </div>
      ))}
      {items.length > limit && (
        <Button variant="outline" className="w-full" onClick={() => setLimit(limit + 50)}>Aur dikhao ({items.length - limit} baaki)</Button>
      )}
    </div>
  );
}

// ============================================================================
// Converted (Demo / Admission)
// ============================================================================
function ConvertedTab({ enquiries, onEdit, onWhatsApp, onChanged }: {
  enquiries: Enquiry[]; onEdit: (e: Enquiry) => void; onWhatsApp: (e: Enquiry) => void; onChanged: () => Promise<void>;
}) {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | 'demo' | 'admission'>('all');
  const [switching, setSwitching] = useState<Enquiry | null>(null);
  const [fuDate, setFuDate] = useState('');
  const [fuNote, setFuNote] = useState('');

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 250);
    return () => clearTimeout(t);
  }, [searchInput]);

  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    return enquiries
      .filter((e) => !!e.converted)
      .filter((e) => typeFilter === 'all' || e.converted === typeFilter)
      .filter((e) => !q || e.name?.toLowerCase().includes(q) || e.phone?.includes(q) || e.course?.toLowerCase().includes(q))
      .sort((a, b) => (b.convertedAt || '').localeCompare(a.convertedAt || ''));
  }, [enquiries, search, typeFilter]);

  const demoCount = enquiries.filter((e) => e.converted === 'demo').length;
  const admissionCount = enquiries.filter((e) => e.converted === 'admission').length;

  // Admin can still change Demo <-> Admission before the data is deleted
  const changeType = async (e: Enquiry, kind: 'demo' | 'admission') => {
    if (e.converted === kind) return;
    await saveEnquiry({ ...e, converted: kind, admissionAt: kind === 'admission' ? new Date().toISOString() : undefined });
    toast.success(kind === 'admission' ? `Admission set — ${ADMISSION_KEEP_DAYS} din baad auto-delete hogi` : 'Demo set ho gaya (auto-delete band)');
    await onChanged();
  };

  const remove = async (e: Enquiry) => {
    if (!window.confirm(`${e.name} ki enquiry delete karni hai? Ye wapas nahi aayegi.`)) return;
    await deleteEnquiry(e.id);
    toast.success('Enquiry delete ho gayi');
    await onChanged();
  };

  const switchToFollowUp = async () => {
    if (!switching) return;
    if (!fuDate) { toast.error('Follow-up date chunein!'); return; }
    await saveEnquiry({
      ...switching,
      converted: undefined, convertedAt: undefined, admissionAt: undefined,
      followUpDate: fuDate, followUpNote: fuNote.trim() || undefined, followUpDone: false,
    });
    toast.success(`${switching.name} wapas Follow-Up me aa gayi`);
    setSwitching(null); setFuDate(''); setFuNote('');
    await onChanged();
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
        <Input className="pl-10" placeholder="Search Name, Phone, Course..." value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
      </div>
      <div className="flex flex-wrap gap-2">
        <Chip active={typeFilter === 'all'} onClick={() => setTypeFilter('all')}>All ({demoCount + admissionCount})</Chip>
        <Chip active={typeFilter === 'demo'} onClick={() => setTypeFilter('demo')}>Demo ({demoCount})</Chip>
        <Chip active={typeFilter === 'admission'} onClick={() => setTypeFilter('admission')}>Admission ({admissionCount})</Chip>
      </div>
      <p className="text-xs text-gray-500">Admission wali enquiry {ADMISSION_KEEP_DAYS} din baad apne aap delete ho jati hai. Usse pehle Demo/Admission badal sakte hain ya wapas Follow-Up me bhej sakte hain.</p>

      {list.length === 0 ? (
        <p className="text-center text-gray-500 py-8 text-sm">Abhi koi converted enquiry nahi hai. Follow-Up me "Converted" dabane par yaha dikhegi.</p>
      ) : list.map((e) => (
        <div key={e.id} className="border-l-4 border-green-500 bg-white rounded-md shadow-sm p-3 space-y-2">
          <div className="flex items-center flex-wrap gap-2">
            <span className="font-semibold text-base">{e.name}</span>
            <span className="text-gray-500">— {e.course}</span>
            <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-medium ${e.converted === 'admission' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>
              {e.converted === 'admission' ? '🎓 Admission' : '🎯 Demo'}
            </span>
            {e.converted === 'admission' && (
              <span className="text-xs text-red-600">⏳ {daysLeftToDelete(e)} din baad auto-delete</span>
            )}
          </div>
          <div className="text-sm text-gray-600 flex items-center flex-wrap gap-x-3 gap-y-1">
            <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {e.phone}</span>
            <span>| {e.source}</span>
            <span>| Enquiry: {formatDateTime(e.createdAt)}</span>
            {e.convertedAt && <span>| Converted: {formatDateTime(e.convertedAt)}</span>}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Select value={e.converted} onValueChange={(v) => changeType(e, v as 'demo' | 'admission')}>
              <SelectTrigger className="h-8 w-36 text-sm"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="demo">Demo</SelectItem>
                <SelectItem value="admission">Admission</SelectItem>
              </SelectContent>
            </Select>
            <Button size="sm" className="bg-green-500/90 hover:bg-green-600 text-white" onClick={() => onWhatsApp(e)}><MessageCircle className="w-3.5 h-3.5 mr-1" /> WA</Button>
            <Button size="sm" className="bg-purple-500/90 hover:bg-purple-600 text-white" onClick={() => { setSwitching(e); setFuDate(''); setFuNote(''); }}><Repeat className="w-3.5 h-3.5 mr-1" /> Switch to Follow-Up</Button>
            <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => remove(e)}><Trash2 className="w-3.5 h-3.5 mr-1" /> Delete</Button>
          </div>
        </div>
      ))}

      <Dialog open={!!switching} onOpenChange={(o) => { if (!o) setSwitching(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Repeat className="w-4 h-4" /> Switch to Follow-Up — {switching?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Follow-Up Date *</Label>
              <Input className="mt-1" type="date" min={todayStr()} value={fuDate} onChange={(e) => setFuDate(e.target.value)} />
            </div>
            <div>
              <Label>Follow-Up Notes</Label>
              <Input className="mt-1" value={fuNote} onChange={(e) => setFuNote(e.target.value)} placeholder="e.g. Monday aayenge, fees discuss karni hai" />
            </div>
            <Button className="w-full bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white" disabled={!fuDate} onClick={switchToFollowUp}>Follow-Up me bhejo</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================================
// QR Enquiry (students fill the QR form in the office -> arrives here)
// Switch to Follow-Up / WhatsApp / Convert (Demo or Admission) / Delete
// ============================================================================
function QrEnquiryTab({ enquiries, allEnquiries, qrOn, onWhatsApp, onChanged }: {
  enquiries: Enquiry[]; allEnquiries: Enquiry[]; qrOn: boolean; onWhatsApp: (e: Enquiry) => void; onChanged: () => Promise<void>;
}) {
  const [searchInput, setSearchInput] = useState('');
  const [search, setSearch] = useState('');
  const [switching, setSwitching] = useState<Enquiry | null>(null);
  const [fuDate, setFuDate] = useState('');
  const [fuNote, setFuNote] = useState('');
  const [converting, setConverting] = useState<Enquiry | null>(null);
  const [limit, setLimit] = useState(50);
  // same name + same phone as an earlier enquiry (anywhere in the Enquiry section) -> warning + old details
  const [oldFor, setOldFor] = useState<Enquiry | null>(null);
  const repeatMap = useMemo(() => buildRepeatMap(allEnquiries), [allEnquiries]);

  useEffect(() => {
    const t = setTimeout(() => setSearch(searchInput), 250);
    return () => clearTimeout(t);
  }, [searchInput]);

  const list = useMemo(() => {
    const q = search.trim().toLowerCase();
    return enquiries
      .filter((e) => !q || e.name?.toLowerCase().includes(q) || e.phone?.includes(q) || e.course?.toLowerCase().includes(q))
      .sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''));
  }, [enquiries, search]);

  // Switch to Follow-Up: leaves the QR tab, shows in Follow-Up (and in Enquiry List)
  const switchToFollowUp = async () => {
    if (!switching) return;
    if (!fuDate) { toast.error('Follow-up date chunein!'); return; }
    await saveEnquiry({
      ...switching,
      qrPending: false,
      followUpDate: fuDate, followUpNote: fuNote.trim() || undefined, followUpDone: false,
    });
    toast.success(`${switching.name} Follow-Up me chali gayi`);
    setSwitching(null); setFuDate(''); setFuNote('');
    await onChanged();
  };

  // Convert: same popup as Follow-Up -> Demo or Admission, then it moves to the Converted tab
  const convertTo = async (kind: 'demo' | 'admission') => {
    if (!converting) return;
    const now = new Date().toISOString();
    await saveEnquiry({ ...converting, qrPending: false, converted: kind, convertedAt: now, admissionAt: kind === 'admission' ? now : undefined });
    toast.success(kind === 'admission'
      ? `${converting.name} — Admission! ${ADMISSION_KEEP_DAYS} din baad enquiry se auto-delete ho jayegi.`
      : `${converting.name} — Demo me Converted section me chali gayi.`);
    setConverting(null);
    await onChanged();
  };

  // Delete only removes it from this computer (the Google Sheet is cleaned automatically after 7 days)
  const remove = async (e: Enquiry) => {
    if (!window.confirm(`${e.name} ki enquiry delete karni hai? Ye wapas nahi aayegi.`)) return;
    await deleteEnquiry(e.id);
    toast.success('Enquiry delete ho gayi');
    await onChanged();
  };

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
        <Input className="pl-10" placeholder="Search Name, Phone, Course..." value={searchInput} onChange={(e) => setSearchInput(e.target.value)} />
      </div>

      {list.length === 0 ? (
        <p className="text-center text-gray-500 py-8 text-sm">
          {enquiries.length === 0 ? 'Abhi koi nayi QR enquiry nahi hai. Student QR scan karke form bharega to yaha aa jayegi.' : 'Koi enquiry match nahi hui.'}
        </p>
      ) : list.slice(0, limit).map((e) => (
        <div key={e.id} className="border-l-4 border-orange-500 bg-white rounded-md shadow-sm p-3 space-y-2">
          <div className="flex items-center flex-wrap gap-2">
            <span className="font-semibold text-base">{e.name}</span>
            <span className="text-gray-500">— {e.course}</span>
            <span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium bg-orange-100 text-orange-800">🆕 QR</span>
          </div>
          <div className="text-sm text-gray-600 flex items-center flex-wrap gap-x-3 gap-y-1">
            <span className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {e.phone}</span>
            <span>| {e.source}</span>
            <span>| Enquiry: {formatDateTime(e.createdAt)}</span>
          </div>
          {repeatMap.has(e.id) && <RepeatNotice onView={() => setOldFor(e)} />}
          <div className="flex flex-wrap gap-2">
            <Button size="sm" className="bg-purple-500/90 hover:bg-purple-600 text-white" onClick={() => { setSwitching(e); setFuDate(''); setFuNote(''); }}><Repeat className="w-3.5 h-3.5 mr-1" /> Switch to Follow-Up</Button>
            <Button size="sm" className="bg-green-500/90 hover:bg-green-600 text-white" onClick={() => onWhatsApp(e)}><MessageCircle className="w-3.5 h-3.5 mr-1" /> WhatsApp</Button>
            <Button size="sm" className="bg-green-600/90 hover:bg-green-700 text-white" onClick={() => setConverting(e)}><UserCheck className="w-3.5 h-3.5 mr-1" /> Convert</Button>
            <Button size="sm" variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={() => remove(e)}><Trash2 className="w-3.5 h-3.5 mr-1" /> Delete</Button>
          </div>
        </div>
      ))}
      {list.length > limit && (
        <Button variant="outline" className="w-full" onClick={() => setLimit(limit + 50)}>Aur dikhao ({list.length - limit} baaki)</Button>
      )}

      <OldEnquiryDialog enquiry={oldFor} olds={oldFor ? repeatMap.get(oldFor.id) || [] : []} qrOn={qrOn} onClose={() => setOldFor(null)} />

      {/* Convert -> Demo or Admission (same popup as Follow-Up) */}
      <Dialog open={!!converting} onOpenChange={(o) => { if (!o) setConverting(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><UserCheck className="w-4 h-4" /> Converted — {converting?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-gray-600">Ye student kya hua?</p>
            <div className="grid grid-cols-2 gap-2">
              <Button className="h-12 bg-blue-500/90 hover:bg-blue-600 text-white" onClick={() => convertTo('demo')}>Demo</Button>
              <Button className="h-12 bg-green-600/90 hover:bg-green-700 text-white" onClick={() => convertTo('admission')}>Admission</Button>
            </div>
            <p className="text-xs text-gray-500">Admission chunne par enquiry {ADMISSION_KEEP_DAYS} din baad apne aap delete ho jayegi.</p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Switch to Follow-Up */}
      <Dialog open={!!switching} onOpenChange={(o) => { if (!o) setSwitching(null); }}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Repeat className="w-4 h-4" /> Switch to Follow-Up — {switching?.name}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div>
              <Label>Follow-Up Date *</Label>
              <Input className="mt-1" type="date" min={todayStr()} value={fuDate} onChange={(e) => setFuDate(e.target.value)} />
            </div>
            <div>
              <Label>Follow-Up Notes</Label>
              <Input className="mt-1" value={fuNote} onChange={(e) => setFuNote(e.target.value)} placeholder="e.g. Monday aayenge, fees discuss karni hai" />
            </div>
            <Button className="w-full bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white" disabled={!fuDate} onClick={switchToFollowUp}>Follow-Up me bhejo</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// ============================================================================
// View / Edit dialog (used from Enquiry List and Follow-Up)
// ============================================================================
function EnquiryEditDialog({ enquiry, courses, sources, onClose, onChanged, onWhatsApp }: {
  enquiry: Enquiry | null; courses: string[]; sources: string[];
  onClose: () => void; onChanged: () => Promise<void>; onWhatsApp: (e: Enquiry) => void;
}) {
  const [form, setForm] = useState<Enquiry | null>(null);
  useEffect(() => { setForm(enquiry ? { ...enquiry } : null); }, [enquiry]);

  if (!form) return null;

  const courseOptions = form.course && !courses.includes(form.course) ? [form.course, ...courses] : courses;
  const sourceOptions = form.source && !sources.includes(form.source) ? [form.source, ...sources] : sources;
  const set = (patch: Partial<Enquiry>) => setForm((f) => (f ? { ...f, ...patch } : f));

  const handleSave = async () => {
    if (!form.name.trim()) { toast.error('Naam likhein!'); return; }
    const phone = form.phone;
    if (!/^\d{10}$/.test(phone)) { toast.error('Phone No sirf 10 digit ka hona chahiye!'); return; }
    const dateChanged = form.followUpDate !== enquiry?.followUpDate;
    await saveEnquiry({
      ...form,
      name: form.name.trim(),
      phone,
      followUpDate: form.followUpDate || undefined,
      followUpNote: (form.followUpNote || '').trim() || undefined,
      // a new/changed follow-up date puts it back in the pending list
      followUpDone: dateChanged ? false : form.followUpDone,
    });
    toast.success('Enquiry update ho gayi!');
    await onChanged();
  };

  return (
    <Dialog open={!!enquiry} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Enquiry Details</DialogTitle></DialogHeader>
        <div className="space-y-3">
          <p className="text-xs text-gray-500">Enquiry date: {formatDateTime(form.createdAt)}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div><Label>Student Name</Label><Input className="mt-1" value={form.name} onChange={(e) => set({ name: e.target.value })} /></div>
            <div><Label>Phone No</Label><Input className="mt-1" inputMode="numeric" maxLength={10} value={form.phone} onChange={(e) => set({ phone: e.target.value.replace(/\D/g, '').slice(0, 10) })} /></div>
          </div>
          <div>
            <Label>Course</Label>
            <Select value={form.course} onValueChange={(v) => set({ course: v })}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select course" /></SelectTrigger>
              <SelectContent>{courseOptions.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Query Source</Label>
            <Select value={form.source} onValueChange={(v) => set({ source: v })}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select source" /></SelectTrigger>
              <SelectContent>{sourceOptions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onValueChange={(v) => set({ status: v as EnquiryStatus })}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>{STATUS_OPTIONS.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
            </Select>
          </div>
          <div className="border-2 border-dashed border-[var(--brand)]/50 bg-[var(--app-bg)]/40 rounded-lg p-3 space-y-3">
            <div>
              <Label>Follow-Up Date (Optional)</Label>
              <Input className="mt-1 bg-white" type="date" value={form.followUpDate || ''} onChange={(e) => set({ followUpDate: e.target.value })} />
            </div>
            <div>
              <Label>Follow-Up Note (Optional)</Label>
              <Input className="mt-1 bg-white" value={form.followUpNote || ''} onChange={(e) => set({ followUpNote: e.target.value })} />
            </div>
            {form.followUpDate && form.followUpDone && (
              <p className="text-xs text-green-700">✅ Ye follow-up Done ho chuka hai. Nayi date daalne par wapas pending me aa jayega.</p>
            )}
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            <Button onClick={handleSave} className="bg-[var(--brand)] hover:bg-[var(--brand-hover)] text-white"><Save className="w-4 h-4 mr-1" /> Save</Button>
            <Button variant="outline" className="text-green-700 border-green-400" onClick={() => onWhatsApp(form)}><MessageCircle className="w-4 h-4 mr-1" /> WhatsApp</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
