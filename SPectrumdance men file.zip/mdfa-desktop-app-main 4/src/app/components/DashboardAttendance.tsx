import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card } from './ui/card';
import { CalendarCheck, ArrowRight, UserCheck, UserX, Clock } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { getStudentsLite } from '../lib/indexedDB';
import { getBatches } from '../lib/storageAdapter';
import { batchSortKey } from '../lib/batchTime';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import {
  AttendanceRecord,
  fetchAttendance,
  getCachedAttendance,
  getSubmittedBatches,
} from '../lib/attendance';

const NO_BATCH = '__none__';
const batchKeyOf = (s: any) => (s.batchTime && String(s.batchTime).trim()) || NO_BATCH;
const localToday = () => new Date().toLocaleDateString('en-CA');

/** "07:30 - 09:00" -> "07:30", "4:30 To 6:00 Pm" -> "4:30" (short x-axis label) */
const shortLabel = (key: string) => (key === NO_BATCH ? 'No Batch' : (String(key).match(/\d{1,2}:\d{2}/)?.[0] || String(key).slice(0, 8)));

/**
 * Dashboard -> "Today's Attendance": Present / Absent / Pending plus a batch-wise chart.
 *  - Present  = checked in (QR, staff or admin), updates live
 *  - Absent   = not checked in, counted only for batches whose attendance was SUBMITTED (Daily Attendance)
 *  - Pending  = not checked in yet in batches that are not submitted
 * "View Report" opens the Reports tab; "View All" opens Daily Attendance.
 */
export function DashboardAttendance({ date, onViewAll, onViewReport }: { date: string; onViewAll: () => void; onViewReport?: () => void }) {
  const { matchesLocation, selectedLocation } = useLocationFilter();
  const [students, setStudents] = useState<any[]>([]);
  const [batchInfos, setBatchInfos] = useState<any[]>([]);
  const [records, setRecords] = useState<Record<string, AttendanceRecord>>({});
  const [submitted, setSubmitted] = useState<string[]>([]);

  const loadBase = useCallback(async () => {
    const [all, b] = await Promise.all([getStudentsLite(), getBatches()]);
    setStudents(all.filter((s: any) => !s.deactivated && matchesLocation(s.location)));
    setBatchInfos((b || []).filter((x: any) => !x.location || matchesLocation(x.location)));
  }, [selectedLocation]);

  const loadLocal = useCallback(async () => {
    const local = await getCachedAttendance(date);
    setRecords(local ? local.records : {});
    setSubmitted(await getSubmittedBatches(date));
  }, [date]);

  useEffect(() => { loadBase().catch(() => {}); }, [loadBase]);
  useEffect(() => {
    const h = () => loadBase().catch(() => {});
    window.addEventListener('studentsUpdated', h);
    window.addEventListener('batchesUpdated', h);
    return () => { window.removeEventListener('studentsUpdated', h); window.removeEventListener('batchesUpdated', h); };
  }, [loadBase]);

  // saved copy first, then one catch-up from Google; after that the live sync keeps firing "attendanceUpdated"
  useEffect(() => {
    let alive = true;
    loadLocal();
    fetchAttendance(date).then((r) => { if (alive) setRecords(r.records); }).catch(() => {});
    return () => { alive = false; };
  }, [date, loadLocal]);
  useEffect(() => {
    window.addEventListener('attendanceUpdated', loadLocal);
    return () => window.removeEventListener('attendanceUpdated', loadLocal);
  }, [loadLocal]);

  const rows = useMemo(() => {
    const map = new Map<string, { total: number; present: number }>();
    batchInfos.forEach((b: any) => { const k = (b.batchTime && String(b.batchTime).trim()) || ''; if (k) map.set(k, { total: 0, present: 0 }); });
    students.forEach((s) => {
      const k = batchKeyOf(s);
      const e = map.get(k) || { total: 0, present: 0 };
      e.total++;
      if (records[String(s.regNo).toLowerCase()]?.checkIn) e.present++;
      map.set(k, e);
    });
    return Array.from(map.entries())
      .filter(([, v]) => v.total > 0)
      .sort((a, b) => batchSortKey(a[0]) - batchSortKey(b[0]) || a[0].localeCompare(b[0]))
      .map(([key, v]) => {
        const isSub = submitted.includes(key);
        const notIn = Math.max(0, v.total - v.present);
        return {
          key,
          label: shortLabel(key),
          full: key === NO_BATCH ? 'No Batch' : key,
          total: v.total,
          Present: v.present,
          Absent: isSub ? notIn : 0,
          Pending: isSub ? 0 : notIn,
        };
      });
  }, [batchInfos, students, records, submitted]);

  const totals = useMemo(() => rows.reduce((a, r) => ({
    present: a.present + r.Present,
    absent: a.absent + r.Absent,
    pending: a.pending + r.Pending,
  }), { present: 0, absent: 0, pending: 0 }), [rows]);

  const isToday = date === localToday();
  const dateLabel = date ? date.split('-').reverse().join('/') : '';

  const tile = (label: string, value: number, Icon: any, cls: string, iconCls: string) => (
    <div className={`rounded-lg border px-3 py-2 flex items-center gap-3 ${cls}`}>
      <Icon className={`w-7 h-7 shrink-0 ${iconCls}`} />
      <div className="leading-tight">
        <p className="text-xs text-gray-600">{label}</p>
        <p className="text-2xl font-bold">{value}</p>
      </div>
    </div>
  );

  return (
    <Card className="h-full min-h-0 gap-2 p-4">
      <div className="flex items-center justify-between">
        <h4 className="flex items-center gap-2 leading-none">
          <span className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center"><CalendarCheck className="w-5 h-5 text-orange-600" /></span>
          {isToday ? "Today's Attendance" : `Attendance — ${dateLabel}`}
        </h4>
        <button type="button" onClick={onViewReport || onViewAll} className="text-sm text-blue-600 hover:underline flex items-center gap-1">
          View Report <ArrowRight className="w-4 h-4" />
        </button>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {tile('Present', totals.present, UserCheck, 'bg-green-50 border-green-200', 'text-green-600')}
        {tile('Absent', totals.absent, UserX, 'bg-red-50 border-red-200', 'text-red-500')}
        {tile('Pending', totals.pending, Clock, 'bg-blue-50 border-blue-200', 'text-blue-500')}
      </div>

      <div className="flex items-center justify-between">
        <p className="font-semibold text-sm">Batch-wise Attendance</p>
        <div className="flex items-center gap-3 text-xs text-gray-600">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-500" />Present</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500" />Absent</span>
          <button type="button" onClick={onViewAll} className="text-blue-600 hover:underline flex items-center gap-1 text-sm">
            View All <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 min-h-0">
        {rows.length === 0 ? (
          <div className="h-full flex items-center justify-center text-sm text-gray-500">Abhi koi batch / student nahi hai</div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={rows} margin={{ top: 4, right: 4, left: -20, bottom: 0 }} barGap={2}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} interval={0} angle={rows.length > 8 ? -35 : 0} textAnchor={rows.length > 8 ? 'end' : 'middle'} height={rows.length > 8 ? 40 : 22} tickLine={false} />
              <YAxis tick={{ fontSize: 10 }} allowDecimals={false} tickLine={false} axisLine={false} />
              <Tooltip
                cursor={{ fill: 'rgba(0,0,0,0.04)' }}
                labelFormatter={(_l, payload) => (payload && payload[0] ? (payload[0].payload as any).full : '')}
                formatter={(value: any, name: any) => [value, name]}
              />
              <Bar dataKey="Present" fill="#22c55e" radius={[3, 3, 0, 0]} maxBarSize={22} />
              <Bar dataKey="Absent" fill="#ef4444" radius={[3, 3, 0, 0]} maxBarSize={22} />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </Card>
  );
}
