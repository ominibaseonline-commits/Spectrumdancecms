import { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { LogOut, User, Calendar, CreditCard, Clock } from 'lucide-react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { getPaymentsByStudent } from '../lib/storageAdapter';
import { useFormLayout } from '../lib/formLayout';
import { StudentIdCardView } from './StudentIdCardView';

interface StudentDashboardProps {
  user: any;
  onLogout: () => void;
}

export function StudentDashboard({ user, onLogout }: StudentDashboardProps) {
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const { isVisible, label: lbl } = useFormLayout(); // hidden fields are skipped

  useEffect(() => {
    // Load payment history for this student from IndexedDB
    const loadPayments = async () => {
      const studentPayments = await getPaymentsByStudent(user.regNo);
      setPaymentHistory(studentPayments);
    };
    loadPayments();
  }, [user.regNo]);

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB');
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: 'var(--app-bg)' }}>
      <div style={{ backgroundColor: 'var(--brand)', padding: '24px' }}>
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <h1 className="text-white">Mayuri Dance & Fitness Academy</h1>
          <Button onClick={onLogout} variant="secondary">
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto p-6 space-y-6">
        {/* Student Profile Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="w-5 h-5" />
              My Profile
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <p className="text-gray-500">Registration No</p>
                <p>{user.regNo}</p>
              </div>
              <div>
                <p className="text-gray-500">Name</p>
                <p>{user.name}</p>
              </div>
              <div>
                <p className="text-gray-500">Mobile</p>
                <p>{user.mobile}</p>
              </div>
              {isVisible('email') && (
              <div>
                <p className="text-gray-500">{lbl('email', 'Email')}</p>
                <p>{user.email || 'N/A'}</p>
              </div>
              )}
              {isVisible('dob') && (
              <div>
                <p className="text-gray-500">{lbl('dob', 'Date of Birth')}</p>
                <p>{formatDate(user.dob)}</p>
              </div>
              )}
              {isVisible('gender') && (
              <div>
                <p className="text-gray-500">{lbl('gender', 'Gender')}</p>
                <p>{user.gender}</p>
              </div>
              )}
              {isVisible('guardianName') && (
              <div>
                <p className="text-gray-500">{lbl('guardianName', 'Guardian Name')}</p>
                <p>{user.guardianName}</p>
              </div>
              )}
              {isVisible('guardianRelation') && (
              <div>
                <p className="text-gray-500">{lbl('guardianRelation', 'Guardian Relation')}</p>
                <p>{user.guardianRelation}</p>
              </div>
              )}
              {isVisible('address') && (
              <div>
                <p className="text-gray-500">{lbl('address', 'Address')}</p>
                <p>{user.address}</p>
              </div>
              )}
              <div>
                <p className="text-gray-500">Category</p>
                <p>{user.category}</p>
              </div>
              <div>
                <p className="text-gray-500">Batch Time</p>
                <p>{user.batchTime}</p>
              </div>
              <div>
                <p className="text-gray-500">Location</p>
                <p>{user.location}</p>
              </div>
              <div>
                <p className="text-gray-500">Admission Date</p>
                <p>{formatDate(user.admissionDate)}</p>
              </div>
              <div>
                <p className="text-gray-500">Expiry Date</p>
                <p className={new Date(user.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>
                  {formatDate(user.expiryDate)}
                </p>
              </div>
              <div>
                <p className="text-gray-500">Status</p>
                <p className={user.status === 'active' ? 'text-green-600' : 'text-red-600'}>
                  {user.status?.toUpperCase()}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* ID Card (Settings -> ID Card ON ho tabhi) */}
        <StudentIdCardView student={user} />

        {/* Payment Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CreditCard className="w-5 h-5" />
              Payment Summary
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <p className="text-gray-500">Total Amount Paid</p>
                <p className="text-blue-600">₹{user.paidAmount || 0}</p>
              </div>
              <div className="p-4 bg-orange-50 rounded-lg">
                <p className="text-gray-500">Total Dues</p>
                <p className="text-orange-600">₹{user.dues || 0}</p>
              </div>
              <div className="p-4 bg-green-50 rounded-lg">
                <p className="text-gray-500">Total Payments</p>
                <p className="text-green-600">{paymentHistory.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Payment History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Payment History
            </CardTitle>
          </CardHeader>
          <CardContent>
            {paymentHistory.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Payment Date</TableHead>
                      <TableHead>Session Date</TableHead>
                      <TableHead>Session Expiry</TableHead>
                      <TableHead>Duration</TableHead>
                      <TableHead>Total Amount</TableHead>
                      <TableHead>Paid Amount</TableHead>
                      <TableHead>Dues</TableHead>
                      <TableHead>Payment Mode</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {paymentHistory.map((payment, index) => (
                      <TableRow key={index}>
                        <TableCell>{formatDate(payment.paymentDate)}</TableCell>
                        <TableCell>{formatDate(payment.sessionDate)}</TableCell>
                        <TableCell>{formatDate(payment.sessionExpiryDate)}</TableCell>
                        <TableCell>{payment.duration} {payment.durationType}</TableCell>
                        <TableCell>₹{payment.totalAmount}</TableCell>
                        <TableCell>₹{payment.paidAmount}</TableCell>
                        <TableCell>₹{payment.dues}</TableCell>
                        <TableCell>{payment.paymentMode}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <p className="text-center text-gray-500 py-8">No payment history found</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
