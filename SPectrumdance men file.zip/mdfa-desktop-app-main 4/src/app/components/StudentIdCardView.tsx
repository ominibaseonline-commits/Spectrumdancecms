import { useMemo, useState } from 'react';
import { toast } from 'sonner';
import { IdCard, Download } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import {
  ID_CARD_CSS, buildIdCardAssets, buildIdCardPdf, downloadBlob, idCardData, renderIdCardSide, useIdCardSettings,
} from '../lib/idCard';

// Student Dashboard me "My ID Card": Settings -> ID Card ka wahi design (ON ho tabhi dikhta hai).
export function StudentIdCardView({ student }: { student: any }) {
  const { settings } = useIdCardSettings();
  const [busy, setBusy] = useState(false);

  const html = useMemo(() => {
    const assets = buildIdCardAssets(settings, student?.photo);
    const data = idCardData(student);
    const sides: ('front' | 'back')[] = settings.sides === 'front' ? ['front'] : settings.sides === 'back' ? ['back'] : ['front', 'back'];
    return sides.map((sd) => renderIdCardSide(sd, settings, data, assets, 'sd-' + sd)).join('');
  }, [settings, student]);

  if (!settings.enabled) return null;

  const download = async () => {
    setBusy(true);
    try {
      const { blob, fileName } = await buildIdCardPdf(student, settings);
      downloadBlob(blob, fileName);
    } catch {
      toast.error('ID Card PDF nahi ban payi.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2"><IdCard className="w-5 h-5" /> My ID Card</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <style>{ID_CARD_CSS}</style>
        <div className="flex flex-wrap justify-center gap-4" dangerouslySetInnerHTML={{ __html: html }} />
        <div className="flex justify-center">
          <Button variant="outline" onClick={download} disabled={busy}>
            <Download className="w-4 h-4 mr-2" /> {busy ? 'PDF ban rahi hai...' : 'Download PDF'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
