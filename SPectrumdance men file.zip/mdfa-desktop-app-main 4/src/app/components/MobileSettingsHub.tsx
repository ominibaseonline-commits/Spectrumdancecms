import type { ComponentType } from 'react';
import {
  PhoneCall, CalendarCheck, Globe, Clock, GraduationCap, MapPin, Tag, UserX, Megaphone, CalendarDays,
  Settings as SettingsIcon, UserCircle, RefreshCw, LogOut, ChevronRight,
} from 'lucide-react';

interface HubProps {
  businessName: string;
  businessLogo?: string | null;
  version: string;
  onlineAdmissionOn: boolean;
  onlineRequestCount: number;
  eventFormsOn: boolean;
  onNavigate: (page: string) => void;
  onProfile: () => void;
  onReload: () => void;
  onLogout: () => void;
}

interface Row {
  id?: string;
  label: string;
  hint: string;
  icon: ComponentType<{ className?: string }>;
  tone: string; // tailwind bg + text for the icon chip
  badge?: number;
  onClick: () => void;
}

/**
 * Phone / PWA ke liye \"Settings\" tab: baaki saare sections yahin se khulte hain
 * (Enquiry, Batches, Teacher ... ) aur app ke settings, profile, reload, logout bhi.
 */
export function MobileSettingsHub(p: HubProps) {
  const go = (id: string) => () => p.onNavigate(id);

  const groups: { title: string; rows: Row[] }[] = [
    {
      title: 'Daily kaam',
      rows: [
        { label: 'Enquiry', hint: 'Nayi enquiry aur follow-ups', icon: PhoneCall, tone: 'bg-sky-100 text-sky-600', onClick: go('enquiry') },
        { label: 'QR Attendance', hint: 'Attendance, QR aur reports', icon: CalendarCheck, tone: 'bg-emerald-100 text-emerald-600', onClick: go('attendance') },
        ...(p.onlineAdmissionOn
          ? [{ label: 'Online Admission', hint: 'Online aaye admission requests', icon: Globe, tone: 'bg-indigo-100 text-indigo-600', badge: p.onlineRequestCount, onClick: go('online-admission') } as Row]
          : []),
      ],
    },
    {
      title: 'Manage karein',
      rows: [
        { label: 'Batches', hint: 'Batch timing aur schedule', icon: Clock, tone: 'bg-orange-100 text-orange-600', onClick: go('batches') },
        { label: 'Teacher', hint: 'Teachers aur unki payment', icon: GraduationCap, tone: 'bg-violet-100 text-violet-600', onClick: go('teacher') },
        { label: 'Location', hint: 'Branches / locations', icon: MapPin, tone: 'bg-rose-100 text-rose-600', onClick: go('location') },
        { label: 'Category', hint: 'Course categories aur fees', icon: Tag, tone: 'bg-amber-100 text-amber-600', onClick: go('category') },
        { label: 'Deactivated Students', hint: 'Band kiye hue students', icon: UserX, tone: 'bg-gray-200 text-gray-600', onClick: go('deactivated-students') },
      ],
    },
    {
      title: 'Promotion',
      rows: [
        { label: 'Campaign', hint: 'WhatsApp messages aur reminders', icon: Megaphone, tone: 'bg-green-100 text-green-600', onClick: go('campaign') },
        ...(p.eventFormsOn
          ? [{ label: 'Events', hint: 'Event forms aur registrations', icon: CalendarDays, tone: 'bg-pink-100 text-pink-600', onClick: go('events') } as Row]
          : []),
      ],
    },
    {
      title: 'App',
      rows: [
        { label: 'App Settings', hint: 'Backup, theme, admission form, license', icon: SettingsIcon, tone: 'bg-slate-200 text-slate-700', onClick: go('settings') },
        { label: 'My Profile', hint: 'License aur business details', icon: UserCircle, tone: 'bg-blue-100 text-blue-600', onClick: p.onProfile },
        { label: 'Reload App', hint: 'Latest data aur version load karein', icon: RefreshCw, tone: 'bg-teal-100 text-teal-600', onClick: p.onReload },
        { label: 'Logout', hint: 'Admin se bahar niklein', icon: LogOut, tone: 'bg-red-100 text-red-600', onClick: p.onLogout },
      ],
    },
  ];

  return (
    <div className="p-3 space-y-4">
      {/* profile card */}
      <div className="rounded-2xl p-4 text-white flex items-center gap-3 shadow-sm" style={{ backgroundColor: 'var(--brand)' }}>
        {p.businessLogo ? (
          <img src={p.businessLogo} alt="" className="w-12 h-12 rounded-xl bg-white object-contain shrink-0" />
        ) : (
          <div className="w-12 h-12 rounded-xl bg-white/25 flex items-center justify-center shrink-0 text-xl font-bold">
            {(p.businessName || 'O').trim().charAt(0).toUpperCase()}
          </div>
        )}
        <div className="min-w-0">
          <p className="font-semibold truncate">{p.businessName}</p>
          <p className="text-xs opacity-90">Admin • Version {p.version}</p>
        </div>
      </div>

      {groups.map((g) => (
        <section key={g.title}>
          <h3 className="px-2 mb-1.5 text-xs font-semibold uppercase tracking-wide text-gray-500">{g.title}</h3>
          <div className="rounded-2xl bg-white border divide-y overflow-hidden">
            {g.rows.map((r) => {
              const Icon = r.icon;
              return (
                <button
                  key={r.label}
                  type="button"
                  onClick={r.onClick}
                  className="w-full flex items-center gap-3 px-3 py-3 text-left active:bg-gray-100 transition-colors"
                >
                  <span className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${r.tone}`}><Icon className="w-5 h-5" /></span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-[15px] font-medium leading-tight">{r.label}</span>
                    <span className="block text-xs text-gray-500 truncate">{r.hint}</span>
                  </span>
                  {!!r.badge && r.badge > 0 && (
                    <span className="min-w-5 h-5 px-1.5 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">{r.badge}</span>
                  )}
                  <ChevronRight className="w-4 h-4 text-gray-400 shrink-0" />
                </button>
              );
            })}
          </div>
        </section>
      ))}
      <p className="text-center text-xs text-gray-400 pb-2">50,000+ Students Capacity</p>
    </div>
  );
}
