import { useState, useEffect, memo } from 'react';
import { getStudentPhoto } from '../lib/indexedDB';

// Shows one student's photo. The student lists hold NO photos (that is what made
// the pages heavy with thousands of students) — each row loads its own photo on
// demand, only for rows that are actually on the current page.
export const StudentPhoto = memo(function StudentPhoto({ regNo, name, hasPhoto, onOpen }: { regNo: string; name: string; hasPhoto: boolean; onOpen: (photo: string) => void }) {
  const [photo, setPhoto] = useState<string>('');
  useEffect(() => {
    let cancelled = false;
    setPhoto('');
    if (hasPhoto) {
      getStudentPhoto(regNo).then((p) => { if (!cancelled) setPhoto(p); }).catch(() => {});
    }
    return () => { cancelled = true; };
  }, [regNo, hasPhoto]);

  if (!hasPhoto) {
    return <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center"><span className="text-gray-500 text-xs">No Photo</span></div>;
  }
  if (!photo) {
    return <div className="w-12 h-12 rounded-full bg-gray-100 animate-pulse" />;
  }
  return <img src={photo} alt={name} loading="lazy" decoding="async" className="w-12 h-12 rounded-full object-cover cursor-pointer hover:opacity-80" onClick={() => onOpen(photo)} />;
});
