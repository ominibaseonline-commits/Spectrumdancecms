import { useEffect, useMemo, useState } from 'react';
import { toast } from 'sonner';
import { ArrowDown, ArrowUp, Lock, RotateCcw, Save } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { getEnabledFieldIds } from '../lib/admissionFields';
import {
  FormFieldLayout,
  getLockLevel,
  loadFormLayout,
  resetFormLayout,
  resolveFields,
  saveFormLayout,
} from '../lib/formLayout';

// Settings -> Admission Form Layout (Phase A: Show/Hide, Required/Optional, Rename, Move up/down)
export function AdmissionFormLayoutSettings() {
  const [layout, setLayout] = useState<FormFieldLayout[] | null>(null);
  const [enabledIds, setEnabledIds] = useState<string[]>([]);
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);

  const reload = async () => {
    const [l, ids] = await Promise.all([loadFormLayout(), getEnabledFieldIds()]);
    setLayout(l);
    setEnabledIds(ids);
    setDirty(false);
  };

  useEffect(() => { reload(); }, []);

  const resolved = useMemo(() => (layout ? resolveFields(layout, enabledIds) : []), [layout, enabledIds]);

  // Rows the owner can arrange (extra fields appear here only when ON in "Admission Fields")
  const freeRows = resolved
    .filter((f) => getLockLevel(f.id) !== 'full' && (f.kind !== 'extra' || f.visible))
    .sort((a, b) => a.order - b.order);
  const lockedRows = resolved.filter((f) => getLockLevel(f.id) === 'full');

  const update = (id: string, patch: Partial<FormFieldLayout>) => {
    setLayout((prev) => (prev ? prev.map((f) => (f.id === id ? { ...f, ...patch } : f)) : prev));
    setDirty(true);
  };

  const move = (id: string, dir: -1 | 1) => {
    const i = freeRows.findIndex((f) => f.id === id);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= freeRows.length) return;
    const a = freeRows[i];
    const b = freeRows[j];
    setLayout((prev) =>
      prev
        ? prev.map((f) => (f.id === a.id ? { ...f, order: b.order } : f.id === b.id ? { ...f, order: a.order } : f))
        : prev
    );
    setDirty(true);
  };

  const handleSave = async () => {
    if (!layout) return;
    setSaving(true);
    try {
      await saveFormLayout(layout);
      await reload();
      toast.success('Admission Form Layout save ho gaya!');
    } catch (error) {
      console.error('Error saving form layout:', error);
      toast.error('Layout save nahi hua. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const handleReset = async () => {
    if (!window.confirm('Form layout default par wapas set karna hai? Aapke rename/hide/order wale changes hat jayenge. (Students ka data safe rahega.)')) return;
    try {
      await resetFormLayout();
      await reload();
      toast.success('Layout default par reset ho gaya');
    } catch (error) {
      console.error('Error resetting form layout:', error);
      toast.error('Reset nahi hua. Please try again.');
    }
  };

  if (!layout) {
    return <p className="text-sm text-gray-500 p-4">Loading...</p>;
  }

  return (
    <div className="space-y-4">
      <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
        <h3 className="mb-1">Admission Form Layout</h3>
        <p className="text-sm text-gray-600">
          Apne paper form ke hisaab se fields ko Show/Hide, Required/Optional, rename aur upar-niche kar sakte ho.
          Hide karne par purane students ka data delete nahi hota — field wapas ON karoge to data phir dikhega.
        </p>
        <p className="text-xs text-gray-500 mt-2">
          Extra fields (Height, Blood Group, etc.) ko ON/OFF karne ke liye "Admission Fields" tab use karo — ON hote hi wo yaha list me aa jayenge.
        </p>
      </Card>

      {/* Registration No (fixed, always first) */}
      {lockedRows.filter((f) => f.id === 'regNo').map((f) => (
        <div key={f.id} className="flex items-center gap-3 p-3 border rounded-lg bg-gray-50">
          <Lock className="w-4 h-4 text-gray-400" />
          <span className="text-sm font-medium">{f.label}</span>
          <span className="text-xs text-gray-500">— hamesha sabse upar, change nahi hota</span>
        </div>
      ))}

      {/* Fields the owner can arrange */}
      <div className="space-y-2">
        <div className="hidden md:grid grid-cols-[88px_1fr_90px_100px] gap-3 px-3 text-xs text-gray-500">
          <span>Move</span>
          <span>Field name (rename kar sakte ho)</span>
          <span className="text-center">Show</span>
          <span className="text-center">Required</span>
        </div>

        {freeRows.map((f, index) => {
          const lock = getLockLevel(f.id);
          const isExtra = f.kind === 'extra';
          return (
            <div
              key={f.id}
              className={`grid grid-cols-1 md:grid-cols-[88px_1fr_90px_100px] gap-3 items-center p-3 border rounded-lg ${f.visible ? 'bg-white' : 'bg-gray-50 opacity-70'}`}
            >
              <div className="flex items-center gap-1">
                <Button type="button" size="icon" variant="outline" className="h-8 w-8" disabled={index === 0} onClick={() => move(f.id, -1)} title="Upar">
                  <ArrowUp className="w-4 h-4" />
                </Button>
                <Button type="button" size="icon" variant="outline" className="h-8 w-8" disabled={index === freeRows.length - 1} onClick={() => move(f.id, 1)} title="Niche">
                  <ArrowDown className="w-4 h-4" />
                </Button>
                {lock === 'basic' && <Lock className="w-4 h-4 text-gray-400 ml-1" aria-label="Locked" />}
              </div>

              <div>
                <Input
                  value={f.label}
                  maxLength={60}
                  onChange={(e) => update(f.id, { label: e.target.value })}
                  placeholder="Field name"
                />
                {isExtra && <p className="text-xs text-gray-500 mt-1">Extra field — ON/OFF "Admission Fields" tab se</p>}
                {lock === 'basic' && <p className="text-xs text-gray-500 mt-1">Ye field hide ya optional nahi ho sakta</p>}
                {(f.id === 'aadhaarFront' || f.id === 'aadhaarBack') && (
                  <p className="text-xs text-gray-500 mt-1">Aadhaar card ki photo — camera se click ya upload (admission form + online form dono me). Show = ON/OFF, Required = mandatory/optional</p>
                )}
                {f.id === 'guardianRelation' && <p className="text-xs text-gray-500 mt-1">Text field (type karke bharna hota hai)</p>}
              </div>

              <div className="flex items-center md:justify-center gap-2">
                <span className="md:hidden text-sm text-gray-500">Show</span>
                <Switch
                  checked={f.visible}
                  disabled={lock !== 'none' || isExtra}
                  onCheckedChange={(checked) => update(f.id, { visible: checked, required: checked ? f.required : false })}
                />
              </div>

              <div className="flex items-center md:justify-center gap-2">
                <span className="md:hidden text-sm text-gray-500">Required</span>
                <Switch
                  checked={f.required}
                  disabled={lock !== 'none' || !f.visible}
                  onCheckedChange={(checked) => update(f.id, { required: checked })}
                />
              </div>
            </div>
          );
        })}
      </div>

      {/* Fixed fields block hidden on purpose (these fields are always at the bottom of the form) */}

      <div className="flex flex-wrap items-center gap-2">
        <Button onClick={handleSave} disabled={!dirty || saving} className="flex items-center gap-2">
          <Save className="w-4 h-4" /> {saving ? 'Saving...' : 'Save Layout'}
        </Button>
        <Button variant="outline" onClick={handleReset} className="flex items-center gap-2">
          <RotateCcw className="w-4 h-4" /> Reset to Default
        </Button>
        {dirty && <span className="text-sm text-orange-600">Unsaved changes — Save Layout dabao</span>}
      </div>
    </div>
  );
}
