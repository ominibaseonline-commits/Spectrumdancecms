import { useState, useEffect, useLayoutEffect, useMemo, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { MessageSquarePlus, ArrowRight, UserPlus, Clock, CheckCircle2, ChevronRight } from 'lucide-react';
import { Enquiry, isPendingFollowUp, purgeExpiredEnquiries, statusInfo, buildRepeatMap } from '../lib/enquiries';
import { QR_ENQUIRY_NEW_EVENT, useQrEnquiryEnabled } from '../lib/qrEnquiry';
import { RepeatNotice, OldEnquiryDialog } from './OldEnquiryDetails';

// Dashboard -> "Enquiries Overview": New / Follow-ups / Converted counts + the latest enquiries.
// compact (one-page dashboard): the list fills the empty space of the box - newest on top, and when the
// box is full the oldest ones drop off the bottom. Repeat enquiries (same name + phone) get a warning
// and a "View Old Details" button. "View All Enquiries" opens the Enquiry section.
const MAX_ROWS = 60; // never draw more than this on the dashboard
// Counts are for ONE day only: today by default, or the date picked on the Dashboard calendar (YYYY-MM-DD).
const localDay = (iso?: string) => { if (!iso) return ''; const d = new Date(iso); return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en-CA'); };
export function EnquiriesOverview({ onViewAll, compact = false, date }: { onViewAll?: () => void; compact?: boolean; date?: string }) {
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const qrOn = useQrEnquiryEnabled();
  const [oldFor, setOldFor] = useState<Enquiry | null>(null);
  // compact mode: how many rows fully fit in the box (null = measuring)
  const [fit, setFit] = useState<number | null>(null);
  const [boxSize, setBoxSize] = useState('');
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let alive = true;
    // QR enquiries are counted here too (New / Recent), and a new one shows up at once
    const load = () => purgeExpiredEnquiries()
      .then((list) => { if (alive) setEnquiries(list); })
      .catch((err) => console.error('Enquiry overview load error:', err));
    load();
    window.addEventListener(QR_ENQUIRY_NEW_EVENT, load);
    return () => { alive = false; window.removeEventListener(QR_ENQUIRY_NEW_EVENT, load); };
  }, []);

  const day = date || new Date().toLocaleDateString('en-CA');
  // New = enquiries added on that day | Follow-ups = calls due on that day (still pending) | Converted = converted on that day
  const fresh = enquiries.filter((e) => localDay(e.createdAt) === day).length;
  const followUps = enquiries.filter((e) => isPendingFollowUp(e) && e.followUpDate === day).length;
  const converted = enquiries.filter((e) => !!e.converted && localDay(e.convertedAt) === day).length;

  const repeatMap = useMemo(() => buildRepeatMap(enquiries), [enquiries]);

  const sorted = useMemo(
    () => [...enquiries].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')),
    [enquiries],
  );
  const candidates = sorted.slice(0, compact ? MAX_ROWS : 5);
  const recent = compact && fit !== null ? candidates.slice(0, fit) : candidates;

  // Box size changes (window resize, other dashboard sections) -> measure again
  useEffect(() => {
    if (!compact || !boxRef.current) return;
    const el = boxRef.current;
    const ro = new ResizeObserver(() => setBoxSize(`${Math.round(el.clientWidth)}x${Math.round(el.clientHeight)}`));
    ro.observe(el);
    return () => ro.disconnect();
  }, [compact]);

  // Data / size changed -> draw all candidates once, count the rows that fully fit, keep only those (before paint)
  const dataKey = candidates.map((e) => e.id).join(',') + '|' + repeatMap.size;
  useEffect(() => { if (compact) setFit(null); }, [compact, dataKey, boxSize]);
  useLayoutEffect(() => {
    if (!compact || fit !== null) return;
    const box = boxRef.current;
    if (!box) return;
    const limit = box.getBoundingClientRect().bottom;
    let n = 0;
    const rows = box.querySelectorAll<HTMLElement>('tbody tr');
    for (let i = 0; i < rows.length; i++) {
      if (rows[i].getBoundingClientRect().bottom <= limit + 0.5) n++; else break;
    }
    setFit(Math.max(1, n));
  });

  const stage = (e: Enquiry) => {
    if (e.converted === 'admission') return { label: 'Admission', cls: 'bg-green-100 text-green-800' };
    if (e.converted === 'demo') return { label: 'Demo', cls: 'bg-blue-100 text-blue-800' };
    if (isPendingFollowUp(e)) return { label: 'Follow Up', cls: 'bg-[var(--app-bg)] text-orange-700' };
    const info = statusInfo(e.status);
    return { label: info.short, cls: info.chip };
  };

  const fmtDate = (iso: string) => {
    const d = new Date(iso);
    return isNaN(d.getTime()) ? '' : d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
  };

  return (
    <Card className={compact ? 'h-full min-h-0 gap-2 p-4 overflow-hidden' : ''}>
      <CardHeader className={`flex flex-row items-center justify-between space-y-0 ${compact ? 'px-0 pt-0' : ''}`}>
        <CardTitle className="flex items-center gap-2"><MessageSquarePlus className="w-5 h-5 text-[var(--brand)]" /> Enquiries Overview</CardTitle>
        <button type="button" onClick={onViewAll} className="text-sm text-blue-600 hover:underline flex items-center gap-1">
          View All Enquiries <ArrowRight className="w-4 h-4" />
        </button>
      </CardHeader>
      <CardContent className={compact ? 'px-0 flex flex-col gap-2 flex-1 min-h-0 overflow-hidden' : 'space-y-4'}>
        <div className={`grid grid-cols-3 shrink-0 ${compact ? 'gap-2' : 'gap-3'}`}>
          <div className={`rounded-lg border border-blue-200 bg-blue-50 ${compact ? 'px-3 py-2' : 'p-3'} flex items-center gap-3`}>
            <UserPlus className="w-8 h-8 text-blue-500" />
            <div><p className="text-sm text-gray-600">New</p><p className="text-2xl font-semibold">{fresh}</p></div>
          </div>
          <div className={`rounded-lg border border-orange-200 bg-orange-50 ${compact ? 'px-3 py-2' : 'p-3'} flex items-center gap-3`}>
            <Clock className="w-8 h-8 text-orange-500" />
            <div><p className="text-sm text-gray-600">Follow-ups</p><p className="text-2xl font-semibold">{followUps}</p></div>
          </div>
          <div className={`rounded-lg border border-purple-200 bg-purple-50 ${compact ? 'px-3 py-2' : 'p-3'} flex items-center gap-3`}>
            <CheckCircle2 className="w-8 h-8 text-purple-500" />
            <div><p className="text-sm text-gray-600">Converted</p><p className="text-2xl font-semibold">{converted}</p></div>
          </div>
        </div>

        <div className={compact ? 'flex flex-col flex-1 min-h-0 [&_td]:py-1 [&_th]:h-8 [&_td]:text-sm' : ''}>
          <h4 className={compact ? 'mb-1 text-sm shrink-0' : 'mb-2'}>Recent Enquiries</h4>
          <div ref={boxRef} className={compact ? 'flex-1 min-h-0 overflow-hidden' : ''}>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Contact</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Date</TableHead>
                <TableHead className="w-8"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {recent.length > 0 ? recent.map((e) => {
                const st = stage(e);
                const olds = repeatMap.get(e.id);
                return (
                  <TableRow key={e.id} className="cursor-pointer" onClick={onViewAll}>
                    <TableCell className="font-medium">
                      {e.name}
                      {olds && <RepeatNotice compact onView={() => setOldFor(e)} />}
                    </TableCell>
                    <TableCell>+91 {e.phone}</TableCell>
                    <TableCell><span className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-medium ${st.cls}`}>{st.label}</span></TableCell>
                    <TableCell>{fmtDate(e.createdAt)}</TableCell>
                    <TableCell><ChevronRight className="w-4 h-4 text-gray-400" /></TableCell>
                  </TableRow>
                );
              }) : (
                <TableRow><TableCell colSpan={5} className="text-center py-6 text-gray-500">Abhi koi enquiry nahi hai</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
          </div>
        </div>
      </CardContent>

      <OldEnquiryDialog enquiry={oldFor} olds={oldFor ? repeatMap.get(oldFor.id) || [] : []} qrOn={qrOn} onClose={() => setOldFor(null)} />
    </Card>
  );
}
