import { useEffect, useState } from 'react';
import { Globe, Copy, Download, ExternalLink, RefreshCw, AlertTriangle, CheckCircle2, Mail } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Input } from './ui/input';
import { qrToDataUrl } from '../lib/qr';
import { isAttendanceConnected } from '../lib/attendance';
import {
  getOnlineAdmissionEnabled,
  getOnlineAdmissionLink,
  getOnlineAdmissionMail,
  saveOnlineAdmissionMail,
  sendOnlineAdmissionTestMail,
  onlineAdmissionError,
  pushOnlineAdmissionConfig,
  setOnlineAdmissionEnabled,
} from '../lib/onlineAdmission';

// Settings -> Online Admission
// Ek toggle. ON karte hi sidebar me "Online Admission" section aa jata hai (Admission Form ke just niche)
// aur student QR / link se form bhar sakte hain. OFF karte hi form band ho jata hai.
export function OnlineAdmissionSettings() {
  const [enabled, setEnabled] = useState(false);
  const [connected, setConnected] = useState(true);
  const [link, setLink] = useState('');
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [loaded, setLoaded] = useState(false);
  const [mailStudent, setMailStudent] = useState(true);
  const [mailAdmin, setMailAdmin] = useState(true);
  const [adminEmail, setAdminEmail] = useState('');
  const [mailBusy, setMailBusy] = useState(false);

  const load = async () => {
    const [on, conn, l, mail] = await Promise.all([getOnlineAdmissionEnabled(), isAttendanceConnected(), getOnlineAdmissionLink(), getOnlineAdmissionMail()]);
    setEnabled(on); setConnected(conn); setLink(l);
    setMailStudent(mail.student); setMailAdmin(mail.admin); setAdminEmail(mail.adminEmail);
    setQr(l ? qrToDataUrl(l, 700) : '');
    setLoaded(true);
  };
  useEffect(() => { load(); }, []);

  const toggle = async (on: boolean) => {
    setBusy(true);
    setEnabled(on);
    const r = await setOnlineAdmissionEnabled(on);
    setBusy(false);
    if (r.error) {
      setProblem(r.error);
      toast.error(on ? 'Online Admission ON ho gaya, par Google Sheet ko abhi nahi bataya ja saka' : 'OFF ho gaya, par Google Sheet ko abhi nahi bataya ja saka');
    } else {
      setProblem('');
      toast.success(on ? 'Online Admission ON ho gaya. Sidebar me section aa gaya.' : 'Online Admission OFF ho gaya.');
    }
  };

  const resync = async () => {
    setBusy(true);
    try {
      await pushOnlineAdmissionConfig(true);
      setProblem('');
      toast.success('Form Google Sheet me update ho gaya');
    } catch (e: any) {
      setProblem(onlineAdmissionError(e));
      toast.error('Update nahi hua');
    } finally { setBusy(false); }
  };

  // admin email(s): comma se alag, max 3
  const emailsOk = (v: string) => {
    const list = v.split(/[,;\s]+/).filter(Boolean);
    return list.length > 0 && list.length <= 3 && list.every((x) => /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/.test(x));
  };

  const saveMail = async () => {
    if (mailAdmin && !emailsOk(adminEmail)) { toast.error('Admin email sahi likhein (max 3, comma se alag)'); return; }
    setMailBusy(true);
    try {
      await saveOnlineAdmissionMail({ student: mailStudent, admin: mailAdmin, adminEmail });
      setProblem('');
      toast.success('Mail settings save ho gayi');
    } catch (e: any) {
      setProblem(onlineAdmissionError(e));
      toast.error('Save hua, par Google Sheet ko abhi nahi bataya ja saka');
    } finally { setMailBusy(false); }
  };

  const testMail = async () => {
    const first = adminEmail.split(/[,;\s]+/).filter(Boolean)[0] || '';
    if (!emailsOk(first)) { toast.error('Pehle Admin email likhein'); return; }
    setMailBusy(true);
    try {
      const r = await sendOnlineAdmissionTestMail(first);
      setProblem('');
      toast.success(`Test mail ${first} par bhej di gayi (aaj ki bachi hui mail limit: ${r.remaining})`);
    } catch (e: any) {
      setProblem(onlineAdmissionError(e));
      toast.error('Test mail nahi gayi');
    } finally { setMailBusy(false); }
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(link); toast.success('Link copy ho gaya'); }
    catch { toast.error('Copy nahi hua'); }
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = qr; a.download = 'online-admission-qr.png'; a.click();
  };

  if (!loaded) return <p className="text-sm text-gray-500">Loading...</p>;

  return (
    <div className="space-y-6">
      <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
        <h3 className="flex items-center gap-2 mb-2"><Globe className="w-5 h-5 text-orange-600" /> Online Admission Form</h3>
        <p className="text-sm text-gray-600">
          Turn ON to add <strong>Online Admission</strong> in the sidebar. Students fill the form via QR / link, you <strong>Approve</strong> it, and the Admission Form opens pre-filled.
        </p>
      </Card>

      <div className="bg-white rounded-lg border p-4 flex items-center justify-between gap-4">
        <div>
          <p className="font-medium">Online Admission Form</p>
          <p className="text-sm text-gray-500">{enabled ? 'ON — students online form bhar sakte hain' : 'OFF — form band hai'}</p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggle} disabled={busy} />
      </div>

      {!connected && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Setup: <strong>Settings → Management & Setup → Attendance Setup</strong> me system connect karein. Isi se sabhi modules chalte hain: Events, QR Enquiry, Online Admission, Attendance.</span>
        </div>
      )}

      {problem && (
        <div className="flex gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{problem}</span>
        </div>
      )}

      {connected && (
        <div className="bg-white rounded-lg border p-4 space-y-4">
          <h4 className="flex items-center gap-2"><Mail className="w-4 h-4 text-orange-600" /> Email Settings</h4>
          <p className="text-sm text-gray-600">
            Student form submit karte hi use <strong>form PDF + Student ID Card</strong> mail ho jata hai, aur admin ko bhi same PDF ke saath alert jata hai.
            Mail me wahi columns dikhte hain jo <strong>Admission Form Layout</strong> me ON hain. Admin jab online request ko Approve karke payment bharke Save karta hai, tab student ko <strong>Payment Receipt (PDF)</strong> bhi mail ho jati hai (discount aur dues date ke saath).
          </p>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="font-medium text-sm">Student ko mail bhejein</p>
              <p className="text-xs text-gray-500">ON hone par online form me Email zaroori ho jata hai</p>
            </div>
            <Switch checked={mailStudent} onCheckedChange={setMailStudent} disabled={mailBusy} />
          </div>
          <div className="flex items-center justify-between gap-4">
            <div>
              <p className="font-medium text-sm">Admin ko mail bhejein</p>
              <p className="text-xs text-gray-500">Har nayi online request par</p>
            </div>
            <Switch checked={mailAdmin} onCheckedChange={setMailAdmin} disabled={mailBusy} />
          </div>
          <div className="space-y-1">
            <label className="text-sm font-medium">Admin Email</label>
            <Input value={adminEmail} onChange={(e) => setAdminEmail(e.target.value)} placeholder="admin@gmail.com (max 3, comma se alag)" disabled={mailBusy} />
          </div>
          <div className="flex flex-wrap gap-2">
            <Button size="sm" onClick={saveMail} disabled={mailBusy}>Save</Button>
            <Button size="sm" variant="outline" onClick={testMail} disabled={mailBusy}>Test mail bhejein</Button>
          </div>
          <p className="text-xs text-gray-500">
            Mail us Google account se jati hai jisse script deploy ki gayi hai (free Gmail me lagbhag 100 mail/din). Script naya paste karne ke baad Apps Script me
            <strong> admAuthorize</strong> ek baar Run karein, phir New version deploy karein.
          </p>
        </div>
      )}

      {enabled && connected && link && (
        <div className="bg-white rounded-lg border p-4 space-y-4">
          <h4 className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-600" /> Student ko ye link / QR dein</h4>
          <div className="flex flex-col md:flex-row gap-4 items-start">
            {qr && <img src={qr} alt="Online admission QR" className="w-44 h-44 border rounded-lg" />}
            <div className="flex-1 min-w-0 space-y-3">
              <div className="text-xs font-mono break-all rounded-md bg-gray-50 border p-2">{link}</div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={copyLink}><Copy className="w-4 h-4 mr-1" /> Link copy</Button>
                <Button size="sm" variant="outline" onClick={downloadQr}><Download className="w-4 h-4 mr-1" /> QR download</Button>
                <Button size="sm" variant="outline" onClick={() => window.open(link, '_blank')}><ExternalLink className="w-4 h-4 mr-1" /> Form dekhein</Button>
                <Button size="sm" variant="outline" onClick={resync} disabled={busy}><RefreshCw className={`w-4 h-4 mr-1 ${busy ? 'animate-spin' : ''}`} /> Form update karein</Button>
              </div>
              <p className="text-xs text-gray-500">
                Admission Form Layout, Category, Batch ya Location badalne par form apne aap update ho jata hai.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
