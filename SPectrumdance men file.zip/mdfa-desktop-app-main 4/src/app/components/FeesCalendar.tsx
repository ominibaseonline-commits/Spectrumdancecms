import { useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ChevronLeft, ChevronRight, SlidersHorizontal, CalendarDays, X } from 'lucide-react';
import { getAllStudents, getAllPayments } from '../lib/indexedDB';
import { useLocationFilter } from '../contexts/LocationFilterContext';

type EntryType = 'admission' | 'fees';
interface Entry {
  key: string;
  type: EntryType;
  date: string; // YYYY-MM-DD
  regNo: string;
  name: string;
  amount: number;
  mode: string;
}

type TypeFilter = 'all' | EntryType;
type ModeFilter = 'all' | 'Cash' | 'Online';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const pad = (n: number) => String(n).padStart(2, '0');
const ymd = (y: number, m: number, d: number) => `${y}-${pad(m + 1)}-${pad(d)}`;
const inr = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
// Chhote cells ke liye: 1500 -> 1.5k, 120000 -> 1.2L
const compact = (n: number) => {
  if (n >= 100000) return `₹${(n / 100000).toFixed(n % 100000 === 0 ? 0 : 1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k`;
  return `₹${Math.round(n)}`;
};
const fmtLong = (d: string) => {
  const [y, m, day] = d.split('-').map(Number);
  return `${day} ${MONTHS[m - 1]} ${y}`;
};

/**
 * Fees Management ke neeche: ek mahine ka collection calendar jaisa grid me.
 * Har date par us din kitna payment aaya dikhta hai. Admin mahina badal sakta hai
 * aur Filter se sirf Admission / sirf Fees payment ya Cash / Online dekh sakta hai.
 */
export function FeesCalendar({ refreshToken }: { refreshToken?: unknown }) {
  const { matchesLocation, selectedLocation } = useLocationFilter();
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth()); // 0-11
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all');
  const [modeFilter, setModeFilter] = useState<ModeFilter>('all');
  const [showFilter, setShowFilter] = useState(false);
  const [openDay, setOpenDay] = useState<string | null>(null);
  const [students, setStudents] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const [s, p] = await Promise.all([getAllStudents(), getAllPayments()]);
      setStudents(s || []);
      setPayments(p || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const onUpdate = () => { load(); };
    window.addEventListener('studentsUpdated', onUpdate);
    return () => window.removeEventListener('studentsUpdated', onUpdate);
  }, []);
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [refreshToken]);

  // Saari entries: Admission payment + Fees payments (location filter ke hisaab se)
  const entries = useMemo<Entry[]>(() => {
    const byReg = new Map<string, any>();
    students.forEach((s) => byReg.set(String(s.regNo), s));
    const paidLater = new Map<string, number>();
    payments.forEach((p) => {
      const k = String(p.regNo);
      paidLater.set(k, (paidLater.get(k) || 0) + (parseFloat(p.paidAmount) || 0));
    });

    const list: Entry[] = [];
    students.forEach((s) => {
      if (!matchesLocation(s.location)) return;
      // student.paidAmount me baad ke fees payments bhi jud jaate hain, isliye admission wala hissa alag nikalte hain
      const admissionPaid = Math.max(0, (parseFloat(s.paidAmount) || 0) - (paidLater.get(String(s.regNo)) || 0));
      const date = String(s.admissionDate || '').slice(0, 10);
      if (admissionPaid > 0 && date) {
        list.push({ key: `a-${s.regNo}`, type: 'admission', date, regNo: String(s.regNo), name: s.name, amount: admissionPaid, mode: s.paymentMode || '' });
      }
    });
    payments.forEach((p, i) => {
      const st = byReg.get(String(p.regNo));
      if (st && !matchesLocation(st.location)) return;
      if (!st && selectedLocation !== 'all') return;
      const amount = parseFloat(p.paidAmount) || 0;
      const date = String(p.paymentDate || '').slice(0, 10);
      if (amount > 0 && date) {
        list.push({ key: `p-${p.id ?? i}`, type: 'fees', date, regNo: String(p.regNo), name: p.name || st?.name || '', amount, mode: p.paymentMode || '' });
      }
    });
    return list;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [students, payments, selectedLocation]);

  const monthPrefix = `${year}-${pad(month + 1)}`;
  const monthEntries = useMemo(
    () => entries.filter((e) =>
      e.date.startsWith(monthPrefix) &&
      (typeFilter === 'all' || e.type === typeFilter) &&
      (modeFilter === 'all' || e.mode === modeFilter)
    ),
    [entries, monthPrefix, typeFilter, modeFilter]
  );

  const byDay = useMemo(() => {
    const m = new Map<string, { total: number; count: number; admission: number; fees: number }>();
    monthEntries.forEach((e) => {
      const d = m.get(e.date) || { total: 0, count: 0, admission: 0, fees: 0 };
      d.total += e.amount;
      d.count += 1;
      d[e.type === 'admission' ? 'admission' : 'fees'] += e.amount;
      m.set(e.date, d);
    });
    return m;
  }, [monthEntries]);

  const totals = useMemo(() => {
    let total = 0, admission = 0, fees = 0, cash = 0, online = 0;
    monthEntries.forEach((e) => {
      total += e.amount;
      if (e.type === 'admission') admission += e.amount; else fees += e.amount;
      if (e.mode === 'Cash') cash += e.amount;
      if (e.mode === 'Online') online += e.amount;
    });
    return { total, admission, fees, cash, online, count: monthEntries.length };
  }, [monthEntries]);

  const maxDay = useMemo(() => Math.max(0, ...Array.from(byDay.values()).map((d) => d.total)), [byDay]);

  // Calendar cells (pehle khali cells, phir 1..last)
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  while (cells.length % 7 !== 0) cells.push(null);

  const todayKey = ymd(today.getFullYear(), today.getMonth(), today.getDate());
  const isCurrentMonth = year === today.getFullYear() && month === today.getMonth();

  const goMonth = (delta: number) => {
    const d = new Date(year, month + delta, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth());
    setOpenDay(null);
  };
  const activeFilters = (typeFilter !== 'all' ? 1 : 0) + (modeFilter !== 'all' ? 1 : 0);

  const dayEntries = openDay ? monthEntries.filter((e) => e.date === openDay) : [];

  const chip = (active: boolean) =>
    `px-3 py-1.5 rounded-full text-sm border transition-colors ${active ? 'bg-orange-500 border-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`;

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            <CalendarDays className="w-5 h-5 text-orange-600" /> Monthly Collection
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={() => setShowFilter((v) => !v)} className={showFilter ? 'border-orange-400 bg-orange-50' : ''}>
              <SlidersHorizontal className="w-4 h-4 mr-1.5" /> Filter
              {activeFilters > 0 && <span className="ml-1.5 min-w-5 h-5 px-1 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">{activeFilters}</span>}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Month selector */}
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="icon" onClick={() => goMonth(-1)} aria-label="Pichla mahina"><ChevronLeft className="w-4 h-4" /></Button>
          <input
            type="month"
            value={monthPrefix}
            onChange={(e) => {
              const [y, m] = e.target.value.split('-').map(Number);
              if (y && m) { setYear(y); setMonth(m - 1); setOpenDay(null); }
            }}
            className="px-3 py-2 border rounded-lg bg-white text-sm font-medium"
            aria-label="Mahina chunein"
          />
          <Button variant="outline" size="icon" onClick={() => goMonth(1)} aria-label="Agla mahina"><ChevronRight className="w-4 h-4" /></Button>
          <span className="font-semibold ml-1">{MONTHS[month]} {year}</span>
          {!isCurrentMonth && (
            <Button variant="ghost" size="sm" onClick={() => { setYear(today.getFullYear()); setMonth(today.getMonth()); setOpenDay(null); }} className="text-orange-600">Is mahine par wapas</Button>
          )}
        </div>

        {/* Filter panel */}
        {showFilter && (
          <div className="rounded-xl border bg-gray-50 p-3 space-y-3">
            <div>
              <p className="text-xs text-gray-500 mb-1.5">Record type</p>
              <div className="flex flex-wrap gap-2">
                <button className={chip(typeFilter === 'all')} onClick={() => setTypeFilter('all')}>Sab</button>
                <button className={chip(typeFilter === 'admission')} onClick={() => setTypeFilter('admission')}>Sirf Admission</button>
                <button className={chip(typeFilter === 'fees')} onClick={() => setTypeFilter('fees')}>Sirf Fees Payment</button>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1.5">Payment mode</p>
              <div className="flex flex-wrap gap-2">
                <button className={chip(modeFilter === 'all')} onClick={() => setModeFilter('all')}>Sab</button>
                <button className={chip(modeFilter === 'Cash')} onClick={() => setModeFilter('Cash')}>Cash</button>
                <button className={chip(modeFilter === 'Online')} onClick={() => setModeFilter('Online')}>Online</button>
              </div>
            </div>
            {activeFilters > 0 && (
              <button className="text-sm text-orange-600 flex items-center gap-1" onClick={() => { setTypeFilter('all'); setModeFilter('all'); }}>
                <X className="w-3.5 h-3.5" /> Filter hatayein
              </button>
            )}
          </div>
        )}

        {/* Summary */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-2">
          <div className="col-span-2 md:col-span-1 rounded-xl border bg-green-50 px-3 py-2">
            <p className="text-xs text-gray-500">Total Collection</p>
            <p className="text-lg font-bold text-green-700">{inr(totals.total)}</p>
            <p className="text-[11px] text-gray-500">{totals.count} payment{totals.count === 1 ? '' : 's'}</p>
          </div>
          <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Admission</p><p className="font-semibold">{inr(totals.admission)}</p></div>
          <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Fees Payment</p><p className="font-semibold">{inr(totals.fees)}</p></div>
          <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Cash</p><p className="font-semibold text-blue-600">{inr(totals.cash)}</p></div>
          <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Online</p><p className="font-semibold text-purple-600">{inr(totals.online)}</p></div>
        </div>

        {/* Calendar grid */}
        <div>
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEK.map((w, i) => (
              <div key={w} className={`text-center text-xs font-medium py-1 ${i === 0 ? 'text-red-500' : 'text-gray-500'}`}>{w}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, idx) => {
              if (day === null) return <div key={`e-${idx}`} className="min-h-[56px] sm:min-h-[84px]" />;
              const key = ymd(year, month, day);
              const info = byDay.get(key);
              const isToday = key === todayKey;
              const intensity = info && maxDay > 0 ? info.total / maxDay : 0;
              const bg = info ? `rgba(34,197,94,${0.1 + intensity * 0.35})` : undefined;
              return (
                <button
                  key={key}
                  type="button"
                  disabled={!info}
                  onClick={() => info && setOpenDay(key)}
                  style={{ backgroundColor: bg }}
                  className={`min-h-[56px] sm:min-h-[84px] rounded-lg border p-1 sm:p-2 text-left flex flex-col justify-between transition ${
                    info ? 'cursor-pointer hover:ring-2 hover:ring-green-400 active:scale-[0.97]' : 'bg-white cursor-default'
                  } ${isToday ? 'ring-2 ring-orange-400' : ''}`}
                >
                  <span className={`text-xs sm:text-sm font-semibold ${isToday ? 'text-orange-600' : info ? 'text-gray-800' : 'text-gray-400'}`}>{day}</span>
                  {info ? (
                    <span className="block">
                      <span className="block text-[11px] sm:hidden font-bold text-green-800 leading-tight">{compact(info.total)}</span>
                      <span className="hidden sm:block text-sm font-bold text-green-800 leading-tight">{inr(info.total)}</span>
                      <span className="hidden sm:block text-[11px] text-gray-600">{info.count} payment{info.count === 1 ? '' : 's'}</span>
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
          {!loading && totals.count === 0 && (
            <p className="text-center text-sm text-gray-500 py-4">{MONTHS[month]} {year} me koi payment record nahi hai{activeFilters > 0 ? ' (filter ke hisaab se)' : ''}.</p>
          )}
        </div>
      </CardContent>

      {/* Ek din ki detail */}
      <Dialog open={!!openDay} onOpenChange={(o) => { if (!o) setOpenDay(null); }}>
        <DialogContent className="w-[95vw] sm:max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{openDay ? fmtLong(openDay) : ''}</DialogTitle></DialogHeader>
          {openDay && byDay.get(openDay) && (
            <div className="grid grid-cols-3 gap-2 text-center">
              <div className="rounded-lg border bg-green-50 p-2"><p className="text-xs text-gray-500">Total</p><p className="font-bold text-green-700">{inr(byDay.get(openDay)!.total)}</p></div>
              <div className="rounded-lg border p-2"><p className="text-xs text-gray-500">Admission</p><p className="font-semibold">{inr(byDay.get(openDay)!.admission)}</p></div>
              <div className="rounded-lg border p-2"><p className="text-xs text-gray-500">Fees</p><p className="font-semibold">{inr(byDay.get(openDay)!.fees)}</p></div>
            </div>
          )}
          <div className="space-y-2">
            {dayEntries.map((e) => (
              <div key={e.key} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                <div className="min-w-0">
                  <p className="font-medium truncate">{e.name || '—'}</p>
                  <p className="text-xs text-gray-500 flex flex-wrap items-center gap-1.5">
                    <span>Reg {e.regNo}</span>
                    <span className={`px-1.5 py-0.5 rounded-full font-semibold ${e.type === 'admission' ? 'bg-orange-100 text-orange-700' : 'bg-blue-100 text-blue-700'}`}>{e.type === 'admission' ? 'Admission' : 'Fees'}</span>
                    {e.mode && <span className="px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-700">{e.mode}</span>}
                  </p>
                </div>
                <p className="font-bold text-green-700 shrink-0">{inr(e.amount)}</p>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </Card>
  );
}
