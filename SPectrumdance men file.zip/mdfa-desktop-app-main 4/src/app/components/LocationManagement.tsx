import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, MapPin, Users, GraduationCap, Lock } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { getAllLocations, saveLocation, deleteLocation, getAllStudents, getAllTeachers, saveStudent, saveTeacher } from '../lib/indexedDB';

export function LocationManagement() {
  const [locations, setLocations] = useState<any[]>([]);
  const [locationName, setLocationName] = useState('');
  const [locationAddress, setLocationAddress] = useState('');
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingOriginalName, setEditingOriginalName] = useState<string>('');
  const [students, setStudents] = useState<any[]>([]);
  const [teachers, setTeachers] = useState<any[]>([]);
  const [showStudentDialog, setShowStudentDialog] = useState(false);
  const [showTeacherDialog, setShowTeacherDialog] = useState(false);
  const [selectedLocationStudents, setSelectedLocationStudents] = useState<any[]>([]);
  const [selectedLocationTeachers, setSelectedLocationTeachers] = useState<any[]>([]);
  const [selectedLocationName, setSelectedLocationName] = useState('');

  const { matchesLocation } = useLocationFilter();
  useEffect(() => { loadData(); }, []);
  const visibleLocations = locations.filter((l: any) => matchesLocation(l.name));

  const loadData = async () => {
    const locationsData = await getAllLocations();
    const studentsData = await getAllStudents();
    const teachersData = await getAllTeachers();
    setLocations(locationsData);
    setStudents(studentsData);
    setTeachers(teachersData);
  };

  const handleAddLocation = async () => {
    if (!locationName) { toast.error('Please enter location name'); return; }

    const isRename = editingIndex !== null && editingOriginalName && editingOriginalName !== locationName;

    if (isRename) {
      // Find how many students/teachers currently use the old location name
      const affectedStudents = students.filter(s => s.location === editingOriginalName);
      const affectedTeachers = teachers.filter(t => t.location === editingOriginalName);
      const totalAffected = affectedStudents.length + affectedTeachers.length;

      let shouldCascade = true;
      if (totalAffected > 0) {
        shouldCascade = confirm(
          `Aap location ka naam "${editingOriginalName}" se "${locationName}" mein badal rahe hain.\n\n` +
          `${affectedStudents.length} student(s) aur ${affectedTeachers.length} teacher(s) is location se already jude hain.\n\n` +
          `Kya aap unka location field bhi naye naam se update karna chahte hain?`
        );
      }

      // Save the location under its new name, then remove the old record
      // (locations are keyed by name, so a rename must delete the old key)
      await saveLocation({ name: locationName, address: locationAddress });
      await deleteLocation(editingOriginalName);

      if (shouldCascade && totalAffected > 0) {
        for (const s of affectedStudents) {
          await saveStudent({ ...s, location: locationName });
        }
        for (const t of affectedTeachers) {
          await saveTeacher({ ...t, location: locationName });
        }
      }
    } else {
      await saveLocation({ name: locationName, address: locationAddress });
    }

    setEditingIndex(null);
    setEditingOriginalName('');
    setLocationName('');
    setLocationAddress('');
    loadData();
    window.dispatchEvent(new CustomEvent('locationsUpdated'));
    toast.success(editingIndex !== null ? 'Location updated!' : 'Location added!');
  };

  const handleEdit = (index: number) => {
    const location = locations[index];
    setLocationName(location.name);
    setLocationAddress(location.address || '');
    setEditingIndex(index);
    setEditingOriginalName(location.name);
  };

  const handleDelete = async (index: number) => {
    const location = locations[index];
    const studentCount = students.filter(s => s.location === location.name).length;

    if (studentCount > 0) {
      toast.error(`Cannot delete "${location.name}" — ${studentCount} student(s) are assigned to this location. Please reassign them first.`);
      return;
    }

    if (!confirm('Are you sure you want to delete this location?')) return;
    await deleteLocation(location.name);
    loadData();
    toast.success('Location deleted!');
  };

  const getLocationStats = (locationName: string) => ({
    studentCount: students.filter(s => s.location === locationName).length,
    teacherCount: teachers.filter(t => t.location === locationName).length
  });

  const handleViewStudents = (locationName: string) => {
    const locationStudents = students.filter(s => s.location === locationName);
    if (locationStudents.length === 0) { toast.info('No students in this location'); return; }
    setSelectedLocationStudents(locationStudents);
    setSelectedLocationName(locationName);
    setShowStudentDialog(true);
  };

  const handleViewTeachers = (locationName: string) => {
    const locationTeachers = teachers.filter(t => t.location === locationName);
    if (locationTeachers.length === 0) { toast.info('No teachers in this location'); return; }
    setSelectedLocationTeachers(locationTeachers);
    setSelectedLocationName(locationName);
    setShowTeacherDialog(true);
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  return (
    <div className="p-6 space-y-6">
      <h3 className="flex items-center gap-2 text-lg font-semibold">
        <MapPin className="w-5 h-5 text-orange-600" />
        Location
      </h3>
      <Card>
        <CardHeader><CardTitle>Add Location</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>Location Name</Label><Input value={locationName} onChange={(e) => setLocationName(e.target.value)} placeholder="Enter location name" /></div>
            <div><Label>Address (Optional)</Label><Input value={locationAddress} onChange={(e) => setLocationAddress(e.target.value)} placeholder="Enter address" /></div>
          </div>
          <Button onClick={handleAddLocation} className="mt-4">
            <Plus className="w-4 h-4 mr-2" />{editingIndex !== null ? 'Update Location' : 'Add Location'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Location List</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {visibleLocations.length > 0 ? locations.map((location, index) => {
              if (!matchesLocation(location.name)) return null;
              const stats = getLocationStats(location.name);
              const hasStudents = stats.studentCount > 0;
              return (
                <div key={index} className="p-4 rounded-lg border" style={{ backgroundColor: 'var(--app-bg)' }}>
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-orange-500 text-white font-bold text-sm">{visibleLocations.indexOf(location) + 1}</div>
                      <MapPin className="w-5 h-5" />
                      <h3>{location.name}</h3>
                    </div>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => handleEdit(index)}><Edit className="w-3 h-3" /></Button>
                      <Button size="sm" variant="outline" onClick={() => handleDelete(index)} className={hasStudents ? 'opacity-50 cursor-not-allowed' : ''} title={hasStudents ? `${stats.studentCount} students assigned` : 'Delete'}><Trash2 className="w-3 h-3" /></Button>
                    </div>
                  </div>
                  {location.address && <p className="text-gray-600 mb-2 text-sm">{location.address}</p>}
                  {hasStudents && <p className="text-xs text-orange-700 mb-2 flex items-center gap-1"><Lock className="w-3.5 h-3.5" /> Cannot delete — has students</p>}
                  <div className="flex gap-4 mt-2">
                    <div className="bg-white px-3 py-1 rounded"><p className="text-gray-500 text-xs">Students</p><p className="font-semibold">{stats.studentCount}</p></div>
                    <div className="bg-white px-3 py-1 rounded"><p className="text-gray-500 text-xs">Teachers</p><p className="font-semibold">{stats.teacherCount}</p></div>
                  </div>
                  <div className="flex gap-2 mt-2">
                    <Button size="sm" variant="outline" onClick={() => handleViewStudents(location.name)}><Users className="w-3 h-3 mr-1" />Students</Button>
                    <Button size="sm" variant="outline" onClick={() => handleViewTeachers(location.name)}><GraduationCap className="w-3 h-3 mr-1" />Teachers</Button>
                  </div>
                </div>
              );
            }) : <p className="text-center text-gray-500 py-8 col-span-full">No locations added yet</p>}
          </div>
        </CardContent>
      </Card>

      <Dialog open={showStudentDialog} onOpenChange={setShowStudentDialog}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Students in {selectedLocationName}</DialogTitle></DialogHeader>
          <Table>
            <TableHeader><TableRow><TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Category</TableHead><TableHead>Batch Time</TableHead><TableHead>Expiry Date</TableHead><TableHead>Dues</TableHead></TableRow></TableHeader>
            <TableBody>
              {selectedLocationStudents.map((s, i) => (
                <TableRow key={i}>
                  <TableCell>{s.regNo}</TableCell><TableCell>{s.name}</TableCell><TableCell>{s.mobile}</TableCell>
                  <TableCell>{s.category}</TableCell><TableCell>{s.batchTime}</TableCell>
                  <TableCell className={new Date(s.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>{formatDate(s.expiryDate)}</TableCell>
                  <TableCell className={s.dues > 0 ? 'text-red-600' : 'text-green-600'}>₹{s.dues || 0}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      <Dialog open={showTeacherDialog} onOpenChange={setShowTeacherDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Teachers in {selectedLocationName}</DialogTitle></DialogHeader>
          <Table>
            <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Email</TableHead><TableHead>Specialization</TableHead></TableRow></TableHeader>
            <TableBody>
              {selectedLocationTeachers.map((t, i) => (
                <TableRow key={i}><TableCell>{t.name}</TableCell><TableCell>{t.mobile}</TableCell><TableCell>{t.email || 'N/A'}</TableCell><TableCell>{t.specialization || 'N/A'}</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>
    </div>
  );
}
