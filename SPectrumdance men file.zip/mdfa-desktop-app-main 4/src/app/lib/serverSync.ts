// =============================================================================
// Server (Cloud Sync) - Supabase based, license-key protected
// =============================================================================
// Ye file "dist-server-version" ke server feature ka readable version hai.
//
// Kaise kaam karta hai:
//  1. IndexedDB (MayuriAcademyDB) ke put/add/delete/clear ko patch karke har
//     local change ek queue (localStorage) me likh liya jata hai.
//  2. Queue ka data Supabase table `app_data` (store, key, value, deleted) me
//     upsert hota hai. Har request ke saath header `x-license-key` jata hai;
//     server par RLS policy sirf wahi license allow karti hai jisne server
//     "claim" kiya hai (supabase/schema.sql dekhein).
//  3. Dusre devices se changes `updated_at` cursor ke through download hote hain.
//
// Server ka URL + anon key in jagah se is order me dhoondha jata hai:
//   config.json (web build)  ->  license data (Google Sheet: supabase_url / supabase_anon_key)  ->
//   localStorage (pichli baar ka)  ->  build-time env (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY)
// =============================================================================

import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import { initDB, invalidateStudentsLite } from './indexedDB';
import { getStoredLicenseKey, getStoredLicenseData } from './googleSheetLicense';

// ----------------------------------------------------------------------------
// Types
// ----------------------------------------------------------------------------

export type ServerStatus =
  | 'no-config'
  | 'no-license'
  | 'checking'
  | 'unclaimed'
  | 'schema-missing'
  | 'mismatch'
  | 'offline'
  | 'error'
  | 'ready';

export interface ServerSyncState {
  status: ServerStatus;
  message: string;
  url: string;
  pending: number;
  lastSyncAt: number | null;
  syncing: boolean;
}

export interface ServerConfig {
  url: string;
  anonKey: string;
}

interface SyncQueue {
  seq: number;
  keys: Record<string, number>; // "store\u0001key" -> version
  reconcile: Record<string, 1>; // store -> needs full delete-reconcile
}

// ----------------------------------------------------------------------------
// Constants
// ----------------------------------------------------------------------------

const CONFIG_KEY = 'server_config_v1';
const QUEUE_KEY = 'serverSyncQueue_v1';
const CURSOR_KEY = 'serverSyncCursor_v1';
const LINKED_KEY = 'serverSyncLinked_v1';

const PLACEHOLDER_URL = 'https://placeholder.supabase.co';
const PLACEHOLDER_KEY = 'placeholder-key';

const DB_NAME = 'MayuriAcademyDB'; // same as indexedDB.ts
const TABLE = 'app_data';
const SEP = '\u0001';
const EXCLUDED_SETTINGS = new Set(['licenseKey']); // device-local, never synced

const PUSH_BATCH = 25;
const PULL_PAGE = 40;
const SYNC_INTERVAL_MS = 45_000;

// ----------------------------------------------------------------------------
// Supabase client (re-created when URL / key / license changes)
// ----------------------------------------------------------------------------

const clientOptions = (license?: string) => ({
  auth: { persistSession: false, autoRefreshToken: false, detectSessionInUrl: false },
  global: license ? { headers: { 'x-license-key': license } } : undefined,
});

let client: SupabaseClient = createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY, clientOptions());
let currentConfig: ServerConfig | null = null;
let currentLicense = '';

function normalizeConfig(url: unknown, anonKey: unknown): ServerConfig | null {
  if (typeof url !== 'string' || typeof anonKey !== 'string') return null;
  const u = url.trim().replace(/\/+$/, '');
  const k = anonKey.trim();
  if (!/^https?:\/\/.+/i.test(u) || k.length < 20) return null;
  return { url: u, anonKey: k };
}

function applyConfig(cfg: ServerConfig | null, license: string) {
  if (!cfg) {
    currentConfig = null;
    client = createClient(PLACEHOLDER_URL, PLACEHOLDER_KEY, clientOptions());
    return;
  }
  const lic = license.trim().toUpperCase();
  if (
    currentConfig &&
    currentConfig.url === cfg.url &&
    currentConfig.anonKey === cfg.anonKey &&
    currentLicense === lic
  ) {
    return; // nothing changed
  }
  currentConfig = cfg;
  currentLicense = lic;
  client = createClient(cfg.url, cfg.anonKey, clientOptions(lic));
}

const getConfig = () => currentConfig;

function loadSavedConfig(): ServerConfig | null {
  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (!raw) return null;
    const p = JSON.parse(raw);
    return normalizeConfig(p.url, p.anonKey);
  } catch {
    return null;
  }
}

function saveConfig(cfg: ServerConfig) {
  try {
    localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg));
  } catch {
    /* ignore */
  }
}

function envConfig(): ServerConfig | null {
  try {
    const env = (import.meta as any).env || {};
    return normalizeConfig(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY);
  } catch {
    return null;
  }
}

async function loadConfig(): Promise<ServerConfig | null> {
  // 1) config.json next to index.html (web / GitHub Pages / Netlify build)
  try {
    const res = await fetch(new URL('config.json', document.baseURI).toString(), { cache: 'no-store' });
    if (res.ok) {
      const j = await res.json();
      const cfg = normalizeConfig(j.supabaseUrl ?? j.url, j.supabaseAnonKey ?? j.anonKey);
      if (cfg) return cfg;
    }
  } catch {
    /* file:// (desktop app) par fetch fail hota hai - next option try karo */
  }
  // 2) license data (Google Sheet response) - sheet hi source of truth hai, isliye
  //    key / client badalne par purana saved config isse upar nahi aata
  const lic: any = getStoredLicenseData();
  const fromLicense = normalizeConfig(lic?.supabase_url, lic?.supabase_anon_key);
  if (fromLicense) return fromLicense;
  // 3) pichli baar save kiya hua config (sheet me fields na hon / offline)
  const saved = loadSavedConfig();
  if (saved) return saved;
  // 4) build-time env
  return envConfig();
}

const licenseUpper = () => (getStoredLicenseKey() || '').trim().toUpperCase();

// ----------------------------------------------------------------------------
// Observable state (used by Settings > Server tab via useSyncExternalStore)
// ----------------------------------------------------------------------------

let state: ServerSyncState = {
  status: 'no-config',
  message: '',
  url: '',
  pending: 0,
  lastSyncAt: null,
  syncing: false,
};
const listeners = new Set<() => void>();

function setState(patch: Partial<ServerSyncState>) {
  state = { ...state, ...patch };
  listeners.forEach((l) => l());
}

export const getServerSyncState = (): ServerSyncState => state;
export const subscribeServerSync = (cb: () => void) => {
  listeners.add(cb);
  return () => {
    listeners.delete(cb);
  };
};

// ----------------------------------------------------------------------------
// Change queue (persisted in localStorage so nothing is lost on app close)
// ----------------------------------------------------------------------------

function loadQueue(): SyncQueue {
  try {
    const q = JSON.parse(localStorage.getItem(QUEUE_KEY) || 'null');
    if (q && q.keys && q.reconcile) return q;
  } catch {
    /* ignore */
  }
  return { seq: 0, keys: {}, reconcile: {} };
}

let queue: SyncQueue = loadQueue();
let persistTimer: ReturnType<typeof setTimeout> | null = null;
let pushTimer: ReturnType<typeof setTimeout> | null = null;
let active = false; // true once server is connected & linked

function persistQueue() {
  if (persistTimer) {
    clearTimeout(persistTimer);
    persistTimer = null;
  }
  try {
    localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
  } catch {
    /* ignore */
  }
  setState({ pending: Object.keys(queue.keys).length + Object.keys(queue.reconcile).length });
}

function schedulePersist() {
  if (!persistTimer) persistTimer = setTimeout(persistQueue, 300);
}

function schedulePush() {
  if (!pushTimer) {
    pushTimer = setTimeout(() => {
      pushTimer = null;
      void syncNow();
    }, 1500);
  }
}

function markKey(store: string, key: unknown) {
  if (!active) return;
  const k = String(key);
  if (store === 'settings' && EXCLUDED_SETTINGS.has(k)) return;
  queue.keys[store + SEP + k] = ++queue.seq;
  schedulePersist();
  schedulePush();
}

function markReconcile(store: string) {
  if (!active) return;
  queue.reconcile[store] = 1;
  schedulePersist();
  schedulePush();
}

// ----------------------------------------------------------------------------
// IndexedDB change tracking (monkey-patch IDBObjectStore for MayuriAcademyDB)
// ----------------------------------------------------------------------------

// Transactions that the sync engine itself opens (remote -> local) are ignored
const ignoredTx = new WeakSet<IDBTransaction>();
let patched = false;

function shouldTrack(os: IDBObjectStore): boolean {
  try {
    return active && os.transaction.db.name === DB_NAME && !ignoredTx.has(os.transaction);
  } catch {
    return false;
  }
}

function patchIndexedDB() {
  if (patched || typeof IDBObjectStore === 'undefined') return;
  patched = true;
  const proto: any = IDBObjectStore.prototype;

  for (const method of ['put', 'add']) {
    const orig = proto[method];
    proto[method] = function (this: IDBObjectStore, ...args: any[]) {
      const req: IDBRequest = orig.apply(this, args);
      try {
        if (shouldTrack(this)) {
          const store = this.name;
          req.addEventListener('success', () => markKey(store, req.result));
        }
      } catch {
        /* ignore */
      }
      return req;
    };
  }

  const origDelete = proto.delete;
  proto.delete = function (this: IDBObjectStore, ...args: any[]) {
    const req: IDBRequest = origDelete.apply(this, args);
    try {
      if (shouldTrack(this)) {
        const store = this.name;
        const key = args[0];
        req.addEventListener('success', () => {
          if (typeof IDBKeyRange !== 'undefined' && key instanceof IDBKeyRange) markReconcile(store);
          else markKey(store, key);
        });
      }
    } catch {
      /* ignore */
    }
    return req;
  };

  const origClear = proto.clear;
  proto.clear = function (this: IDBObjectStore, ...args: any[]) {
    const req: IDBRequest = origClear.apply(this, args);
    try {
      if (shouldTrack(this)) {
        const store = this.name;
        req.addEventListener('success', () => markReconcile(store));
      }
    } catch {
      /* ignore */
    }
    return req;
  };
}

// ----------------------------------------------------------------------------
// IndexedDB helpers
// ----------------------------------------------------------------------------

const promisify = <T,>(req: IDBRequest<T>) =>
  new Promise<T>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });

async function listStores(): Promise<string[]> {
  const db = await initDB();
  return Array.from(db.objectStoreNames);
}

async function getAllKeys(store: string): Promise<IDBValidKey[]> {
  const db = await initDB();
  return promisify(db.transaction([store], 'readonly').objectStore(store).getAllKeys());
}

async function readValues(store: string, keys: IDBValidKey[]) {
  const db = await initDB();
  const os = db.transaction([store], 'readonly').objectStore(store);
  return Promise.all(
    keys.map(async (k) => {
      let value: any = await promisify(os.get(k));
      // keys are stringified in the queue; numeric keys need a second try
      if (value === undefined && typeof k === 'string' && /^-?\d+(\.\d+)?$/.test(k)) {
        value = await promisify(os.get(Number(k)));
      }
      return { key: String(k), value };
    })
  );
}

// ----------------------------------------------------------------------------
// Server status (is schema installed? who owns this server?)
// ----------------------------------------------------------------------------

interface StatusResult {
  status: 'ok' | 'unclaimed' | 'mismatch' | 'schema-missing' | 'offline' | 'error';
  message: string;
}

async function checkServerStatus(): Promise<StatusResult> {
  try {
    const { data, error } = await client.rpc('server_status', { p_key: licenseUpper() });
    if (error) {
      const text = `${(error as any).code || ''} ${error.message || ''}`;
      if (/PGRST202|42883|Could not find the function|schema cache/i.test(text)) {
        return { status: 'schema-missing', message: 'Server ka database setup (schema.sql) abhi nahi chala hai.' };
      }
      if (/Failed to fetch|NetworkError|network|fetch/i.test(text)) {
        return { status: 'offline', message: 'Internet / server tak pahunch nahi paya.' };
      }
      return { status: 'error', message: error.message || 'Server error' };
    }
    if (data === 'ok' || data === 'unclaimed' || data === 'mismatch') {
      return { status: data, message: '' };
    }
    return { status: 'error', message: 'Server ne anjaan jawab diya.' };
  } catch (e: any) {
    return { status: 'offline', message: e?.message || 'Network error' };
  }
}

// ----------------------------------------------------------------------------
// "Linked" flag (per server URL) + pull cursor (per server URL)
// ----------------------------------------------------------------------------

const readLinked = (): Record<string, number> => {
  try {
    return JSON.parse(localStorage.getItem(LINKED_KEY) || '{}');
  } catch {
    return {};
  }
};
const isLinked = (url: string) => !!readLinked()[url];
const markLinked = (url: string) => {
  try {
    localStorage.setItem(LINKED_KEY, JSON.stringify({ ...readLinked(), [url]: 1 }));
  } catch {
    /* ignore */
  }
};
const cursorKey = () => `${CURSOR_KEY}:${getConfig()?.url || ''}`;

// ----------------------------------------------------------------------------
// Push (local -> server)
// ----------------------------------------------------------------------------

async function pushRows(store: string, rows: { key: string; value: any }[]) {
  if (!rows.length) return;
  const payload = rows.map((r) =>
    r.value === undefined
      ? { store, key: r.key, value: null, deleted: true }
      : { store, key: r.key, value: r.value, deleted: false }
  );
  const { error } = await client.from(TABLE).upsert(payload, { onConflict: 'store,key' });
  if (error) throw error;
}

// A store was cleared / range-deleted: mark every server key that no longer exists locally as deleted
async function reconcileStore(store: string) {
  const local = new Set((await getAllKeys(store)).map(String));
  const gone: string[] = [];
  let from = 0;
  for (;;) {
    const { data, error } = await client
      .from(TABLE)
      .select('key')
      .eq('store', store)
      .eq('deleted', false)
      .order('key')
      .range(from, from + 999);
    if (error) throw error;
    if (!data || !data.length) break;
    for (const row of data as any[]) if (!local.has(row.key)) gone.push(row.key);
    if (data.length < 1000) break;
    from += 1000;
  }
  for (let i = 0; i < gone.length; i += 100) {
    const batch = gone.slice(i, i + 100).map((key) => ({ store, key, value: null, deleted: true }));
    const { error } = await client.from(TABLE).upsert(batch, { onConflict: 'store,key' });
    if (error) throw error;
  }
}

async function flushQueue() {
  for (const store of Object.keys(queue.reconcile)) {
    await reconcileStore(store);
    delete queue.reconcile[store];
    persistQueue();
  }

  const byStore = new Map<string, { key: string; ver: number }[]>();
  for (const [k, ver] of Object.entries(queue.keys)) {
    const i = k.indexOf(SEP);
    const store = k.slice(0, i);
    const key = k.slice(i + 1);
    if (!byStore.has(store)) byStore.set(store, []);
    byStore.get(store)!.push({ key, ver });
  }

  for (const [store, items] of byStore) {
    for (let i = 0; i < items.length; i += PUSH_BATCH) {
      const chunk = items.slice(i, i + PUSH_BATCH);
      const values = await readValues(store, chunk.map((c) => c.key));
      await pushRows(store, values);
      // only drop from queue if it was not modified again while uploading
      for (const c of chunk) {
        if (queue.keys[store + SEP + c.key] === c.ver) delete queue.keys[store + SEP + c.key];
      }
      persistQueue();
    }
  }
}

// First link: upload every local row the server doesn't have yet
async function uploadAll(serverKeys: Set<string>) {
  for (const store of await listStores()) {
    const keys = (await getAllKeys(store)).filter(
      (k) =>
        !(store === 'settings' && EXCLUDED_SETTINGS.has(String(k))) &&
        !serverKeys.has(store + SEP + String(k))
    );
    for (let i = 0; i < keys.length; i += PUSH_BATCH) {
      const values = await readValues(store, keys.slice(i, i + PUSH_BATCH));
      await pushRows(store, values.filter((v) => v.value !== undefined));
    }
  }
}

// ----------------------------------------------------------------------------
// Pull (server -> local)
// ----------------------------------------------------------------------------

async function applyRemote(rows: any[], touched: Set<string>) {
  const db = await initDB();
  const byStore = new Map<string, any[]>();
  for (const row of rows) {
    if (queue.keys[row.store + SEP + row.key]) continue; // local change not uploaded yet -> local wins
    if (row.store === 'settings' && EXCLUDED_SETTINGS.has(row.key)) continue;
    if (!db.objectStoreNames.contains(row.store)) continue;
    if (!byStore.has(row.store)) byStore.set(row.store, []);
    byStore.get(row.store)!.push(row);
  }

  for (const [store, items] of byStore) {
    await new Promise<void>((resolve, reject) => {
      const tx = db.transaction([store], 'readwrite');
      ignoredTx.add(tx); // don't echo these writes back to the server
      const os = tx.objectStore(store);
      for (const row of items) {
        if (row.deleted) {
          os.delete(row.key);
          if (/^-?\d+(\.\d+)?$/.test(row.key)) os.delete(Number(row.key));
        } else if (row.value !== null && row.value !== undefined) {
          os.put(row.value);
        }
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
      tx.onabort = () => reject(tx.error);
    });
    touched.add(store);
  }
}

// full=true -> download everything (first link), else only rows newer than the saved cursor
async function pull(full: boolean): Promise<Set<string>> {
  const seen = new Set<string>();
  const ckey = cursorKey();
  const since = full ? null : localStorage.getItem(ckey);
  let latest = since;
  let offset = 0;
  const touched = new Set<string>();

  for (;;) {
    let q = client
      .from(TABLE)
      .select('store,key,value,deleted,updated_at')
      .order('updated_at', { ascending: true })
      .order('store', { ascending: true })
      .order('key', { ascending: true })
      .range(offset, offset + PULL_PAGE - 1);
    if (since) q = q.gte('updated_at', since);

    const { data, error } = await q;
    if (error) throw error;
    if (!data || !data.length) break;

    await applyRemote(data as any[], touched);

    for (const row of data as any[]) {
      if (!row.deleted) seen.add(row.store + SEP + row.key);
      if (!latest || row.updated_at > latest) latest = row.updated_at;
    }
    if (data.length < PULL_PAGE) break;
    offset += PULL_PAGE;
  }

  if (latest) localStorage.setItem(ckey, latest);

  if (touched.size) {
    if (touched.has('students')) invalidateStudentsLite();
    window.dispatchEvent(new CustomEvent('server-sync-updated', { detail: Array.from(touched) }));
  }
  return seen;
}

async function initialLink() {
  const serverKeys = await pull(true);
  await uploadAll(serverKeys);
  markLinked(getConfig()!.url);
}

// ----------------------------------------------------------------------------
// Public API
// ----------------------------------------------------------------------------

let syncRunning = false;
let backgroundStarted = false;

/** Push pending changes, then pull new ones. Returns true on success. */
export async function syncNow(): Promise<boolean> {
  if (!active || syncRunning || !getConfig()) return false;
  syncRunning = true;
  setState({ syncing: true });
  try {
    await flushQueue();
    await pull(false);
    setState({ status: 'ready', message: '', lastSyncAt: Date.now() });
    return true;
  } catch (e: any) {
    const isNetwork = /Failed to fetch|NetworkError|network/i.test(String(e?.message || e));
    setState({
      status: 'ready',
      message: isNetwork ? 'Offline - changes internet aate hi sync honge.' : `Sync error: ${e?.message || e}`,
    });
    return false;
  } finally {
    syncRunning = false;
    setState({ syncing: false });
  }
}

function startBackgroundSync() {
  if (backgroundStarted) return;
  backgroundStarted = true;
  setInterval(() => {
    if (active) void syncNow();
  }, SYNC_INTERVAL_MS);
  window.addEventListener('online', () => {
    if (active) void syncNow();
  });
  window.addEventListener('focus', () => {
    if (active) void syncNow();
  });
  window.addEventListener('beforeunload', persistQueue);
}

function activate() {
  active = true;
  startBackgroundSync();
}

async function prepare(): Promise<{ cfg: ServerConfig; license: string } | null> {
  patchIndexedDB();
  const license = licenseUpper();
  if (!license) {
    setState({ status: 'no-license', message: 'Pehle license key daalein.' });
    return null;
  }
  const cfg = await loadConfig();
  if (!cfg) {
    setState({ status: 'no-config', url: '' });
    return null;
  }
  applyConfig(cfg, license);
  setState({ status: 'checking', message: '', url: cfg.url });
  persistQueue();
  return { cfg, license };
}


// ----------------------------------------------------------------------------
// Helpers for "Forgot Password" (license-key based admin reset)
// ----------------------------------------------------------------------------

/** true jab server connected + linked ho (data Supabase se sync ho raha hai). */
export const isServerActive = (): boolean => active && !!getConfig();

/**
 * Supabase se poochta hai: kya ye license key is server ki owner key hai?
 * 'unavailable' = server is device par chalu hi nahi hai (sirf local app).
 */
export async function verifyLicenseWithServer(
  key: string
): Promise<'ok' | 'mismatch' | 'offline' | 'error' | 'unavailable'> {
  if (!isServerActive()) return 'unavailable';
  try {
    const { data, error } = await client.rpc('server_status', { p_key: key.trim().toUpperCase() });
    if (error) {
      return /Failed to fetch|NetworkError|network|fetch/i.test(error.message || '') ? 'offline' : 'error';
    }
    if (data === 'ok') return 'ok';
    if (data === 'mismatch') return 'mismatch';
    return 'error';
  } catch {
    return 'offline';
  }
}

/** Call once at app start (after license validation + IndexedDB migration). */
export async function initServerSync(): Promise<ServerSyncState> {
  const prep = await prepare();
  if (!prep) return state;

  const st = await checkServerStatus();
  if (st.status === 'ok') {
    saveConfig(prep.cfg);
    if (isLinked(prep.cfg.url)) {
      activate();
      await Promise.race([syncNow(), new Promise((r) => setTimeout(r, 20_000))]);
    } else {
      try {
        await initialLink();
        activate();
        setState({ status: 'ready', message: '', lastSyncAt: Date.now() });
      } catch (e: any) {
        setState({ status: 'error', message: e?.message || 'Data download fail hua.' });
      }
    }
  } else if (st.status === 'offline' && isLinked(prep.cfg.url)) {
    activate();
    setState({ status: 'ready', message: 'Offline - changes internet aate hi sync honge.' });
  } else {
    setState({ status: st.status, message: st.message });
  }
  return state;
}

/** "Connect Server" button: claims an unclaimed server for this license and uploads local data. */
export async function connectServer(): Promise<ServerSyncState> {
  const prep = await prepare();
  if (!prep) return state;

  let st = await checkServerStatus();
  if (st.status === 'unclaimed') {
    const { data, error } = await client.rpc('claim_server', { p_key: prep.license });
    if (error || data !== true) {
      setState({ status: 'error', message: error?.message || 'Server claim nahi ho paya.' });
      return state;
    }
    st = { status: 'ok', message: '' };
  }

  if (st.status === 'ok') {
    try {
      saveConfig(prep.cfg);
      setState({ status: 'checking', message: 'Data server par chadh raha hai...' });
      await initialLink();
      activate();
      setState({ status: 'ready', message: '', lastSyncAt: Date.now() });
    } catch (e: any) {
      setState({ status: 'error', message: e?.message || 'Connect fail hua.' });
    }
  } else {
    setState({
      status: st.status,
      message: st.status === 'mismatch' ? 'Ye server kisi dusri license key ka hai.' : st.message,
    });
  }
  return state;
}
