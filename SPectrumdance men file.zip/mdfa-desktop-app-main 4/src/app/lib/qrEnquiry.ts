// QR Enquiry — CMS side.
//
// Flow:  Settings -> Enquiry Settings -> QR Enquiry (toggle ON)  ->  Enquiry section me "QR Enquiry" tab aata hai
//        Student QR scan karke form bharta hai (Name, Phone, Course)  ->  Google Sheet ke "QrEnquiries" tab me row aati hai
//        CMS har ~4 sec me chhota check karta hai (aur CMS khulte hi turant); nayi row ho to turant le leta hai
//        aur apne LOCAL storage (IndexedDB) me save kar leta hai. CMS me jo dikhta hai wo local se hi dikhta hai.
//
// Google Sheet sirf beech ka rasta hai: wahan rows 7 din baad apne aap delete ho jati hain, lekin CMS me
// enquiry kabhi isse delete nahi hoti (sirf admin ke Delete dabane par).
//
// Ye Attendance wale Google Apps Script ka hi extra hissa hai (same web app URL, koi alag script nahi), isliye pehle
// Settings -> Management & Setup -> Attendance Setup me script connect hona chahiye.

import { useEffect, useState } from 'react';
import { toast } from 'sonner';
import { getSetting, saveSetting, saveEnquiry, getAllEnquiries } from './indexedDB';
import { getAttendanceConfig, scriptGet, scriptPost } from './attendance';
import { getEnquiryCourses, ENQUIRY_COURSES_EVENT, type Enquiry } from './enquiries';

const KEY_ENABLED = 'qrEnquiryEnabled';
const KEY_CFG_HASH = 'qrEnquiryCfgHash';
const KEY_LAST_SEQ = 'qrEnquiryLastSeq';   // sheet ki kitni rows tak CMS le chuka hai
const KEY_SEQ_URL = 'qrEnquirySeqUrl';      // kis web app link ka counter hai (link badle to counter naye sire se)

export const QR_ENQUIRY_EVENT = 'qrEnquiryToggled';   // toggle ON / OFF hua
export const QR_ENQUIRY_NEW_EVENT = 'qrEnquiryChanged'; // local storage me nayi QR enquiry aayi
export const QR_SOURCE = 'Office Visit';

const POLL_MS = 4000;

// ---------- on / off ----------

export async function getQrEnquiryEnabled(): Promise<boolean> {
  return (await getSetting(KEY_ENABLED)) === true;
}

/** Toggle turant save hota hai (tab aa jata / chala jata hai). Sheet ko batana (open / band) best-effort hai. */
export async function setQrEnquiryEnabled(enabled: boolean): Promise<{ pushed: boolean; error?: string }> {
  await saveSetting(KEY_ENABLED, enabled);
  window.dispatchEvent(new CustomEvent(QR_ENQUIRY_EVENT));
  try {
    return { pushed: await pushQrEnquiryConfig(true) };
  } catch (e: any) {
    return { pushed: false, error: qrEnquiryError(e) };
  }
}

export function qrEnquiryError(e: any): string {
  const msg = String(e?.message || e || '');
  if (/qenqPost_|qenqGet_|qenqPage_|is not defined|unknown action/i.test(msg)) {
    return 'Google Script purani hai. Settings → Management & Setup → Attendance Setup se naya code copy karke Apps Script me paste karein aur dobara Deploy karein (script ek hi hai).';
  }
  return msg || 'Google Sheet se baat nahi ho payi.';
}

export async function getQrEnquiryLink(): Promise<string> {
  const cfg = await getAttendanceConfig();
  return cfg.webAppUrl ? `${cfg.webAppUrl}?page=enquiry` : '';
}

export function useQrEnquiryEnabled(): boolean {
  const [on, setOn] = useState(false);
  useEffect(() => {
    let alive = true;
    const load = () => getQrEnquiryEnabled().then((v) => { if (alive) setOn(v); });
    load();
    window.addEventListener(QR_ENQUIRY_EVENT, load);
    return () => { alive = false; window.removeEventListener(QR_ENQUIRY_EVENT, load); };
  }, []);
  return on;
}

// ---------- config -> Google Sheet (form open / band + course list) ----------

/** Form me wahi courses dikhte hain jo Settings -> Enquiry Settings -> Courses me hain. Pehle jaisa ho to kuch nahi bhejta. */
export async function pushQrEnquiryConfig(force = false): Promise<boolean> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return false;
  const open = await getQrEnquiryEnabled();
  const courses = await getEnquiryCourses();
  const hash = JSON.stringify([cfg.webAppUrl, open, courses]);
  if (!force && (await getSetting(KEY_CFG_HASH)) === hash) return false;
  await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'qenq_config', open, courses }, 60000);
  await saveSetting(KEY_CFG_HASH, hash);
  return true;
}

// ---------- Sheet -> local storage ----------

let syncing = false;

/** Sheet se nayi enquiries leta hai aur LOCAL storage me save karta hai. Kitni nayi aayi wo wapas deta hai. */
export async function syncQrEnquiries(): Promise<number> {
  if (syncing) return 0;
  syncing = true;
  try {
    const cfg = await getAttendanceConfig();
    if (!cfg.webAppUrl) return 0;

    // Naya web app link = naya sheet = counter 0 se shuru
    if ((await getSetting(KEY_SEQ_URL)) !== cfg.webAppUrl) {
      await saveSetting(KEY_LAST_SEQ, 0);
      await saveSetting(KEY_SEQ_URL, cfg.webAppUrl);
    }
    let last = Number(await getSetting(KEY_LAST_SEQ)) || 0;

    // Ek hi halki call: "last ke baad kuch naya?". Kuch na ho to Google turant khaali jawab deta hai (sheet padhe bina).
    let added = 0;
    const names: string[] = [];
    let resets = 0;
    for (let round = 0; round < 15; round++) {
      const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'qenq_list', since: String(last) });
      const ver = Number(d.ver) || 0;
      if (ver < last && resets === 0) {
        // Sheet / script naya ho gaya -> sab dobara dekho (id se duplicate nahi banta)
        resets++; last = 0; await saveSetting(KEY_LAST_SEQ, 0); continue;
      }
      const items: any[] = d.items || [];
      if (items.length === 0) {
        // Purani rows 7 din baad delete ho chuki: counter ko aage badha do taaki baar baar list na maange
        if (ver > last) { last = ver; await saveSetting(KEY_LAST_SEQ, last); }
        break;
      }
      const existing = new Set<string>(((await getAllEnquiries()) || []).map((e: Enquiry) => e.id));
      for (const it of items) {
        const id = `qr_${it.id}`;
        if (!existing.has(id)) {
          const ms = Number(it.ms) || Date.now();
          const enquiry: Enquiry = {
            id,
            name: String(it.name || '').trim(),
            phone: String(it.phone || '').replace(/\D/g, '').slice(-10),
            course: String(it.course || ''),
            source: String(it.source || QR_SOURCE),
            status: 'interested',
            followUpDone: false,
            createdAt: new Date(ms).toISOString(),
            fromQr: true,
            qrPending: true,
          };
          await saveEnquiry(enquiry);   // pehle local me save...
          added++;
          names.push(enquiry.name);
        }
        last = Math.max(last, Number(it.seq) || 0);
      }
      await saveSetting(KEY_LAST_SEQ, last); // ...phir counter aage (beech me band ho to dobara le leta hai)
      if (!d.more) break;
    }

    if (added > 0) {
      window.dispatchEvent(new CustomEvent(QR_ENQUIRY_NEW_EVENT));
      toast.success(added === 1 ? `Nayi QR enquiry: ${names[0]}` : `${added} nayi QR enquiry aayi`);
    }
    return added;
  } finally {
    syncing = false;
  }
}

// ---------- background sync (AdminDashboard me ek baar mount hota hai) ----------
// 1) course list / toggle badle to config Sheet ko bhejta hai
// 2) har ~10 sec me nayi enquiry check karta hai (toggle ON ho tabhi; app chhupi ho to ruk jata hai)

export function useQrEnquirySync() {
  useEffect(() => {
    let stopped = false;
    let running = false;
    let cfgTimer: any = null;

    const pushSoon = () => {
      clearTimeout(cfgTimer);
      cfgTimer = setTimeout(async () => {
        try { if (await getQrEnquiryEnabled()) await pushQrEnquiryConfig(); } catch { /* agli baar phir koshish */ }
      }, 3000);
    };
    const evs = [ENQUIRY_COURSES_EVENT, 'categoriesUpdated'];
    evs.forEach((e) => window.addEventListener(e, pushSoon));
    pushSoon();

    const tick = async () => {
      if (stopped || running || document.hidden) return;
      running = true;
      try {
        if (await getQrEnquiryEnabled()) await syncQrEnquiries();
      } catch { /* net slow / band: agli baar */ }
      running = false;
    };
    tick();
    const iv = setInterval(tick, POLL_MS);
    const onVisible = () => { if (!document.hidden) tick(); };
    document.addEventListener('visibilitychange', onVisible);
    window.addEventListener('online', tick);
    window.addEventListener('focus', tick);
    window.addEventListener(QR_ENQUIRY_EVENT, tick);

    return () => {
      stopped = true;
      clearInterval(iv);
      clearTimeout(cfgTimer);
      evs.forEach((e) => window.removeEventListener(e, pushSoon));
      document.removeEventListener('visibilitychange', onVisible);
      window.removeEventListener('online', tick);
      window.removeEventListener('focus', tick);
      window.removeEventListener(QR_ENQUIRY_EVENT, tick);
    };
  }, []);
}
