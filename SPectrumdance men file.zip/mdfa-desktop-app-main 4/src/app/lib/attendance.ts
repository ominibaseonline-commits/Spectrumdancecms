// QR Attendance — CMS side helpers.
//
// Flow:  CMS  --(sync students / config)-->  Google Apps Script (Google Sheet)
//        Student scans QR -> Apps Script page -> reg no + last 4 digits -> check-in
//        CMS  <--(read today's attendance)--  Google Apps Script
//
// Everything is stored in the existing IndexedDB "settings" store, so no schema change is needed.
//
// IMPORTANT (how data lives):
//  - The Google Sheet is only a RELAY (staff phones / student QR -> sheet -> CMS). It keeps attendance for
//    SHEET_KEEP_DAYS days only and deletes older rows by itself.
//  - This computer's local storage (IndexedDB) is the real record. Every entry is saved here the moment it
//    arrives; student history / reports are read from here, never re-loaded from the sheet.
//  - Google is asked only for what is NEW (tiny "delta" ping), and only for days still inside the sheet window.

import { compressPhotoToTarget } from './imageCompress';
import { useEffect } from 'react';
import jsPDF from 'jspdf';
import { getStudentsLite, getSetting, saveSetting, getAllPayments } from './indexedDB';
import { DuesSplit, splitDues } from './dues';
import { qrToDataUrl } from './qr';
// The Apps Script source lives in its own .gs file and is imported as plain text.
import scriptTemplate from './attendanceScript.gs?raw';
// Mobile page staff open from the link the admin shares (served by the same Apps Script)
import staffPageHtml from './staffPage.html?raw';
// Online Admission (QR form) — extra part of the same script, kept in its own files.
import admissionTemplate from './onlineAdmissionScript.gs?raw';
import admissionPageHtml from './onlineAdmissionPage.html?raw';
import idCardLib from './idCardRender.js?raw';   // ID card design: Online Admission page + Google Script me bhi jati hai
import { ADM_THEME } from './assets/admTheme';   // Spectrum banner / ID card images (form, mail, PDF)
// QR Enquiry (Name / Phone / Course form) — another extra part of the same script.
import qrEnquiryTemplate from './qrEnquiryScript.gs?raw';
import qrEnquiryPageHtml from './qrEnquiryPage.html?raw';
// Google Review (star + keywords -> AI review -> Google link) — another extra part of the same script.
import reviewTemplate from './reviewScript.gs?raw';
import reviewPageHtml from './reviewPage.html?raw';
import { buildEventsScriptPart } from '../events/lib/eventsScriptBuild'; // Events (isolated module)

export interface AttendanceConfig {
  webAppUrl: string;
  adminKey: string;
  enableCheckout: boolean;
  blockExpired: boolean;
  lastSyncAt: string;
}

export interface AttendanceRecord {
  regNo: string;
  checkIn: string;
  checkOut: string;
}

const KEY_URL = 'attendanceWebAppUrl';
const KEY_ADMIN = 'attendanceAdminKey';
const KEY_CHECKOUT = 'attendanceEnableCheckout';
const KEY_BLOCK = 'attendanceBlockExpired';
const KEY_LAST_SYNC = 'attendanceLastSync';
const KEY_SYNC_STATE = 'attendanceSyncState';
const KEY_CFG_HASH = 'attendanceConfigHash';
const KEY_STAFF = 'attendanceStaff';
const KEY_STAFF_HASH = 'attendanceStaffHash';
const KEY_LAST_URL = 'attendanceLastUrl';       // the web app URL used last time (kept after Disconnect, to know if it is the same sheet again)
const KEY_SHEET_SINCE = 'attendanceSheetSince'; // day this sheet was first connected (older days live only on this computer)
const KEY_ATT_CACHE = 'attCache:';          // + date  -> that day's records, saved locally
const KEY_ATT_CACHE_DATES = 'attCacheDates'; // list of cached dates (old ones are pruned)
const KEY_ATT_PENDING = 'attPending';        // admin check-ins saved here but not yet confirmed by Google
const KEEP_CACHED_DAYS = 3650; // ~10 years: the local copy is the permanent record (the Google Sheet keeps only 7 days)
const SHEET_KEEP_DAYS = 7;     // must match KEEP_DAYS in the Apps Script

// ---------- settings ----------

function randomKey(): string {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
}

export async function getAdminKey(): Promise<string> {
  let key = await getSetting(KEY_ADMIN);
  if (!key) {
    key = randomKey();
    await saveSetting(KEY_ADMIN, key);
  }
  return key;
}

export async function getAttendanceConfig(): Promise<AttendanceConfig> {
  const [webAppUrl, adminKey, enableCheckout, blockExpired, lastSyncAt] = await Promise.all([
    getSetting(KEY_URL),
    getAdminKey(),
    getSetting(KEY_CHECKOUT),
    getSetting(KEY_BLOCK),
    getSetting(KEY_LAST_SYNC),
  ]);
  return {
    webAppUrl: webAppUrl || '',
    adminKey,
    enableCheckout: !!enableCheckout,
    blockExpired: !!blockExpired,
    lastSyncAt: lastSyncAt || '',
  };
}

export async function isAttendanceConnected(): Promise<boolean> {
  return !!(await getSetting(KEY_URL));
}

export async function saveAttendanceOptions(opts: { enableCheckout?: boolean; blockExpired?: boolean }) {
  if (opts.enableCheckout !== undefined) await saveSetting(KEY_CHECKOUT, opts.enableCheckout);
  if (opts.blockExpired !== undefined) await saveSetting(KEY_BLOCK, opts.blockExpired);
  // Open attendance screens re-read the switches (e.g. the Check Out column appears at once)
  window.dispatchEvent(new CustomEvent('attendanceConfigUpdated'));
}

export async function disconnectAttendance() {
  // Local attendance history stays on this computer (it is the permanent record); only the link is removed.
  // The URL is remembered so that connecting the SAME link again is recognised as the same sheet.
  const current = await getSetting(KEY_URL);
  if (current) await saveSetting(KEY_LAST_URL, current);
  await saveSetting(KEY_URL, '');
  await saveSetting(KEY_SYNC_STATE, null);
  await saveSetting(KEY_CFG_HASH, '');
  await saveSetting(KEY_LAST_SYNC, '');
  await saveSetting(KEY_STAFF_HASH, '');
}

/** The full Apps Script code with this CMS's secret key already filled in. */
export function buildAttendanceScript(adminKey: string): string {
  const base = scriptTemplate
    .replace('__ADMIN_KEY__', () => adminKey)
    .replace('__STAFF_HTML__', () => JSON.stringify(staffPageHtml));
  // Shared ID card code ko ek function ke andar band karke diya jata hai, taaki baaki script ke naam na takrayein
  const idcBody = idCardLib.replace(/^export /gm, '');
  const pageIdc = `var IDC = (function(){\n${idcBody}\nreturn { render: renderIdCardSide, css: ID_CARD_CSS, normalize: normalizeIdCardSettings };\n})();`;
  const scriptIdc = `var IDC_ = (function(){\n${idcBody}\nreturn { normalize: normalizeIdCardSettings };\n})();`;
  const pageHtml = admissionPageHtml.replace('/*__ID_CARD_LIB__*/', () => pageIdc);
  const admission = admissionTemplate
    .replace('__ADM_HTML__', () => JSON.stringify(pageHtml))
    .replace('__ADM_THEME__', () => JSON.stringify(ADM_THEME))
    .replace('/*__ID_CARD_LIB__*/', () => scriptIdc);
  const qrEnquiry = qrEnquiryTemplate.replace('__QENQ_HTML__', () => JSON.stringify(qrEnquiryPageHtml));
  const review = reviewTemplate.replace('__REV_HTML__', () => JSON.stringify(reviewPageHtml));
  const events = buildEventsScriptPart();
  return base + '\n\n' + admission + '\n\n' + qrEnquiry + '\n\n' + review + '\n\n' + events;
}

export function isValidWebAppUrl(url: string): boolean {
  return /^https:\/\/script\.google\.com\/(a\/[^/]+\/)?macros\/s\/[^/]+\/exec$/.test(url.trim());
}

// ---------- network ----------

async function request(url: string, init: RequestInit = {}, timeoutMs = 60000): Promise<any> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, { ...init, signal: controller.signal });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const text = await res.text();
    try {
      return JSON.parse(text);
    } catch {
      // Apps Script returns an HTML page when the deployment is wrong / not public
      throw new Error('Script se sahi jawab nahi mila. Deploy settings check karein (Who has access: Anyone).');
    }
  } finally {
    clearTimeout(timer);
  }
}

export async function scriptPost(url: string, adminKey: string, body: any, timeoutMs = 120000) {
  const data = await request(
    url,
    {
      method: 'POST',
      // text/plain keeps this a "simple" request (no CORS preflight, which Apps Script can't answer)
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify({ key: adminKey, ...body }),
    },
    timeoutMs,
  );
  if (!data?.success) {
    throw new Error(data?.error === 'unauthorized'
      ? 'Secret key match nahi hui. CMS me dikha hua latest code script me paste karke dobara deploy karein.'
      : data?.error || 'Script error');
  }
  return data;
}

export async function scriptGet(url: string, adminKey: string, params: Record<string, string>) {
  const q = new URLSearchParams({ key: adminKey, ...params }).toString();
  const data = await request(`${url}?${q}`, { method: 'GET' }, 30000);
  if (!data?.success) {
    throw new Error(data?.error === 'unauthorized'
      ? 'Secret key match nahi hui. CMS me dikha hua latest code script me paste karke dobara deploy karein.'
      : data?.error || 'Script error');
  }
  return data;
}

// ---------- connect ----------

export interface ConnectResult {
  sameSheet: boolean;     // true = same web app link as before (its change counter and data carry on)
  latestBefore: string;   // newest day this computer had before connecting ('' = none)
  daysFilled: number;     // days checked / downloaded from the sheet right after connecting
}

export async function connectAttendance(url: string): Promise<ConnectResult> {
  const clean = url.trim();
  if (!isValidWebAppUrl(clean)) {
    throw new Error('URL galat hai. Ye "https://script.google.com/macros/s/.../exec" jaisa hona chahiye.');
  }
  const adminKey = await getAdminKey();
  await scriptGet(clean, adminKey, { action: 'ping' });
  await scriptPost(clean, adminKey, { action: 'setup' });
  // Same link as last time -> same sheet: keep its change counters, just catch up what is missing.
  // Different link -> a new sheet that counts from 0: forget the counters, keep every saved day.
  const lastUrl = ((await getSetting(KEY_LAST_URL)) || '') as string;
  const sameSheet = lastUrl === clean;
  if (!sameSheet) {
    await resetCacheVersions();
    await saveSetting(KEY_SHEET_SINCE, localToday());
  }
  await saveSetting(KEY_URL, clean);
  await saveSetting(KEY_LAST_URL, clean);
  await saveSetting(KEY_SYNC_STATE, null);
  await saveSetting(KEY_CFG_HASH, '');
  await pushAttendanceConfig(true);
  await pushStaffConfig(true);
  await syncStudentsToScript({ force: true });

  // Right away: how recent is this computer's data? Anything missing (up to the sheet's 7 days) comes from the sheet now.
  let latestBefore = '';
  let daysFilled = 0;
  try {
    const r = await catchUpFromSheet();
    latestBefore = r.latestBefore;
    daysFilled = r.daysChecked;
  } catch {
    // Connected fine; the live sync repeats the catch-up as soon as the internet is stable
  }
  return { sameSheet, latestBefore, daysFilled };
}

// ---------- config push (business name, logo, switches) ----------

// Small JPEG copy of the logo — keeps the Google Sheet cell well under its size limit.
function shrinkLogo(dataUrl: string, max = 160): Promise<string> {
  if (!dataUrl) return Promise.resolve('');
  return compressPhotoToTarget(dataUrl, undefined, max).catch(() => '');
}

export async function pushAttendanceConfig(force = false): Promise<void> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return;
  const [businessName, businessLogo] = await Promise.all([getSetting('businessName'), getSetting('businessLogo')]);
  const hash = JSON.stringify([businessName, (businessLogo || '').length, cfg.enableCheckout, cfg.blockExpired]);
  if (!force && (await getSetting(KEY_CFG_HASH)) === hash) return;
  const logo = await shrinkLogo(businessLogo || '');
  await scriptPost(cfg.webAppUrl, cfg.adminKey, {
    action: 'config',
    businessName: businessName || 'Attendance',
    logo,
    enableCheckout: cfg.enableCheckout,
    blockExpired: cfg.blockExpired,
  });
  await saveSetting(KEY_CFG_HASH, hash);
}

// ---------- student sync ----------

function studentRow(s: any, dues?: DuesSplit, flexi?: { total: number; startDate: string; base: number }): any[] {
  const digits = String(s.mobile || '').replace(/\D/g, '');
  return [
    String(s.regNo ?? ''),
    s.name || '',
    digits.length >= 4 ? digits.slice(-4) : '',
    s.expiryDate ? String(s.expiryDate).slice(0, 10) : '',
    Number(s.dues) || 0,
    s.status || 'active',
    s.batchTime || '',
    s.location || '',
    s.category || '',
    dues?.admission || 0,                              // AdmDues  (staff panel)
    dues?.monthly || 0,                                // MonDues  (staff panel)
    flexi ? `${flexi.total}|${flexi.startDate}|${flexi.base}` : '',  // Flexi "total|startDate|base" (staff panel). base = classes before the sheet's 7-day window (counted here, the sheet deletes them)
  ];
}

// Flexi: the sheet deletes attendance older than 7 days, so the classes already taken before that window are
// counted here (from the permanent local record) and sent along; the sheet adds the days it still holds.
let flexiBaseMemo: { key: string; map: Record<string, number> } | null = null;
async function computeFlexiBase(plans: Record<string, any>): Promise<Record<string, number>> {
  const list = Object.values(plans);
  if (list.length === 0) return {};
  // Days the sheet itself no longer holds (older than 7 days) or never held (before this sheet was connected)
  const since = ((await getSetting(KEY_SHEET_SINCE)) || '') as string;
  const winStart = since && since > sheetWindowStart() ? since : sheetWindowStart();
  const dates = ((await getSetting(KEY_ATT_CACHE_DATES)) || []) as string[];
  const old = dates.filter((d) => d < winStart);
  const key = JSON.stringify([winStart, old.length, list.map((p: any) => [p.regNo, p.startDate])]);
  if (flexiBaseMemo?.key === key) return flexiBaseMemo.map;
  const map: Record<string, number> = {};
  for (const d of old) {
    const c = await readAttendanceCache(d);
    if (!c) continue;
    for (const r of c.records) {
      if (!r.checkIn) continue;
      const reg = String(r.regNo).toLowerCase();
      const plan = plans[reg];
      if (plan && d >= plan.startDate) map[reg] = (map[reg] || 0) + 1;
    }
  }
  flexiBaseMemo = { key, map };
  return map;
}

let syncing: Promise<{ changed: number; total: number }> | null = null;

/**
 * Pushes active (non-deactivated) students to the Google Sheet.
 * After the first full sync only changed students are sent.
 */
export function syncStudentsToScript(opts: { force?: boolean } = {}): Promise<{ changed: number; total: number }> {
  if (syncing) return syncing;
  syncing = (async () => {
    const cfg = await getAttendanceConfig();
    if (!cfg.webAppUrl) throw new Error('Attendance connect nahi hai');

    const all = await getStudentsLite(); // lite = no photos, cached in memory
    const active = all.filter((s: any) => !s.deactivated && s.regNo);
    const duesMap = await buildDuesMap(active);
    const plans: Record<string, any> = (await getSetting('flexiPlans')) || {};
    const flexiBase = await computeFlexiBase(plans);
    const rows = active.map((s: any) => {
      const plan = plans[String(s.regNo).toLowerCase()];
      return studentRow(
        s,
        duesMap[String(s.regNo)],
        plan ? { total: plan.total, startDate: plan.startDate, base: flexiBase[String(s.regNo).toLowerCase()] || 0 } : undefined,
      );
    });
    const hashes: Record<string, string> = {};
    rows.forEach((r) => { hashes[r[0]] = r.join('|'); });

    const prev: Record<string, string> | null = await getSetting(KEY_SYNC_STATE);
    const changedRows = prev ? rows.filter((r) => prev[r[0]] !== hashes[r[0]]) : rows;
    const removed = prev ? Object.keys(prev).filter((k) => !(k in hashes)) : [];

    if (prev && !opts.force && changedRows.length === 0 && removed.length === 0) {
      return { changed: 0, total: rows.length };
    }

    if (!prev || opts.force || changedRows.length > 1500 || removed.length > 1500) {
      // Full refresh, in chunks
      const CHUNK = 2500;
      for (let i = 0; i === 0 || i < rows.length; i += CHUNK) {
        await scriptPost(cfg.webAppUrl, cfg.adminKey, {
          action: 'sync',
          reset: i === 0,
          append: i !== 0,
          upserts: rows.slice(i, i + CHUNK),
        });
        if (rows.length === 0) break;
      }
    } else {
      await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'sync', upserts: changedRows, removed });
    }

    await saveSetting(KEY_SYNC_STATE, hashes);
    await saveSetting(KEY_LAST_SYNC, new Date().toISOString());
    return { changed: prev && !opts.force ? changedRows.length + removed.length : rows.length, total: rows.length };
  })().finally(() => { syncing = null; });
  return syncing;
}

// ---------- read attendance (local cache first, Google only when something changed) ----------
//
// Every day's records are saved in the CMS's own IndexedDB.
//  - Past days (already fetched after the day ended) are NEVER requested from Google again.
//  - Today: a tiny "version" ping is sent; the full list is downloaded only if a student
//    has checked in / out since the last download.

interface AttendanceCache {
  records: AttendanceRecord[];
  version: string;   // script's attendance counter at the time of download
  fetchedOn: string; // local date when it was downloaded (to know if a past day is final)
  savedAt: string;   // ISO time, shown as "last updated"
}

export interface AttendanceResult {
  records: Record<string, AttendanceRecord>;
  savedAt: string;
  fromCache: boolean; // true = no data was downloaded from Google
}

const localToday = () => new Date().toLocaleDateString('en-CA'); // YYYY-MM-DD

const toRecordMap = (list: AttendanceRecord[]) => {
  const map: Record<string, AttendanceRecord> = {};
  list.forEach((r) => { map[String(r.regNo).toLowerCase()] = r; });
  return map;
};

async function readAttendanceCache(date: string): Promise<AttendanceCache | null> {
  const c = await getSetting(KEY_ATT_CACHE + date);
  return c && Array.isArray(c.records) ? (c as AttendanceCache) : null;
}

async function writeAttendanceCache(date: string, cache: AttendanceCache) {
  await saveSetting(KEY_ATT_CACHE + date, cache);
  const dates: string[] = (await getSetting(KEY_ATT_CACHE_DATES)) || [];
  if (!dates.includes(date)) dates.push(date);
  dates.sort();
  while (dates.length > KEEP_CACHED_DAYS) {
    const old = dates.shift() as string;
    await saveSetting(KEY_ATT_CACHE + old, null);
  }
  await saveSetting(KEY_ATT_CACHE_DATES, dates);
}

export async function clearAttendanceCache() {
  const dates: string[] = (await getSetting(KEY_ATT_CACHE_DATES)) || [];
  for (const d of dates) await saveSetting(KEY_ATT_CACHE + d, null);
  await saveSetting(KEY_ATT_CACHE_DATES, []);
}

/** Forget the sheet's change counter of every saved day (the saved records themselves stay). */
async function resetCacheVersions() {
  const dates: string[] = (await getSetting(KEY_ATT_CACHE_DATES)) || [];
  for (const d of dates) {
    const c = await readAttendanceCache(d);
    if (c && c.version) await saveSetting(KEY_ATT_CACHE + d, { ...c, version: '' });
  }
}

const addDays = (date: string, n: number) => {
  const [y, m, d] = date.split('-').map(Number);
  return new Date(y, m - 1, d + n).toLocaleDateString('en-CA');
};
/** First date that the Google Sheet still holds (older days were deleted there; only this computer has them). */
const sheetWindowStart = () => addDays(localToday(), -SHEET_KEEP_DAYS);

/** Dates (YYYY-MM-DD) whose attendance is already saved on this computer. */
export async function getCachedAttendanceDates(): Promise<string[]> {
  return ((await getSetting(KEY_ATT_CACHE_DATES)) || []) as string[];
}

/**
 * Dates that really have attendance (at least one check-in / check-out) saved on this computer.
 * Connecting to the sheet saves the last 7 days as EMPTY copies too; those are not counted here,
 * so "QR Attendance days" shows only days on which someone was actually marked.
 */
export async function getAttendanceDaysWithData(): Promise<string[]> {
  const dates = await getCachedAttendanceDates();
  const out: string[] = [];
  for (const d of dates) {
    const c = await readAttendanceCache(d);
    if (c && Array.isArray(c.records) && c.records.some((r: any) => r && (r.checkIn || r.checkOut))) out.push(d);
  }
  return out;
}

/** Instant, offline: whatever is already saved on this computer for that date. */
export async function getCachedAttendance(date: string): Promise<AttendanceResult | null> {
  const c = await readAttendanceCache(date);
  return c ? { records: toRecordMap(c.records), savedAt: c.savedAt, fromCache: true } : null;
}

// ---------- admin actions saved on this computer first, Google confirms afterwards ----------
// Google Sheet is only the data relay (staff phones / student QR -> sheet -> CMS). When the admin
// marks someone here, it is written to the local copy instantly and then sent to the sheet. If the
// internet is down, it stays in a pending list and is re-sent automatically.

type PendingKind = 'in' | 'out' | 'submit';
interface PendingItem { kind?: PendingKind; regNo: string; date: string; time: string; batch?: string }

const kindOf = (p: PendingItem): PendingKind => p.kind || 'in';
const sameItem = (a: PendingItem, b: PendingItem) =>
  kindOf(a) === kindOf(b) && a.date === b.date &&
  (kindOf(a) === 'submit' ? a.batch === b.batch : a.regNo.toLowerCase() === b.regNo.toLowerCase());

const nowTimeStr = () => new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true }); // "09:05 AM"

async function getPending(): Promise<PendingItem[]> {
  const l = await getSetting(KEY_ATT_PENDING);
  return Array.isArray(l) ? (l as PendingItem[]) : [];
}
async function addPending(p: PendingItem) {
  const l = (await getPending()).filter((x) => !sameItem(x, p));
  l.push(p);
  await saveSetting(KEY_ATT_PENDING, l);
}
async function removePending(p: PendingItem) {
  const l = (await getPending()).filter((x) => !sameItem(x, p));
  await saveSetting(KEY_ATT_PENDING, l);
}

/** Puts not-yet-confirmed check-ins / check-outs of that date into a record map (so a download from Google never hides them). */
async function applyPending(date: string, map: Record<string, AttendanceRecord>) {
  (await getPending()).filter((p) => p.date === date && kindOf(p) !== 'submit').forEach((p) => {
    const key = p.regNo.toLowerCase();
    const rec = map[key] || { regNo: p.regNo, checkIn: '', checkOut: '' };
    if (kindOf(p) === 'in') { if (!rec.checkIn) rec.checkIn = p.time; }
    else if (rec.checkIn && !rec.checkOut) rec.checkOut = p.time;
    map[key] = rec;
  });
}

async function patchLocalRecord(date: string, regNo: string, fn: (rec: AttendanceRecord) => AttendanceRecord | null) {
  const cached = await readAttendanceCache(date);
  const map = toRecordMap(cached?.records || []);
  const key = String(regNo).toLowerCase();
  const rec = map[key] || { regNo: String(regNo), checkIn: '', checkOut: '' };
  const next = fn(rec);
  if (next) map[key] = next; else delete map[key];
  await writeAttendanceCache(date, {
    records: Object.values(map),
    version: cached?.version || '', // unchanged: the live sync will simply re-merge this same entry
    fetchedOn: date,
    savedAt: new Date().toISOString(),
  });
}

const setLocalCheckIn = (date: string, regNo: string, time: string) =>
  patchLocalRecord(date, regNo, (r) => ({ ...r, checkIn: time }));
const setLocalCheckOut = (date: string, regNo: string, time: string) =>
  patchLocalRecord(date, regNo, (r) => ({ ...r, checkOut: time }));
const removeLocalCheckIn = (date: string, regNo: string) =>
  patchLocalRecord(date, regNo, (r) => (r.checkOut ? { ...r, checkIn: '' } : null));
const removeLocalCheckOut = (date: string, regNo: string) =>
  patchLocalRecord(date, regNo, (r) => ({ ...r, checkOut: '' }));

const notifyUpdated = (date: string) => window.dispatchEvent(new CustomEvent('attendanceUpdated', { detail: { date } }));

// ---------- submitted batches (Daily Attendance panel is locked for the day) ----------

const KEY_SUBMITTED = 'attSubmitted:'; // + date -> ["07:00 AM To 09:00 AM", ...]

/** Batches whose attendance is submitted for that date (from this CMS or from a staff phone). Nothing can mark that batch any more. */
export async function getSubmittedBatches(date: string): Promise<string[]> {
  const l = await getSetting(KEY_SUBMITTED + date);
  return Array.isArray(l) ? (l as string[]) : [];
}

/** Submit a batch's attendance from the Daily Attendance panel: saved here first (locks the batch here), then Google locks it for QR / staff / every other place too. */
export async function submitBatchAttendance(batch: string): Promise<{ pending: boolean }> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Attendance connect nahi hai');
  const date = localToday();
  const done = await getSubmittedBatches(date);
  if (done.includes(batch)) return { pending: false };

  await saveSetting(KEY_SUBMITTED + date, [...done, batch]);
  const item: PendingItem = { kind: 'submit', regNo: '', date, time: '', batch };
  await addPending(item);
  notifyUpdated(date);
  try {
    await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'submit', date, batch }, 60000);
    await removePending(item);
    return { pending: false };
  } catch {
    return { pending: true }; // offline: it is locked here already and goes to Google when the internet is back
  }
}

/** Takes the list of submitted batches that Google reports (staff phone submits arrive this way) into the local copy. */
async function mergeSubmitted(date: string, list: any): Promise<void> {
  if (!Array.isArray(list)) return;
  const have = await getSubmittedBatches(date);
  const add = list.map(String).filter((b) => !have.includes(b));
  if (add.length === 0) return;
  await saveSetting(KEY_SUBMITTED + date, [...have, ...add]);
  notifyUpdated(date); // Daily Attendance / dashboard show "Submitted" at once
}

let flushing = false;
/** Re-sends admin actions that could not reach Google earlier (safe to repeat: Google ignores duplicates). */
export async function flushPendingCheckIns() {
  if (flushing) return;
  flushing = true;
  try {
    const list = await getPending();
    if (list.length === 0) return;
    const cfg = await getAttendanceConfig();
    if (!cfg.webAppUrl) return;
    for (const p of list) {
      try {
        const kind = kindOf(p);
        if (kind === 'submit') {
          await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'submit', date: p.date, batch: p.batch }, 60000);
        } else {
          const res = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: kind === 'in' ? 'mark' : 'markout', regNo: p.regNo }, 60000);
          if (!res.ok) {
            if (kind === 'in') await removeLocalCheckIn(p.date, p.regNo); else await removeLocalCheckOut(p.date, p.regNo);
          } else if (kind === 'in' && res.checkIn && String(res.checkIn) !== p.time) {
            await setLocalCheckIn(p.date, p.regNo, String(res.checkIn));
          } else if (kind === 'out' && res.checkOut && String(res.checkOut) !== p.time) {
            await setLocalCheckOut(p.date, p.regNo, String(res.checkOut));
          }
        }
        await removePending(p);
        notifyUpdated(p.date);
      } catch {
        break; // still offline -> try again on the next tick
      }
    }
  } finally {
    flushing = false;
  }
}

/**
 * Looks at how recent this computer's attendance is and asks the sheet ONLY for what is missing.
 *  - A past day that was already downloaded after it ended is final -> skipped (no request at all).
 *  - A past day that is missing, or was saved while the day was still running -> downloaded once from the sheet.
 *  - Today -> the normal live path (tiny "what is new?" ping).
 *  - Days older than the sheet's 7 days are not asked for (the sheet deleted them; this computer keeps them).
 * Works the same for the same web app link and for a new one (a new sheet that has nothing simply adds nothing).
 */
export async function catchUpFromSheet(): Promise<{ latestBefore: string; daysChecked: number }> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return { latestBefore: '', daysChecked: 0 };
  const today = localToday();
  const dates = ((await getSetting(KEY_ATT_CACHE_DATES)) || []) as string[];
  const latestBefore = dates.length ? dates[dates.length - 1] : '';
  let daysChecked = 0;
  for (let d = sheetWindowStart(); d <= today; d = addDays(d, 1)) {
    const c = await readAttendanceCache(d);
    if (c && d < today && c.fetchedOn > d) continue; // final
    await fetchAttendance(d, { force: d < today });
    daysChecked++;
  }
  if (daysChecked > 0) window.dispatchEvent(new CustomEvent('attendanceUpdated', { detail: { date: today } }));
  return { latestBefore, daysChecked };
}

const inFlight = new Map<string, Promise<AttendanceResult>>();

/**
 * Returns the day's attendance, downloading from Google only when needed.
 * force = true skips the shortcuts (used by the Refresh button).
 * Calls for the same date that overlap share one request.
 */
export function fetchAttendance(date: string, opts: { force?: boolean } = {}): Promise<AttendanceResult> {
  const k = `${date}|${opts.force ? 1 : 0}`;
  const running = inFlight.get(k);
  if (running) return running;
  const p = fetchAttendanceInner(date, opts).finally(() => { inFlight.delete(k); });
  inFlight.set(k, p);
  return p;
}

async function fetchAttendanceInner(date: string, opts: { force?: boolean }): Promise<AttendanceResult> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Attendance connect nahi hai');

  const cached = await readAttendanceCache(date);
  const asResult = (c: AttendanceCache): AttendanceResult => ({ records: toRecordMap(c.records), savedAt: c.savedAt, fromCache: true });
  const today = localToday();

  // Older than the sheet's 7 days: Google no longer has it, so never ask. This computer's copy (if any) is the record.
  if (date < sheetWindowStart()) {
    return cached ? asResult(cached) : { records: {}, savedAt: '', fromCache: true };
  }

  // Past day that was already downloaded after it ended -> it can never change
  if (!opts.force && cached && date < today && cached.fetchedOn > date) return asResult(cached);

  let version = '';

  // LIVE PATH (today): ask only "what is new since my version?" and merge the few new entries
  if (!opts.force && cached && cached.version && date === today) {
    try {
      const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'delta', since: cached.version });
      await mergeSubmitted(date, d.subm); // staff may have submitted a batch without any new check-in
      if (!d.full && Array.isArray(d.events)) {
        if (d.events.length === 0) return asResult(cached);
        const map = toRecordMap(cached.records);
        d.events.forEach((e: any) => {
          if (e.d && e.d !== date) return;
          const key = String(e.r).toLowerCase();
          const rec = map[key] || { regNo: String(e.r), checkIn: '', checkOut: '' };
          if (e.i) rec.checkIn = String(e.i);
          if (e.o) rec.checkOut = String(e.o);
          map[key] = rec;
        });
        await applyPending(date, map);
        const merged: AttendanceCache = {
          records: Object.values(map),
          version: String(d.attVer),
          fetchedOn: today,
          savedAt: new Date().toISOString(),
        };
        await writeAttendanceCache(date, merged); // saved locally right away
        return { records: map, savedAt: merged.savedAt, fromCache: false };
      }
      if (d.attVer !== undefined) version = String(d.attVer); // log too short -> download the full list below
    } catch {
      // Old script without "delta" (or a network hiccup) -> normal path below
    }
  }

  // Cheap check: has anything been marked since our last download?
  if (!version) {
    try {
      const v = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'version' });
      version = v.attVer !== undefined ? String(v.attVer) : '';
      if (date === today) await mergeSubmitted(date, v.subm);
    } catch {
      // Old script without the "version" action -> fall through to a normal download
    }
    if (!opts.force && cached && version && cached.version === version) return asResult(cached);
  }

  const data = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'list', date });
  if (date === today) await mergeSubmitted(date, data.subm);
  // This computer's copy is the permanent record: keep what it has, add / complete with what the sheet has
  // (a different or empty sheet therefore never wipes saved attendance).
  const freshMap = toRecordMap(cached?.records || []);
  ((data.records || []) as AttendanceRecord[]).forEach((r) => {
    const k = String(r.regNo).toLowerCase();
    const mine = freshMap[k];
    freshMap[k] = { regNo: String(r.regNo), checkIn: r.checkIn || mine?.checkIn || '', checkOut: r.checkOut || mine?.checkOut || '' };
  });
  await applyPending(date, freshMap);
  const fresh: AttendanceCache = {
    records: Object.values(freshMap),
    version,
    fetchedOn: today,
    savedAt: new Date().toISOString(),
  };
  await writeAttendanceCache(date, fresh);
  return { records: toRecordMap(fresh.records), savedAt: fresh.savedAt, fromCache: false };
}

// ---------- staff panel (mobile link + PIN + batch access) ----------

export interface StaffMember {
  id: string;
  name: string;
  pin: string;          // 4-8 digits, admin shares it with the staff member
  allBatches: boolean;  // true = every batch
  batches: string[];    // batch time labels (used when allBatches is false)
}

export interface StaffConfig {
  enabled: boolean;
  staff: StaffMember[];
}

export async function getStaffConfig(): Promise<StaffConfig> {
  const c = await getSetting(KEY_STAFF);
  return { enabled: !!c?.enabled, staff: Array.isArray(c?.staff) ? c.staff : [] };
}

export async function saveStaffConfig(cfg: StaffConfig): Promise<void> {
  await saveSetting(KEY_STAFF, cfg);
}

export function randomPin(): string {
  const b = new Uint32Array(1);
  crypto.getRandomValues(b);
  return String(100000 + (b[0] % 900000));
}

export function staffLink(webAppUrl: string): string {
  return webAppUrl ? `${webAppUrl.trim()}?mode=staff` : '';
}

/** Sends the staff list (PIN is hashed inside the script) to the Google Sheet. */
export async function pushStaffConfig(force = false): Promise<void> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return;
  const staff = await getStaffConfig();
  const hash = JSON.stringify(staff);
  if (!force && (await getSetting(KEY_STAFF_HASH)) === hash) return;
  await scriptPost(cfg.webAppUrl, cfg.adminKey, {
    action: 'staff',
    enabled: staff.enabled,
    staff: staff.staff.map((m) => ({ id: m.id, name: m.name, pin: m.pin, all: m.allBatches, batches: m.batches })),
  });
  await saveSetting(KEY_STAFF_HASH, hash);
}

// ---------- admin: mark a student present straight from the CMS ----------

export interface AdminCheckInResult {
  ok: boolean;
  already: boolean;
  checkIn: string;
  checkOut?: string;
  name: string;
  expired: boolean;
  pending?: boolean; // saved on this computer, Google will get it as soon as the internet is back
}

const NO_BATCH_KEY = '__none__'; // same value the Apps Script uses for students without a batch

async function batchKeyOfStudent(regNo: string): Promise<string | null> {
  try {
    const key = String(regNo).toLowerCase();
    const s: any = (await getStudentsLite()).find((x: any) => String(x.regNo).toLowerCase() === key);
    if (!s) return null;
    return (s.batchTime && String(s.batchTime).trim()) || NO_BATCH_KEY;
  } catch {
    return null;
  }
}

/**
 * Check-in by the admin. Saved in this computer's local attendance copy FIRST (instant, works
 * offline); the Google Sheet is updated right after. If Google refuses it (e.g. student blocked),
 * the local entry is taken back. `batch` = the student's batch key (looked up automatically
 * when not given). Once a batch is submitted, nobody can mark it any more.
 */
export async function adminCheckIn(regNo: string, studentName = '', batch?: string): Promise<AdminCheckInResult> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Attendance connect nahi hai');

  const date = localToday();
  const key = String(regNo).toLowerCase();
  const cached = await readAttendanceCache(date);
  const existing = toRecordMap(cached?.records || [])[key];
  if (existing?.checkIn) {
    return { ok: true, already: true, checkIn: existing.checkIn, name: studentName, expired: false };
  }
  // A submitted batch accepts no attendance from anywhere. If the caller did not pass the batch, look it up.
  const batchKey = batch !== undefined ? batch : await batchKeyOfStudent(regNo);
  if (batchKey !== null && (await getSubmittedBatches(date)).includes(batchKey)) {
    throw new Error('Is batch ki attendance submit ho chuki hai. Ab attendance nahi lag sakti.');
  }

  // 1) local save, right now
  const time = nowTimeStr();
  const item: PendingItem = { kind: 'in', regNo: String(regNo), date, time };
  await setLocalCheckIn(date, regNo, time);
  await addPending(item);
  notifyUpdated(date);

  // 2) hand it to Google
  let res: any;
  try {
    res = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'mark', regNo: String(regNo) }, 60000);
  } catch {
    // Offline / script down: it stays saved here and is re-sent automatically
    return { ok: true, already: false, checkIn: time, name: studentName, expired: false, pending: true };
  }

  if (!res.ok) {
    await removePending(item);
    await removeLocalCheckIn(date, regNo);
    notifyUpdated(date);
    throw new Error(res.message || 'Attendance mark nahi hui');
  }

  await removePending(item);
  const finalTime = String(res.checkIn || time);
  if (finalTime !== time) {
    await setLocalCheckIn(date, regNo, finalTime); // Google already had an entry -> use its time
    notifyUpdated(date);
  }
  return { ok: true, already: !!res.already, checkIn: finalTime, name: String(res.name || studentName), expired: !!res.expired };
}

/** Check-out by the admin (only when Check-out is switched on in Settings). Same local-first flow. */
export async function adminCheckOut(regNo: string, studentName = ''): Promise<AdminCheckInResult> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Attendance connect nahi hai');
  if (!cfg.enableCheckout) throw new Error('Check-out chalu nahi hai (Settings → Management & Setup)');

  const date = localToday();
  const key = String(regNo).toLowerCase();
  const rec = toRecordMap((await readAttendanceCache(date))?.records || [])[key];
  if (!rec?.checkIn) throw new Error('Pehle check-in karna zaroori hai');
  if (rec.checkOut) return { ok: true, already: true, checkIn: rec.checkIn, checkOut: rec.checkOut, name: studentName, expired: false };

  const time = nowTimeStr();
  const item: PendingItem = { kind: 'out', regNo: String(regNo), date, time };
  await setLocalCheckOut(date, regNo, time);
  await addPending(item);
  notifyUpdated(date);

  let res: any;
  try {
    res = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'markout', regNo: String(regNo) }, 60000);
  } catch {
    return { ok: true, already: false, checkIn: rec.checkIn, checkOut: time, name: studentName, expired: false, pending: true };
  }
  await removePending(item);
  if (!res.ok) {
    await removeLocalCheckOut(date, regNo);
    notifyUpdated(date);
    throw new Error(res.message || 'Check-out nahi hua');
  }
  const finalOut = String(res.checkOut || time);
  if (finalOut !== time) { await setLocalCheckOut(date, regNo, finalOut); notifyUpdated(date); }
  return { ok: true, already: !!res.already, checkIn: rec.checkIn, checkOut: finalOut, name: String(res.name || studentName), expired: false };
}

// ---------- dues split (admission / monthly) ----------

/** Admission + monthly dues for each student, keyed by reg no. */
export async function buildDuesMap(students: any[]): Promise<Record<string, DuesSplit>> {
  const needsHistory = students.some(
    (s) => (Number(s.dues) || 0) > 0 && s.admissionDues === undefined && s.monthlyDues === undefined,
  );
  let paid = new Set<string>();
  if (needsHistory) {
    const payments = await getAllPayments();
    paid = new Set(payments.map((p: any) => String(p.regNo)));
  }
  const map: Record<string, DuesSplit> = {};
  students.forEach((s) => { map[String(s.regNo)] = splitDues(s, paid.has(String(s.regNo))); });
  return map;
}

// ---------- LIVE sync: new check-ins appear in the CMS within a couple of seconds ----------
// Mounted once in the admin dashboard, so the local copy stays current even while another
// screen is open. The attendance screen is told through the "attendanceUpdated" event.

// Speed vs. Google's free-account limits:
//  - while entries are coming in (a change in the last 10 min): check every 2 s
//  - quiet period: check every 4 s (roughly halves the calls over a long day)
//  - errors / quota hit: back off up to 60 s, then recover by itself
const LIVE_FAST_MS = 2000;
const LIVE_IDLE_MS = 4000;
const LIVE_ACTIVE_WINDOW_MS = 10 * 60 * 1000;

export function useAttendanceLiveSync() {
  useEffect(() => {
    let stopped = false;
    let running = false;
    let timer: any = null;
    let lastChange = Date.now();
    let failures = 0;
    let caughtUpOn = ''; // day for which the "is my data recent?" check was done

    const tick = async () => {
      if (stopped || running) return;
      running = true;
      let delay = Date.now() - lastChange < LIVE_ACTIVE_WINDOW_MS ? LIVE_FAST_MS : LIVE_IDLE_MS;
      try {
        if (document.hidden) {
          delay = 5000;
        } else if (await isAttendanceConnected()) {
          const date = localToday();
          await flushPendingCheckIns(); // admin check-ins that were saved offline
          if (caughtUpOn !== date) {
            // CMS just opened (or a new day started): is the local data recent? If not, get the missing days now
            await catchUpFromSheet();
            caughtUpOn = date;
          }
          const res = await fetchAttendance(date);
          failures = 0;
          if (!res.fromCache) {
            lastChange = Date.now();
            window.dispatchEvent(new CustomEvent('attendanceUpdated', { detail: { date } }));
          }
        } else {
          delay = 5000;
        }
      } catch {
        failures++;
        delay = Math.min(60000, 10000 * failures); // offline / script down / quota -> slow down
      } finally {
        running = false;
      }
      if (!stopped) timer = setTimeout(tick, delay);
    };

    const onVisible = () => {
      if (!document.hidden && !running) { lastChange = Date.now(); clearTimeout(timer); timer = setTimeout(tick, 0); }
    };

    timer = setTimeout(tick, 1500);
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      stopped = true;
      clearTimeout(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, []);
}

// ---------- background auto-sync (mounted once in the admin dashboard) ----------

export function useAttendanceAutoSync() {
  useEffect(() => {
    let cancelled = false;
    let debounce: any = null;

    const run = async () => {
      try {
        if (cancelled || !(await isAttendanceConnected())) return;
        await pushAttendanceConfig();
        await pushStaffConfig();
        await syncStudentsToScript();
      } catch (e) {
        // Offline / script down — silently retry on the next tick
        console.warn('Attendance auto-sync skipped:', e);
      }
    };

    const first = setTimeout(run, 4000);
    const interval = setInterval(run, 2 * 60 * 1000);
    const onUpdate = () => {
      clearTimeout(debounce);
      debounce = setTimeout(run, 5000);
    };
    window.addEventListener('studentsUpdated', onUpdate);
    window.addEventListener('flexiUpdated', onUpdate);
    return () => {
      cancelled = true;
      clearTimeout(first);
      clearTimeout(debounce);
      clearInterval(interval);
      window.removeEventListener('studentsUpdated', onUpdate);
      window.removeEventListener('flexiUpdated', onUpdate);
    };
  }, []);
}

// ---------- QR PDF ----------

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    if (!src) return resolve(null);
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => resolve(null);
    img.src = src;
  });
}

export async function buildQrPreview(url: string): Promise<string> {
  return qrToDataUrl(url, 1000, 4);
}

/** A4 poster: logo, studio name, "QR Attendance", QR code. */
export async function downloadAttendanceQrPdf(opts: { businessName: string; businessLogo?: string; url: string }) {
  const { businessName, businessLogo, url } = opts;
  const doc = new jsPDF({ unit: 'mm', format: 'a4' });
  const pageW = doc.internal.pageSize.getWidth();
  let y = 22;

  const logo = await loadImage(businessLogo || '');
  if (logo) {
    const box = 38;
    const ratio = Math.min(box / logo.width, box / logo.height);
    const w = logo.width * ratio;
    const h = logo.height * ratio;
    // Re-draw on a canvas so any format (png/jpg/webp/svg) goes into the PDF as PNG
    const canvas = document.createElement('canvas');
    canvas.width = logo.width;
    canvas.height = logo.height;
    canvas.getContext('2d')!.drawImage(logo, 0, 0);
    doc.addImage(canvas.toDataURL('image/png'), 'PNG', (pageW - w) / 2, y, w, h);
    y += h + 10;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(28);
  doc.setTextColor(30, 30, 30);
  const nameLines = doc.splitTextToSize(businessName || 'Attendance', pageW - 40);
  doc.text(nameLines, pageW / 2, y + 8, { align: 'center' });
  y += nameLines.length * 12 + 6;

  doc.setFontSize(22);
  doc.setTextColor(232, 99, 10);
  doc.text('QR Attendance', pageW / 2, y + 8, { align: 'center' });
  y += 20;

  const qrSize = 130;
  doc.addImage(qrToDataUrl(url, 1000, 4), 'PNG', (pageW - qrSize) / 2, y, qrSize, qrSize);

  const safe = (businessName || 'Attendance').trim().replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_');
  doc.save(`QR_Attendance_${safe}.pdf`);
}
