// Central library of "extra" admission-form fields the admin can turn ON/OFF
// from Settings -> Admission Fields. Each field, once enabled, automatically
// shows up in: Admission Form, Student List (table + edit dialog), the
// Admission Receipt PDF, the Student Details PDF, and the WhatsApp message —
// all of them read from this same list, so there is only one place to
// add/edit a field definition.
//
// Values entered by the admin are stored per-student in `student.customFields`
// (an object keyed by field id) — no database schema change needed.

import { getSetting, saveSetting } from './indexedDB';

export type AdmissionFieldType = 'text' | 'number' | 'date' | 'select' | 'textarea' | 'phone';

export interface AdmissionFieldDef {
  id: string;            // unique key, used as customFields[id]
  label: string;         // shown on form / list / PDF / WhatsApp
  type: AdmissionFieldType;
  options?: string[];    // for type: 'select'
  businessTypes: string[]; // which business categories usually use this field (for grouping in Settings UI)
}

// Grouping labels shown in Settings UI
export const BUSINESS_TYPES = [
  'Gym / Fitness',
  'Coaching / Tuition',
  'Sports Academy',
  'Salon / Spa',
  'Corporate / Skill Training',
  'Art / Music / Dance',
] as const;

export const ALL_ADMISSION_FIELDS: AdmissionFieldDef[] = [
  // Gym / Fitness
  { id: 'height', label: 'Height (cm)', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'weight', label: 'Weight (kg)', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'fitnessGoal', label: 'Fitness Goal', type: 'select', options: ['Weight Loss', 'Weight Gain', 'General Fitness', 'Muscle Building'], businessTypes: ['Gym / Fitness'] },
  { id: 'medicalCondition', label: 'Medical Condition / Injury History', type: 'textarea', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'bloodGroup', label: 'Blood Group', type: 'select', options: ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'], businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'emergencyContact', label: 'Emergency Contact Number', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'trainerAssigned', label: 'Trainer Assigned', type: 'text', businessTypes: ['Gym / Fitness'] },
  { id: 'membershipType', label: 'Membership Type', type: 'select', options: ['General', 'Personal Training', 'Couple'], businessTypes: ['Gym / Fitness'] },
  { id: 'lockerNumber', label: 'Locker Number', type: 'text', businessTypes: ['Gym / Fitness'] },

  // Coaching / Tuition
  { id: 'schoolName', label: 'School / College Name', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'classGrade', label: 'Class / Grade', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'subjectsEnrolled', label: 'Subjects Enrolled', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'previousMarks', label: 'Previous Marks / Percentage', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'board', label: 'Board', type: 'select', options: ['CBSE', 'ICSE', 'State Board', 'Other'], businessTypes: ['Coaching / Tuition'] },
  { id: 'parentOccupation', label: "Parent's Occupation", type: 'text', businessTypes: ['Coaching / Tuition'] },

  // Sports Academy
  { id: 'sportRole', label: 'Sport-specific Role (e.g. Bowler, Batsman)', type: 'text', businessTypes: ['Sports Academy'] },
  { id: 'skillLevel', label: 'Skill Level', type: 'select', options: ['Beginner', 'Intermediate', 'Advanced'], businessTypes: ['Sports Academy'] },
  { id: 'medicalFitnessCert', label: 'Medical Fitness Certificate Submitted', type: 'select', options: ['Yes', 'No'], businessTypes: ['Sports Academy'] },
  { id: 'kitSize', label: 'Kit / Jersey Size', type: 'text', businessTypes: ['Sports Academy'] },
  { id: 'tournamentExperience', label: 'Previous Tournament Experience', type: 'textarea', businessTypes: ['Sports Academy'] },

  // Salon / Spa
  { id: 'skinHairType', label: 'Skin / Hair Type', type: 'text', businessTypes: ['Salon / Spa'] },
  { id: 'allergyInfo', label: 'Allergy Information', type: 'textarea', businessTypes: ['Salon / Spa'] },
  { id: 'packageName', label: 'Package Name', type: 'text', businessTypes: ['Salon / Spa'] },
  { id: 'sessionsTotal', label: 'Sessions Total', type: 'number', businessTypes: ['Salon / Spa'] },
  { id: 'sessionsUsed', label: 'Sessions Used', type: 'number', businessTypes: ['Salon / Spa'] },
  { id: 'preferredStaff', label: 'Preferred Staff / Stylist', type: 'text', businessTypes: ['Salon / Spa'] },

  // Corporate / Skill Training
  { id: 'companyName', label: 'Company Name', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'designation', label: 'Designation', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'qualification', label: 'Qualification', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'certificateIssued', label: 'Certificate Issued', type: 'select', options: ['Yes', 'No'], businessTypes: ['Corporate / Skill Training'] },

  // Art / Music / Dance
  { id: 'instrumentArtForm', label: 'Instrument / Art Form', type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'performanceGrade', label: 'Performance Level / Grade', type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'studentOccupation', label: "Student's Occupation", type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'currentAddress', label: 'Current Address', type: 'textarea', businessTypes: ['Art / Music / Dance'] },
  { id: 'guardianMobile', label: 'Guardian Mobile No', type: 'phone', businessTypes: ['Art / Music / Dance'] },
  { id: 'guardianOccupation', label: "Guardian's Occupation", type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'permanentAddress', label: 'Permanent Address', type: 'textarea', businessTypes: ['Art / Music / Dance'] },
];

const SETTING_KEY = 'enabledAdmissionFields';

export async function getEnabledFieldIds(): Promise<string[]> {
  try {
    const saved = await getSetting(SETTING_KEY);
    return Array.isArray(saved) ? saved : [];
  } catch (error) {
    console.error('Error loading enabled admission fields:', error);
    return [];
  }
}

export async function saveEnabledFieldIds(ids: string[]): Promise<void> {
  await saveSetting(SETTING_KEY, ids);
}

export function getEnabledFieldDefs(enabledIds: string[]): AdmissionFieldDef[] {
  const idSet = new Set(enabledIds);
  return ALL_ADMISSION_FIELDS.filter((f) => idSet.has(f.id));
}

export function getFieldValue(customFields: Record<string, any> | undefined, id: string): string {
  if (!customFields) return '';
  const val = customFields[id];
  return val === undefined || val === null ? '' : String(val);
}

// ---------------------------------------------------------------------------
// Extra Charges (AC charges, dress, ID card, shoes, security ...)
// Admin turns this ON from Settings -> Admission Fields. Once ON, the Admission
// Form gets an "Add Extra Charges" checkbox where up to MAX_EXTRA_CHARGES
// name + amount rows can be added. The breakdown is stored per-student in
// `student.extraCharges` and the student's `totalAmount` already includes it.
// The breakdown is shown only in Student List -> Edit dialog and Student
// Details PDF.
// ---------------------------------------------------------------------------

export interface ExtraCharge {
  name: string;
  amount: string | number;
}

export const MAX_EXTRA_CHARGES = 5;

const EXTRA_CHARGES_KEY = 'extraChargesEnabled';

export async function getExtraChargesEnabled(): Promise<boolean> {
  try {
    const saved = await getSetting(EXTRA_CHARGES_KEY);
    return saved === true;
  } catch (error) {
    console.error('Error loading extra charges setting:', error);
    return false;
  }
}

export async function saveExtraChargesEnabled(enabled: boolean): Promise<void> {
  await saveSetting(EXTRA_CHARGES_KEY, enabled);
}

export function sumExtraCharges(charges: ExtraCharge[] | undefined | null): number {
  if (!Array.isArray(charges)) return 0;
  return charges.reduce((sum, c) => sum + (parseFloat(String(c?.amount)) || 0), 0);
}
