// Admission Form Layout — single source of truth.
//
// Owner can (from Settings -> Admission Form Layout) show/hide, make required/optional,
// rename and re-order fields. The saved layout lives in the settings store
// (key: 'admissionFormLayout'), so it is part of the JSON backup/restore.
//
// LOCK RULES (enforced here on every load/save, so nobody can break them,
// not even by editing a backup file):
//   'full'  -> bottom block + Registration No. Nothing can be changed.
//   'basic' -> Student Name, Mobile No, Admission Date. Cannot be hidden / made optional,
//              but label, order and width can change.
//   'none'  -> everything else. Fully controlled by the owner.
//
// If no layout is saved, the default layout below reproduces today's form exactly.

import { useCallback, useEffect, useMemo, useState } from 'react';
import { getSetting, saveSetting } from './indexedDB';
import { ALL_ADMISSION_FIELDS, AdmissionFieldDef, getEnabledFieldIds } from './admissionFields';

export type FormFieldType =
  | 'text' | 'email' | 'number' | 'date' | 'select' | 'textarea' | 'phone' | 'yesno' | 'photo';

export type FieldWidth = 'full' | 'half' | 'third';
export type LockLevel = 'full' | 'basic' | 'none';

export interface FormFieldLayout {
  id: string;
  label: string;
  type: FormFieldType;
  kind: 'core' | 'extra' | 'custom'; // core = built-in, extra = admissionFields.ts, custom = owner-made
  visible: boolean;
  required: boolean;
  order: number;
  width: FieldWidth;
  group?: string;     // optional section title (used from Phase B)
  options?: string[]; // for select
}

export const FORM_LAYOUT_KEY = 'admissionFormLayout';
export const FORM_LAYOUT_EVENT = 'formLayoutUpdated';

// ---------------------------------------------------------------------------
// Locks
// ---------------------------------------------------------------------------

// Fixed bottom block, always in this order (rendered as fixed rows by the form).
export const LOCKED_BLOCK_IDS = [
  'category', 'subCategory', 'batchTime', 'location',
  'duration', 'durationType', 'expiryDate',
  'totalAmount', 'paidAmount', 'dues', 'paymentMode',
] as const;

const FULL_LOCKED = new Set<string>(['regNo', ...LOCKED_BLOCK_IDS]);
const BASIC_LOCKED = new Set<string>(['name', 'mobile', 'admissionDate']);

export function getLockLevel(id: string): LockLevel {
  if (FULL_LOCKED.has(id)) return 'full';
  if (BASIC_LOCKED.has(id)) return 'basic';
  return 'none';
}

export function isInLockedBlock(id: string): boolean {
  return (LOCKED_BLOCK_IDS as readonly string[]).includes(id);
}

// Fields that are system-generated / calculated: never validated as "required".
const NEVER_VALIDATED = new Set<string>(['regNo', 'dues', 'expiryDate']);

// Core fields that live directly on the student object and can be hidden.
// Hidden ones are saved as '' (never undefined).
const HIDEABLE_CORE_KEYS = [
  'gender', 'dob', 'photo', 'alternateMobile', 'aadhaarNumber', 'aadhaarFront', 'aadhaarBack',
  'guardianName', 'guardianRelation', 'learnedBefore', 'address', 'email',
];

// ---------------------------------------------------------------------------
// Default layout (= today's form)
// ---------------------------------------------------------------------------

function core(
  id: string, label: string, type: FormFieldType, over: Partial<FormFieldLayout> = {}
): FormFieldLayout {
  return { id, label, type, kind: 'core', visible: true, required: false, order: 0, width: 'third', ...over };
}

export function getDefaultLayout(): FormFieldLayout[] {
  const free: FormFieldLayout[] = [
    core('admissionDate', 'Admission Date', 'date', { required: true }),
    core('name', 'Student Name', 'text', { required: true }),
    core('gender', 'Gender', 'select', { required: true, width: 'full', options: ['Male', 'Female', 'Other'] }),
    core('dob', 'Date of Birth', 'date'),
    core('photo', 'Upload Photo', 'photo'),
    core('mobile', 'Mobile No', 'phone', { required: true }),
    core('alternateMobile', 'Alternate Mobile', 'phone', { width: 'half' }),
    core('aadhaarNumber', 'Aadhaar Number', 'text', { width: 'half' }),
    // Aadhaar card ki photo (front / back): camera se click ya upload. ON/OFF + Required/Optional yahin se.
    core('aadhaarFront', 'Aadhaar Front Photo', 'photo', { width: 'half' }),
    core('aadhaarBack', 'Aadhaar Back Photo', 'photo', { width: 'half' }),
    core('guardianName', 'Guardian Name', 'text', { required: true, width: 'half' }),
    core('guardianRelation', 'Guardian Relation', 'text', { required: true, width: 'half' }),
    core('learnedBefore', 'Have You Learned Before?', 'select', { required: true, width: 'full', options: ['Yes', 'No'] }),
    core('address', 'Address', 'text', { required: true, width: 'half' }),
    core('email', 'Email', 'email', { width: 'half' }),
    // Extra fields from admissionFields.ts (ON/OFF stays in Settings -> Admission Fields)
    ...ALL_ADMISSION_FIELDS.map((a): FormFieldLayout => ({
      id: a.id, label: a.label, type: a.type, options: a.options,
      kind: 'extra', visible: false, required: false, order: 0, width: 'half',
      group: 'Additional Information',
    })),
  ];
  free.forEach((f, i) => { f.order = i + 1; });

  const regNo = core('regNo', 'Registration No', 'text', { required: true, order: 0 });

  const locked: FormFieldLayout[] = [
    core('category', 'Category', 'select', { required: true }),
    core('subCategory', 'Sub-Category', 'select', { required: true }),
    core('batchTime', 'Batch Time', 'select', { required: true }),
    core('location', 'Location', 'select', { required: true, width: 'half' }),
    core('duration', 'Duration', 'number', { required: true }),
    core('durationType', 'Duration Type', 'select', { required: true, options: ['Days', 'Month', 'Year'] }),
    core('expiryDate', 'Expiry Date', 'date'),
    core('totalAmount', 'Total Amount', 'number', { required: true }),
    core('paidAmount', 'Paid Amount', 'number', { required: true }),
    core('dues', 'Dues', 'number'),
    core('paymentMode', 'Payment Mode', 'select', { required: true, width: 'full', options: ['Cash', 'Online'] }),
  ];
  locked.forEach((f, i) => { f.order = 1000 + i; });

  return [regNo, ...free, ...locked];
}

// ---------------------------------------------------------------------------
// Merge saved layout with defaults + enforce locks
// ---------------------------------------------------------------------------

const WIDTHS: FieldWidth[] = ['full', 'half', 'third'];
const CUSTOM_TYPES: FormFieldType[] = ['text', 'number', 'date', 'select', 'yesno', 'textarea', 'phone'];

function cleanLabel(v: any): string {
  return typeof v === 'string' ? v.trim().slice(0, 60) : '';
}

function cleanOptions(v: any): string[] {
  if (!Array.isArray(v)) return [];
  return v.map((o) => String(o ?? '').trim().slice(0, 60)).filter(Boolean).slice(0, 30);
}

function sanitizeCustom(s: any): FormFieldLayout | null {
  if (!s || typeof s.id !== 'string' || !s.id.startsWith('cf_')) return null;
  const label = cleanLabel(s.label);
  if (!label) return null;
  const type: FormFieldType = CUSTOM_TYPES.includes(s.type) ? s.type : 'text';
  const options = type === 'yesno' ? ['Yes', 'No'] : type === 'select' ? cleanOptions(s.options) : undefined;
  return {
    id: s.id,
    label,
    type,
    kind: 'custom',
    visible: s.visible !== false,
    required: s.required === true,
    order: Number.isFinite(s.order) ? Number(s.order) : 9999,
    width: WIDTHS.includes(s.width) ? s.width : 'half',
    group: cleanLabel(s.group) || 'Additional Information',
    options,
  };
}

export function mergeWithDefaults(saved?: any[] | null): FormFieldLayout[] {
  const defaults = getDefaultLayout();
  const savedMap = new Map<string, any>();
  (Array.isArray(saved) ? saved : []).forEach((s) => {
    if (s && typeof s.id === 'string') savedMap.set(s.id, s);
  });

  const merged: FormFieldLayout[] = defaults.map((d) => {
    const s = savedMap.get(d.id);
    const lock = getLockLevel(d.id);
    if (!s || lock === 'full') return d; // locked = always default
    const out: FormFieldLayout = { ...d };
    const label = cleanLabel(s.label);
    if (label) out.label = label;
    if (WIDTHS.includes(s.width)) out.width = s.width;
    if (Number.isFinite(s.order)) out.order = Number(s.order);
    if (typeof s.group === 'string') out.group = cleanLabel(s.group) || d.group;
    if (lock === 'none') {
      if (typeof s.visible === 'boolean') out.visible = s.visible;
      if (typeof s.required === 'boolean') out.required = s.required;
    } else {
      out.visible = true;   // basic lock
      out.required = true;
    }
    return out;
  });

  // Owner-made custom fields
  savedMap.forEach((s) => {
    const c = sanitizeCustom(s);
    if (c && !merged.some((m) => m.id === c.id)) merged.push(c);
  });

  // Fixed order: regNo first, then free fields (by order), then the locked block
  const regNo = merged.filter((f) => f.id === 'regNo');
  const free = merged
    .filter((f) => getLockLevel(f.id) !== 'full')
    .sort((a, b) => a.order - b.order); // stable sort keeps default order on ties
  free.forEach((f, i) => { f.order = i + 1; });
  const locked = LOCKED_BLOCK_IDS
    .map((id) => merged.find((f) => f.id === id)!)
    .map((f, i) => ({ ...f, order: 1000 + i }));
  regNo.forEach((f) => { f.order = 0; });

  return [...regNo, ...free, ...locked];
}

// ---------------------------------------------------------------------------
// Load / save / reset
// ---------------------------------------------------------------------------

export async function loadFormLayout(): Promise<FormFieldLayout[]> {
  try {
    const saved = await getSetting(FORM_LAYOUT_KEY);
    const arr = Array.isArray(saved?.fields) ? saved.fields : null;
    return mergeWithDefaults(arr);
  } catch (error) {
    console.error('Error loading form layout:', error);
    return mergeWithDefaults(null);
  }
}

export async function saveFormLayout(fields: FormFieldLayout[]): Promise<void> {
  const normalized = mergeWithDefaults(fields);
  await saveSetting(FORM_LAYOUT_KEY, { version: 1, fields: normalized });
  window.dispatchEvent(new Event(FORM_LAYOUT_EVENT));
}

export async function resetFormLayout(): Promise<void> {
  await saveSetting(FORM_LAYOUT_KEY, { version: 1, fields: getDefaultLayout() });
  window.dispatchEvent(new Event(FORM_LAYOUT_EVENT));
}

export function newCustomFieldId(): string {
  return `cf_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
}

// ---------------------------------------------------------------------------
// Resolve (combine layout + Settings -> Admission Fields ON/OFF) and helpers
// ---------------------------------------------------------------------------

// Extra fields keep their existing ON/OFF switch (enabledAdmissionFields).
export function resolveFields(layout: FormFieldLayout[], enabledExtraIds: string[]): FormFieldLayout[] {
  const on = new Set(enabledExtraIds);
  return layout.map((f) => (f.kind === 'extra' ? { ...f, visible: on.has(f.id) } : f));
}

export function getVisibleFields(fields: FormFieldLayout[]): FormFieldLayout[] {
  return fields.filter((f) => f.visible);
}

// Unknown id => treated as visible (so nothing disappears by accident)
export function isFieldVisible(fields: FormFieldLayout[], id: string): boolean {
  const f = fields.find((x) => x.id === id);
  return f ? f.visible : true;
}

// Label shown on a screen. Pass the screen's OWN old label as `fallback`: if the owner has
// not renamed the field, the screen keeps its old wording (nothing changes); if renamed,
// the owner's label is used.
let defaultLabelCache: Map<string, string> | null = null;
function defaultLabelOf(id: string): string | undefined {
  if (!defaultLabelCache) {
    defaultLabelCache = new Map(getDefaultLayout().map((f) => [f.id, f.label]));
  }
  return defaultLabelCache.get(id);
}

export function getFieldLabel(fields: FormFieldLayout[], id: string, fallback = ''): string {
  const f = fields.find((x) => x.id === id);
  if (!f) return fallback;
  if (fallback && f.label === defaultLabelOf(id)) return fallback;
  return f.label || fallback;
}

export function isFieldRequired(fields: FormFieldLayout[], id: string): boolean {
  const f = fields.find((x) => x.id === id);
  return !!f && f.visible && f.required;
}

// Extra + custom fields (visible only), in layout order, in the same shape the
// old screens already use (AdmissionFieldDef) — so they only swap the source.
export function getExtraDefs(fields: FormFieldLayout[]): AdmissionFieldDef[] {
  return fields
    .filter((f) => (f.kind === 'extra' || f.kind === 'custom') && f.visible)
    .map((f) => ({
      id: f.id,
      label: f.label,
      type: f.type === 'yesno' ? 'select' : (f.type as AdmissionFieldDef['type']),
      options: f.type === 'yesno' ? ['Yes', 'No'] : f.options,
      businessTypes: [],
    }));
}

// Tailwind classes for the 6-column grid (full = 6, half = 3, third = 2)
export function widthClass(w: FieldWidth): string {
  return w === 'full' ? 'md:col-span-6' : w === 'half' ? 'md:col-span-3' : 'md:col-span-2';
}

// ---------------------------------------------------------------------------
// Validation + hidden-value cleanup (used by the admission form)
// ---------------------------------------------------------------------------

function valueOf(data: any, f: FormFieldLayout): string {
  const v = f.kind === 'core' ? data?.[f.id] : data?.customFields?.[f.id];
  return String(v ?? '').trim();
}

// Returns the first "missing required field" message (Hindi/Hinglish style), or null.
export function validateRequired(fields: FormFieldLayout[], data: any): string | null {
  for (const f of fields) {
    if (!f.visible || !f.required || NEVER_VALIDATED.has(f.id)) continue;
    if (valueOf(data, f) !== '') continue;
    if (f.type === 'select' || f.type === 'yesno') return `कृपया ${f.label} select करें`;
    if (f.type === 'photo') return `कृपया ${f.label} attach करें`;
    return `कृपया ${f.label} भरें`;
  }
  return null;
}

// Hidden built-in fields are saved as '' (never undefined) so no screen crashes on .trim()
export function blankHiddenFields<T extends Record<string, any>>(data: T, fields: FormFieldLayout[]): T {
  const out: Record<string, any> = { ...data };
  HIDEABLE_CORE_KEYS.forEach((key) => {
    if (!isFieldVisible(fields, key)) out[key] = '';
  });
  return out as T;
}

// ---------------------------------------------------------------------------
// React hook for screens: const { fields, extraDefs, isVisible, label } = useFormLayout();
// Starts with the default layout (= today's look) and updates when the layout is saved.
// ---------------------------------------------------------------------------

export function useFormLayout() {
  const [layout, setLayout] = useState<FormFieldLayout[]>(() => mergeWithDefaults(null));
  const [enabledIds, setEnabledIds] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    const [l, ids] = await Promise.all([loadFormLayout(), getEnabledFieldIds()]);
    setLayout(l);
    setEnabledIds(ids);
    setLoading(false);
  }, []);

  useEffect(() => {
    reload();
    const handler = () => { reload(); };
    window.addEventListener(FORM_LAYOUT_EVENT, handler);
    return () => window.removeEventListener(FORM_LAYOUT_EVENT, handler);
  }, [reload]);

  const fields = useMemo(() => resolveFields(layout, enabledIds), [layout, enabledIds]);
  const extraDefs = useMemo(() => getExtraDefs(fields), [fields]);
  const isVisible = useCallback((id: string) => isFieldVisible(fields, id), [fields]);
  const label = useCallback((id: string, fallback = '') => getFieldLabel(fields, id, fallback), [fields]);

  return { fields, extraDefs, isVisible, label, loading, reload };
}
