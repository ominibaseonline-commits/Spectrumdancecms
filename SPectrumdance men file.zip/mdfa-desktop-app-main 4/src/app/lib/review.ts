// Google Review — CMS side.
//
// Flow:  Settings -> Google Review  ->  Groq API key add karo (test hote hi GREEN)  ->  Google Review link + keywords save karo
//        ->  QR / link banta hai  (<web app url>?page=review)
//        Student QR scan karke star + keywords chunta hai; Google Apps Script usi waqt Groq se chhota, naya review banati hai
//        aur student Submit dabate hi review copy karke Google Review link par jata hai.
//
// Google Sheet me is feature ka koi data nahi likha jata. Key, link aur keywords Apps Script ke Script Properties me rehte hain;
// Sheet sirf beech ka rasta hai. Key CMS me bhi save rehti hai, taaki admin baad me yahin se badal / hata sake.
//
// Ye Attendance wale Google Apps Script ka hi extra hissa hai (same web app URL, koi alag script nahi), isliye pehle
// Settings -> Management & Setup -> Attendance Setup me script connect hona chahiye.

import { getSetting, saveSetting } from './indexedDB';
import { getAttendanceConfig, scriptGet, scriptPost } from './attendance';

const KEY_ENABLED = 'reviewEnabled';
const KEY_LINK = 'reviewLink';
const KEY_KEYWORDS = 'reviewKeywords';
const KEY_GROQ = 'reviewGroqKey';
const KEY_GROQ_OK = 'reviewGroqOk';   // key Groq par test ho chuki hai (green)

export const REVIEW_EVENT = 'reviewSettingsChanged';
export const MAX_KEYWORDS = 20;

export interface ReviewSettings {
  enabled: boolean;
  link: string;
  keywords: string[];
  groqKey: string;
  keyOk: boolean;
}

// ---------- local settings ----------

export async function getReviewSettings(): Promise<ReviewSettings> {
  const [enabled, link, keywords, groqKey, keyOk] = await Promise.all([
    getSetting(KEY_ENABLED),
    getSetting(KEY_LINK),
    getSetting(KEY_KEYWORDS),
    getSetting(KEY_GROQ),
    getSetting(KEY_GROQ_OK),
  ]);
  return {
    enabled: enabled === true,
    link: typeof link === 'string' ? link : '',
    keywords: Array.isArray(keywords) ? keywords.map(String) : [],
    groqKey: typeof groqKey === 'string' ? groqKey : '',
    keyOk: keyOk === true && typeof groqKey === 'string' && groqKey.length > 0,
  };
}

/** "a, b\nc" -> ['a','b','c'] (khali / duplicate hata kar, max 20) */
export function parseKeywords(text: string): string[] {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const part of String(text || '').split(/[,\n]/)) {
    const k = part.replace(/\s+/g, ' ').trim().slice(0, 40);
    if (k && !seen.has(k.toLowerCase())) { seen.add(k.toLowerCase()); out.push(k); }
    if (out.length >= MAX_KEYWORDS) break;
  }
  return out;
}

export function isValidReviewLink(link: string): boolean {
  return /^https:\/\/[^\s]+$/i.test(link.trim()) && link.trim().length <= 500;
}

export function maskKey(key: string): string {
  if (!key) return '';
  return key.length <= 10 ? '••••••' : `${key.slice(0, 4)}••••••••${key.slice(-4)}`;
}

// ---------- errors ----------

export function reviewError(e: any): string {
  const msg = String(e?.message || e || '');
  if (/revPost_|revGet_|revPage_|rev_config|rev_test|rev_status|is not defined|unknown action/i.test(msg)) {
    return 'Google Script purani hai. Settings → Management & Setup → Attendance Setup se naya code copy karke Apps Script me paste karein aur dobara Deploy karein (script ek hi hai).';
  }
  if (/UrlFetchApp|external_request|permission/i.test(msg)) {
    return 'Script ko Groq se baat karne ki permission chahiye. Apps Script me function list se "revAuthorize" chuno → Run → Allow karein. Phir Deploy → Manage deployments → Edit → New version → Deploy karein.';
  }
  return msg || 'Google Sheet se baat nahi ho payi.';
}

// ---------- link ----------

export async function getReviewPageLink(): Promise<string> {
  const cfg = await getAttendanceConfig();
  return cfg.webAppUrl ? `${cfg.webAppUrl}?page=review` : '';
}

// ---------- Groq key test (CMS se seedha) ----------

export async function testGroqKey(key: string): Promise<{ ok: boolean; error?: string }> {
  const k = key.trim();
  if (!/^[A-Za-z0-9_\-]{20,200}$/.test(k)) return { ok: false, error: 'Key ka format sahi nahi hai. Groq ki key aam taur par "gsk_" se shuru hoti hai.' };
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 15000);
    const res = await fetch('https://api.groq.com/openai/v1/models', {
      headers: { Authorization: `Bearer ${k}` },
      signal: ctrl.signal,
    });
    clearTimeout(t);
    if (res.ok) return { ok: true };
    if (res.status === 401 || res.status === 403) return { ok: false, error: 'Key galat hai ya band ho chuki hai.' };
    if (res.status === 429) return { ok: false, error: 'Groq ki limit abhi lagi hui hai. Thodi der baad try karein.' };
    return { ok: false, error: `Groq ne error diya (${res.status}).` };
  } catch {
    return { ok: false, error: 'Groq se baat nahi ho payi. Internet check karein.' };
  }
}

// ---------- CMS -> Google Script ----------

/** Config Script ko bhejta hai. Key sirf tab jati hai jab sendKey / clearKey diya ho. */
async function pushConfig(opts: { sendKey?: boolean; clearKey?: boolean; enabled?: boolean } = {}): Promise<void> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Pehle Attendance Setup me Google Script connect karein.');
  const s = await getReviewSettings();
  const body: any = {
    action: 'rev_config',
    open: opts.enabled ?? s.enabled,
    link: s.link,
    keywords: s.keywords,
  };
  if (opts.clearKey) body.clearKey = true;
  else if (opts.sendKey && s.groqKey) body.groqKey = s.groqKey;
  await scriptPost(cfg.webAppUrl, cfg.adminKey, body, 60000);
}

/** Script se Groq tak ka raasta check karta hai (key script me hai aur chal rahi hai). */
async function scriptReachesGroq(): Promise<boolean> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return false;
  const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'rev_test' });
  return d.ok === true;
}

/** Key add / badalna: pehle Groq par test, phir Script ko bhejna, phir Script se Groq tak test. Sab theek ho to GREEN. */
export async function connectGroqKey(key: string): Promise<{ ok: boolean; error?: string }> {
  const k = key.trim();
  const t = await testGroqKey(k);
  if (!t.ok) return t;
  const prevKey = await getSetting(KEY_GROQ);
  const prevOk = await getSetting(KEY_GROQ_OK);
  await saveSetting(KEY_GROQ, k);
  try {
    await pushConfig({ sendKey: true });
    if (!(await scriptReachesGroq())) throw new Error('Script Groq tak nahi pahunch pa rahi. Key dobara check karein.');
  } catch (e: any) {
    // Pichli (chalti hui) key wapas, taaki half-state na bache
    await saveSetting(KEY_GROQ, typeof prevKey === 'string' ? prevKey : '');
    await saveSetting(KEY_GROQ_OK, prevOk === true);
    try { if (typeof prevKey === 'string' && prevKey) await pushConfig({ sendKey: true }); } catch { /* agli baar Settings khulne par theek ho jayega */ }
    return { ok: false, error: reviewError(e) };
  }
  await saveSetting(KEY_GROQ_OK, true);
  window.dispatchEvent(new CustomEvent(REVIEW_EVENT));
  return { ok: true };
}

/** Key hatana (CMS se bhi aur Script se bhi). */
export async function removeGroqKey(): Promise<{ ok: boolean; error?: string }> {
  let error: string | undefined;
  try { await pushConfig({ clearKey: true }); } catch (e: any) { error = reviewError(e); }
  await saveSetting(KEY_GROQ, '');
  await saveSetting(KEY_GROQ_OK, false);
  window.dispatchEvent(new CustomEvent(REVIEW_EVENT));
  return { ok: !error, error };
}

/** Link + keywords save karke Script ko bhejta hai. */
export async function saveReviewDetails(link: string, keywords: string[]): Promise<{ ok: boolean; error?: string }> {
  const l = link.trim();
  if (l && !isValidReviewLink(l)) return { ok: false, error: 'Link https:// se shuru hona chahiye (jaise https://g.page/r/.../review).' };
  await saveSetting(KEY_LINK, l);
  await saveSetting(KEY_KEYWORDS, keywords.slice(0, MAX_KEYWORDS));
  window.dispatchEvent(new CustomEvent(REVIEW_EVENT));
  try {
    await pushConfig();
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: reviewError(e) };
  }
}

/** Toggle turant save hota hai. Script ko batana best-effort hai. */
export async function setReviewEnabled(enabled: boolean): Promise<{ ok: boolean; error?: string }> {
  await saveSetting(KEY_ENABLED, enabled);
  window.dispatchEvent(new CustomEvent(REVIEW_EVENT));
  try {
    await pushConfig({ enabled });
    return { ok: true };
  } catch (e: any) {
    return { ok: false, error: reviewError(e) };
  }
}

/**
 * Settings khulte hi: agar CMS me key hai par Script me nahi (naya Sheet / naya deploy), to key dobara bhej deta hai.
 * Wapas deta hai: Script me key hai ya nahi.
 */
export async function checkReviewScript(): Promise<{ reachable: boolean; hasKey: boolean; error?: string }> {
  try {
    const cfg = await getAttendanceConfig();
    if (!cfg.webAppUrl) return { reachable: false, hasKey: false };
    const s = await getReviewSettings();
    const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'rev_status' });
    if (!d.hasKey && s.keyOk) {
      await pushConfig({ sendKey: true });
      return { reachable: true, hasKey: true };
    }
    return { reachable: true, hasKey: d.hasKey === true };
  } catch (e: any) {
    return { reachable: false, hasKey: false, error: reviewError(e) };
  }
}
