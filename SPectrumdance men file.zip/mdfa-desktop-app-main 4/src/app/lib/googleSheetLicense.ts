// Google Sheet License Management System
// Integrates with Google Apps Script API for license validation

export interface GoogleSheetLicenseData {
  success: boolean;
  code: string;
  message?: string;
  license_key?: string;
  business_name?: string;
  business?: string; // matches the field name actually returned by Apps Script
  user_name?: string;
  expiry_date?: string;
  expired_on?: string;
  days_left?: number;
  status?: 'active' | 'expired' | 'revoked';
  domain?: string;
  email?: string;
  phone?: string;
  plan?: string;
  created_at?: string;
  // Optional: Server (Cloud Sync) credentials, agar Google Sheet / Apps Script se bheje jayen
  supabase_url?: string;
  supabase_anon_key?: string;
}

// Google Apps Script API URL (from your existing script)
const GOOGLE_SHEET_API_URL = 'https://script.google.com/macros/s/AKfycbzmqyeF0io_3tVYX0lEC6dTYYEZxPZplGLYiO9_l1n-l8yRvGOgiXj8F8PzOvxW_PI6yA/exec';

// Cache settings
const CACHE_KEY = 'google_sheet_license_cache';
const CACHE_TIME_KEY = 'google_sheet_license_cache_time';
const CACHE_DURATION_MINUTES = 0; // Always revalidate - no cache

// LocalStorage keys
const LICENSE_KEY_STORAGE = 'user_license_key';
const LICENSE_DATA_STORAGE = 'user_license_data';

/**
 * Returns a stable device identifier for this install.
 * - Inside the Windows desktop app (Electron): returns the hardware machine ID.
 * - Inside the existing web/PWA version: returns undefined, so the request
 *   falls back to the old domain-based check exactly as before.
 * This keeps every existing web/PWA customer working unchanged.
 */
async function getDeviceMachineId(): Promise<string | undefined> {
  try {
    const desktopApi = (window as any).desktopApp;
    if (desktopApi?.isElectron && typeof desktopApi.getMachineId === 'function') {
      return await desktopApi.getMachineId();
    }
  } catch (error) {
    console.error('Error getting machine id:', error);
  }
  return undefined;
}

// Sheet ke ye jawab pakke hain (license sach me expire / band / galat hai). Inke alawa koi bhi
// failure (net slow, timeout, Apps Script ka error) sirf "abhi check nahi ho paya" hai, expiry nahi.
const DEFINITIVE_FAIL_CODES = ['EXPIRED', 'REVOKED', 'INVALID', 'NOT_FOUND', 'DOMAIN_MISMATCH', 'DEVICE_LIMIT_REACHED'];

export interface ValidateOptions {
  /**
   * true = Google Sheet tak na pahunch paye (slow / band internet) to isi key ka pichla
   * SAHI jawab (jo localStorage me save hai) use karo. Sirf app start par use hota hai.
   * Naya key activate karte waqt isse use NAHI karna chahiye.
   */
  useStoredOnError?: boolean;
}

/**
 * Sheet tak nahi pahunch paye to pichle SAHI jawab (localStorage me save) se faisla:
 * - Lifetime license hamesha chalta hai.
 * - Baaki me saved expiry date abhi tak nahi nikli -> chalta hai.
 * - Saved expiry date nikal chuki hai -> "EXPIRED" jawab (user ko seedha "License Expired" dikhe, "internet" nahi).
 * - Saved data nahi hai / kisi aur key ka hai -> null (tab "Internet slow" screen aati hai).
 */
function getOfflineFallback(licenseKey: string): GoogleSheetLicenseData | null {
  const stored = getStoredLicenseData();
  if (!stored || !stored.success) return null;
  if (DEFINITIVE_FAIL_CODES.includes(stored.code)) return null;
  const storedKey = String(stored.license_key || '').trim().toUpperCase();
  if (storedKey && storedKey !== licenseKey.trim().toUpperCase()) return null;
  if (!isLifetimeLicense(stored)) {
    const expiryStr = extractExpiryDate(stored);
    const expiry = parseLicenseDate(expiryStr);
    // expiry wale din ka poora din chalta hai
    if (expiry && expiry.getTime() + 24 * 60 * 60 * 1000 < Date.now()) {
      console.log('⛔ Saved expiry date nikal chuki hai - License Expired');
      return { ...stored, success: false, code: 'EXPIRED', status: 'expired', expired_on: expiryStr, expiry_date: expiryStr };
    }
  }
  console.log('📴 Sheet tak nahi pahunch paye - pichla valid license data use ho raha hai');
  return stored;
}

/**
 * Validate license key from Google Sheet
 */
export async function validateLicenseFromGoogleSheet(
  licenseKey: string,
  domain?: string,
  options: ValidateOptions = {}
): Promise<GoogleSheetLicenseData> {
  try {
    const currentDomain = domain || window.location.hostname;
    const machineId = await getDeviceMachineId();

    // Build API URL with parameters
    const url = new URL(GOOGLE_SHEET_API_URL);
    url.searchParams.append('action', 'verify_license');
    url.searchParams.append('key', licenseKey.trim().toUpperCase());
    url.searchParams.append('domain', currentDomain);

    // Only sent by the Windows desktop app. Existing web/PWA requests
    // won't include this param, so the backend keeps using domain-based
    // checks for them — nothing changes for current users.
    if (machineId) {
      url.searchParams.append('machine_id', machineId);
    }

    console.log('🔍 Validating license from Google Sheet:', licenseKey);

    // Fetch with timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 15000); // 15 second timeout (slow net par Apps Script der leta hai)

    const response = await fetch(url.toString(), {
      method: 'GET',
      signal: controller.signal
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data: GoogleSheetLicenseData = await response.json();
    if (!data.success && !data.message && (data as any).error) data.message = (data as any).error;

    console.log('✅ License validation response:', data);

    // Sheet ne "expired / revoked / invalid" nahi kaha, bas koi aur error diya (quota, busy...) -> ye expiry nahi hai
    if (!data.success && !DEFINITIVE_FAIL_CODES.includes(data.code) && options.useStoredOnError) {
      const fallback = getOfflineFallback(licenseKey);
      if (fallback) return fallback;
    }

    // Cache successful response
    if (data.success) {
      cacheLicenseData(data);
      // Always keep the saved copy in sync with the sheet (Profile / Dashboard read this)
      storeLicenseData(data);
    }

    return data;
  } catch (error) {
    console.error('❌ License validation error:', error);

    // Try to use cached data on error
    const cached = getCachedLicenseData();
    if (cached) {
      console.log('📦 Using cached license data due to network error');
      return cached;
    }

    // Slow / band internet: pichla valid license chalne do (lifetime ya abhi tak na nikli expiry)
    if (options.useStoredOnError) {
      const fallback = getOfflineFallback(licenseKey);
      if (fallback) return fallback;
    }

    // Return error response
    return {
      success: false,
      code: 'NETWORK_ERROR',
      message: 'Unable to validate license. Please check your internet connection.'
    };
  }
}

/**
 * Get stored license key from localStorage
 */
export function getStoredLicenseKey(): string | null {
  try {
    return localStorage.getItem(LICENSE_KEY_STORAGE);
  } catch (error) {
    console.error('Error getting stored license key:', error);
    return null;
  }
}

/**
 * Store license key in localStorage
 */
export function storeLicenseKey(licenseKey: string): void {
  try {
    localStorage.setItem(LICENSE_KEY_STORAGE, licenseKey.trim().toUpperCase());
  } catch (error) {
    console.error('Error storing license key:', error);
  }
}

/**
 * Get stored license data
 */
export function getStoredLicenseData(): GoogleSheetLicenseData | null {
  try {
    const data = localStorage.getItem(LICENSE_DATA_STORAGE);
    return data ? JSON.parse(data) : null;
  } catch (error) {
    console.error('Error getting stored license data:', error);
    return null;
  }
}

/**
 * Store license data
 */
export function storeLicenseData(data: GoogleSheetLicenseData): void {
  try {
    localStorage.setItem(LICENSE_DATA_STORAGE, JSON.stringify(data));
  } catch (error) {
    console.error('Error storing license data:', error);
  }
}

/**
 * Clear all license data
 */
export function clearLicenseData(): void {
  try {
    localStorage.removeItem(LICENSE_KEY_STORAGE);
    localStorage.removeItem(LICENSE_DATA_STORAGE);
    localStorage.removeItem(CACHE_KEY);
    localStorage.removeItem(CACHE_TIME_KEY);
    localStorage.removeItem('ams_license_cache');
    localStorage.removeItem('ams_license_cache_time');
    localStorage.removeItem('ams_license_domain');
  } catch (error) {
    console.error('Error clearing license data:', error);
  }
}

/**
 * Cache license data
 */
function cacheLicenseData(data: GoogleSheetLicenseData): void {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(data));
    localStorage.setItem(CACHE_TIME_KEY, Date.now().toString());
  } catch (error) {
    console.error('Error caching license data:', error);
  }
}

/**
 * Get cached license data if still valid
 */
function getCachedLicenseData(): GoogleSheetLicenseData | null {
  try {
    const cachedData = localStorage.getItem(CACHE_KEY);
    const cachedTime = localStorage.getItem(CACHE_TIME_KEY);

    if (!cachedData || !cachedTime) {
      return null;
    }

    const cacheAge = (Date.now() - parseInt(cachedTime)) / 60000; // minutes

    // Cache expired
    if (cacheAge > CACHE_DURATION_MINUTES) {
      return null;
    }

    return JSON.parse(cachedData);
  } catch (error) {
    console.error('Error getting cached license data:', error);
    return null;
  }
}

/**
 * Check if license needs revalidation
 */
export function shouldRevalidateLicense(): boolean {
  return true; // Always fetch fresh from Google Sheet
}

const LIFETIME_TEXT = /life\s*-?\s*time|unlimited|forever|permanent|never/i;

/**
 * Parses the expiry value coming from the sheet. Handles ISO dates and
 * dd/mm/yyyy or dd-mm-yyyy (which plain new Date() cannot read -> "Invalid Date").
 */
export function parseLicenseDate(value: string): Date | null {
  if (!value) return null;
  const str = String(value).trim();
  const dmy = str.match(/^(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);
  if (dmy) {
    const d = new Date(Number(dmy[3]), Number(dmy[2]) - 1, Number(dmy[1]));
    return isNaN(d.getTime()) ? null : d;
  }
  const d = new Date(str);
  return isNaN(d.getTime()) ? null : d;
}

/**
 * Format expiry date for display. Lifetime licenses show "Lifetime".
 */
export function formatExpiryDateDisplay(dateString: string): string {
  if (!dateString) return 'N/A';
  if (LIFETIME_TEXT.test(String(dateString))) return 'Lifetime';

  const date = parseLicenseDate(dateString);
  if (!date) return String(dateString);
  if (date.getFullYear() >= 2099) return 'Lifetime';
  return date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}

/**
 * Get days until expiry
 */
export function getDaysUntilExpiryFromDate(expiryDate: string): number {
  const expiry = parseLicenseDate(expiryDate);
  if (!expiry) return 0;
  const diffTime = expiry.getTime() - new Date().getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Check if license is valid (not expired and active)
 */
export function isGoogleSheetLicenseValid(data: GoogleSheetLicenseData | null): boolean {
  if (!data) return false;
  if (!data.success) return false;
  if (data.code === 'EXPIRED') return false;
  if (data.code === 'REVOKED') return false;
  if (data.code === 'INVALID') return false;
  if (data.code === 'DOMAIN_MISMATCH') return false;
  if (data.code === 'DEVICE_LIMIT_REACHED') return false;

  return true;
}

// Helper to extract expiry date from any possible field name
export function extractExpiryDate(data: any): string {
  return data?.expiry_date || data?.expired_on || data?.expiryDate || data?.expiry || data?.Expiry_Date || data?.ExpiryDate || '';
}

/**
 * Lifetime license check.
 * A license is "Lifetime" when the plan says so, or when the sheet returns an
 * extremely long validity (days_left > 9000, same rule as license-check.js).
 */
export function isLifetimeLicense(data: GoogleSheetLicenseData | null | undefined): boolean {
  if (!data) return false;
  if (typeof data.plan === 'string' && LIFETIME_TEXT.test(data.plan)) return true;
  if (typeof data.days_left === 'number' && data.days_left > 9000) return true;
  const expiry = extractExpiryDate(data);
  if (expiry) {
    if (LIFETIME_TEXT.test(String(expiry))) return true;
    const d = parseLicenseDate(expiry);
    if (d && d.getFullYear() >= 2099) return true;
  }
  return false;
}
