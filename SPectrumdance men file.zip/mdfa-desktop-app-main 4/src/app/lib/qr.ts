// Small wrapper around the vendored qrcode generator.
// Returns a crisp PNG data URL drawn on a canvas.
import qrcode from './qrcodeGenerator.js';

export function qrToDataUrl(text: string, size = 900, margin = 4): string {
  const qr = (qrcode as any)(0, 'M');
  qr.addData(text);
  qr.make();
  const count: number = qr.getModuleCount();
  const cell = Math.max(1, Math.floor(size / (count + margin * 2)));
  const px = cell * (count + margin * 2);
  const canvas = document.createElement('canvas');
  canvas.width = px;
  canvas.height = px;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, px, px);
  ctx.fillStyle = '#000000';
  for (let r = 0; r < count; r++) {
    for (let c = 0; c < count; c++) {
      if (qr.isDark(r, c)) ctx.fillRect((c + margin) * cell, (r + margin) * cell, cell, cell);
    }
  }
  return canvas.toDataURL('image/png');
}
