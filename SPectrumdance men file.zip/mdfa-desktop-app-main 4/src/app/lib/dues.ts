// Admission dues vs Monthly (renewal) dues.
//
//  admissionDues : balance left from the admission payment
//  monthlyDues   : balance left after a fees / renewal payment
//  dues          : always admissionDues + monthlyDues (so every old screen keeps working)
//
// Students saved before this change have no split fields. For them we guess from history:
// no payment record yet => it is still the admission balance, otherwise it is a monthly balance.

export interface DuesSplit {
  admission: number;
  monthly: number;
}

// ---- Discount + Dues Date (admission form se student par save hote hain) ----
//   student.discountAmount : ₹ me discount (total me se kam hota hai)
//   student.duesDate       : YYYY-MM-DD, is date tak dues pay karna hai (sirf jab dues > 0)
//   dues = (total + extra charges) - paid - discount

export function calcDues(total: any, paid: any, discount: any): number {
  return (parseFloat(String(total)) || 0) - (parseFloat(String(paid)) || 0) - (parseFloat(String(discount)) || 0);
}

/** Discount % (1 decimal). Total 0 / discount 0 ho to 0. */
export function discountPercent(total: any, discount: any): number {
  const t = parseFloat(String(total)) || 0;
  const d = parseFloat(String(discount)) || 0;
  return t > 0 && d > 0 ? Math.round((d / t) * 1000) / 10 : 0;
}

/** Student ke liye dues date (sirf tab jab dues baaki ho). Date ke din ke end tak pay kar sakta hai. */
export function isDuesDateOver(duesDate: string | undefined, dues: any): boolean {
  if (!duesDate || !(Number(dues) > 0)) return false;
  const d = new Date(`${duesDate}T23:59:59`);
  return !isNaN(d.getTime()) && d.getTime() < Date.now();
}

export function splitDues(student: any, hasPayments: boolean): DuesSplit {
  if (student?.admissionDues !== undefined || student?.monthlyDues !== undefined) {
    return {
      admission: Math.max(0, Number(student.admissionDues) || 0),
      monthly: Math.max(0, Number(student.monthlyDues) || 0),
    };
  }
  const d = Math.max(0, Number(student?.dues) || 0);
  return hasPayments ? { admission: 0, monthly: d } : { admission: d, monthly: 0 };
}
