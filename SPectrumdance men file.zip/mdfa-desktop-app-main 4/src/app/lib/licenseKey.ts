// License Key Management System

export interface LicenseKey {
  key: string;
  expiryDate: string;
  isActive: boolean;
  createdDate: string;
}

// Generate a unique license key
export function generateLicenseKey(): string {
  const prefix = 'MDA'; // Mayuri Dance Academy
  const randomPart = Math.random().toString(36).substring(2, 10).toUpperCase();
  const timestamp = Date.now().toString(36).toUpperCase();
  return `${prefix}-${randomPart}-${timestamp}`;
}

// Check if license key is valid and not expired
export function isLicenseValid(license: LicenseKey | null): boolean {
  if (!license) return false;
  if (!license.isActive) return false;

  const today = new Date();
  const expiryDate = new Date(license.expiryDate);

  return today <= expiryDate;
}

// Get days remaining until expiry
export function getDaysUntilExpiry(expiryDate: string): number {
  const today = new Date();
  const expiry = new Date(expiryDate);
  const diffTime = expiry.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

// Format expiry date for display
export function formatExpiryDate(dateString: string): string {
  const date = new Date(dateString);
  return date.toLocaleDateString('en-GB', {
    day: '2-digit',
    month: 'short',
    year: 'numeric'
  });
}
