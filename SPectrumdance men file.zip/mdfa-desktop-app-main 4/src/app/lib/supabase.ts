import { createClient } from '@supabase/supabase-js';

// Get Supabase credentials from environment or fallback
const getSupabaseUrl = (): string => {
  // Check for environment variables
  if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_URL) {
    return import.meta.env.VITE_SUPABASE_URL;
  }
  // Check for process.env (Node environment)
  if (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_URL) {
    return process.env.VITE_SUPABASE_URL;
  }
  return '';
};

const getSupabaseAnonKey = (): string => {
  // Check for environment variables
  if (typeof import.meta !== 'undefined' && import.meta.env?.VITE_SUPABASE_ANON_KEY) {
    return import.meta.env.VITE_SUPABASE_ANON_KEY;
  }
  // Check for process.env (Node environment)
  if (typeof process !== 'undefined' && process.env?.VITE_SUPABASE_ANON_KEY) {
    return process.env.VITE_SUPABASE_ANON_KEY;
  }
  return '';
};

const supabaseUrl = getSupabaseUrl();
const supabaseAnonKey = getSupabaseAnonKey();

// Create Supabase client
export const supabase = createClient(
  supabaseUrl || 'https://placeholder.supabase.co',
  supabaseAnonKey || 'placeholder-key'
);

// Check if Supabase is properly connected
export const isSupabaseConnected = () => {
  const connected = !!supabaseUrl && 
                   !!supabaseAnonKey && 
                   supabaseUrl !== 'https://placeholder.supabase.co' &&
                   supabaseAnonKey !== 'placeholder-key';
  
  if (connected) {
    console.log('✅ Supabase Connected:', supabaseUrl);
  } else {
    console.log('⚠️ Supabase Not Connected - Using localStorage only');
  }
  
  return connected;
};

// Database table names
export const TABLES = {
  STUDENTS: 'students',
  PAYMENTS: 'payments',
  TEACHERS: 'teachers',
  BATCHES: 'batches',
  LOCATIONS: 'locations',
  ADMIN_CREDENTIALS: 'admin_credentials'
};