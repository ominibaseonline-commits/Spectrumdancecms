// Auto-reminder WhatsApp message templates for Dues, Expiry Soon & Expired students.
// Templates are editable by the admin (Campaign > Auto Reminders), but the
// Business Name signature line is ALWAYS appended automatically from
// Business Settings and can never be typed/edited inside the template itself.

import { getSetting, saveSetting } from './indexedDB';
import { getPaymentsByStudent } from './storageAdapter';

export const DUES_TEMPLATE_KEY = 'duesReminderTemplate';
export const EXPIRY_TEMPLATE_KEY = 'expirySoonReminderTemplate';
export const EXPIRED_TEMPLATE_KEY = 'expiredReminderTemplate';
export const ABSENT_TEMPLATE_KEY = 'attendanceAbsentTemplate';
export const ZERO_TEMPLATE_KEY = 'attendanceZeroTemplate';

export const DEFAULT_DUES_TEMPLATE =
`प्रिय {{studentName}},
{{location}} में आपकी {{duesType}} ₹{{amount}} बकाया है। कृपया जल्द से जल्द भुगतान करें।
धन्यवाद!`;

export const DEFAULT_EXPIRY_TEMPLATE =
`प्रिय {{studentName}},
{{location}} में आपकी क्लास का पैकेज {{expiryDate}} को समाप्त हो रहा है।
कृपया तुरंत Renewal कराएं। धन्यवाद!`;

export const DEFAULT_EXPIRED_TEMPLATE =
`प्रिय {{studentName}},
{{location}} में आपकी क्लास का पैकेज {{expiryDate}} को समाप्त हो चुका है।
कृपया जल्द से जल्द Renewal कराएं, ताकि आप classes जारी रख सकें। धन्यवाद!`;

// Attendance — message sent to a student who was absent (Reports -> Today ka Report -> send button).
// Business Name is appended automatically as the last line, same as the other reminders.
export const DEFAULT_ABSENT_TEMPLATE =
`प्रिय {{studentName}},
Ek aur class miss ho gayi!
Yaad rakhein, regular class mein hona bahut zaroori hai.
kripaya jald wapas aayein aur apni classes Regular banaye rakhein.`;

export const ABSENT_PLACEHOLDERS = ['{{studentName}}', '{{batchTime}}', '{{location}}'];

export async function getAbsentTemplate(): Promise<string> {
  const saved = await getSetting(ABSENT_TEMPLATE_KEY);
  return saved || DEFAULT_ABSENT_TEMPLATE;
}
export async function saveAbsentTemplate(text: string): Promise<void> {
  await saveSetting(ABSENT_TEMPLATE_KEY, text);
}

// Placeholders shown as hints to the admin while editing each template.
// {{duesDate}} optional: admission form me jo "Pay Dues By" date bhari thi (dd/mm/yyyy), nahi bhari to khali.
export const DUES_PLACEHOLDERS = ['{{studentName}}', '{{location}}', '{{duesType}}', '{{amount}}', '{{duesDate}}'];

function fmtDuesDate(iso?: string): string {
  const p = String(iso || '').split('-');
  return p.length === 3 ? `${p[2]}/${p[1]}/${p[0]}` : '';
}
export const EXPIRY_PLACEHOLDERS = ['{{studentName}}', '{{location}}', '{{expiryDate}}'];

export async function getDuesTemplate(): Promise<string> {
  const saved = await getSetting(DUES_TEMPLATE_KEY);
  return saved || DEFAULT_DUES_TEMPLATE;
}
export async function saveDuesTemplate(text: string): Promise<void> {
  await saveSetting(DUES_TEMPLATE_KEY, text);
}

export async function getExpiryTemplate(): Promise<string> {
  const saved = await getSetting(EXPIRY_TEMPLATE_KEY);
  return saved || DEFAULT_EXPIRY_TEMPLATE;
}
export async function saveExpiryTemplate(text: string): Promise<void> {
  await saveSetting(EXPIRY_TEMPLATE_KEY, text);
}

export async function getExpiredTemplate(): Promise<string> {
  const saved = await getSetting(EXPIRED_TEMPLATE_KEY);
  return saved || DEFAULT_EXPIRED_TEMPLATE;
}
export async function saveExpiredTemplate(text: string): Promise<void> {
  await saveSetting(EXPIRED_TEMPLATE_KEY, text);
}

// A student's outstanding dues are "Admission Dues" if no fee-collection
// payment has ever been recorded for them (i.e. the balance is still the
// original admission balance), otherwise they are "Monthly Dues" (a later
// renewal/collection cycle has already started).
export async function getDuesType(regNo: string): Promise<string> {
  try {
    const payments = await getPaymentsByStudent(regNo);
    return payments && payments.length > 0 ? 'Monthly Dues' : 'Admission Dues';
  } catch {
    return 'Admission Dues';
  }
}

function fillTemplate(template: string, values: Record<string, string>): string {
  let out = template;
  Object.entries(values).forEach(([key, val]) => {
    out = out.split(`{{${key}}}`).join(val);
  });
  return out;
}

// Business name is never part of the editable template — it is always
// pulled live from Business Settings and appended as the final line.
function appendSignature(body: string, businessName: string): string {
  return `${body}\n${businessName}`;
}

export async function buildDuesMessage(student: any, businessName: string): Promise<string> {
  const template = await getDuesTemplate();
  const duesType = await getDuesType(student.regNo);
  const body = fillTemplate(template, {
    studentName: student.name || '',
    location: student.location || '',
    duesType,
    amount: String(student.dues || 0),
    duesDate: fmtDuesDate(student.duesDate),
  });
  return appendSignature(body, businessName);
}

export async function buildExpiryMessage(
  student: any,
  businessName: string,
  formatDate: (d: string) => string
): Promise<string> {
  const template = await getExpiryTemplate();
  const body = fillTemplate(template, {
    studentName: student.name || '',
    location: student.location || '',
    expiryDate: formatDate(student.expiryDate),
  });
  return appendSignature(body, businessName);
}

export async function buildExpiredMessage(
  student: any,
  businessName: string,
  formatDate: (d: string) => string
): Promise<string> {
  const template = await getExpiredTemplate();
  const body = fillTemplate(template, {
    studentName: student.name || '',
    location: student.location || '',
    expiryDate: formatDate(student.expiryDate),
  });
  return appendSignature(body, businessName);
}

export async function buildAbsentMessage(student: any, businessName: string, batchTime?: string): Promise<string> {
  const template = await getAbsentTemplate();
  const body = fillTemplate(template, {
    studentName: student.name || '',
    batchTime: batchTime || student.batchTime || '',
    location: student.location || '',
  });
  return appendSignature(body, businessName);
}

// 0% attendance — student who did not attend a single class in a month (Reports -> 0% This Month).
// Business Name is appended automatically in *bold* (WhatsApp formatting) as the last line.
export const DEFAULT_ZERO_TEMPLATE =
`Namaste {{studentName}},

Humne notice kiya ki {{monthYear}} mein aapne ek bhi class nahi li. Kya sab theek hai?

Hum aapka intezaar kar rahe hain - jald aayein!`;

export const ZERO_PLACEHOLDERS = ['{{studentName}}', '{{monthYear}}'];

export async function getZeroTemplate(): Promise<string> {
  const saved = await getSetting(ZERO_TEMPLATE_KEY);
  return saved || DEFAULT_ZERO_TEMPLATE;
}
export async function saveZeroTemplate(text: string): Promise<void> {
  await saveSetting(ZERO_TEMPLATE_KEY, text);
}

export async function buildZeroAttendanceMessage(student: any, businessName: string, monthYear: string): Promise<string> {
  const template = await getZeroTemplate();
  const body = fillTemplate(template, {
    studentName: student.name || '',
    monthYear,
  });
  return `${body}\n\n*${businessName}*`;
}

// ---------------------------------------------------------------------------
// Attendance panel — dues WhatsApp buttons (Attendance -> Admission Dues / Monthly Dues).
// Until the admin edits them (Campaign -> Attendance Messages) they use the same text as the
// normal CMS Dues reminder. Business Name is appended automatically as the last line.
// ---------------------------------------------------------------------------
export const ATT_ADM_DUES_KEY = 'attendanceAdmissionDuesTemplate';
export const ATT_MON_DUES_KEY = 'attendanceMonthlyDuesTemplate';

export type AttendanceDuesKind = 'admission' | 'monthly';

export async function getAttendanceDuesTemplate(kind: AttendanceDuesKind): Promise<string> {
  const saved = await getSetting(kind === 'admission' ? ATT_ADM_DUES_KEY : ATT_MON_DUES_KEY);
  return saved || (await getDuesTemplate());
}
export async function saveAttendanceDuesTemplate(kind: AttendanceDuesKind, text: string): Promise<void> {
  await saveSetting(kind === 'admission' ? ATT_ADM_DUES_KEY : ATT_MON_DUES_KEY, text);
}

export async function buildAttendanceDuesMessage(
  student: any,
  businessName: string,
  kind: AttendanceDuesKind,
  amount: number
): Promise<string> {
  const template = await getAttendanceDuesTemplate(kind);
  const body = fillTemplate(template, {
    studentName: student.name || '',
    location: student.location || '',
    duesType: kind === 'admission' ? 'Admission Dues' : 'Monthly Dues',
    amount: String(amount || 0),
    duesDate: fmtDuesDate(student.duesDate),
  });
  return appendSignature(body, businessName);
}

// ---------------------------------------------------------------------------
// Attendance panel — Expiry WhatsApp button (Attendance -> Expiry column).
//   * Expiry Soon (5 din ya kam bacha) -> Expiry Soon message
//   * Expired                          -> Expired message
// Until the admin edits them (Campaign -> Attendance Messages) they use the same text as the
// Dashboard reminders. Business Name is appended automatically as the last line.
// ---------------------------------------------------------------------------
export const ATT_EXPIRY_SOON_KEY = 'attendanceExpirySoonTemplate';
export const ATT_EXPIRED_KEY = 'attendanceExpiredTemplate';

export type AttendanceExpiryKind = 'soon' | 'expired';

export async function getAttendanceExpiryTemplate(kind: AttendanceExpiryKind): Promise<string> {
  const saved = await getSetting(kind === 'soon' ? ATT_EXPIRY_SOON_KEY : ATT_EXPIRED_KEY);
  return saved || (kind === 'soon' ? await getExpiryTemplate() : await getExpiredTemplate());
}
export async function saveAttendanceExpiryTemplate(kind: AttendanceExpiryKind, text: string): Promise<void> {
  await saveSetting(kind === 'soon' ? ATT_EXPIRY_SOON_KEY : ATT_EXPIRED_KEY, text);
}

export async function buildAttendanceExpiryMessage(
  student: any,
  businessName: string,
  kind: AttendanceExpiryKind,
  formatDate: (d: string) => string
): Promise<string> {
  const template = await getAttendanceExpiryTemplate(kind);
  const body = fillTemplate(template, {
    studentName: student.name || '',
    location: student.location || '',
    expiryDate: formatDate(student.expiryDate),
  });
  return appendSignature(body, businessName);
}
