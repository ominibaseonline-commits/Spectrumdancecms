// Google Drive Auto Backup — renderer-side helpers.
// Talks to the Electron main process via window.driveBackup (see preload.cjs).
// All actual OAuth/network work happens in electron/googleDrive.cjs; this
// file just builds the backup payload and forwards calls.

import { exportEverything, importAllData } from './indexedDB';

export interface DriveStatus {
  connected: boolean;
  email: string | null;
  lastBackupTime: string | null;
  lastFileName?: string | null;
}

export interface DriveBackupResult {
  success: boolean;
  unchanged?: boolean;
  lastBackupTime?: string | null;
  fileName?: string | null;
  error?: string;
  code?: 'not_connected' | 'empty_cms';
}

export interface DriveRestoreResult {
  success: boolean;
  fileName?: string;
  createdTime?: string;
  error?: string;
  code?: 'not_connected' | 'no_backups';
}

function getDriveApi() {
  const api = (window as any).driveBackup;
  const isElectron = (window as any).desktopApp?.isElectron;
  return isElectron && api ? api : null;
}

export const isDriveBackupAvailable = (): boolean => !!getDriveApi();

export const connectGoogleDrive = async (): Promise<{ success: boolean; email?: string | null; error?: string }> => {
  const api = getDriveApi();
  if (!api) return { success: false, error: 'Ye feature sirf desktop app mein available hai.' };
  return api.connect();
};

export const disconnectGoogleDrive = async (): Promise<{ success: boolean; error?: string }> => {
  const api = getDriveApi();
  if (!api) return { success: false, error: 'Ye feature sirf desktop app mein available hai.' };
  return api.disconnect();
};

export const getGoogleDriveStatus = async (): Promise<DriveStatus> => {
  const api = getDriveApi();
  if (!api) return { connected: false, email: null, lastBackupTime: null };
  return api.getStatus();
};

// Actually re-checks Drive itself (not just the cached local status) — this
// is what the "Refresh" button calls, so it reflects reality (e.g. a backup
// made from another device, or a backup file deleted manually from Drive).
export const refreshGoogleDriveStatus = async (): Promise<DriveStatus> => {
  const api = getDriveApi();
  if (!api) return { connected: false, email: null, lastBackupTime: null };
  return api.refreshStatus();
};

function pad(n: number): string {
  return String(n).padStart(2, '0');
}

// Dated + timestamped filename, e.g. "Sunrise_Academy_Backup_2026-09-07_14-32-05.json"
// — makes it easy for the admin to tell backups apart just by looking at Drive.
function buildBackupFileName(businessName?: string): string {
  const safeName = (businessName || 'Ominibase').replace(/[^a-zA-Z0-9]/g, '_');
  const now = new Date();
  const dateStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())}`;
  const timeStr = `${pad(now.getHours())}-${pad(now.getMinutes())}-${pad(now.getSeconds())}`;
  return `${safeName}_Backup_${dateStr}_${timeStr}.json`;
}

// True if the CMS holds at least one real record (students, payments, batches, etc.).
// Settings alone (theme, business name...) do not count as "data" worth backing up.
const RECORD_KEYS = [
  'students', 'payments', 'batches', 'locations', 'teachers', 'categories',
  'teacherPayments', 'campaignTemplates', 'enquiries',
  'eventEvents', 'eventTemplates', 'eventSubmissions',
];
export const hasAnyCmsData = (data: any): boolean =>
  RECORD_KEYS.some((k) => Array.isArray(data?.[k]) && data[k].length > 0);

// Builds the same complete-data JSON used by the "Export JSON File" button
// and sends it to the main process to upload to Drive.
export const backupToGoogleDrive = async (businessName?: string): Promise<DriveBackupResult> => {
  const api = getDriveApi();
  if (!api) return { success: false, error: 'Ye feature sirf desktop app mein available hai.' };

  // Complete data (same as "Export JSON File"): every record + every setting
  // (QR Attendance, QR Enquiry, Online Admission, Google Review, Theme, Event
  // Forms...) + Events module stores. Nothing from the CMS is left out.
  const allData = await exportEverything();

  // Empty CMS guard: if there is nothing in the CMS, do NOT upload a blank
  // backup (it would look like a valid latest backup and could be restored over real data).
  if (!hasAnyCmsData(allData)) {
    return {
      success: false,
      code: 'empty_cms',
      error: 'CMS me abhi koi data nahi hai, isliye backup nahi liya gaya.',
    };
  }

  const name = businessName || allData.businessName || 'Ominibase';

  // hashPayload = ONLY the actual data (students, payments, settings, etc.),
  // with NO timestamp inside it. This is what "has anything changed?" is
  // checked against — a fresh exportDate on every click must never by
  // itself count as a change, or "Backup Now" would always re-upload even
  // when nothing in the actual data was touched.
  // Housekeeping settings that change by themselves (sync timestamps / counters) are left
  // out of the hash so they alone never trigger a new backup.
  const hashPayload = JSON.stringify({
    ...allData,
    settingsAll: (allData.settingsAll || []).filter(
      (r: any) => !/(LastSync|LastSeq|SeqUrl)$/.test(r?.key || '')
    ),
  });

  const exportData = {
    ...allData,
    businessName: name,
    exportDate: new Date().toISOString(),
    version: '2.0',
    source: name + ' POS',
    backupType: 'google-drive-auto',
  };
  const jsonString = JSON.stringify(exportData, null, 2);
  const fileName = buildBackupFileName(name);

  return api.backupNow({ jsonString, hashPayload, fileName });
};

// "Restore" button — pulls the newest backup file from the "Ominibase CMS"
// Drive folder and imports it straight into this device's data.
export const restoreLatestGoogleDriveBackup = async (): Promise<DriveRestoreResult> => {
  const api = getDriveApi();
  if (!api) return { success: false, error: 'Ye feature sirf desktop app mein available hai.' };

  const result = await api.restoreLatest();
  if (!result.success) return result;

  try {
    const data = JSON.parse(result.content);
    if (!data.students && !data.batches && !data.locations) {
      return { success: false, error: 'Backup file khaali ya invalid lag rahi hai.' };
    }
    await importAllData(data);
    return { success: true, fileName: result.fileName, createdTime: result.createdTime };
  } catch (e: any) {
    return { success: false, error: e?.message || 'Backup file parse nahi ho payi.' };
  }
};

// Registers the listener for the main process's daily 9 PM trigger. Call
// once near the app root (App.tsx). Returns nothing to clean up since
// ipcRenderer.on listeners here are meant to live for the app's lifetime.
export const onAutoBackupRequested = (callback: () => void): void => {
  const api = getDriveApi();
  if (!api) return;
  api.onAutoBackupRequested(callback);
};
