// ID Card (CMS side). Design ek hi jagah (idCardRender.js) me hai; yaha settings save/load, image / PDF banana
// aur WhatsApp par bhejna hai.
//
//  - Settings -> ID Card se admin card customize karta hai (columns, header image, template, front / back / single, ON / OFF).
//  - Save karte hi online admission form ko bhi naya card config chala jata hai (onlineAdmission.ts).
//  - Admission Saved popup / Student Dashboard me wahi card dikhta hai.

import { useCallback, useEffect, useState } from 'react';
import { getSetting, saveSetting } from './indexedDB';
import { ADM_THEME } from './assets/admTheme';
import { qrToDataUrl } from './qr';
import { compressDocumentToTarget } from './imageCompress';
import * as R from './idCardRender.js';
import { printDocument } from './printReceipt';

export type IdCardSettings = ReturnType<typeof R.defaultIdCardSettings>;
export interface IdCardAssets { banner?: string; dancer?: string; photo?: string; qr?: string }

export const ID_CARD_KEY = 'idCardSettings';
export const ID_CARD_EVENT = 'idCardSettingsUpdated';
export const ID_CARD_TEMPLATES = R.ID_CARD_TEMPLATES as Record<string, { name: string; dark: string; a1: string }>;
export const ID_CARD_BASE_FIELDS = R.ID_CARD_BASE_FIELDS as { id: string; label: string }[];
export const defaultIdCardSettings = R.defaultIdCardSettings as () => IdCardSettings;
export const normalizeIdCardSettings = R.normalizeIdCardSettings as (raw: any) => IdCardSettings;
export const renderIdCardSide = R.renderIdCardSide as (side: 'front' | 'back', settings: any, data: any, assets: IdCardAssets, rootId?: string) => string;
export const ID_CARD_CSS = R.ID_CARD_CSS as string;

export async function loadIdCardSettings(): Promise<IdCardSettings> {
  try {
    return normalizeIdCardSettings(await getSetting(ID_CARD_KEY));
  } catch {
    return defaultIdCardSettings();
  }
}

export async function saveIdCardSettings(s: IdCardSettings): Promise<IdCardSettings> {
  const clean = normalizeIdCardSettings(s);
  await saveSetting(ID_CARD_KEY, clean);
  window.dispatchEvent(new Event(ID_CARD_EVENT));
  return clean;
}

export async function getIdCardEnabled(): Promise<boolean> {
  return (await loadIdCardSettings()).enabled;
}

/** Screens ke liye: const { settings, loading } = useIdCardSettings(); */
export function useIdCardSettings() {
  const [settings, setSettings] = useState<IdCardSettings>(() => defaultIdCardSettings());
  const [loading, setLoading] = useState(true);
  const reload = useCallback(async () => {
    setSettings(await loadIdCardSettings());
    setLoading(false);
  }, []);
  useEffect(() => {
    reload();
    window.addEventListener(ID_CARD_EVENT, reload);
    return () => window.removeEventListener(ID_CARD_EVENT, reload);
  }, [reload]);
  return { settings, loading, reload };
}

// ---------- assets ----------

export function getIdCardBanner(s: IdCardSettings): string {
  return s.bannerImage || ADM_THEME.cardBanner;
}

export function buildIdCardAssets(s: IdCardSettings, photo?: string): IdCardAssets {
  let qr = '';
  if (s.qrEnabled && s.qrUrl) {
    try { qr = qrToDataUrl(s.qrUrl, 300, 1); } catch { qr = ''; }
  }
  return { banner: getIdCardBanner(s), dancer: ADM_THEME.dancer, photo: photo || '', qr };
}

/** Header image (banner): card par 255x107 me aati hai, isliye 30 KB ke andar compress. */
export async function compressIdCardBanner(file: File | Blob): Promise<string> {
  return compressDocumentToTarget(file, 30 * 1024);
}

// Card ke liye student ka data: student object + (agar ho to) category-subCategory
export function idCardData(student: any): any {
  return { ...(student || {}), customFields: student?.customFields || {} };
}

// ---------- image / PDF ----------

function waitImages(root: HTMLElement): Promise<void> {
  const imgs = Array.from(root.querySelectorAll('img'));
  return Promise.all(
    imgs.map((img) => (img.complete ? Promise.resolve() : new Promise<void>((res) => { img.onload = () => res(); img.onerror = () => res(); })))
  ).then(() => undefined);
}

/** Card ke sides ko PNG data-URL me badalta hai (settings.sides ke hisaab se). */
export async function renderIdCardImages(student: any, settings: IdCardSettings, scale = 3, mime: 'image/png' | 'image/jpeg' = 'image/png'): Promise<{ front?: string; back?: string }> {
  const html2canvas = (await import('html2canvas')).default;
  const host = document.createElement('div');
  host.style.cssText = 'position:fixed;left:-10000px;top:0;display:flex;gap:20px;background:#fff;';
  const assets = buildIdCardAssets(settings, student?.photo);
  const data = idCardData(student);
  const want: ('front' | 'back')[] = settings.sides === 'front' ? ['front'] : settings.sides === 'back' ? ['back'] : ['front', 'back'];
  host.innerHTML = `<style>${ID_CARD_CSS}</style>` + want.map((sd) => renderIdCardSide(sd, settings, data, assets, 'idc-' + sd)).join('');
  document.body.appendChild(host);
  try {
    await waitImages(host);
    const out: { front?: string; back?: string } = {};
    for (const sd of want) {
      const el = host.querySelector<HTMLElement>('#idc-' + sd)!;
      const canvas = await html2canvas(el, { backgroundColor: '#ffffff', scale, useCORS: true, scrollX: 0, scrollY: 0 });
      out[sd] = mime === 'image/jpeg' ? canvas.toDataURL('image/jpeg', 0.92) : canvas.toDataURL('image/png');
    }
    return out;
  } finally {
    document.body.removeChild(host);
  }
}

/** ID card ka PDF (A4 par, front + back saath me; sirf ek side ON ho to ek hi). */
export async function buildIdCardPdf(student: any, settings: IdCardSettings): Promise<{ blob: Blob; fileName: string }> {
  const { jsPDF } = await import('jspdf');
  const imgs = await renderIdCardImages(student, settings, 3, 'image/jpeg');   // JPEG: PDF chhoti rehti hai (WhatsApp ke liye)
  const list = [imgs.front, imgs.back].filter(Boolean) as string[];
  const pdf = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
  const w = 80;                 // card ki chaudai (mm)
  const h = (w * 404) / 255;    // 126.7 mm
  const gap = 10;
  const total = list.length * w + (list.length - 1) * gap;
  const startX = (210 - total) / 2;
  list.forEach((src, i) => pdf.addImage(src, 'JPEG', startX + i * (w + gap), 30, w, h));
  const safe = String(student?.name || 'Student').replace(/[^A-Za-z0-9]+/g, '_').slice(0, 40);
  return { blob: pdf.output('blob'), fileName: `IDCard_${safe}.pdf` };
}

/**
 * ID Card ko wahi "Print / Save as PDF" flow se kholta hai jo Admission Receipt ka hai.
 * Desktop app me Save As dialog khulta hai aur file ka naam apne aap "<Student Name>_ID_Card.pdf" hota hai;
 * browser me print window khulti hai (title wahi naam hota hai), vaha "Save as PDF" chun sakte hain.
 */
export async function printIdCard(student: any, settings: IdCardSettings): Promise<void> {
  const imgs = await renderIdCardImages(student, settings, 3, 'image/png');
  const list = [imgs.front, imgs.back].filter(Boolean) as string[];
  const name = String(student?.name || 'Student').trim() || 'Student';
  const esc = (t: string) => t.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c] as string));
  const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>${esc(name)}_ID_Card</title>
  <style>
    @page { size: A4; margin: 10mm; }
    * { box-sizing: border-box; }
    body { margin: 0; padding: 0; font-family: Arial, sans-serif; background: #fff; }
    .wrap { display: flex; justify-content: center; align-items: flex-start; gap: 10mm; padding-top: 18mm; }
    .wrap img { width: 80mm; height: auto; display: block; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  </style>
</head>
<body>
  <div class="wrap">
    ${list.map((src) => `<img src="${src}" alt="ID Card" />`).join('\n    ')}
  </div>
</body>
</html>`;
  await printDocument(html, `${name}_ID_Card`, { fitOnePage: true });
}

export function downloadBlob(blob: Blob, fileName: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export type IdCardSendResult = 'shared' | 'downloaded';

/**
 * Student ke WhatsApp par ID card PDF bhejna.
 *  - Phone / jaha browser file-share support karta hai: share sheet khulti hai, WhatsApp chun kar bhej do (PDF saath jati hai).
 *  - Computer par: PDF download hoti hai + student ki WhatsApp chat khulti hai; PDF ko chat me attach / drag karna hota hai
 *    (WhatsApp ka link PDF apne aap attach nahi karne deta).
 */
export async function sendIdCardWhatsApp(student: any, settings: IdCardSettings, message: string): Promise<IdCardSendResult> {
  const { blob, fileName } = await buildIdCardPdf(student, settings);
  const file = new File([blob], fileName, { type: 'application/pdf' });
  const nav: any = navigator;
  if (nav.canShare && nav.canShare({ files: [file] })) {
    try {
      await nav.share({ files: [file], text: message });
      return 'shared';
    } catch (e: any) {
      if (e?.name === 'AbortError') return 'shared'; // user ne share band kar diya
    }
  }
  downloadBlob(blob, fileName);
  const phone = String(student?.mobile || '').replace(/\D/g, '').slice(-10);
  if (phone) window.open(`https://wa.me/91${phone}?text=${encodeURIComponent(message)}`, '_blank');
  return 'downloaded';
}

// ---------- online admission ko bhejne wala hissa ----------

/** Script ko jane wali settings. Banner image alag bheji jati hai (badi hoti hai), isliye yaha khali. */
export function idCardForOnline(s: IdCardSettings): Omit<IdCardSettings, 'bannerImage'> & { bannerImage: '' } {
  return { ...s, bannerImage: '' };
}
