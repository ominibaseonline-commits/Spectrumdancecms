// =============================================================================
// Admin password reset via LICENSE KEY (Forgot Password)
// =============================================================================
//  - Default login: admin@1234 / admin@1234
//  - Password change -> IndexedDB 'settings' (adminUser/adminPass) -> serverSync
//    ise automatically Supabase (app_data) me save kar deta hai.
//  - Forgot Password -> license key daalo -> key Supabase se verify hoti hai ->
//    adminUser/adminPass Supabase me default par reset ho jate hain ->
//    'adminResetEpoch' badal jata hai. Dusre devices jaise hi sync karte hain,
//    unhe naya epoch dikhta hai aur woh apne aap logout ho jate hain.
// =============================================================================

import { getSetting, saveSetting } from './indexedDB';
import { saveAdminCredentials } from './storageAdapter';
import { getStoredLicenseKey } from './googleSheetLicense';
import { isServerActive, verifyLicenseWithServer, syncNow } from './serverSync';

export const DEFAULT_ADMIN_EMAIL = 'admin@1234';
export const DEFAULT_ADMIN_PASSWORD = 'admin@1234';
const EPOCH_KEY = 'adminResetEpoch';

/** Har reset par badalta hai. Logged-in device isse apne login-time wale value se compare karta hai. */
export const getAdminResetEpoch = async (): Promise<string> => {
  try {
    return String((await getSetting(EPOCH_KEY)) ?? '');
  } catch {
    return '';
  }
};

export type ResetResult =
  | { ok: true; syncedToServer: boolean }
  | { ok: false; reason: 'empty' | 'wrong-key' | 'no-license' | 'error'; message: string };

export async function resetAdminPasswordWithLicense(enteredKey: string): Promise<ResetResult> {
  const entered = (enteredKey || '').trim().toUpperCase();
  if (!entered) {
    return { ok: false, reason: 'empty', message: 'License key daalein.' };
  }

  const stored = (getStoredLicenseKey() || '').trim().toUpperCase();
  if (!stored) {
    return { ok: false, reason: 'no-license', message: 'Is device par koi license key activate nahi hai.' };
  }

  // 1) Key match (local)
  if (entered !== stored) {
    return { ok: false, reason: 'wrong-key', message: 'Galat license key. Sahi key daalein.' };
  }

  // 2) Key match (Supabase) - sirf tab jab server chalu ho
  if (isServerActive()) {
    const serverCheck = await verifyLicenseWithServer(entered);
    if (serverCheck === 'mismatch') {
      return { ok: false, reason: 'wrong-key', message: 'Ye license key is server se match nahi karti.' };
    }
    // 'offline' / 'error' -> local reset ho jayega, internet aate hi server par chala jayega
  }

  try {
    // 3) Default credentials + naya epoch. Ye teeno IndexedDB 'settings' me jate hain,
    //    isliye serverSync inhe apne aap Supabase par bhej deta hai.
    await saveAdminCredentials(DEFAULT_ADMIN_EMAIL, DEFAULT_ADMIN_PASSWORD);
    await saveSetting(EPOCH_KEY, `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`);

    // 4) Turant server par push (45s ka wait nahi)
    let synced = false;
    if (isServerActive()) synced = await syncNow();

    return { ok: true, syncedToServer: synced };
  } catch (e: any) {
    return { ok: false, reason: 'error', message: e?.message || 'Password reset nahi ho paya.' };
  }
}
