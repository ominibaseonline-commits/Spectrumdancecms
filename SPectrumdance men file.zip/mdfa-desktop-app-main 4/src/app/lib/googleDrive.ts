// Google Drive daily backup — works in BOTH builds from the same code:
//
//  - Desktop (Electron/.exe): all OAuth + Drive API calls happen in the main
//    process (electron/googleDrive.cjs). This file just calls window.driveBackup,
//    which the preload script exposes.
//
//  - Web (Netlify): there is no main process, so this file talks to Google
//    directly — Google Identity Services (GIS) for sign-in, then the Drive
//    REST API over fetch() with the access token, from the browser.
//
// Either way, the data only ever goes to the SIGNED-IN USER'S OWN Google
// Drive (scope is drive.file — this app can only see/create files it made
// itself, never the rest of the user's Drive).

import { exportAllData, importAllData } from './indexedDB';

// Google Cloud Console > "Ominibase Forms Client" (Web application client)
const WEB_CLIENT_ID = '423726952026-2dehn302mj629g57fpqvd3v9svfull5p.apps.googleusercontent.com';
const WEB_SCOPE = 'https://www.googleapis.com/auth/drive.file';
const BACKUP_FOLDER_NAME = 'Ominibase CMS Backups';
const TOKEN_FUNCTION_URL = '/.netlify/functions/google-drive-token';

const LAST_BACKUP_KEY = 'driveLastAutoBackupDate';
// Fingerprint of the data as of the last successful backup — used to skip
// re-uploading when nothing has actually changed (point 5 of the request).
const LAST_BACKUP_HASH_KEY = 'driveLastBackupDataHash';
const DAILY_BACKUP_HOUR = 21; // 9 PM, 24-hour clock
// The web app's refresh token — same idea as the desktop app's token file,
// just stored in this browser instead. This is what makes the connection
// survive closing the tab/app, instead of needing to sign in every time.
const WEB_REFRESH_TOKEN_KEY = 'driveWebRefreshToken';

export interface DriveBackupFile {
  id: string;
  name: string;
  createdTime: string;
  size?: string;
}

export interface DriveResult<T = undefined> {
  success: boolean;
  error?: string;
  data?: T;
}

async function hashString(str: string): Promise<string> {
  try {
    if ((window as any).crypto?.subtle) {
      const enc = new TextEncoder().encode(str);
      const buf = await (window as any).crypto.subtle.digest('SHA-256', enc);
      return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('');
    }
  } catch {
    // fall through to the simple fallback below
  }
  // Fallback (no Web Crypto available) — good enough just to detect "changed vs not".
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) | 0;
  return String(h);
}

// ---------------------------------------------------------------------------
// Environment detection
// ---------------------------------------------------------------------------

function isElectron(): boolean {
  return !!(window as any).desktopApp?.isElectron;
}

function driveApi(): any {
  return (window as any).driveBackup;
}

// ---------------------------------------------------------------------------
// WEB flow — Authorization Code + PKCE via a popup, refresh token stored in
// this browser. The actual token exchange/refresh (which needs the client
// secret) happens in a Netlify function — see netlify/functions/google-drive-token.js
// — so the secret never ships to the browser.
// ---------------------------------------------------------------------------

let webAccessToken: string | null = null;
let webTokenExpiresAt = 0;

function base64url(bytes: Uint8Array): string {
  let str = '';
  bytes.forEach((b) => (str += String.fromCharCode(b)));
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function makePkcePair(): Promise<{ verifier: string; challenge: string }> {
  const verifierBytes = new Uint8Array(32);
  crypto.getRandomValues(verifierBytes);
  const verifier = base64url(verifierBytes);
  const digest = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier));
  const challenge = base64url(new Uint8Array(digest));
  return { verifier, challenge };
}

function callTokenFunction(body: Record<string, string>): Promise<any> {
  return fetch(TOKEN_FUNCTION_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  }).then(async (res) => {
    const json = await res.json();
    if (!res.ok) throw new Error(json.error || 'Google sign-in failed');
    return json;
  });
}

function openConsentPopupAndWaitForCode(challenge: string, redirectUri: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const authUrl =
      `https://accounts.google.com/o/oauth2/v2/auth?` +
      `client_id=${encodeURIComponent(WEB_CLIENT_ID)}` +
      `&redirect_uri=${encodeURIComponent(redirectUri)}` +
      `&response_type=code` +
      `&scope=${encodeURIComponent(WEB_SCOPE)}` +
      `&access_type=offline` +
      `&prompt=consent` +
      `&code_challenge=${challenge}` +
      `&code_challenge_method=S256`;

    const popup = window.open(authUrl, 'google-drive-connect', 'width=480,height=640');
    if (!popup) {
      reject(new Error('Popup was blocked — please allow popups for this site and try again.'));
      return;
    }

    let settled = false;
    const cleanup = () => {
      window.removeEventListener('message', onMessage);
      clearInterval(popupCheck);
    };

    const onMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      if (event.data?.type !== 'google-drive-oauth') return;
      settled = true;
      cleanup();
      if (event.data.error) reject(new Error(event.data.error));
      else if (!event.data.code) reject(new Error('No authorization code received'));
      else resolve(event.data.code);
    };
    window.addEventListener('message', onMessage);

    // If the user just closes the popup without finishing, don't hang forever.
    const popupCheck = setInterval(() => {
      if (popup.closed && !settled) {
        cleanup();
        reject(new Error('Sign-in window was closed before finishing'));
      }
    }, 500);
  });
}

async function getWebAccessToken(): Promise<string> {
  if (webAccessToken && Date.now() < webTokenExpiresAt) return webAccessToken;

  let refreshToken: string | null = null;
  try {
    refreshToken = localStorage.getItem(WEB_REFRESH_TOKEN_KEY);
  } catch {
    // ignore
  }
  if (!refreshToken) throw new Error('Not connected to Google Drive');

  const tokenResp = await callTokenFunction({ action: 'refresh', refreshToken });
  webAccessToken = tokenResp.access_token;
  webTokenExpiresAt = Date.now() + (tokenResp.expires_in - 60) * 1000;
  return webAccessToken!;
}

// ---------------------------------------------------------------------------
// WEB flow — Drive REST API (browser fetch)
// ---------------------------------------------------------------------------

async function webFindOrCreateFolder(token: string): Promise<string> {
  const q = encodeURIComponent(
    `name='${BACKUP_FOLDER_NAME}' and mimeType='application/vnd.google-apps.folder' and trashed=false`
  );
  const searchRes = await fetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id,name)`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const searchJson = await searchRes.json();
  if (searchJson.files?.length > 0) return searchJson.files[0].id;

  const createRes = await fetch('https://www.googleapis.com/drive/v3/files?fields=id', {
    method: 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: BACKUP_FOLDER_NAME, mimeType: 'application/vnd.google-apps.folder' }),
  });
  const createJson = await createRes.json();
  if (!createJson.id) throw new Error('Could not create backup folder on Drive');
  return createJson.id;
}

async function webUploadJson(token: string, folderId: string, fileName: string, jsonString: string) {
  const boundary = 'ominibase_backup_boundary';
  // If a backup file with this exact name already exists in the folder
  // (e.g. "Backup Now" was clicked twice today, or the 9 PM job runs on a
  // day something was already manually backed up), overwrite it instead of
  // creating a duplicate — one file per day, not several.
  const existingId = await webFindFileIdByName(token, folderId, fileName);

  // Google's Drive API rejects `parents` in an UPDATE (PATCH) request body —
  // it's only valid when CREATING a file. Include it only when creating.
  const metadata = existingId
    ? JSON.stringify({ name: fileName, mimeType: 'application/json' })
    : JSON.stringify({ name: fileName, parents: [folderId], mimeType: 'application/json' });
  const body =
    `--${boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n${metadata}\r\n` +
    `--${boundary}\r\nContent-Type: application/json\r\n\r\n${jsonString}\r\n` +
    `--${boundary}--`;

  const url = existingId
    ? `https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=multipart&fields=id,name,createdTime`
    : 'https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,createdTime';

  const res = await fetch(url, {
    method: existingId ? 'PATCH' : 'POST',
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': `multipart/related; boundary=${boundary}` },
    body,
  });
  const json = await res.json();
  if (!json.id) throw new Error(json.error?.message || 'Upload failed');
  return json;
}

async function webFindFileIdByName(token: string, folderId: string, fileName: string): Promise<string | null> {
  const q = encodeURIComponent(`name='${fileName}' and '${folderId}' in parents and trashed=false`);
  const res = await fetch(`https://www.googleapis.com/drive/v3/files?q=${q}&fields=files(id)`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const json = await res.json();
  return json.files?.[0]?.id || null;
}

async function webListFolderFiles(token: string, folderId: string): Promise<DriveBackupFile[]> {
  const q = encodeURIComponent(`'${folderId}' in parents and trashed=false`);
  const res = await fetch(
    `https://www.googleapis.com/drive/v3/files?q=${q}&orderBy=createdTime desc&fields=files(id,name,createdTime,size)`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  const json = await res.json();
  if (!json.files) throw new Error(json.error?.message || 'Could not list backups');
  return json.files;
}

async function webDownloadFile(token: string, fileId: string): Promise<string> {
  const res = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  if (!res.ok) throw new Error('Could not download backup file');
  return res.text();
}

// ---------------------------------------------------------------------------
// Public unified API
// ---------------------------------------------------------------------------

export async function connectDrive(): Promise<DriveResult> {
  try {
    if (isElectron()) {
      const result = await driveApi().connect();
      // A fresh connect should always be free to run its first backup,
      // even if this device previously backed up (possibly a different
      // Google account) and still remembers that data's hash.
      if (result.success) clearLastBackupTracking();
      return result;
    }

    const { verifier, challenge } = await makePkcePair();
    const redirectUri = `${window.location.origin}/callback`;
    const code = await openConsentPopupAndWaitForCode(challenge, redirectUri);
    const tokenResp = await callTokenFunction({ action: 'exchange', code, verifier, redirectUri });

    if (!tokenResp.refresh_token) {
      throw new Error(
        'Google did not return a refresh token. If you connected this account before, remove access at myaccount.google.com/permissions and try again.'
      );
    }

    webAccessToken = tokenResp.access_token;
    webTokenExpiresAt = Date.now() + (tokenResp.expires_in - 60) * 1000;
    try {
      localStorage.setItem(WEB_REFRESH_TOKEN_KEY, tokenResp.refresh_token);
    } catch {
      // ignore
    }
    clearLastBackupTracking();
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || String(err) };
  }
}

export async function getDriveStatus(): Promise<{ connected: boolean }> {
  if (isElectron()) {
    try {
      const status = await driveApi().status();
      return { connected: !!status.connected };
    } catch {
      return { connected: false };
    }
  }
  try {
    return { connected: !!localStorage.getItem(WEB_REFRESH_TOKEN_KEY) };
  } catch {
    return { connected: false };
  }
}

export async function disconnectDrive(): Promise<void> {
  clearLastBackupTracking();
  if (isElectron()) {
    await driveApi().disconnect();
    return;
  }
  webAccessToken = null;
  webTokenExpiresAt = 0;
  try {
    localStorage.removeItem(WEB_REFRESH_TOKEN_KEY);
  } catch {
    // ignore
  }
}

function buildBackupFileName(businessName: string): string {
  const safeName = (businessName || 'Ominibase').replace(/[^a-zA-Z0-9]/g, '_');
  const dateStr = new Date().toISOString().split('T')[0];
  return `${safeName}_Backup_${dateStr}.json`;
}

async function buildBackupJson(businessName: string, preloadedData?: any): Promise<string> {
  const allData = preloadedData || (await exportAllData());
  const exportData = {
    ...allData,
    exportDate: new Date().toISOString(),
    version: '2.0',
    source: (businessName || 'Ominibase') + ' POS',
    backupType: 'google-drive-auto',
  };
  return JSON.stringify(exportData, null, 2);
}

export async function backupNow(businessName: string): Promise<DriveResult<{ ran: boolean; skippedNoChange?: boolean; fileName?: string }>> {
  // Manual "Backup Now" now behaves the same as the scheduled check: it
  // looks at the DATA (not the date) — if nothing changed since the last
  // backup (morning's backup, say), it skips instead of writing a pointless
  // duplicate. If data DID change (even later the same day), it backs up.
  return checkAndRunScheduledBackup(businessName);
}

export async function listDriveBackups(): Promise<DriveResult<DriveBackupFile[]>> {
  try {
    if (isElectron()) {
      const result = await driveApi().listBackups();
      if (!result.success) return { success: false, error: result.error };
      return { success: true, data: result.files };
    }
    const token = await getWebAccessToken();
    const folderId = await webFindOrCreateFolder(token);
    const files = await webListFolderFiles(token, folderId);
    return { success: true, data: files };
  } catch (err: any) {
    return { success: false, error: err?.message || String(err) };
  }
}

export async function restoreDriveBackup(fileId: string): Promise<DriveResult> {
  try {
    let content: string;
    if (isElectron()) {
      const result = await driveApi().downloadBackup(fileId);
      if (!result.success) return { success: false, error: result.error };
      content = result.content;
    } else {
      const token = await getWebAccessToken();
      content = await webDownloadFile(token, fileId);
    }

    const data = JSON.parse(content);
    if (!data.students && !data.batches && !data.locations) {
      throw new Error('Backup file looks invalid or empty');
    }
    await importAllData(data);
    return { success: true };
  } catch (err: any) {
    return { success: false, error: err?.message || String(err) };
  }
}

// ---------------------------------------------------------------------------
// Daily 9 PM auto-backup
//
// Rules (as requested):
//  - Backup should happen once a day around 9 PM, only while data has
//    actually changed since the last backup (no pointless duplicate files).
//  - If the app wasn't open at 9 PM, the very next time it's opened, it
//    checks "did today's backup happen?" — if not, it runs one immediately.
//  - "Backup Now" (manual/emergency button) follows the SAME data-changed
//    rule, not the date — click it any time of day; if data changed since
//    the last backup (even later the same day, after a morning backup) it
//    uploads, otherwise it tells the user nothing has changed.
// ---------------------------------------------------------------------------

function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}

function readLocal(key: string): string | null {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeLocal(key: string, value: string) {
  try {
    localStorage.setItem(key, value);
  } catch {
    // ignore
  }
}

/** Forgets what we think the "last backup" was — used whenever the connected
 * Google account changes (fresh connect, or disconnect), since the previous
 * hash/date belonged to a possibly different account's backup history and
 * should never cause a real first backup on the new account to be skipped. */
function clearLastBackupTracking() {
  try {
    localStorage.removeItem(LAST_BACKUP_KEY);
    localStorage.removeItem(LAST_BACKUP_HASH_KEY);
  } catch {
    // ignore
  }
}

/** Runs (or skips) the backup right now, applying the "skip if unchanged" rule. */
export async function checkAndRunScheduledBackup(
  businessName: string
): Promise<DriveResult<{ ran: boolean; skippedNoChange?: boolean; fileName?: string }>> {
  const status = await getDriveStatus();
  if (!status.connected) return { success: false, error: 'Google Drive is not connected', data: { ran: false } };

  try {
    const allData = await exportAllData();
    // Hash only the actual DATA, not the exportDate timestamp (which is
    // always "now" and would otherwise make every check look "changed").
    const hash = await hashString(JSON.stringify(allData));
    const lastHash = readLocal(LAST_BACKUP_HASH_KEY);

    if (lastHash === hash) {
      // Belt-and-suspenders: even if our local hash says "unchanged", double
      // check Drive itself actually has a backup file. If it doesn't (fresh
      // account, or the file was deleted from Drive), a stale local hash
      // should never be allowed to skip the real first backup.
      const existing = await listDriveBackups();
      const driveHasNoBackups = existing.success && (existing.data?.length || 0) === 0;
      if (!driveHasNoBackups) {
        // Nothing changed since the last backup — don't re-upload, just mark
        // today as "checked" so we don't keep re-checking every few minutes.
        writeLocal(LAST_BACKUP_KEY, todayStr());
        return { success: true, data: { ran: false, skippedNoChange: true } };
      }
    }

    const fileName = buildBackupFileName(businessName);
    const jsonString = await buildBackupJson(businessName, allData);
    if (isElectron()) {
      const result = await driveApi().backup(fileName, jsonString);
      if (!result.success) return { success: false, error: result.error };
    } else {
      const token = await getWebAccessToken();
      const folderId = await webFindOrCreateFolder(token);
      await webUploadJson(token, folderId, fileName, jsonString);
    }

    writeLocal(LAST_BACKUP_KEY, todayStr());
    writeLocal(LAST_BACKUP_HASH_KEY, hash);
    return { success: true, data: { ran: true, fileName } };
  } catch (err: any) {
    return { success: false, error: err?.message || String(err) };
  }
}

function msUntilNextNinePM(): number {
  const now = new Date();
  const target = new Date();
  target.setHours(DAILY_BACKUP_HOUR, 0, 0, 0);
  if (target.getTime() <= now.getTime()) target.setDate(target.getDate() + 1);
  return target.getTime() - now.getTime();
}

/**
 * Call once when the app starts. Handles both cases:
 *  - App happens to be open at/after 9 PM and today isn't backed up yet → runs now.
 *  - A previous day was missed entirely (app wasn't opened at all) → catches up immediately.
 *  - Otherwise (before 9 PM today, nothing missed) → waits until 9 PM tonight, as long as the app stays open.
 *
 * Returns a cleanup function to clear the pending timers (call from a useEffect return).
 */
export function scheduleDailyDriveBackup(
  businessName: string,
  onRan?: (ran: boolean) => void
): () => void {
  let dayTimeout: ReturnType<typeof setTimeout> | null = null;
  let safetyInterval: ReturnType<typeof setInterval> | null = null;
  let cancelled = false;

  const runCheck = async () => {
    const result = await checkAndRunScheduledBackup(businessName);
    if (!cancelled && result.success) onRan?.(!!result.data?.ran);
  };

  const lastRun = readLocal(LAST_BACKUP_KEY);
  const today = todayStr();
  const nowPastNine = new Date().getHours() >= DAILY_BACKUP_HOUR;

  if (lastRun !== today) {
    // Either never backed up, or missed one or more earlier days, or it's
    // simply a new day and 9 PM already passed today — in every one of
    // these cases, catch up right away.
    if (nowPastNine || lastRun === null || lastRun < today) {
      runCheck();
    }
  }

  // Schedule the "on time" run for tonight's 9 PM (harmless if it already
  // ran above — checkAndRunScheduledBackup no-ops once today is done).
  dayTimeout = setTimeout(function scheduleNext() {
    runCheck();
    dayTimeout = setTimeout(scheduleNext, 24 * 60 * 60 * 1000);
  }, msUntilNextNinePM());

  // Safety net: if the computer was asleep or the timeout got throttled
  // (common for background browser tabs), re-check every 15 minutes too.
  safetyInterval = setInterval(runCheck, 15 * 60 * 1000);

  return () => {
    cancelled = true;
    if (dayTimeout) clearTimeout(dayTimeout);
    if (safetyInterval) clearInterval(safetyInterval);
  };
}
