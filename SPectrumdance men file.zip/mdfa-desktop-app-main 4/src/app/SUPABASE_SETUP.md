# Supabase Setup Guide for Mayuri Dance & Fitness Academy

## Overview
यह system अब Supabase के साथ integrated है। सभी data server पर store होता है और किसी भी device से access किया जा सकता है।

## Database Tables Required

आपको Supabase में निम्नलिखित tables create करने होंगे:

### 1. students
```sql
CREATE TABLE students (
  id TEXT PRIMARY KEY,
  regNo TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  gender TEXT,
  dob TEXT,
  mobile TEXT NOT NULL,
  alternateMobile TEXT,
  email TEXT,
  address TEXT,
  guardianName TEXT,
  guardianRelation TEXT,
  admissionDate TEXT,
  location TEXT,
  batchTime TEXT,
  category TEXT,
  learnedBefore TEXT,
  duration TEXT,
  durationType TEXT,
  expiryDate TEXT,
  totalAmount NUMERIC,
  paidAmount NUMERIC,
  dues NUMERIC,
  paymentMode TEXT,
  userId TEXT,
  password TEXT,
  status TEXT DEFAULT 'active',
  pushedDate TEXT,
  photo TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 2. payments
```sql
CREATE TABLE payments (
  id TEXT PRIMARY KEY,
  regNo TEXT NOT NULL,
  name TEXT NOT NULL,
  paymentDate TEXT,
  sessionDate TEXT,
  duration TEXT,
  durationType TEXT,
  sessionExpiryDate TEXT,
  totalAmount NUMERIC,
  paidAmount NUMERIC,
  dues NUMERIC,
  paymentMode TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 3. teachers
```sql
CREATE TABLE teachers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  category TEXT,
  mobile TEXT NOT NULL,
  email TEXT,
  address TEXT,
  joiningDate TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 4. batches
```sql
CREATE TABLE batches (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  time TEXT NOT NULL,
  category TEXT,
  location TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 5. locations
```sql
CREATE TABLE locations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT,
  city TEXT,
  totalStudents INTEGER DEFAULT 0,
  totalTeachers INTEGER DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);
```

### 6. admin_credentials
```sql
CREATE TABLE admin_credentials (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);
```

## Setup Steps

### 1. Supabase Project Setup
1. [Supabase](https://supabase.com) पर account बनाएं
2. New project create करें
3. Project URL और Anon Key copy करें

### 2. Environment Variables
आपके project में `.env` file में:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

### 3. Initial Data Sync
1. Admin panel में login करें
2. Settings → Supabase Sync tab पर जाएं
3. "Sync All To Supabase" button click करें
4. सभी localStorage data Supabase में upload हो जाएगा

## How It Works

### On App Load
- Automatically Supabase से data fetch होता है
- localStorage में sync हो जाता है
- Offline mode में भी काम करता है

### Data Flow
```
User Action → localStorage (immediate) → Supabase (background)
                      ↓
              Works Offline Too!
```

### Cross-Device Access
1. Desktop से data add करें
2. Mobile से same login credentials use करें
3. सभी data automatically show होगा!

## Features

✅ **Auto Sync**: App open करते ही data sync
✅ **Manual Sync**: Settings में manual sync options
✅ **Offline Support**: Internet नहीं होने पर भी काम करता है
✅ **Cross-Device**: किसी भी device से access करें
✅ **Data Safety**: Server और localStorage दोनों में safe

## Troubleshooting

### Data Not Syncing?
1. Internet connection check करें
2. Supabase credentials verify करें
3. Settings → Supabase Sync → "Sync From Supabase" try करें

### Old Data Showing?
1. Settings → Supabase Sync → "Sync From Supabase" click करें
2. Page refresh करें

## Support
किसी भी problem के लिए Supabase dashboard में logs check करें।
