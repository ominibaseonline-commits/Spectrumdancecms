import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { getSetting, saveSetting } from '../lib/indexedDB';

interface BusinessContextType {
  businessName: string;
  updateBusinessName: (name: string) => Promise<void>;
  businessLogo: string; // base64 data URL, or '' if none set
  updateBusinessLogo: (logoDataUrl: string) => Promise<void>;
  businessAddress: string;
  updateBusinessAddress: (address: string) => Promise<void>;
  businessPhone: string;
  updateBusinessPhone: (phone: string) => Promise<void>;
  isLoading: boolean;
}

const BusinessContext = createContext<BusinessContextType | undefined>(undefined);

export function BusinessProvider({ children }: { children: ReactNode }) {
  const [businessName, setBusinessName] = useState('Ominibase CMS');
  const [businessLogo, setBusinessLogo] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadBusinessInfo();
  }, []);

  const loadBusinessInfo = async () => {
    try {
      const name = await getSetting('businessName');
      if (name) setBusinessName(name);

      const logo = await getSetting('businessLogo');
      if (logo) setBusinessLogo(logo);

      const address = await getSetting('businessAddress');
      if (address) setBusinessAddress(address);

      const phone = await getSetting('businessPhone');
      if (phone) setBusinessPhone(phone);
    } catch (error) {
      console.error('Error loading business info:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const updateBusinessName = async (name: string) => {
    try {
      await saveSetting('businessName', name);
      setBusinessName(name);
    } catch (error) {
      console.error('Error updating business name:', error);
      throw error;
    }
  };

  const updateBusinessLogo = async (logoDataUrl: string) => {
    try {
      await saveSetting('businessLogo', logoDataUrl);
      setBusinessLogo(logoDataUrl);
    } catch (error) {
      console.error('Error updating business logo:', error);
      throw error;
    }
  };

  const updateBusinessAddress = async (address: string) => {
    try {
      await saveSetting('businessAddress', address);
      setBusinessAddress(address);
    } catch (error) {
      console.error('Error updating business address:', error);
      throw error;
    }
  };

  const updateBusinessPhone = async (phone: string) => {
    try {
      await saveSetting('businessPhone', phone);
      setBusinessPhone(phone);
    } catch (error) {
      console.error('Error updating business phone:', error);
      throw error;
    }
  };

  return (
    <BusinessContext.Provider
      value={{
        businessName,
        updateBusinessName,
        businessLogo,
        updateBusinessLogo,
        businessAddress,
        updateBusinessAddress,
        businessPhone,
        updateBusinessPhone,
        isLoading,
      }}
    >
      {children}
    </BusinessContext.Provider>
  );
}

export function useBusinessName() {
  const context = useContext(BusinessContext);
  if (context === undefined) {
    throw new Error('useBusinessName must be used within a BusinessProvider');
  }
  return context;
}
