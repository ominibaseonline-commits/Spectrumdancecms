import { createContext, useContext, useState, useMemo, ReactNode } from 'react';

// Global "active location" chosen by the admin from the Dashboard dropdown.
// 'all' = every location. Any other value = that location's name.
//
// It is intentionally kept in memory only (NOT saved to localStorage/IndexedDB):
// clicking "Reload App" reloads the window, which resets it back to 'all'.
interface LocationFilterContextType {
  selectedLocation: string;
  setSelectedLocation: (loc: string) => void;
  isAllLocations: boolean;
  // Returns true when the given location name should be visible right now.
  matchesLocation: (loc?: string | null) => boolean;
}

const LocationFilterContext = createContext<LocationFilterContextType | undefined>(undefined);

export function LocationFilterProvider({ children }: { children: ReactNode }) {
  const [selectedLocation, setSelectedLocation] = useState('all');

  const value = useMemo<LocationFilterContextType>(() => ({
    selectedLocation,
    setSelectedLocation,
    isAllLocations: selectedLocation === 'all',
    matchesLocation: (loc) => selectedLocation === 'all' || loc === selectedLocation,
  }), [selectedLocation]);

  return <LocationFilterContext.Provider value={value}>{children}</LocationFilterContext.Provider>;
}

export function useLocationFilter() {
  const ctx = useContext(LocationFilterContext);
  if (!ctx) throw new Error('useLocationFilter must be used within LocationFilterProvider');
  return ctx;
}
