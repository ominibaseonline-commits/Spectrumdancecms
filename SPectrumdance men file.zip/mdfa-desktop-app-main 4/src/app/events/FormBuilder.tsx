import { useEffect, useMemo, useRef, useState } from 'react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Switch } from '../components/ui/switch';
import {
  ArrowUp, ArrowDown, Trash2, Plus, RotateCcw, Archive, Copy, GripVertical, Search, MousePointerClick, X,
  Type, AlignLeft, Hash, IndianRupee, Mail, Phone, CalendarDays, CalendarClock, ChevronDown, CircleDot, CheckSquare, Clock, ListChecks, ToggleLeft,
} from 'lucide-react';
import type { EventField, FieldType } from './lib/eventsDb';
import { mkField, newFieldKey, safeColor, DEFAULT_THEME, titleFontCss, validBg, isDarkColor } from './lib/eventTemplates';

// ---------- field catalogue ----------
interface TypeMeta { value: FieldType; label: string; icon: any; group: 'basic' | 'special'; defaultLabel: string; hint: string }
const TYPES: TypeMeta[] = [
  { value: 'text', label: 'Text', icon: Type, group: 'basic', defaultLabel: 'Text Question', hint: 'Chhota jawab (naam, school...)' },
  { value: 'textarea', label: 'Text Area', icon: AlignLeft, group: 'basic', defaultLabel: 'Details', hint: 'Lamba jawab / comment' },
  { value: 'number', label: 'Number', icon: Hash, group: 'basic', defaultLabel: 'Number', hint: 'Sirf ank (age, members)' },
  { value: 'phone', label: 'Phone', icon: Phone, group: 'basic', defaultLabel: 'Phone Number', hint: 'Mobile number (10 digit check)' },
  { value: 'email', label: 'Email', icon: Mail, group: 'basic', defaultLabel: 'Email', hint: 'Email (format check hota hai)' },
  { value: 'dropdown', label: 'Dropdown', icon: ChevronDown, group: 'basic', defaultLabel: 'Select Option', hint: 'List me se ek chunna' },
  { value: 'radio', label: 'Radio', icon: CircleDot, group: 'basic', defaultLabel: 'Choose One', hint: 'Option dikhte hain, ek chunna' },
  { value: 'checkbox', label: 'Checkbox', icon: CheckSquare, group: 'basic', defaultLabel: 'Choose Many', hint: 'Ek se zyada option chun sakte hain' },
  { value: 'date', label: 'Date', icon: CalendarDays, group: 'basic', defaultLabel: 'Date', hint: 'Sirf tarikh' },
  { value: 'time', label: 'Time', icon: Clock, group: 'basic', defaultLabel: 'Batch Time', hint: 'Sirf samay (jaise 7:00 AM)' },
  { value: 'multiselect', label: 'Multi-Select Dropdown', icon: ListChecks, group: 'basic', defaultLabel: 'Select Multiple', hint: 'Dropdown se ek se zyada option chunna' },
  { value: 'yesno', label: 'Yes / No Toggle', icon: ToggleLeft, group: 'basic', defaultLabel: 'Do you have experience?', hint: 'Ek click me Yes ya No' },
  { value: 'amount', label: 'Amount (\u20B9)', icon: IndianRupee, group: 'special', defaultLabel: 'Amount', hint: 'Rupees me raashi, \u20B9 symbol ke saath' },
  { value: 'datetime', label: 'Date & Time', icon: CalendarClock, group: 'special', defaultLabel: 'Date & Time', hint: 'Tarikh aur samay dono' },
];
const META = Object.fromEntries(TYPES.map(t => [t.value, t])) as Record<FieldType, TypeMeta>;

// kept exported - other files import these
export const FIELD_TYPES: { value: FieldType; label: string }[] = TYPES.map(({ value, label }) => ({ value, label }));
export const selectCls = 'h-9 w-full rounded-md border border-input bg-white px-2 text-sm';

const hasOptions = (t: FieldType) => t === 'dropdown' || t === 'radio' || t === 'checkbox' || t === 'multiselect';
const defaultOptions = () => ['Option 1', 'Option 2'];

interface Props {
  fields: EventField[];
  onChange: (f: EventField[]) => void;
  /** Keys of fields that already have stored submissions. Removing these ARCHIVES them (data is kept). */
  lockedKeys?: Set<string>;
  /** Shown at the top of the live preview. */
  title?: string;
  subtitle?: string;
  /** Theme colour used for the preview's submit button / highlights. */
  color?: string;
  /** Event name ka style (font / bold / alignment) aur poore form ka background - live preview me dikhta hai. */
  titleStyle?: { font?: string; bold?: boolean; align?: 'left' | 'center' | 'right' };
  bgColor?: string;
}

// ---------- read-only preview of one field ----------
function PreviewInput({ f }: { f: EventField }) {
  const base = 'w-full h-10 rounded-md border bg-white px-3 text-sm text-gray-500 flex items-center';
  const ph = f.placeholder || '';
  switch (f.type) {
    case 'textarea': return <div className={base + ' h-20 items-start pt-2'}>{ph}</div>;
    case 'amount': return <div className={base}><span className="mr-2 font-semibold text-gray-700">{'\u20B9'}</span>{ph || '0'}</div>;
    case 'date': return <div className={base + ' justify-between'}>{ph || 'DD-MM-YYYY'}<CalendarDays className="w-4 h-4" /></div>;
    case 'datetime': return <div className={base + ' justify-between'}>{ph || 'DD-MM-YYYY, HH:MM'}<CalendarClock className="w-4 h-4" /></div>;
    case 'time': return <div className={base + ' justify-between'}>{ph || 'HH:MM AM/PM'}<Clock className="w-4 h-4" /></div>;
    case 'dropdown': return <div className={base + ' justify-between'}>{ph || 'Select...'}<ChevronDown className="w-4 h-4" /></div>;
    case 'multiselect': return <div className={base + ' justify-between'}>{ph || 'Select one or more...'}<ChevronDown className="w-4 h-4" /></div>;
    case 'yesno': return (
      <div className="flex items-center gap-2 py-1">
        <span className="inline-flex w-11 h-6 rounded-full bg-gray-300 p-0.5"><span className="w-5 h-5 rounded-full bg-white shadow" /></span>
        <span className="text-sm font-semibold opacity-80">No</span>
      </div>);
    case 'radio':
    case 'checkbox':
      return (
        <div className="flex flex-wrap gap-x-5 gap-y-1.5 py-1">
          {(f.options || []).map((o, i) => (
            <span key={i} className="flex items-center gap-1.5 text-sm opacity-80">
              <span className={`inline-block w-4 h-4 border-2 border-gray-400 ${f.type === 'radio' ? 'rounded-full' : 'rounded-sm'}`} />{o}
            </span>))}
        </div>);
    default: return <div className={base}>{ph || (f.type === 'phone' ? '10 digit mobile number' : f.type === 'email' ? 'name@example.com' : '')}</div>;
  }
}

// Left: add fields | Centre: live preview (click to select, drag / arrows to reorder) | Right: field settings.
// A field with existing submissions is never erased - it is archived (column hidden, data kept)
// and can be restored from the "Archived fields" list.
export function FormBuilder({ fields, onChange, lockedKeys, title, subtitle, color, titleStyle, bgColor }: Props) {
  const live = useMemo(() => fields.filter(f => !f.archived).sort((a, b) => a.order - b.order), [fields]);
  const archived = fields.filter(f => f.archived);
  const accent = safeColor(color || DEFAULT_THEME);
  const bg = validBg(bgColor);
  const dark = isDarkColor(bg);

  const [selected, setSelected] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const [overIdx, setOverIdx] = useState<number | null>(null);
  const cardRefs = useRef<Record<string, HTMLDivElement | null>>({});

  // keep the selection valid (e.g. when a template / edit loads different fields)
  useEffect(() => {
    if (selected && !live.some(f => f.key === selected)) setSelected(null);
  }, [live, selected]);

  const sel = live.find(f => f.key === selected) || null;
  const selIdx = sel ? live.findIndex(f => f.key === sel.key) : -1;
  const isLocked = (k: string) => !!lockedKeys?.has(k);

  const commit = (liveList: EventField[]) => onChange([...liveList.map((f, i) => ({ ...f, order: i })), ...archived]);
  const patch = (key: string, p: Partial<EventField>) => commit(live.map(f => (f.key === key ? { ...f, ...p } : f)));
  const move = (i: number, d: number) => {
    const j = i + d; if (j < 0 || j >= live.length) return;
    const a = [...live]; [a[i], a[j]] = [a[j], a[i]]; commit(a);
  };
  const reorder = (from: number, to: number) => {
    if (from === to || from < 0 || to < 0 || to >= live.length) return;
    const a = [...live]; const [m] = a.splice(from, 1); a.splice(to, 0, m); commit(a);
  };
  const remove = (f: EventField) => {
    if (isLocked(f.key)) onChange([...live.filter(x => x.key !== f.key).map((x, i) => ({ ...x, order: i })), ...archived, { ...f, archived: true }]);
    else commit(live.filter(x => x.key !== f.key));
    setSelected(null);
  };
  const restore = (f: EventField) =>
    onChange([...live, { ...f, archived: false, order: live.length }, ...archived.filter(x => x.key !== f.key)].map((x, i) => (x.archived ? x : { ...x, order: i })));

  const add = (t: FieldType) => {
    const m = META[t];
    const nf = mkField(m.defaultLabel, t, false, hasOptions(t) ? defaultOptions() : undefined);
    // insert right after the selected field, else at the end
    const at = selIdx >= 0 ? selIdx + 1 : live.length;
    const a = [...live]; a.splice(at, 0, nf); commit(a);
    setSelected(nf.key);
  };
  const duplicate = (f: EventField, i: number) => {
    const copy: EventField = { ...f, key: newFieldKey(), label: `${f.label} (copy)`, options: f.options ? [...f.options] : undefined };
    const a = [...live]; a.splice(i + 1, 0, copy); commit(a); setSelected(copy.key);
  };
  const changeType = (f: EventField, t: FieldType) =>
    patch(f.key, { type: t, required: t === 'yesno' ? false : f.required, options: hasOptions(t) ? (f.options?.length ? f.options : defaultOptions()) : undefined });

  // scroll the selected card into view (after "Add")
  useEffect(() => {
    if (selected) cardRefs.current[selected]?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [selected]);

  const q = search.trim().toLowerCase();
  const visibleTypes = TYPES.filter(t => !q || t.label.toLowerCase().includes(q) || t.hint.toLowerCase().includes(q));
  const group = (g: 'basic' | 'special') => visibleTypes.filter(t => t.group === g);

  const TypeBtn = ({ t }: { t: TypeMeta }) => {
    const Icon = t.icon;
    return (
      <button type="button" onClick={() => add(t.value)} title={t.hint}
        className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm text-left hover:bg-gray-100 active:bg-gray-200 transition-colors group">
        <Icon className="w-4 h-4 text-gray-600 shrink-0" />
        <span className="flex-1">{t.label}</span>
        <Plus className="w-4 h-4 text-gray-400 group-hover:text-gray-900" />
      </button>
    );
  };

  return (
    <div className="rounded-2xl bg-gray-100 p-3 grid gap-3 lg:grid-cols-[230px_minmax(0,1fr)_290px] items-start">
      {/* ================= LEFT: add fields ================= */}
      <div className="rounded-xl bg-white p-3 lg:sticky lg:top-3 max-h-[80vh] overflow-y-auto">
        <div className="text-sm font-semibold mb-2">Add Fields</div>
        <div className="relative mb-3">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search fields"
            className="w-full h-9 rounded-lg bg-gray-100 pl-9 pr-3 text-sm outline-none focus:ring-2 focus:ring-gray-300" />
        </div>
        {group('basic').length > 0 && <div className="text-xs uppercase tracking-wide text-gray-400 px-3 mb-1">Basic Fields</div>}
        {group('basic').map(t => <TypeBtn key={t.value} t={t} />)}
        {group('special').length > 0 && <div className="text-xs uppercase tracking-wide text-gray-400 px-3 mt-3 mb-1">Special Fields</div>}
        {group('special').map(t => <TypeBtn key={t.value} t={t} />)}
        {visibleTypes.length === 0 && <p className="text-xs text-gray-500 px-3">Koi field nahi mila.</p>}
        <p className="text-[11px] text-gray-400 mt-3 px-3 leading-snug">Field par click karte hi wo form me jud jata hai. Kisi field ko select karke uske neeche naya field jodein.</p>
      </div>

      {/* ================= CENTRE: live preview ================= */}
      <div className="rounded-xl bg-white p-4 min-w-0" style={bg ? { background: bg, color: dark ? '#f9fafb' : undefined } : undefined}>
        <div className="mb-3" style={{ textAlign: titleStyle?.align || 'left' }}>
          <div className="text-lg" style={{ color: dark ? '#ffffff' : accent, fontFamily: titleFontCss(titleStyle?.font), fontWeight: titleStyle?.bold === false ? 400 : 700 }}>{title || 'Registration Form'}</div>
          <div className="text-xs opacity-60">{subtitle || 'Live preview - isi tarah students ko form dikhega'}</div>
        </div>

        {live.length === 0 && (
          <div className="border-2 border-dashed rounded-xl py-12 text-center text-sm text-gray-500">
            <MousePointerClick className="w-6 h-6 mx-auto mb-2 text-gray-400" />
            Abhi koi field nahi hai.<br />Left side se koi field chunein.
          </div>
        )}

        <div className="space-y-2">
          {live.map((f, i) => {
            const isSel = f.key === selected;
            const Icon = META[f.type]?.icon || Type;
            return (
              <div key={f.key} ref={el => { cardRefs.current[f.key] = el; }}
                draggable onDragStart={() => setDragIdx(i)} onDragEnd={() => { setDragIdx(null); setOverIdx(null); }}
                onDragOver={e => { e.preventDefault(); setOverIdx(i); }}
                onDrop={e => { e.preventDefault(); if (dragIdx !== null) reorder(dragIdx, i); setDragIdx(null); setOverIdx(null); }}
                onClick={() => setSelected(f.key)}
                className={`rounded-xl border-2 p-3 cursor-pointer transition-colors ${bg ? 'bg-transparent' : 'bg-white'} ${isSel ? (dark ? 'border-white shadow-sm' : 'border-gray-900 shadow-sm') : 'border-transparent hover:border-gray-300'} ${overIdx === i && dragIdx !== null && dragIdx !== i ? 'ring-2 ring-blue-400' : ''} ${dragIdx === i ? 'opacity-50' : ''}`}>
                <div className="flex items-start gap-2">
                  <GripVertical className="w-4 h-4 mt-0.5 text-gray-400 shrink-0 cursor-grab" />
                  <div className="flex-1 min-w-0 space-y-1.5">
                    <div className="text-sm font-medium">{f.label || <span className="text-gray-400">(label likhein)</span>}{f.required && <span className="text-red-600"> *</span>}</div>
                    {f.helpText && <div className="text-xs opacity-60">{f.helpText}</div>}
                    <PreviewInput f={f} />
                  </div>
                </div>

                {isSel && (
                  <div className="flex items-center justify-between mt-2 pl-6" onClick={e => e.stopPropagation()}>
                    <span className="inline-flex items-center gap-1 rounded-md bg-gray-700 text-white text-xs px-2 py-1"><Icon className="w-3 h-3" />{META[f.type]?.label}</span>
                    <div className="flex items-center gap-0.5">
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" title="Upar le jaayein" disabled={i === 0} onClick={() => move(i, -1)}><ArrowUp className="w-4 h-4" /></Button>
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" title="Neeche le jaayein" disabled={i === live.length - 1} onClick={() => move(i, 1)}><ArrowDown className="w-4 h-4" /></Button>
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" title="Duplicate" onClick={() => duplicate(f, i)}><Copy className="w-4 h-4" /></Button>
                      <Button type="button" variant="ghost" size="icon" className="h-8 w-8" title={isLocked(f.key) ? 'Archive (data safe rahega)' : 'Delete'} onClick={() => remove(f)}>
                        {isLocked(f.key) ? <Archive className="w-4 h-4 text-orange-600" /> : <Trash2 className="w-4 h-4 text-red-600" />}
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {live.length > 0 && (
          <div className="mt-4 rounded-lg h-11 flex items-center justify-center text-white text-sm font-semibold select-none" style={{ background: accent }}>Submit</div>
        )}

        {archived.length > 0 && (
          <div className="border border-dashed rounded-lg p-3 bg-gray-50 mt-4">
            <p className="text-sm font-medium mb-2">Archived fields (column hidden, purana data safe hai)</p>
            {archived.map(f => (
              <div key={f.key} className="flex items-center justify-between text-sm py-1">
                <span>{f.label || '(no label)'} <span className="text-gray-400">- {META[f.type]?.label || f.type}</span></span>
                <Button type="button" size="sm" variant="outline" onClick={() => restore(f)}><RotateCcw className="w-3 h-3 mr-1" /> Restore</Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ================= RIGHT: field settings ================= */}
      <div className="rounded-xl bg-white p-4 lg:sticky lg:top-3 max-h-[80vh] overflow-y-auto">
        {!sel ? (
          <div className="text-center text-sm text-gray-500 py-10">
            <MousePointerClick className="w-6 h-6 mx-auto mb-2 text-gray-400" />
            Preview me kisi field par click karein,<br />uski settings yahan dikhengi.
          </div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 font-semibold">
                {(() => { const I = META[sel.type]?.icon || Type; return <I className="w-4 h-4" />; })()} Field Settings
              </div>
              <Button type="button" variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelected(null)}><X className="w-4 h-4" /></Button>
            </div>

            <div>
              <label className="text-xs text-gray-500">Label (sawaal)</label>
              <Input value={sel.label} placeholder="e.g. Full Name" onChange={e => patch(sel.key, { label: e.target.value })} />
            </div>

            {!hasOptions(sel.type) && (
              <div>
                <label className="text-xs text-gray-500">Placeholder</label>
                <Input value={sel.placeholder || ''} placeholder="Input ke andar halka hint" onChange={e => patch(sel.key, { placeholder: e.target.value })} />
              </div>
            )}

            <div>
              <label className="text-xs text-gray-500">Help text (optional)</label>
              <Input value={sel.helpText || ''} placeholder="Label ke neeche chhoti line" onChange={e => patch(sel.key, { helpText: e.target.value })} />
            </div>

            {sel.type !== 'yesno' && (
              <div className="flex items-center justify-between">
                <label className="text-sm">Required (zaroori)</label>
                <Switch checked={sel.required} onCheckedChange={v => patch(sel.key, { required: v })} />
              </div>)}

            <div>
              <label className="text-xs text-gray-500">Field type</label>
              <select className={selectCls} value={sel.type} disabled={isLocked(sel.key)} onChange={e => changeType(sel, e.target.value as FieldType)}>
                {TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
              </select>
              {isLocked(sel.key)
                ? <p className="text-[11px] text-orange-700 mt-1">Is field ka data aa chuka hai, isliye type nahi badal sakte.</p>
                : <p className="text-[11px] text-gray-400 mt-1">{META[sel.type]?.hint}</p>}
            </div>

            {hasOptions(sel.type) && (
              <div>
                <label className="text-xs text-gray-500">Options</label>
                <div className="space-y-1.5 mt-1">
                  {(sel.options || []).map((o, oi) => (
                    <div key={oi} className="flex gap-1.5">
                      <Input value={o} onChange={e => patch(sel.key, { options: (sel.options || []).map((x, k) => (k === oi ? e.target.value : x)) })} />
                      <Button type="button" variant="ghost" size="icon" className="h-9 w-9 shrink-0" disabled={(sel.options || []).length <= 1}
                        onClick={() => patch(sel.key, { options: (sel.options || []).filter((_, k) => k !== oi) })}><X className="w-4 h-4" /></Button>
                    </div>
                  ))}
                  <Button type="button" variant="outline" size="sm" onClick={() => patch(sel.key, { options: [...(sel.options || []), `Option ${(sel.options || []).length + 1}`] })}>
                    <Plus className="w-3 h-3 mr-1" /> Add option
                  </Button>
                </div>
              </div>
            )}

            <Button type="button" variant="outline" className="w-full text-red-600" onClick={() => remove(sel)}>
              {isLocked(sel.key) ? <><Archive className="w-4 h-4 mr-2" /> Archive field</> : <><Trash2 className="w-4 h-4 mr-2" /> Delete field</>}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
