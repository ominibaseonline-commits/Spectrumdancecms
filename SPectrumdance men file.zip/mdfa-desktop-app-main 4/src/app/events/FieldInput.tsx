import { Input } from '../components/ui/input';
import { Switch } from '../components/ui/switch';
import { selectCls } from './FormBuilder';
import type { EventField } from './lib/eventsDb';

// One input for any field type (used by Manual Add / Edit of a submission).
export function FieldInput({ f, value, onChange }: { f: EventField; value: any; onChange: (v: any) => void }) {
  if (f.type === 'dropdown')
    return <select className={selectCls} value={value || ''} onChange={e => onChange(e.target.value)}>
      <option value="">Select...</option>{(f.options || []).map(o => <option key={o}>{o}</option>)}</select>;
  if (f.type === 'radio')
    return <div className="flex flex-wrap gap-4">{(f.options || []).map(o => (
      <label key={o} className="flex items-center gap-1 text-sm"><input type="radio" name={f.key} checked={value === o} onChange={() => onChange(o)} /> {o}</label>))}</div>;
  if (f.type === 'yesno')
    return <div className="flex items-center gap-2"><Switch checked={value === 'Yes'} onCheckedChange={v => onChange(v ? 'Yes' : 'No')} />
      <span className="text-sm font-semibold">{value === 'Yes' ? 'Yes' : 'No'}</span></div>;
  if (f.type === 'checkbox' || f.type === 'multiselect') {
    const arr: string[] = Array.isArray(value) ? value : [];
    return <div className="flex flex-wrap gap-4">{(f.options || []).map(o => (
      <label key={o} className="flex items-center gap-1 text-sm"><input type="checkbox" checked={arr.includes(o)}
        onChange={e => onChange(e.target.checked ? [...arr, o] : arr.filter(x => x !== o))} /> {o}</label>))}</div>;
  }
  if (f.type === 'textarea')
    return <textarea className={selectCls + ' h-20 py-2'} placeholder={f.placeholder} value={value || ''} onChange={e => onChange(e.target.value)} />;
  if (f.type === 'amount')
    return <div className="relative"><span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">{'\u20B9'}</span>
      <Input className="pl-7" type="number" min="0" placeholder={f.placeholder} value={value || ''} onChange={e => onChange(e.target.value)} /></div>;
  const type = ({ number: 'number', email: 'email', phone: 'tel', date: 'date', time: 'time', datetime: 'datetime-local' } as any)[f.type] || 'text';
  return <Input type={type} placeholder={f.placeholder} value={value || ''} onChange={e => onChange(e.target.value)} />;
}
