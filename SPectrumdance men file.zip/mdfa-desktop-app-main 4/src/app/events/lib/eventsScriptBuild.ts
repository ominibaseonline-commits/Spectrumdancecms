// Builds the Events part of the (single) Google Apps Script - same as QR Enquiry / Online Admission / Review.
// attendance.ts appends this to the attendance script, so the admin pastes ONE script only
// (Settings -> Management & Setup -> Attendance Setup -> Copy Code).
import eventsScript from './eventsScript.gs?raw';
import eventPageHtml from './eventFormPage.html?raw';
import qrSource from '../../lib/qrcodeGenerator.js?raw';

/** The vendored QR generator is an ES module; turn it into a plain script usable inside the form page. */
function qrForBrowser(): string {
  return qrSource
    .replace(/export const qrcode =/, 'var qrcode =')
    .replace(/export default qrcode;/, '')
    .replace(/export const stringToBytes = [^\n]*;/, '');
}

export function buildEventsScriptPart(): string {
  const html = eventPageHtml.replace('__QR_JS__', () => qrForBrowser());
  return eventsScript.replace('__EVT_HTML__', () => JSON.stringify(html));
}
