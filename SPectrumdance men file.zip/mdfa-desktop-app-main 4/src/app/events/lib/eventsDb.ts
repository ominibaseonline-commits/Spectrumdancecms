// Events module - data layer.
// ISOLATION RULE: only this module reads/writes the event_* IndexedDB stores.
// Nothing here touches students/payments/etc., and no other section imports this file
// (except the one-line Settings toggle + sidebar visibility check).
import { initDB, getSetting, saveSetting } from '../../lib/indexedDB';

// ---------- Types ----------
export type FieldType = 'text' | 'textarea' | 'number' | 'amount' | 'email' | 'phone' | 'date' | 'datetime' | 'dropdown' | 'radio' | 'checkbox' | 'time' | 'multiselect' | 'yesno';

export interface EventField {
  key: string;          // stable id used as the JSON key in submissions
  label: string;
  type: FieldType;
  required: boolean;
  options?: string[];   // dropdown / radio / checkbox / multiselect
  placeholder?: string; // grey hint inside the input
  helpText?: string;    // small line under the label
  order: number;
  archived?: boolean;   // deleted-after-submissions fields are hidden, never erased
}

export interface EventRecord {
  id: string;
  name: string;
  date: string;
  venue: string;
  description: string;
  fee: number;                    // 0 = free
  maxRegistrations?: number;      // optional cap
  formFields: EventField[];
  externalFormUrl?: string;       // external Google Form (data NOT stored here)
  themeColor?: string;            // public form + PDF colour, e.g. '#ea580c'
  titleFont?: string;             // event name font key (see TITLE_FONTS)
  titleBold?: boolean;            // event name bold (default true)
  titleAlign?: 'left' | 'center' | 'right'; // event name alignment (default left)
  bgColor?: string;               // whole form background colour (default: theme tint / white)
  status: 'open' | 'closed';
  deletedAt?: number | null;      // soft delete
  createdAt: number;
  updatedAt: number;
}

export interface EventSubmission {
  id: string;
  event_id: string;
  data: Record<string, any>;      // keyed by EventField.key
  source: 'online' | 'offline';
  payment_status: 'paid' | 'unpaid';
  registration_id: string;
  created_at: number;
  remoteId?: string;              // row id in the relay Google Sheet (dedupe on re-sync)
  deletedAt?: number | null;
}

export interface EventTemplate {
  id: string;
  name: string;
  builtIn?: boolean;
  fields: EventField[];
  createdAt: number;
}

const S = {
  events: 'event_events',
  templates: 'event_templates',
  submissions: 'event_submissions',
} as const;

// ---------- Tiny helpers (kept private so the module is self-contained) ----------
const tx = async (store: string, mode: IDBTransactionMode) => (await initDB()).transaction([store], mode).objectStore(store);
const wrap = <T,>(req: IDBRequest<T>) =>
  new Promise<T>((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });

const put = async (store: string, v: any) => { await wrap(await tx(store, 'readwrite').then(s => s.put(v))); };
const del = async (store: string, id: string) => { await wrap(await tx(store, 'readwrite').then(s => s.delete(id))); };
const all = async <T,>(store: string): Promise<T[]> => wrap(await tx(store, 'readonly').then(s => s.getAll())) as Promise<T[]>;
const byEvent = async <T,>(store: string, eventId: string): Promise<T[]> =>
  wrap(await tx(store, 'readonly').then(s => s.index('event_id').getAll(eventId))) as Promise<T[]>;

export const newId = (prefix: string) =>
  `${prefix}_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;

// ---------- Settings toggle (Settings -> "Event Forms") ----------
// OFF only hides the Events section + disables public links. It NEVER deletes data.
const TOGGLE_KEY = 'eventFormsEnabled';
export const EVENT_FORMS_TOGGLED = 'eventFormsToggled'; // Settings toggle ON / OFF hua
export const EVENTS_CHANGED = 'eventsChanged';           // event / offline entry badli -> Google Sheet ko update bhejna hai
const changed = () => window.dispatchEvent(new CustomEvent(EVENTS_CHANGED));
export const getEventFormsEnabled = async () => (await getSetting(TOGGLE_KEY)) === true;
export const saveEventFormsEnabled = async (on: boolean) => {
  await saveSetting(TOGGLE_KEY, on);
  window.dispatchEvent(new CustomEvent(EVENT_FORMS_TOGGLED, { detail: on }));
};

// ---------- Events ----------
export const listEvents = async (includeDeleted = false) =>
  (await all<EventRecord>(S.events)).filter(e => includeDeleted || !e.deletedAt).sort((a, b) => b.createdAt - a.createdAt);
export const listDeletedEvents = async () => (await all<EventRecord>(S.events)).filter(e => !!e.deletedAt);
export const saveEvent = async (e: EventRecord) => { await put(S.events, { ...e, updatedAt: Date.now() }); changed(); };
export const softDeleteEvent = async (e: EventRecord) => saveEvent({ ...e, deletedAt: Date.now() });
export const restoreEvent = async (e: EventRecord) => saveEvent({ ...e, deletedAt: null });

/** Permanently removes ONE event and only its own submissions. */
export const purgeEvent = async (eventId: string) => {
  for (const s of await byEvent<EventSubmission>(S.submissions, eventId)) await del(S.submissions, s.id);
  await del(S.events, eventId);
  changed();
};

// ---------- Submissions ----------
export const listSubmissions = async (eventId: string, includeDeleted = false) =>
  (await byEvent<EventSubmission>(S.submissions, eventId))
    .filter(s => includeDeleted || !s.deletedAt)
    .sort((a, b) => a.created_at - b.created_at);
export const listDeletedSubmissions = async () => (await all<EventSubmission>(S.submissions)).filter(s => !!s.deletedAt);
export const saveSubmission = async (s: EventSubmission) => { await put(S.submissions, s); if (s.source === 'offline') changed(); };
export const softDeleteSubmission = (s: EventSubmission) => saveSubmission({ ...s, deletedAt: Date.now() });
export const restoreSubmission = (s: EventSubmission) => saveSubmission({ ...s, deletedAt: null });
export const purgeSubmission = async (id: string) => { await del(S.submissions, id); changed(); };
/** Used by the sync to avoid saving the same Google-Sheet row twice. */
export const getAllRemoteIds = async () =>
  new Set((await all<EventSubmission>(S.submissions)).map(s => s.remoteId).filter(Boolean) as string[]);

// ---------- Templates ----------
export const listTemplates = () => all<EventTemplate>(S.templates);
export const saveTemplate = (t: EventTemplate) => put(S.templates, t);
export const deleteTemplate = (id: string) => del(S.templates, id);

// ---------- Separate backup of ALL events data (Events -> "Export all events data") ----------
export const exportAllEventsData = async () => ({
  exportedAt: new Date().toISOString(),
  module: 'events',
  events: await all(S.events),
  templates: await all(S.templates),
  submissions: await all(S.submissions),
});
