// Events PDFs - built as HTML and printed with the app's existing Electron "printToPDF" (works offline,
// renders Hindi/Unicode and the rupee symbol natively). Browser fallback: opens a print window.
//   recordPdf      - ONE event: info, totals and every registration (landscape, repeating header)
//   allEventsPdf   - ALL events in one PDF: overview table + one section per event
//   blankFormPdf   - printable empty form built from the event's CURRENT fields (always in sync)
import type { EventRecord, EventSubmission, EventField } from './eventsDb';
import { safeColor, titleFontCss } from './eventTemplates';

const esc = (v: any) => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c] as string));
const visible = (ev: EventRecord): EventField[] => ev.formFields.filter(f => !f.archived).sort((a, b) => a.order - b.order);
const fmtDate = (d: string) => { const p = (d || '').split('-'); return p.length === 3 ? `${p[2]}-${p[1]}-${p[0]}` : d || ''; };
export const cellValue = (v: any) => (Array.isArray(v) ? v.join(', ') : v ?? '');
/** '07:30' -> '07:30 AM' (agar format alag ho to jaisa hai waisa) */
export const fmtTime12 = (v: any) => {
  const m = /^(\d{1,2}):(\d{2})/.exec(String(v ?? ''));
  if (!m) return String(v ?? '');
  const h = Number(m[1]); return `${String(h % 12 || 12).padStart(2, '0')}:${m[2]} ${h >= 12 ? 'PM' : 'AM'}`;
};
const safeName = (s: string) => s.replace(/[\\/:*?"<>|]/g, '_').slice(0, 80);
const rupee = (n: number) => `\u20B9${n.toLocaleString('en-IN')}`;

const FONT = `font-family:-apple-system,'Segoe UI','Noto Sans Devanagari','Nirmala UI','Mangal',Arial,sans-serif;`;

async function savePdf(html: string, fileName: string, landscape: boolean) {
  const app = (window as any).desktopApp;
  if (app?.isElectron && app?.printToPDF) {
    const r = await app.printToPDF(html, safeName(fileName), { landscape });
    if (!r?.success && !r?.canceled) throw new Error(r?.error || 'PDF nahi bana');
    return;
  }
  const w = window.open('', '_blank');
  if (!w) throw new Error('Pop-up blocked');
  w.document.write(html); w.document.close(); w.focus(); setTimeout(() => w.print(), 400);
}

const totals = (ev: EventRecord, subs: EventSubmission[]) => {
  const paid = subs.filter(s => s.payment_status === 'paid').length;
  return { total: subs.length, paid, expected: ev.fee * subs.length, collected: ev.fee * paid, pending: ev.fee * (subs.length - paid) };
};

// ---------- shared pieces (Record PDF + All Events PDF) ----------
const recordCss = (dense: boolean, color: string) => `
  @page{size:A4 landscape;margin:10mm}*{box-sizing:border-box}
  body{${FONT}color:#111;font-size:${dense ? 9 : 11}px;margin:0}
  h1{font-size:20px;margin:0 0 4px;color:${color}}h2{font-size:16px;margin:0 0 4px;color:${color}}
  .meta{font-size:12px;color:#444;margin-bottom:8px}
  .sum{display:flex;gap:10px;margin:8px 0 12px}.sum div{border:1px solid #ddd;border-radius:6px;padding:6px 12px}
  .sum b{display:block;font-size:15px}
  table{width:100%;border-collapse:collapse}thead{display:table-header-group}tr{page-break-inside:avoid}
  th{background:${color};color:#fff;text-align:left}th,td{border:1px solid #ccc;padding:4px 5px;vertical-align:top;word-break:break-word}
  tr:nth-child(even) td{background:#fafafa}.ev{page-break-before:always}.note{color:#777;font-style:italic;margin:10px 0}`;

function eventSection(ev: EventRecord, subs: EventSubmission[], heading: 'h1' | 'h2') {
  const fields = visible(ev);
  const t = totals(ev, subs);
  const head = ['#', 'Reg. ID', ...fields.map(f => f.label), 'Source', 'Status', 'Date & Time'];
  const rows = subs.map((s, i) => [
    i + 1, s.registration_id, ...fields.map(f => (f.type === 'amount' && s.data[f.key] !== undefined && s.data[f.key] !== '' ? rupee(Number(s.data[f.key])) : f.type === 'time' ? fmtTime12(s.data[f.key]) : cellValue(s.data[f.key]))),
    s.source === 'online' ? 'Online' : 'Offline', s.payment_status === 'paid' ? 'Paid' : 'Unpaid',
    new Date(s.created_at).toLocaleDateString('en-GB') + ' ' + new Date(s.created_at).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true }),
  ]);
  return `<${heading}>${esc(ev.name)}</${heading}>
    <div class="meta">Date: ${esc(fmtDate(ev.date))} &nbsp;|&nbsp; Venue: ${esc(ev.venue)} &nbsp;|&nbsp; Fee: ${ev.fee > 0 ? rupee(ev.fee) : 'Free'} &nbsp;|&nbsp; ${ev.status === 'open' ? 'Registration open' : 'Registration closed'}</div>
    <div class="sum"><div>Total registrations<b>${t.total}</b></div><div>Expected amount<b>${rupee(t.expected)}</b></div>
      <div>Collected amount<b>${rupee(t.collected)}</b></div><div>Pending amount<b>${rupee(t.pending)}</b></div></div>
    <table><thead><tr>${head.map(h => `<th>${esc(h)}</th>`).join('')}</tr></thead>
    <tbody>${rows.map(r => `<tr>${r.map(c => `<td>${esc(c)}</td>`).join('')}</tr>`).join('') || `<tr><td colspan="${head.length}">No registrations</td></tr>`}</tbody></table>`;
}

// ---------- Record PDF: one event (landscape, repeating header, auto page breaks) ----------
export async function recordPdf(ev: EventRecord, subs: EventSubmission[]) {
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${esc(ev.name)}</title>
    <style>${recordCss(visible(ev).length > 8, safeColor(ev.themeColor))}</style></head><body>${eventSection(ev, subs, 'h1')}</body></html>`;
  await savePdf(html, `${ev.name} - Record`, true);
}

// ---------- All Events PDF: overview + one section per event, everything in a single file ----------
export async function allEventsPdf(items: Array<{ ev: EventRecord; subs: EventSubmission[] }>) {
  const color = '#c2410c';
  const dense = items.some(({ ev }) => visible(ev).length > 8);
  const sum = items.reduce((a, { ev, subs }) => { const t = totals(ev, subs); return { reg: a.reg + t.total, exp: a.exp + t.expected, col: a.col + t.collected, pen: a.pen + t.pending }; }, { reg: 0, exp: 0, col: 0, pen: 0 });
  const overview = items.map(({ ev, subs }, i) => {
    const t = totals(ev, subs);
    return `<tr><td>${i + 1}</td><td>${esc(ev.name)}</td><td>${esc(fmtDate(ev.date))}</td><td>${esc(ev.venue)}</td><td>${ev.fee > 0 ? rupee(ev.fee) : 'Free'}</td>
      <td>${ev.externalFormUrl ? 'External form' : t.total}</td><td>${ev.externalFormUrl ? '-' : t.paid}</td><td>${rupee(t.expected)}</td><td>${rupee(t.collected)}</td><td>${rupee(t.pending)}</td></tr>`;
  }).join('');
  const sections = items.map(({ ev, subs }) => `<div class="ev">${ev.externalFormUrl
    ? `<h2>${esc(ev.name)}</h2><div class="meta">Date: ${esc(fmtDate(ev.date))} | Venue: ${esc(ev.venue)}</div><p class="note">Ye event external Google Form use karta hai - iska data yaha store nahi hota.</p>`
    : eventSection(ev, subs, 'h2')}</div>`).join('');
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>All Events</title><style>${recordCss(dense, color)}</style></head><body>
    <h1>All Events Report</h1>
    <div class="meta">Generated on ${new Date().toLocaleDateString('en-GB')} &nbsp;|&nbsp; ${items.length} events</div>
    <div class="sum"><div>Total registrations<b>${sum.reg}</b></div><div>Expected amount<b>${rupee(sum.exp)}</b></div>
      <div>Collected amount<b>${rupee(sum.col)}</b></div><div>Pending amount<b>${rupee(sum.pen)}</b></div></div>
    <table><thead><tr>${['#', 'Event', 'Date', 'Venue', 'Fee', 'Registrations', 'Paid', 'Expected', 'Collected', 'Pending'].map(h => `<th>${h}</th>`).join('')}</tr></thead>
    <tbody>${overview || '<tr><td colspan="10">No events</td></tr>'}</tbody></table>
    ${sections}</body></html>`;
  await savePdf(html, `All Events - ${new Date().toISOString().slice(0, 10)}`, true);
}

// ---------- Blank Form PDF: built from the event's CURRENT fields, so it is always in sync; works offline ----------
export async function blankFormPdf(ev: EventRecord) {
  const fields = visible(ev);
  const color = safeColor(ev.themeColor);
  const box = '<span class="cb"></span>';
  const body = fields.map(f => {
    const star = f.required ? ' <span class="r">*</span>' : '';
    let input = '<div class="line"></div>';
    if (f.type === 'dropdown' || f.type === 'radio' || f.type === 'checkbox' || f.type === 'multiselect')
      input = `<div class="opts">${(f.options || []).map(o => `<span class="o">${box} ${esc(o)}</span>`).join('')}</div>`;
    if (f.type === 'date') input = '<div class="line"><span class="hint">DD / MM / YYYY</span></div>';
    if (f.type === 'time') input = '<div class="line"><span class="hint">HH : MM &nbsp; AM / PM</span></div>';
    if (f.type === 'yesno') input = `<div class="opts"><span class="o">${box} Yes</span><span class="o">${box} No</span></div>`;
    if (f.type === 'datetime') input = '<div class="line"><span class="hint">DD / MM / YYYY &nbsp; HH : MM</span></div>';
    if (f.type === 'amount') input = '<div class="line"><span class="hint" style="left:8px;right:auto;color:#333;font-size:14px">\u20B9</span></div>';
    if (f.type === 'textarea') input = '<div class="line" style="height:80px"></div>';
    return `<div class="f"><div class="lb">${esc(f.label)}${star}</div>${input}</div>`;
  }).join('');
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"><title>${esc(ev.name)}</title><style>
    @page{size:A4;margin:14mm}*{box-sizing:border-box}body{${FONT}color:#111;font-size:13px;margin:0}
    h1{margin:0;font-size:24px;color:${color};text-align:${ev.titleAlign || 'center'};font-weight:${ev.titleBold === false ? 400 : 700};font-family:${titleFontCss(ev.titleFont)}}.meta{text-align:${ev.titleAlign || 'center'};color:#444;margin:4px 0 14px}
    .fee{border:1.5px solid ${color};border-radius:6px;padding:6px 10px;text-align:center;font-weight:700;margin-bottom:14px}
    .f{margin-bottom:12px;page-break-inside:avoid}.lb{font-weight:600;margin-bottom:4px}.r{color:#dc2626}
    .line{border:1px solid #555;border-radius:3px;height:28px;position:relative}.hint{position:absolute;right:8px;top:6px;color:#aaa;font-size:11px}
    .opts{display:flex;flex-wrap:wrap;gap:14px;padding:4px 0}.o{display:inline-flex;align-items:center;gap:6px}
    .cb{display:inline-block;width:14px;height:14px;border:1.5px solid #333}
    .foot{display:flex;justify-content:space-between;align-items:flex-end;margin-top:26px;page-break-inside:avoid}
    .sig{width:45%;border-top:1px solid #333;padding-top:4px;text-align:center}
    .office{width:45%;border:1.5px dashed #555;padding:8px;min-height:56px}.office small{display:block;color:#555}</style></head><body>
    <h1>${esc(ev.name)}</h1>
    <div class="meta">Date: ${esc(fmtDate(ev.date))} &nbsp;|&nbsp; Venue: ${esc(ev.venue)}</div>
    ${ev.fee > 0 ? `<div class="fee">\u20B9${ev.fee} payable at office</div>` : ''}
    ${body}
    <div class="foot"><div class="sig">Signature</div><div class="office"><small>Registration ID (office use)</small></div></div>
    </body></html>`;
  await savePdf(html, `${ev.name} - Blank Form`, false);
}
