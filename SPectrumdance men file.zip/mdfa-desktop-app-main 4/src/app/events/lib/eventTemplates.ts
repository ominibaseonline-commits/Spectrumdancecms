// Ready-made form templates (Events -> Templates). Admin can customise any of them and save as a new template.
import type { EventField, FieldType } from './eventsDb';

const rid = () => Math.random().toString(36).slice(2, 8);
export const newFieldKey = () => `f_${rid()}`;

export const mkField = (label: string, type: FieldType, required = false, options?: string[]): EventField =>
  ({ key: newFieldKey(), label, type, required, options, order: 0 });

/** Fresh keys + order, so a template can be reused for many events without key clashes. */
export const cloneFields = (fields: EventField[]): EventField[] =>
  fields.filter(f => !f.archived).map((f, i) => ({ ...f, key: newFieldKey(), order: i, options: f.options ? [...f.options] : undefined }));

const base = () => [mkField('Full Name', 'text', true), mkField('Mobile Number', 'phone', true)];

/** Zaroori columns jo har event form me chahiye hote hain. Naya event isi se shuru hota hai (hata / badal sakte hain). */
export const essentialFields = (): EventField[] => [
  mkField('Full Name', 'text', true),
  mkField('Mobile Number', 'phone', true),
  mkField('Email', 'email', false),
  mkField('Age', 'number', true),
  mkField('Gender', 'radio', true, ['Male', 'Female', 'Other']),
  mkField('Address', 'text', false),
  mkField('City', 'text', false),
].map((f, i) => ({ ...f, order: i }));

/** Form ke rang ke ready options (Create tab me). */
export const THEME_COLORS: { name: string; hex: string }[] = [
  { name: 'Orange', hex: '#ea580c' }, { name: 'Blue', hex: '#2563eb' }, { name: 'Green', hex: '#16a34a' },
  { name: 'Purple', hex: '#7c3aed' }, { name: 'Pink', hex: '#db2777' }, { name: 'Red', hex: '#dc2626' },
  { name: 'Teal', hex: '#0d9488' }, { name: 'Dark', hex: '#1f2937' },
];
export const DEFAULT_THEME = '#ea580c';
/** Event name ke font styles (system fonts - koi download nahi, phone par bhi chalte hain). */
export const TITLE_FONTS: { key: string; label: string; css: string }[] = [
  { key: 'sans', label: 'Modern (Sans)', css: "-apple-system,'Segoe UI',Roboto,'Noto Sans Devanagari',Arial,sans-serif" },
  { key: 'serif', label: 'Classic (Serif)', css: "Georgia,'Times New Roman','Noto Serif Devanagari',serif" },
  { key: 'elegant', label: 'Elegant', css: "'Palatino Linotype','Book Antiqua',Palatino,Georgia,serif" },
  { key: 'rounded', label: 'Rounded', css: "'Trebuchet MS','Segoe UI',Verdana,sans-serif" },
  { key: 'display', label: 'Display (Heavy)', css: "Impact,'Arial Black','Segoe UI',sans-serif" },
  { key: 'script', label: 'Script (Handwriting)', css: "'Brush Script MT','Segoe Script','Lucida Handwriting',cursive" },
  { key: 'mono', label: 'Typewriter', css: "'Courier New',Courier,monospace" },
];
export const titleFontCss = (key?: string) => (TITLE_FONTS.find(f => f.key === key) || TITLE_FONTS[0]).css;
export const BG_COLORS: { name: string; hex: string }[] = [
  { name: 'White', hex: '#ffffff' }, { name: 'Cream', hex: '#fff7ed' }, { name: 'Light Yellow', hex: '#fefce8' },
  { name: 'Light Green', hex: '#f0fdf4' }, { name: 'Light Blue', hex: '#eff6ff' }, { name: 'Light Pink', hex: '#fdf2f8' },
  { name: 'Light Purple', hex: '#f5f3ff' }, { name: 'Light Grey', hex: '#f3f4f6' }, { name: 'Dark', hex: '#1f2937' },
];
export const validBg = (c?: string) => (c && /^#[0-9a-fA-F]{6}$/.test(c) ? c : '');
/** true = dark background (text white karna padega) */
export const isDarkColor = (hex?: string) => {
  const c = validBg(hex); if (!c) return false;
  const r = parseInt(c.substr(1, 2), 16), g = parseInt(c.substr(3, 2), 16), b = parseInt(c.substr(5, 2), 16);
  return (0.299 * r + 0.587 * g + 0.114 * b) / 255 < 0.5;
};
export const safeColor = (c?: string) => (c && /^#[0-9a-fA-F]{6}$/.test(c) ? c : DEFAULT_THEME);

export const BUILTIN_TEMPLATES: Array<{ id: string; name: string; description: string; build: () => EventField[] }> = [
  { id: 'tpl_basic', name: 'Basic (Essential)', description: 'Name, mobile, email, age, gender, address, city', build: essentialFields },
  { id: 'tpl_sports', name: 'Sports', description: 'Name, age, gender, category, T-shirt size, games', build: () => [
    ...base(), mkField('Age', 'number', true), mkField('Gender', 'radio', true, ['Male', 'Female', 'Other']),
    mkField('Category', 'dropdown', true, ['Under 10', '10-14', '15-18', 'Open']),
    mkField('T-Shirt Size', 'radio', true, ['S', 'M', 'L', 'XL']), mkField('Games', 'checkbox', false, ['Race', 'Relay', 'Long Jump']) ] },
  { id: 'tpl_workshop', name: 'Workshop', description: 'Name, email, occupation, experience level', build: () => [
    ...base(), mkField('Email', 'email', true), mkField('Occupation', 'text', false),
    mkField('Experience', 'dropdown', true, ['Beginner', 'Intermediate', 'Advanced']) ] },
  { id: 'tpl_cultural', name: 'Cultural', description: 'Name, age, item, group size', build: () => [
    ...base(), mkField('Age', 'number', true), mkField('Item', 'dropdown', true, ['Dance', 'Singing', 'Drama', 'Other']),
    mkField('Group Size', 'number', false) ] },
  { id: 'tpl_seminar', name: 'Seminar', description: 'Name, email, organisation, designation', build: () => [
    ...base(), mkField('Email', 'email', true), mkField('Organisation', 'text', false), mkField('Designation', 'text', false) ] },
  { id: 'tpl_competition', name: 'Competition', description: 'Name, age, category, solo/group, team name', build: () => [
    ...base(), mkField('Age', 'number', true), mkField('Category', 'dropdown', true, ['Junior', 'Senior', 'Open']),
    mkField('Participation', 'radio', true, ['Solo', 'Group']), mkField('Team Name', 'text', false) ] },
];
