import { useCallback, useEffect, useMemo, useState } from 'react';
import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Badge } from '../components/ui/badge';
import { Switch } from '../components/ui/switch';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '../components/ui/table';
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from '../components/ui/dialog';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import { ArrowLeft, Plus, Pencil, Trash2, FileSpreadsheet, FileText, Download, Loader2 } from 'lucide-react';
import { ConfirmDialog } from './ConfirmDialog';
import { FieldInput } from './FieldInput';
import { selectCls } from './FormBuilder';
import { EventRecord, EventSubmission, listSubmissions, saveSubmission, softDeleteSubmission, newId } from './lib/eventsDb';
import { EVENT_SUBMISSIONS_UPDATED, eventCode, syncEventToRelay } from './lib/eventSync';
import { blankFormPdf, cellValue, fmtTime12, recordPdf } from './lib/eventPdf';

const fmt = (ts: number) => new Date(ts).toLocaleDateString('en-GB');
const fmtDT = (ts: number) => { const d = new Date(ts); return `${d.toLocaleDateString('en-GB')} ${d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: true })}`; };
const money = (n: number) => `\u20B9${n.toLocaleString('en-IN')}`;

// Events History -> View submissions: summary, dynamic-column table, manual add, paid toggle, export, PDFs.
export function SubmissionsView({ ev, onBack }: { ev: EventRecord; onBack: () => void }) {
  const [subs, setSubs] = useState<EventSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [q, setQ] = useState('');
  const [pay, setPay] = useState<'all' | 'paid' | 'unpaid'>('all');
  const [src, setSrc] = useState<'all' | 'online' | 'offline'>('all');
  const [form, setForm] = useState<{ sub: EventSubmission | null; data: Record<string, any> } | null>(null);
  const [del, setDel] = useState<EventSubmission | null>(null);
  const [busy, setBusy] = useState(false);

  const fields = useMemo(() => ev.formFields.filter(f => !f.archived).sort((a, b) => a.order - b.order), [ev]);
  const load = useCallback(() => listSubmissions(ev.id).then(s => { setSubs(s); setLoading(false); }), [ev.id]);
  useEffect(() => {
    load();
    window.addEventListener(EVENT_SUBMISSIONS_UPDATED, load); // new online registrations appear live
    return () => window.removeEventListener(EVENT_SUBMISSIONS_UPDATED, load);
  }, [load]);

  const paidCount = subs.filter(s => s.payment_status === 'paid').length;
  const shown = subs.filter(s =>
    (pay === 'all' || s.payment_status === pay) && (src === 'all' || s.source === src) &&
    (!q.trim() || s.registration_id.toLowerCase().includes(q.toLowerCase()) ||
      Object.values(s.data).some(v => String(cellValue(v)).toLowerCase().includes(q.toLowerCase()))));

  const refreshRelay = () => { if (!ev.externalFormUrl) syncEventToRelay(ev).catch(() => {}); };

  const togglePaid = async (s: EventSubmission) => {
    await saveSubmission({ ...s, payment_status: s.payment_status === 'paid' ? 'unpaid' : 'paid' });
    load();
  };

  // ---- manual add / edit (paper forms filled offline are saved as source = "offline") ----
  const validate = (data: Record<string, any>) => {
    for (const f of fields) {
      const v = data[f.key]; const empty = Array.isArray(v) ? !v.length : !String(v ?? '').trim();
      if (empty) { if (f.required) return `${f.label} zaroori hai`; continue; }
      const s = String(v);
      if (f.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(s)) return `${f.label} sahi email nahi hai`;
      if (f.type === 'phone' && !/^\d{10,15}$/.test(s.replace(/\D/g, ''))) return `${f.label} sahi mobile number nahi hai`;
      if ((f.type === 'number' || f.type === 'amount') && !/^-?\d+(\.\d+)?$/.test(s)) return `${f.label} me sirf number likhein`;
    }
    return '';
  };
  const saveForm = async () => {
    if (!form) return;
    const err = validate(form.data); if (err) return toast.error(err);
    if (form.sub) await saveSubmission({ ...form.sub, data: form.data });
    else {
      const all = await listSubmissions(ev.id, true);
      const used = new Set(all.map(s => s.registration_id));
      let n = all.filter(s => s.source === 'offline').length + 1, regId = '';
      do { regId = `${eventCode(ev)}-O${String(n++).padStart(3, '0')}`; } while (used.has(regId));
      await saveSubmission({ id: newId('sub'), event_id: ev.id, data: form.data, source: 'offline', payment_status: 'unpaid', registration_id: regId, created_at: Date.now() });
      refreshRelay();
    }
    setForm(null); load(); toast.success('Saved');
  };
  const confirmDelete = async () => { if (!del) return; await softDeleteSubmission(del); setDel(null); load(); refreshRelay(); toast.success('Delete ho gaya (Recently Deleted me restore kar sakte hain)'); };

  // ---- export ----
  const exportRows = () => shown.map(s => ({
    'Registration ID': s.registration_id,
    ...Object.fromEntries(fields.map(f => [f.label, cellValue(s.data[f.key])])),
    Source: s.source === 'online' ? 'Online' : 'Offline', Payment: s.payment_status === 'paid' ? 'Paid' : 'Unpaid', 'Date & Time': fmtDT(s.created_at),
  }));
  const fileBase = `${ev.name.replace(/[\\/:*?"<>|]/g, '_')}_registrations`;
  const exportExcel = () => { const wb = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(exportRows()), 'Registrations'); XLSX.writeFile(wb, `${fileBase}.xlsx`); };
  const exportCsv = () => {
    const csv = XLSX.utils.sheet_to_csv(XLSX.utils.json_to_sheet(exportRows()));
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' })); a.download = `${fileBase}.csv`; a.click(); URL.revokeObjectURL(a.href);
  };
  const run = async (fn: () => Promise<void>) => { setBusy(true); try { await fn(); } catch (e: any) { toast.error(e?.message || 'PDF nahi bana'); } finally { setBusy(false); } };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={onBack}><ArrowLeft className="w-4 h-4 mr-1" /> Back</Button>
          <div><h3>{ev.name}</h3><p className="text-xs text-gray-500">{fmt(new Date(ev.date).getTime())} {ev.venue && `• ${ev.venue}`}</p></div>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" disabled={busy} onClick={() => run(() => recordPdf(ev, subs))}><FileText className="w-4 h-4 mr-1" /> Record PDF</Button>
          <Button variant="outline" disabled={busy} onClick={() => run(() => blankFormPdf(ev))}><FileText className="w-4 h-4 mr-1" /> Blank Form PDF</Button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[['Total registrations', String(subs.length)], ['Expected amount', money(ev.fee * subs.length)],
          ['Collected', money(ev.fee * paidCount)], ['Pending', money(ev.fee * (subs.length - paidCount))]].map(([l, v]) => (
          <Card key={l} className="p-3"><div className="text-xs text-gray-500">{l}</div><div className="text-lg font-semibold">{v}</div></Card>))}
      </div>

      <div className="flex flex-wrap gap-2 items-center">
        <Input className="max-w-xs" placeholder="Search..." value={q} onChange={e => setQ(e.target.value)} />
        <select className={selectCls + ' max-w-[140px]'} value={pay} onChange={e => setPay(e.target.value as any)}><option value="all">All payments</option><option value="paid">Paid</option><option value="unpaid">Unpaid</option></select>
        <select className={selectCls + ' max-w-[140px]'} value={src} onChange={e => setSrc(e.target.value as any)}><option value="all">Online + Offline</option><option value="online">Online</option><option value="offline">Offline</option></select>
        <div className="flex-1" />
        <Button variant="outline" onClick={exportCsv}><Download className="w-4 h-4 mr-1" /> CSV</Button>
        <Button variant="outline" onClick={exportExcel}><FileSpreadsheet className="w-4 h-4 mr-1" /> Excel</Button>
        <Button onClick={() => setForm({ sub: null, data: {} })}><Plus className="w-4 h-4 mr-1" /> Manual Add</Button>
      </div>

      {loading ? <p className="text-sm text-gray-500 flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> Loading...</p> : (
        <Card className="overflow-x-auto">
          <Table>
            <TableHeader><TableRow>
              <TableHead>Reg. ID</TableHead>{fields.map(f => <TableHead key={f.key}>{f.label}</TableHead>)}
              <TableHead>Source</TableHead><TableHead>Paid</TableHead><TableHead>Date &amp; Time</TableHead><TableHead className="text-right">Actions</TableHead>
            </TableRow></TableHeader>
            <TableBody>
              {shown.length === 0 && <TableRow><TableCell colSpan={fields.length + 5} className="text-center text-gray-500 py-8">
                {subs.length === 0 ? 'Abhi koi registration nahi aayi.' : 'Filter se koi entry match nahi hui.'}</TableCell></TableRow>}
              {shown.map(s => (
                <TableRow key={s.id}>
                  <TableCell className="font-mono text-xs">{s.registration_id}</TableCell>
                  {fields.map(f => <TableCell key={f.key}>{f.type === 'amount' && s.data[f.key] !== undefined && s.data[f.key] !== '' ? money(Number(s.data[f.key])) : f.type === 'datetime' ? String(cellValue(s.data[f.key])).replace('T', ' ') : f.type === 'time' ? fmtTime12(s.data[f.key]) : String(cellValue(s.data[f.key]))}</TableCell>)}
                  <TableCell><Badge variant={s.source === 'online' ? 'default' : 'secondary'}>{s.source === 'online' ? 'Online' : 'Offline'}</Badge></TableCell>
                  <TableCell><div className="flex items-center gap-2"><Switch checked={s.payment_status === 'paid'} onCheckedChange={() => togglePaid(s)} />
                    <span className={`text-xs ${s.payment_status === 'paid' ? 'text-green-700' : 'text-red-600'}`}>{s.payment_status === 'paid' ? 'Paid' : 'Unpaid'}</span></div></TableCell>
                  <TableCell className="whitespace-nowrap">{fmtDT(s.created_at)}</TableCell>
                  <TableCell className="text-right whitespace-nowrap">
                    <Button size="icon" variant="ghost" onClick={() => setForm({ sub: s, data: { ...s.data } })}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => setDel(s)}><Trash2 className="w-4 h-4 text-red-600" /></Button>
                  </TableCell>
                </TableRow>))}
            </TableBody>
          </Table>
        </Card>
      )}

      <Dialog open={!!form} onOpenChange={o => !o && setForm(null)}>
        <DialogContent className="max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{form?.sub ? `Edit ${form.sub.registration_id}` : 'Manual Add (offline form)'}</DialogTitle></DialogHeader>
          {form && fields.map(f => (
            <div key={f.key}><Label>{f.label}{f.required && <span className="text-red-600"> *</span>}</Label>
              <FieldInput f={f} value={form.data[f.key]} onChange={v => setForm({ ...form, data: { ...form.data, [f.key]: v } })} /></div>))}
          <DialogFooter><Button variant="outline" onClick={() => setForm(null)}>Cancel</Button><Button onClick={saveForm}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <ConfirmDialog open={!!del} title="Are you sure you want to delete this entry?" onCancel={() => setDel(null)} onConfirm={confirmDelete}>
        {del && <p>Registration <b>{del.registration_id}</b> delete hoga. Recently Deleted se wapas la sakte hain.</p>}
      </ConfirmDialog>
    </div>
  );
}
