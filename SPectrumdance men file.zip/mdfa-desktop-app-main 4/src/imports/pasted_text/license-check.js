// =============================================
// LICENSE-CHECK.JS — AMS License Validator v2.0
// =============================================

const AMS_LICENSE_KEY = 'AMS-OZ4P-H45X-ZCAZ'; // User ka license key yahan
const AMS_LICENSE_API = 'https://script.google.com/macros/s/AKfycbzmqyeF0io_3tVYX0lEC6dTYYEZxPZplGLYiO9_l1n-l8yRvGOgiXj8F8PzOvxW_PI6yA/exec';

const LIC_CACHE_KEY  = 'ams_license_cache';
const LIC_CACHE_TIME = 'ams_license_cache_time';
const LIC_CACHE_MIN  = 30;

// =============================================
// MAIN CHECK
// =============================================
async function checkAMSLicense() {
  // Auto cache clear — agar domain change hua ho
  const cachedDomain  = localStorage.getItem('ams_license_domain');
  const currentDomain = window.location.hostname;
  if (cachedDomain && cachedDomain !== currentDomain) {
    clearLicenseCache();
  }
  localStorage.setItem('ams_license_domain', currentDomain);

  // Cache check
  const cached = getCachedLicense();
  if (cached && cached.success) return cached;

  try {
    const domain = window.location.hostname;
    const url = AMS_LICENSE_API +
      '?action=verify_license' +
      '&key=' + encodeURIComponent(AMS_LICENSE_KEY) +
      '&domain=' + encodeURIComponent(domain);

    const controller = new AbortController();
    const timeoutId  = setTimeout(() => controller.abort(), 10000);
    const res        = await fetch(url, { signal: controller.signal });
    clearTimeout(timeoutId);
    const data = await res.json();

    // Sirf success hone par cache karo
    if (data.success) cacheLicense(data);
    return data;
  } catch(e) {
    const old = localStorage.getItem(LIC_CACHE_KEY);
    if (old) return JSON.parse(old);
    return { success: true, code: 'OFFLINE', days_left: 999 };
  }
}

// =============================================
// LICENSE GATE
// =============================================
async function initLicenseGate() {
  const result = await checkAMSLicense();

  if (!result.success) {
    if (result.code === 'EXPIRED')  { showLicenseExpiredScreen(result); return false; }
    if (result.code === 'REVOKED')  { showLicenseRevokedScreen();       return false; }
    if (result.code === 'INVALID')  { showLicenseInvalidScreen();       return false; }
    if (result.code === 'DOMAIN_MISMATCH') { showLicenseInvalidScreen(); return false; }
  }

  // Warning banner — 7 din se kam
  if (result.success && result.days_left <= 7 && result.days_left > 0) {
    showLicenseWarningBanner(result.days_left);
  }

  // Badge show karo topbar + mobile mein
  showLicenseBadge(result);

  return true;
}

// =============================================
// LICENSE BADGE — Topbar + Mobile
// =============================================
function showLicenseBadge(result) {
  if (!result || !result.success) return;

  const days = result.days_left;
  if (!days || days > 9000) return; // Lifetime — badge mat dikhao

  let color, label;
  if (days > 30) {
    color = '#16a34a'; // Green
    label = '🔑 ' + days + ' days';
  } else if (days > 7) {
    color = '#d97706'; // Amber
    label = '⏳ ' + days + ' days';
  } else {
    color = '#dc2626'; // Red
    label = '⚠️ ' + days + 'd left!';
  }

  const style = `display:inline-flex;align-items:center;padding:4px 10px;border-radius:20px;font-size:0.72rem;font-weight:700;background:#ffffff;color:${color};border:1.5px solid ${color}`;

  // PC topbar badge
  const pcBadge = document.getElementById('lic-badge');
  if (pcBadge) {
    pcBadge.style.cssText = style;
    pcBadge.textContent = label;
    pcBadge.title = 'License expiry: ' + (result.expiry || '');
  }

  // Mobile badge
  const mobBadge = document.getElementById('mob-lic-badge');
  if (mobBadge) {
    mobBadge.style.cssText = style;
    mobBadge.textContent = label;
  }
}

// =============================================
// CACHE
// =============================================
function getCachedLicense() {
  try {
    const data = localStorage.getItem(LIC_CACHE_KEY);
    const time = parseInt(localStorage.getItem(LIC_CACHE_TIME) || '0');
    if (!data) return null;
    if ((Date.now() - time) / 60000 > LIC_CACHE_MIN) return null;
    return JSON.parse(data);
  } catch(e) { return null; }
}

function cacheLicense(data) {
  try {
    localStorage.setItem(LIC_CACHE_KEY, JSON.stringify(data));
    localStorage.setItem(LIC_CACHE_TIME, String(Date.now()));
  } catch(e) {}
}

function clearLicenseCache() {
  localStorage.removeItem(LIC_CACHE_KEY);
  localStorage.removeItem(LIC_CACHE_TIME);
}

// =============================================
// LOCK SCREENS
// =============================================
function showLicenseExpiredScreen(data) {
  clearLicenseCache();
  _showLockScreen('🔒', 'License Expired',
    'Aapka AMS license <strong style="color:#ef4444">' + (data.expired_on || '') + '</strong> ko expire ho gaya.',
    'Renewal ke liye apne service provider se contact karein।'
  );
}

function showLicenseRevokedScreen() {
  clearLicenseCache();
  _showLockScreen('⛔', 'License Suspended',
    'Aapki AMS license temporarily suspend kar di gayi hai.',
    'Kisi bhi query ke liye apne service provider se contact karein।'
  );
}

function showLicenseInvalidScreen() {
  clearLicenseCache();
  _showLockScreen('❌', 'Invalid License',
    'Yeh license key valid nahi hai ya is domain ke liye authorized nahi hai.',
    'Apne service provider se valid license key lein।'
  );
}

function _showLockScreen(icon, title, msg, sub) {
  document.querySelectorAll('[id^="screen-"]').forEach(el => {
    el.style.display = 'none';
    el.classList.add('hidden');
  });
  const ex = document.getElementById('ams-license-lock');
  if (ex) ex.remove();

  const lock = document.createElement('div');
  lock.id = 'ams-license-lock';
  lock.style.cssText = 'position:fixed;inset:0;background:linear-gradient(135deg,#080810,#14142e);display:flex;align-items:center;justify-content:center;padding:20px;z-index:99999;font-family:Segoe UI,sans-serif';
  lock.innerHTML = `
    <div style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.1);border-radius:24px;padding:44px 36px;max-width:440px;width:100%;text-align:center;">
      <div style="font-size:3rem;margin-bottom:20px">${icon}</div>
      <h2 style="color:#fff;font-size:1.5rem;font-weight:800;margin-bottom:12px">${title}</h2>
      <p style="color:rgba(255,255,255,0.6);font-size:0.88rem;line-height:1.7;margin-bottom:12px">${msg}</p>
      <p style="color:rgba(255,255,255,0.4);font-size:0.8rem;line-height:1.6">${sub}</p>
      <div style="background:rgba(16,185,129,0.08);border:1px solid rgba(16,185,129,0.2);border-radius:12px;padding:12px 16px;margin-top:20px;font-size:0.8rem;color:rgba(255,255,255,0.6)">
        🔒 Aapka data bilkul safe hai।
      </div>
    </div>`;
  document.body.appendChild(lock);
}

// =============================================
// WARNING BANNER — 7 din se kam
// =============================================
function showLicenseWarningBanner(daysLeft) {
  const ex = document.getElementById('ams-lic-warn');
  if (ex) return;
  const warn = document.createElement('div');
  warn.id = 'ams-lic-warn';
  warn.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;background:linear-gradient(135deg,#b45309,#f59e0b);color:#fff;padding:10px 20px;display:flex;align-items:center;justify-content:space-between;font-size:0.85rem;font-family:Segoe UI,sans-serif';
  warn.innerHTML = `
    <span>⚠️ AMS License sirf <strong>${daysLeft} din</strong> mein expire hogi — Renewal ke liye contact karein</span>
    <button onclick="this.parentElement.remove()" style="background:rgba(255,255,255,0.2);border:none;color:#fff;padding:4px 10px;border-radius:6px;cursor:pointer;margin-left:12px">✕</button>`;
  document.body.prepend(warn);
  const topbar = document.querySelector('.topbar');
  if (topbar) topbar.style.marginTop = '42px';
}