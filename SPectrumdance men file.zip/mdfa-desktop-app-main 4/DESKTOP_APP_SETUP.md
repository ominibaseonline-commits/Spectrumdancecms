# MDFA Desktop App — Setup Guide (Windows .exe)

Ye guide batata hai ki is folder mein kya naya add hua hai aur GitHub pe push karke
`.exe` kaise banega.

---

## ✅ Kya Naya Add Hua Hai

1. **`electron/main.js`** — Desktop window banata hai, tumhara React app (`dist/index.html`) load karta hai
2. **`electron/preload.js`** — React app ko safely machine ID tak access deta hai
3. **`electron/machineId.js`** — Har Windows PC ka unique, stable ID generate karta hai
4. **`src/app/lib/googleSheetLicense.ts`** — Update hua: ab Electron app se `machine_id` bhi
   bhejta hai. **Web/PWA version bilkul waisa hi chalega jaisa chalta hai** — koi
   `machine_id` nahi bhejega, purana domain-check hi hoga.
5. **`package.json`** — Electron + electron-builder + auto-update packages add kiye,
   aur `.exe` banane ka build config likha
6. **`.github/workflows/build.yml`** — GitHub Actions file jo cloud mein Windows `.exe`
   banati hai

## ⚠️ Abhi Baaki Hai (Apps Script)

Google Sheet backend (Apps Script) ka naya "device limit" logic isi mein add nahi kiya
gaya — kyunki tumhare current live Apps Script ka exact code mere paas nahi hai, aur
usse chhede bina copy karna risky hai (existing paying customers break ho sakte hain).

**Jab tum apna current Apps Script code paste karoge, main usi mein safely "machine_id"
wala fallback logic add kar dunga — bina kuch existing tod.**

---

## 🚀 Code GitHub Pe Push Karna (apne terminal mein)

Apne computer pe terminal khol ke, is project folder ke andar jaake ye commands
ek-ek karke chalao:

```bash
git init
git add .
git commit -m "Initial desktop app setup"
git branch -M main
git remote add origin https://github.com/ominibaseonline-commits/mdfa-desktop-app.git
git push -u origin main
```

Push hone ke baad GitHub pe repo mein saara code dikhega (`node_modules` aur `dist`
chhod ke — wo `.gitignore` mein hain, unki zarurat nahi).

## 🏗️ Windows `.exe` Banana (GitHub Actions se)

1. GitHub repo kholo → **"Actions"** tab pe click karo
2. Left side mein **"Build Windows App"** workflow dikhega, uspe click karo
3. **"Run workflow"** button dabao (branch: `main` select rahega) → phir dobara "Run workflow"
4. ~5-10 minute wait karo (green tick = success)
5. Us run ke andar niche **"Artifacts"** section mein `mdfa-windows-installer` dikhega
   → download karo → zip ke andar `.exe` milega

Ye `.exe` kisi bhi Windows PC pe install/test kar sakte ho.
