# ID Card (Settings -> ID Card)

- **ON / OFF**: Settings -> ID Card ke upar wala switch. OFF = Admission Saved popup me "ID Card" button nahi aata, aur online admission form me card banta / mail me jata hi nahi.
- **Design**: front + back / sirf front / sirf back, 5 templates (rang), header banner image, heading, tagline, front ke columns (add / remove / order / naam), back ke contact lines, QR link, founder, neeche ke 3 shabd. Default = purana Spectrum card.
- **Save** karte hi card CMS me, Student Dashboard me aur online admission form (Google Script) me ek saath badal jata hai.
- **Admission Saved popup -> ID Card**: PDF banti hai. Phone par share sheet se seedha WhatsApp; computer par PDF download hoti hai aur student ki WhatsApp chat khulti hai (PDF ko attach karna hota hai).
- Online form ke liye **Google Script dobara paste + New Deployment** karna zaroori hai (Settings -> Attendance Setup se naya code).
- Code: `src/app/lib/idCardRender.js` (ek hi design code CMS + online page + script me), `idCard.ts`, `components/IdCardSettings.tsx`.
