// Batch time labels look like "4:30 To 6:00 Pm", "9:00 To 10:00 Pm (Govind Sir)",
// "7:35 To 8:35 AM Guitar ( Sat & Sun )" or 24h style "15:00 - 16:30".
// The AM/PM usually appears only after the END time, so the start time has to inherit it.
// Returns minutes from midnight of the START time, so batches sort morning -> night.

const TIME_RE = /(\d{1,2})(?::(\d{2}))?\s*(AM|PM)?/gi;

export function batchSortKey(label: string): number {
  const text = String(label || '');
  const found: { h: number; m: number; mer: string }[] = [];
  let match: RegExpExecArray | null;
  TIME_RE.lastIndex = 0;
  while ((match = TIME_RE.exec(text)) && found.length < 2) {
    found.push({ h: Number(match[1]), m: Number(match[2] || 0), mer: (match[3] || '').toUpperCase() });
  }
  if (found.length === 0) return Number.MAX_SAFE_INTEGER;

  const to24 = (t: { h: number; m: number }, mer: string) => {
    if (t.h >= 13) return t.h * 60 + t.m; // already 24h
    let h = t.h % 12;
    if (mer === 'PM') h += 12;
    return h * 60 + t.m;
  };

  const start = found[0];
  const end = found[1];
  // Meridiem on the start time itself, otherwise the one written after the end time
  const endMer = end?.mer || '';
  if (start.mer) return to24(start, start.mer);
  if (!endMer) return to24(start, ''); // no AM/PM anywhere: treat as written (24h or AM)

  const endMin = to24(end, endMer);
  let startMin = to24(start, endMer);
  // "11:00 To 1:00 Pm" -> start must be 11 AM, not 11 PM
  if (startMin > endMin) startMin -= 12 * 60;
  return startMin;
}

export type BatchStatus = 'live' | 'upcoming' | 'closed' | 'today';

/** Where a batch is right now: LIVE (inside its time), UPCOMING (not started) or CLOSED (over). 'today' = time label could not be read. */
export function batchStatus(batchTime: string, now: Date = new Date()): BatchStatus {
  const raw = String(batchTime || '');
  const range = raw.includes(' - ') ? raw.split(' - ') : raw.split(/\s+[Tt][Oo]\s+/);
  if (range.length !== 2) return 'today';
  const cur = now.getHours() * 60 + now.getMinutes();
  const parse = (s: string, fallback?: string) => {
    const m = s.trim().toUpperCase().match(/(\d+):(\d+)\s*(AM|PM)?/);
    if (!m) return 0;
    let h = parseInt(m[1]);
    const min = parseInt(m[2]);
    const p = m[3] || fallback;
    if (p === 'PM' && h !== 12) h += 12;
    if (p === 'AM' && h === 12) h = 0;
    return h * 60 + min;
  };
  const endPeriod = range[1].trim().toUpperCase().match(/(AM|PM)/)?.[1];
  const start = parse(range[0], endPeriod);
  const end = parse(range[1]);
  if (cur >= start && cur <= end) return 'live';
  if (cur < start) return 'upcoming';
  return 'closed';
}

// ---------------------------------------------------------------------------
// Ek batch time -> kai Category / Sub-Category
// ---------------------------------------------------------------------------
// Batch ka key batchTime hi hai (students isi se jude hain). Pehle ek time sirf ek category me ja sakta tha,
// dusri category me wahi time daalne par purana batch overwrite ho jata tha (mismatch). Ab ek batch me
// `targets` list hoti hai: [{ category, subCategory }, ...]. Purane batch (sirf category/subCategory) bhi chalte hain.

export interface BatchTarget { category: string; subCategory: string; }

export function getBatchTargets(batch: any): BatchTarget[] {
  const out: BatchTarget[] = [];
  const add = (c: any, s: any) => {
    const category = String(c ?? '').trim();
    const subCategory = String(s ?? '').trim();
    if (!category && !subCategory) return;
    if (!out.some((t) => t.category === category && t.subCategory === subCategory)) out.push({ category, subCategory });
  };
  if (Array.isArray(batch?.targets)) batch.targets.forEach((t: any) => add(t?.category, t?.subCategory));
  add(batch?.category, batch?.subCategory); // purane batch + primary
  return out;
}

/** Kya ye batch is Category + Sub-Category me aata hai? */
export function batchMatches(batch: any, category: string, subCategory: string): boolean {
  return getBatchTargets(batch).some((t) => t.category === category && t.subCategory === subCategory);
}

// ---------------------------------------------------------------------------
// Ek student -> kai batch
// ---------------------------------------------------------------------------
// Student ka MAIN batch `batchTime` me hi rehta hai (fees, attendance Google Script, QR sab isi ko padhte hain,
// isliye wo bilkul same chalta hai). Extra batches `extraBatches: string[]` me alag se save hote hain.

/** Student ke saare batches: main batch pehle, phir extra (duplicate hata kar). */
export function getStudentBatches(student: any): string[] {
  const out: string[] = [];
  const add = (v: any) => {
    const t = String(v ?? '').trim();
    if (t && !out.includes(t)) out.push(t);
  };
  add(student?.batchTime);
  if (Array.isArray(student?.extraBatches)) student.extraBatches.forEach(add);
  return out;
}

/** Kya student is batch me hai (main ya extra)? */
export function studentInBatch(student: any, batchTime: string): boolean {
  return getStudentBatches(student).includes(String(batchTime ?? '').trim());
}
