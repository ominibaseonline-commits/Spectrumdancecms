import { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Search, Plus, FileText, MessageCircle, Edit, Trash2, Pencil } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { getAllStudents, saveStudent, getAllPayments, savePayment, getPaymentsByRegNo, deletePayment } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { splitDues, discountPercent, isDuesDateOver } from '../lib/dues';
import { hasSeparateExtras, extraChargeDues, sumExtraDues, sumExtraCharges, sumExtraPaid, syncExtraPayments, todayYmd } from '../lib/admissionFields';
import { FeesCalendar } from './FeesCalendar';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';

export function FeesManagement() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const { matchesLocation, selectedLocation } = useLocationFilter();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  const [showPaymentSummary, setShowPaymentSummary] = useState(false);
  const [savedPayment, setSavedPayment] = useState<any>(null);
  const [paymentHistory, setPaymentHistory] = useState<any[]>([]);
  const [editingPayment, setEditingPayment] = useState<any>(null);
  // true when the form was opened from "Update Dues" (pay off the old balance), false for a new fees payment
  const payingDuesRef = useRef(false);

  const [paymentData, setPaymentData] = useState({
    regNo: '',
    paymentDate: new Date().toISOString().split('T')[0],
    sessionDate: new Date().toISOString().split('T')[0],
    duration: '',
    durationType: '',
    sessionExpiryDate: '',
    totalAmount: '',
    discount: '',
    paidAmount: '',
    dues: 0,
    duesDate: '',
    paymentMode: ''
  });
  // Discount button dabane par hi discount box khulta hai (edit me discount ho to apne aap khula rehta hai)
  const [showDiscount, setShowDiscount] = useState(false);

  // ----- Extra Charge dues collect (class/admission dues se bilkul alag) -----
  const [extraCollect, setExtraCollect] = useState<{ index: number; amount: string; mode: string; date: string } | null>(null);
  const openExtraCollect = (index: number) => {
    const c = (selectedStudent?.extraCharges || [])[index];
    if (!c) return;
    setExtraCollect({ index, amount: String(Math.max(0, extraChargeDues(c))), mode: '', date: todayYmd() });
  };
  const saveExtraCollect = async () => {
    if (!selectedStudent || !extraCollect) return;
    const charges = (selectedStudent.extraCharges || []).map((c: any) => ({ ...c }));
    const c = charges[extraCollect.index];
    if (!c) return;
    const due = Math.max(0, extraChargeDues(c));
    const amt = parseFloat(extraCollect.amount);
    if (!amt || amt <= 0) { toast.error('Sahi amount daalo'); return; }
    if (amt > due) { toast.error(`Amount extra charge ke dues (₹${due}) se zyada nahi ho sakta`); return; }
    if (!extraCollect.mode) { toast.error('Payment mode chuno'); return; }
    c.paid = (parseFloat(String(c.paid)) || 0) + amt;
    const payments = [
      ...(Array.isArray(selectedStudent.extraPayments) ? selectedStudent.extraPayments : []),
      { id: `xp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date: extraCollect.date || todayYmd(), name: String(c.name), amount: amt, mode: extraCollect.mode },
    ];
    try {
      const updated = { ...selectedStudent, extraCharges: charges, extraPayments: payments };
      await saveStudent(updated);
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      setSelectedStudent(updated);
      setExtraCollect(null);
      toast.success(`${c.name}: ₹${amt} collect ho gaya`);
    } catch (e) {
      console.error(e);
      toast.error('Extra charge payment save nahi ho payi');
    }
  };

  // ----- Extra Charge add / edit (admin kabhi bhi amount badal sakta hai, ya purane student par naya charge laga sakta hai) -----
  // Jaise: winter me AC charge nahi, summer aane par har student (purane bhi) par "AC Charge" add kar do.
  const MAX_EXTRA_FEES_MGMT = 50;
  const [extraEdit, setExtraEdit] = useState<{ mode: 'add' | 'edit'; index: number; name: string; amount: string; paid: string; origPaid: string; payMode: string; date: string } | null>(null);
  const normName = (v: any) => String(v ?? '').trim().toLowerCase();

  const openExtraAdd = () => setExtraEdit({ mode: 'add', index: -1, name: '', amount: '', paid: '', origPaid: '', payMode: '', date: todayYmd() });
  const openExtraEdit = (index: number) => {
    const c = (selectedStudent?.extraCharges || [])[index];
    if (!c) return;
    setExtraEdit({ mode: 'edit', index, name: String(c.name || ''), amount: String(c.amount ?? ''), paid: String(parseFloat(String(c.paid)) || 0), origPaid: String(parseFloat(String(c.paid)) || 0), payMode: '', date: todayYmd() });
  };

  const saveExtraEdit = async () => {
    if (!selectedStudent || !extraEdit) return;
    const name = extraEdit.name.trim();
    const amount = parseFloat(extraEdit.amount);
    if (!name) { toast.error('Charge ka naam daalo'); return; }
    if (!amount || amount <= 0) { toast.error('Sahi amount daalo'); return; }
    const charges: any[] = (selectedStudent.extraCharges || []).map((c: any) => ({ ...c }));
    const dup = charges.some((c, i) => i !== extraEdit.index && normName(c.name) === normName(name));
    if (dup) { toast.error('Is naam ka charge pehle se hai. Naam alag rakho (jaise "AC Charge Jun 2027")'); return; }
    let payments: any[] = Array.isArray(selectedStudent.extraPayments) ? selectedStudent.extraPayments.map((p: any) => ({ ...p })) : [];

    if (extraEdit.mode === 'add') {
      if (charges.length >= MAX_EXTRA_FEES_MGMT) { toast.error(`Maximum ${MAX_EXTRA_FEES_MGMT} extra charges`); return; }
      const paidNow = Math.max(0, parseFloat(extraEdit.paid) || 0);
      if (paidNow > amount) { toast.error('Paid amount charge se zyada nahi ho sakta'); return; }
      if (paidNow > 0 && !extraEdit.payMode) { toast.error('Payment mode chuno'); return; }
      charges.push({ name, amount, paid: paidNow });
      if (paidNow > 0) {
        payments.push({ id: `xp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date: extraEdit.date || todayYmd(), name, amount: paidNow, mode: extraEdit.payMode });
      }
    } else {
      const old = charges[extraEdit.index];
      if (!old) return;
      const oldPaid = parseFloat(String(old.paid)) || 0;
      const newPaid = parseFloat(extraEdit.paid);
      if (isNaN(newPaid) || newPaid < 0) { toast.error('Sahi paid amount daalo'); return; }
      if (newPaid > amount) { toast.error(`Paid amount (₹${newPaid}) charge amount (₹${amount}) se zyada nahi ho sakta`); return; }
      // naam badla to uski collected payments ka naam bhi badlo (Monthly Collection me link bana rahe)
      if (normName(old.name) !== normName(name)) {
        payments = payments.map((p) => (normName(p.name) === normName(old.name) ? { ...p, name } : p));
      }
      // paid badla to payments list bhi uske barabar karo (Monthly Collection sahi rahe)
      const diff = Math.round((newPaid - oldPaid) * 100) / 100;
      if (diff > 0) {
        if (!extraEdit.payMode) { toast.error('Paid amount badhaya hai, Payment mode chuno'); return; }
        payments.push({ id: `xp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date: extraEdit.date || todayYmd(), name, amount: diff, mode: extraEdit.payMode });
      } else if (diff < 0) {
        let toCut = -diff;
        const mine = payments.filter((p) => normName(p.name) === normName(name)).sort((a, b) => (a.date < b.date ? 1 : -1));
        for (const p of mine) {
          if (toCut <= 0) break;
          const cut = Math.min(p.amount, toCut);
          p.amount = Math.round((p.amount - cut) * 100) / 100;
          toCut -= cut;
        }
        payments = payments.filter((p) => p.amount > 0);
      }
      charges[extraEdit.index] = { ...old, name, amount, paid: newPaid };
    }
    try {
      const updated = { ...selectedStudent, extraCharges: charges, extraChargesSeparate: true, extraPayments: payments };
      await saveStudent(updated);
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      setSelectedStudent(updated);
      setExtraEdit(null);
      toast.success(extraEdit.mode === 'add' ? `${name}: ₹${amount} extra charge add ho gaya` : `${name} update ho gaya`);
    } catch (e) {
      console.error(e);
      toast.error('Extra charge save nahi ho paya');
    }
  };

  const deleteExtraCharge = async () => {
    if (!selectedStudent || !extraEdit || extraEdit.mode !== 'edit') return;
    const charges: any[] = selectedStudent.extraCharges || [];
    const c = charges[extraEdit.index];
    if (!c) return;
    if ((parseFloat(String(c.paid)) || 0) > 0) { toast.error('Is charge me payment collect ho chuki hai, isliye delete nahi ho sakta. Amount ko paid ke barabar kar do.'); return; }
    if (!confirm(`"${c.name}" extra charge delete karna hai?`)) return;
    try {
      const updated = { ...selectedStudent, extraCharges: charges.filter((_: any, i: number) => i !== extraEdit.index) };
      await saveStudent(updated);
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      setSelectedStudent(updated);
      setExtraEdit(null);
      toast.success('Extra charge delete ho gaya');
    } catch (e) {
      console.error(e);
      toast.error('Delete nahi ho paya');
    }
  };

  useEffect(() => {
    if (selectedStudent && !matchesLocation(selectedStudent.location)) {
      setSelectedStudent(null);
      setPaymentHistory([]);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLocation]);

  useEffect(() => {
    if (selectedStudent) {
      loadPaymentHistory();
    }
  }, [selectedStudent]);

  useEffect(() => {
    if (paymentData.sessionDate && paymentData.duration && paymentData.durationType) {
      const startDate = new Date(paymentData.sessionDate);
      let expiryDate = new Date(startDate);
      const duration = parseInt(paymentData.duration);
      if (paymentData.durationType === 'Days') {
        expiryDate.setDate(expiryDate.getDate() + duration);
      } else if (paymentData.durationType === 'Month') {
        expiryDate.setMonth(expiryDate.getMonth() + duration);
      } else if (paymentData.durationType === 'Year') {
        expiryDate.setFullYear(expiryDate.getFullYear() + duration);
      }
      setPaymentData(prev => ({ ...prev, sessionExpiryDate: expiryDate.toISOString().split('T')[0] }));
    }
  }, [paymentData.sessionDate, paymentData.duration, paymentData.durationType]);

  useEffect(() => {
    const total = parseFloat(paymentData.totalAmount) || 0;
    const paid = parseFloat(paymentData.paidAmount) || 0;
    const disc = parseFloat(String((paymentData as any).discount)) || 0;
    setPaymentData(prev => ({ ...prev, dues: total - disc - paid }));
  }, [paymentData.totalAmount, paymentData.paidAmount, (paymentData as any).discount]);

  const handleSearch = async () => {
    const allStudents = await getAllStudents();
    const students = allStudents.filter((s: any) => !s.deactivated && matchesLocation(s.location));
    const student = students.find((s: any) =>
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.regNo.includes(searchTerm) ||
      s.mobile.includes(searchTerm) ||
      s.alternateMobile?.includes(searchTerm)
    );
    if (student) {
      setSelectedStudent(student);
      await loadPaymentHistory(student.regNo);
      toast.success('Student found!');
    } else {
      toast.error(selectedLocation === 'all' ? 'Student not found!' : `Student not found in ${selectedLocation}!`);
      setSelectedStudent(null);
    }
  };

  const loadPaymentHistory = async (regNo?: string) => {
    const studentRegNo = regNo || selectedStudent?.regNo;
    if (!studentRegNo) return;
    const studentPayments = await getPaymentsByRegNo(studentRegNo);
    // Newest payment first — id is auto-incrementing, so a higher id always means
    // it was added more recently (reliable even when multiple payments share the
    // same Payment Date).
    const sorted = [...studentPayments].sort((a: any, b: any) => (b.id || 0) - (a.id || 0));
    setPaymentHistory(sorted);
  };

  const handleUpdateDues = () => {
    if (!selectedStudent) return;
    payingDuesRef.current = true;
    if (paymentHistory && paymentHistory.length > 0) {
      // Dues exist from a previous payment cycle — pre-fill last payment's details
      // (paymentHistory is already sorted newest-first by id, so this is just its first item)
      const lastPayment = [...paymentHistory].sort(
        (a: any, b: any) => (b.id || 0) - (a.id || 0)
      )[0];
      setPaymentData({
        regNo: selectedStudent.regNo,
        paymentDate: new Date().toISOString().split('T')[0],
        sessionDate: lastPayment.sessionDate || new Date().toISOString().split('T')[0],
        duration: lastPayment.duration || '',
        durationType: lastPayment.durationType || '',
        sessionExpiryDate: lastPayment.sessionExpiryDate || '',
        totalAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        discount: '',
        paidAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        dues: 0,
        duesDate: selectedStudent.duesDate || '',
        paymentMode: ''
      });
    } else {
      // Dues exist since admission (no payment record yet) — pre-fill admission date & expiry date
      setPaymentData({
        regNo: selectedStudent.regNo,
        paymentDate: new Date().toISOString().split('T')[0],
        sessionDate: selectedStudent.admissionDate || new Date().toISOString().split('T')[0],
        duration: selectedStudent.duration || '',
        durationType: selectedStudent.durationType || '',
        sessionExpiryDate: selectedStudent.expiryDate || '',
        totalAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        discount: '',
        paidAmount: selectedStudent.dues > 0 ? selectedStudent.dues.toString() : '',
        dues: 0,
        duesDate: selectedStudent.duesDate || '',
        paymentMode: ''
      });
    }
    setEditingPayment(null);
    setShowDiscount(false);
    setShowPaymentForm(true);
  };

  const handleAddPayment = () => {
    if (!selectedStudent) return;
    payingDuesRef.current = false;
    // Auto-fill session expiry date from student's existing expiry date
    const studentExpiryDate = selectedStudent.expiryDate || '';
    setPaymentData({
      regNo: selectedStudent.regNo,
      paymentDate: new Date().toISOString().split('T')[0],
      sessionDate: studentExpiryDate || new Date().toISOString().split('T')[0],
      duration: '',
      durationType: '',
      sessionExpiryDate: '',
      // Add Payment: Total / Paid amount khali (sirf Payment Date + Session Date autofill). Dues "Update" button se hi collect hote hain.
      totalAmount: '',
      discount: '',
      paidAmount: '',
      dues: 0,
      duesDate: '',
      paymentMode: ''
    });
    setEditingPayment(null);
    setShowDiscount(false);
    setShowPaymentForm(true);
  };

  const handleSavePayment = async () => {
    if (!paymentData.duration || !paymentData.durationType ||
      !paymentData.totalAmount || !paymentData.paidAmount ||
      !paymentData.paymentMode) {
      toast.error('Please fill all required fields');
      return;
    }
    const discountVal = Math.max(0, parseFloat(String((paymentData as any).discount)) || 0);
    if (discountVal > (parseFloat(paymentData.totalAmount) || 0)) {
      toast.error('Discount total amount se zyada nahi ho sakta');
      return;
    }
    try {
      const remainingAfter = (parseFloat(paymentData.totalAmount) || 0) - discountVal - (parseFloat(paymentData.paidAmount) || 0);
      // Dues date sirf tab jab dues baaki ho
      // "Update" (dues collect) se bani payment par flag lagta hai — receipt me Total Amount ki jagah Dues Amount / Collected / Remaining dikhta hai
      const isDuesPayment = payingDuesRef.current || !!(paymentData as any).isDuesPayment;
      const paymentToSave = { ...paymentData, discount: discountVal, duesDate: remainingAfter > 0 ? (paymentData.duesDate || '') : '', name: selectedStudent.name, isDuesPayment };
      await savePayment(paymentToSave);
      const updatedStudent = { ...selectedStudent };
      updatedStudent.expiryDate = paymentData.sessionExpiryDate;
      updatedStudent.duration = paymentData.duration;
      updatedStudent.durationType = paymentData.durationType;
      const previousDues = parseFloat(selectedStudent.dues) || 0;
      const paidAmount = parseFloat(paymentData.paidAmount) || 0;
      const totalAmount = parseFloat(paymentData.totalAmount) || 0;
      const newDues = totalAmount - discountVal - paidAmount;

      const currentPaidAmount = parseFloat(updatedStudent.paidAmount) || 0;
      updatedStudent.paidAmount = currentPaidAmount + paidAmount; // always credit exactly what was paid this time
      const remaining = newDues > 0 ? newDues : 0; // remaining owed after this transaction
      // Split: paying off an old admission balance keeps the rest as Admission Dues;
      // a normal fees payment leaves its balance as Monthly Dues.
      const before = splitDues(selectedStudent, paymentHistory.length > 0);
      if (payingDuesRef.current && (before.admission > 0 || before.monthly > 0)) {
        // Dues collect: pehle admission dues bharta hai, monthly dues baad me — jo bacha wo apni jagah rehta hai
        updatedStudent.monthlyDues = Math.min(before.monthly, remaining);
        updatedStudent.admissionDues = Math.round((remaining - updatedStudent.monthlyDues) * 100) / 100;
      } else {
        updatedStudent.admissionDues = 0;
        updatedStudent.monthlyDues = remaining;
      }
      updatedStudent.dues = updatedStudent.admissionDues + updatedStudent.monthlyDues;
      // Dues date: dues clear to hat jati hai; baaki hai to nayi date (khali chhodi to purani date rehti hai)
      updatedStudent.duesDate = remaining > 0 ? (paymentToSave.duesDate || selectedStudent.duesDate || '') : '';

      if (previousDues > 0 && paidAmount >= previousDues) {
        toast.success('Admission dues cleared successfully!');
      }
      await saveStudent(updatedStudent);
      window.dispatchEvent(new CustomEvent('studentsUpdated')); // Google Sheet ko jaldi sync ho
      setSelectedStudent(updatedStudent);
      setSavedPayment(paymentToSave);
      setShowPaymentForm(false);
      setShowPaymentSummary(true);
      await loadPaymentHistory();
      toast.success(editingPayment ? 'Payment updated successfully!' : 'Payment saved successfully!');
    } catch (error) {
      console.error('Error saving payment:', error);
      toast.error('Failed to save payment. Please try again.');
    }
  };

  const handleEditPayment = (payment: any) => {
    payingDuesRef.current = false;
    setPaymentData({ ...payment, discount: payment.discount ? String(payment.discount) : '' });
    setShowDiscount(Number(payment.discount) > 0);
    setEditingPayment(payment);
    setShowPaymentForm(true);
  };

  const handleDeletePayment = async (payment: any) => {
    if (!confirm('Are you sure you want to delete this payment record?')) return;
    try {
      if (payment.id) {
        await deletePayment(payment.id);
        const remainingPayments = await getPaymentsByRegNo(payment.regNo);

        // Revert the student's expiry date to whatever the most recent
        // REMAINING payment says, so deleting the latest payment doesn't
        // leave a stale future expiry date behind.
        if (selectedStudent && selectedStudent.regNo === payment.regNo) {
          const students = await getAllStudents();
          const studentRecord = students.find((s: any) => s.regNo === payment.regNo);
          if (studentRecord) {
            if (remainingPayments && remainingPayments.length > 0) {
              // Same "most recent" definition as the Payment History table itself
              // (highest id = most recently added) — so the expiry date always
              // matches whatever record is now sitting at the top of the list.
              const mostRecent = [...remainingPayments].sort(
                (a: any, b: any) => (b.id || 0) - (a.id || 0)
              )[0];
              const updatedStudent = {
                ...studentRecord,
                expiryDate: mostRecent.sessionExpiryDate || studentRecord.expiryDate,
                dues: parseFloat(mostRecent.dues) || 0,
                admissionDues: 0,
                monthlyDues: parseFloat(mostRecent.dues) || 0,
                duesDate: (parseFloat(mostRecent.dues) || 0) > 0 ? (mostRecent.duesDate || '') : '',
              };
              await saveStudent(updatedStudent);
              window.dispatchEvent(new CustomEvent('studentsUpdated'));
              setSelectedStudent(updatedStudent);
            } else {
              // No payments left at all — nothing to revert to, leave as-is
              setSelectedStudent(studentRecord);
            }
          }
        }

        await loadPaymentHistory();
        toast.success('Payment record deleted successfully!');
      } else {
        toast.error('Cannot delete payment without ID');
      }
    } catch (error) {
      console.error('Error deleting payment:', error);
      toast.error('Failed to delete payment. Please try again.');
    }
  };

  // Discount (₹ + %) — receipt PDF / print me tabhi dikhta hai jab discount diya ho
  const hasDiscount = (p: any) => (parseFloat(String(p?.discount)) || 0) > 0;
  const discountText = (p: any) => `₹${p.discount} (${discountPercent(p.totalAmount, p.discount)}%)`;
  const discountRow = (p: any) => hasDiscount(p)
    ? `<div class="row"><div class="label">Discount:</div><div class="value" style="color:#15803d;font-weight:bold;">${discountText(p)}</div></div>`
    : '';

  const handlePrint = async (payment: any) => {
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      return new Date(dateString).toLocaleDateString('en-GB');
    };
    const studentName = payment.name || selectedStudent?.name || 'Student';
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${studentName} - Payment Receipt</title>
        <style>
          body { font-family: Arial, sans-serif; padding: 40px; max-width: 800px; margin: 0 auto; }
          .header { background-color: #E8630A; padding: 20px; text-align: center; margin-bottom: 30px; color: white; }
          .header h1 { margin: 0; color: white; }
          .section { margin-bottom: 20px; }
          .section h2 { background-color: #FCE6D4; padding: 10px; margin-bottom: 10px; }
          .row { display: flex; padding: 8px 0; border-bottom: 1px solid #eee; }
          .label { font-weight: bold; width: 200px; }
          .value { flex: 1; }
        </style>
      </head>
      <body>
        ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Payment Receipt')}
        <div class="section">
          <h2>Student Information</h2>
          <div class="row"><div class="label">Registration No:</div><div class="value">${payment.regNo}</div></div>
          <div class="row"><div class="label">Student Name:</div><div class="value">${studentName}</div></div>
          <div class="row"><div class="label">Payment Date:</div><div class="value">${formatDate(payment.paymentDate)}</div></div>
        </div>
        <div class="section">
          <h2>Session Information</h2>
          <div class="row"><div class="label">Session Date:</div><div class="value">${formatDate(payment.sessionDate)}</div></div>
          <div class="row"><div class="label">Duration:</div><div class="value">${payment.duration} ${payment.durationType}</div></div>
          <div class="row"><div class="label">Session Expiry Date:</div><div class="value">${formatDate(payment.sessionExpiryDate)}</div></div>
        </div>
        <div class="section">
          <h2>Payment Information</h2>
          ${payment.isDuesPayment ? `
          <div class="row"><div class="label">Dues Amount:</div><div class="value">₹${payment.totalAmount}</div></div>
          ${discountRow(payment)}
          <div class="row"><div class="label">Dues Collect Amount:</div><div class="value">₹${payment.paidAmount}</div></div>
          <div class="row"><div class="label">Dues Remaining:</div><div class="value" style="color: ${(parseFloat(payment.dues) || 0) > 0 ? '#c00' : 'green'}; font-weight: bold;">₹${payment.dues}</div></div>
          ` : `
          <div class="row"><div class="label">Total Amount:</div><div class="value">₹${payment.totalAmount}</div></div>
          ${discountRow(payment)}
          <div class="row"><div class="label">Paid Amount:</div><div class="value">₹${payment.paidAmount}</div></div>
          <div class="row"><div class="label">Dues:</div><div class="value">₹${payment.dues}</div></div>
          `}
          ${(parseFloat(payment.dues) || 0) > 0 && payment.duesDate ? `<div class="row"><div class="label">Pay Dues By:</div><div class="value" style="color:#c00;font-weight:bold;">${formatDate(payment.duesDate)}</div></div>` : ''}
          <div class="row"><div class="label">Payment Mode:</div><div class="value">${payment.paymentMode}</div></div>
        </div>
        ${buildBrandingFooter({ businessName, businessPhone }, 'payment')}
      </body>
      </html>
    `;
    await printDocument(html, `${studentName}_Payment_Receipt`);
  };

  const handleWhatsApp = (payment: any) => {
    if (!selectedStudent?.mobile) {
      toast.error('Mobile number not found!');
      return;
    }
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      return new Date(dateString).toLocaleDateString('en-GB');
    };
    const message =
`*${businessName.toUpperCase()}*
*Payment Receipt*

*Student Details:*
Name: ${payment.name || selectedStudent.name}
Reg No: ${payment.regNo}

*Payment Details:*
Payment Date: ${formatDate(payment.paymentDate)}
Session Date: ${formatDate(payment.sessionDate)}
Duration: ${payment.duration} ${payment.durationType}
${payment.isDuesPayment ? `Dues Amount: ₹${payment.totalAmount}${hasDiscount(payment) ? `\nDiscount: ${discountText(payment)}` : ''}
Dues Collect Amount: ₹${payment.paidAmount}
Dues Remaining: ₹${payment.dues}` : `Total Amount: ₹${payment.totalAmount}${hasDiscount(payment) ? `\nDiscount: ${discountText(payment)}` : ''}
Paid Amount: ₹${payment.paidAmount}
Dues: ₹${payment.dues}`}${(parseFloat(payment.dues) || 0) > 0 && payment.duesDate ? `\nPay Dues By: ${formatDate(payment.duesDate)}` : ''}
Payment Mode: ${payment.paymentMode}
Expiry Date: ${formatDate(payment.sessionExpiryDate)}

Thank you for your payment!`;
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/91${selectedStudent.mobile}?text=${encodedMessage}`, '_blank');
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  return (
    <div className="p-3 sm:p-6 space-y-4 sm:space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Fees Management</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Section */}
          <div className="flex gap-2">
            <Input
              placeholder="Search by Name, Reg No, Mobile, or Alternate Mobile..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            />
            <Button onClick={handleSearch}>
              <Search className="w-4 h-4 mr-2" />
              Search
            </Button>
          </div>

          {/* Student Details */}
          {selectedStudent && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-gray-50 rounded-lg">
                <div><p className="text-gray-500">Reg No</p><p>{selectedStudent.regNo}</p></div>
                <div><p className="text-gray-500">Name</p><p>{selectedStudent.name}</p></div>
                <div><p className="text-gray-500">Mobile</p><p>{selectedStudent.mobile}</p></div>
                <div><p className="text-gray-500">Category</p><p>{selectedStudent.category}</p></div>
                <div><p className="text-gray-500">Sub Category</p><p>{selectedStudent.subCategory || 'N/A'}</p></div>
                <div><p className="text-gray-500">Batch Time</p><p>{selectedStudent.batchTime}</p></div>
                <div><p className="text-gray-500">Location</p><p>{selectedStudent.location || 'N/A'}</p></div>
                <div><p className="text-gray-500">Admission Date</p><p>{formatDate(selectedStudent.admissionDate)}</p></div>
                <div><p className="text-gray-500">Duration</p><p>{selectedStudent.duration ? `${selectedStudent.duration} ${selectedStudent.durationType}` : 'N/A'}</p></div>
                <div>
                  <p className="text-gray-500">Expiry Date</p>
                  <p className={new Date(selectedStudent.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>
                    {formatDate(selectedStudent.expiryDate)}
                  </p>
                </div>
                {Number(selectedStudent.discountAmount) > 0 && (
                  <div>
                    <p className="text-gray-500">Discount</p>
                    <p className="text-green-700">₹{selectedStudent.discountAmount} ({discountPercent(selectedStudent.totalAmount, selectedStudent.discountAmount)}%)</p>
                  </div>
                )}
              </div>

              {/* Dues breakdown: Admission / Fees / Extra Charge — admin ko clear dikhe kis cheez ka dues hai */}
              {(() => {
                const split = splitDues(selectedStudent, paymentHistory.length > 0);
                const sep = hasSeparateExtras(selectedStudent);
                const extras: any[] = sep && Array.isArray(selectedStudent.extraCharges) ? selectedStudent.extraCharges : [];
                const extraDues = sep ? sumExtraDues(extras) : 0;
                const classDues = Math.max(0, Number(selectedStudent.dues) || 0);
                const overdue = isDuesDateOver(selectedStudent.duesDate, selectedStudent.dues);
                const hasClassDues = classDues > 0;
                return (
                  <div className="rounded-lg border p-4 space-y-4">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <h3 className="font-semibold">Dues Details</h3>
                      <p className="text-sm">Total Dues: <span className={`font-bold ${classDues + extraDues > 0 ? 'text-red-600' : 'text-green-600'}`}>₹{classDues + extraDues}</span></p>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div className={`rounded-lg border p-3 ${split.admission > 0 ? 'bg-red-50 border-red-200' : 'bg-gray-50'}`}>
                        <p className="text-xs text-gray-500">Admission Dues</p>
                        <p className={`text-lg font-bold ${split.admission > 0 ? 'text-red-600' : 'text-green-600'}`}>₹{split.admission}</p>
                      </div>
                      <div className={`rounded-lg border p-3 ${split.monthly > 0 ? 'bg-red-50 border-red-200' : 'bg-gray-50'}`}>
                        <p className="text-xs text-gray-500">Fees Dues (Monthly / Renewal)</p>
                        <p className={`text-lg font-bold ${split.monthly > 0 ? 'text-red-600' : 'text-green-600'}`}>₹{split.monthly}</p>
                      </div>
                      <div className={`rounded-lg border p-3 ${extraDues > 0 ? 'bg-yellow-50 border-yellow-300' : 'bg-gray-50'}`}>
                        <p className="text-xs text-gray-500">Extra Charge Dues</p>
                        <p className={`text-lg font-bold ${extraDues > 0 ? 'text-yellow-700' : 'text-green-600'}`}>{sep ? `₹${extraDues}` : '—'}</p>
                      </div>
                    </div>

                    {hasClassDues && (
                      <div className="flex flex-wrap items-center gap-2 text-sm">
                        {selectedStudent.duesDate && (
                          <span className={overdue ? 'text-red-600 font-semibold' : 'text-orange-600'}>
                            Pay by {formatDate(selectedStudent.duesDate)}{overdue ? ' (date nikal gayi)' : ''}
                          </span>
                        )}
                        <Button size="sm" variant="outline" onClick={() => { toast.info(`Student ${selectedStudent.name} has pending dues of ₹${selectedStudent.dues}.`, { duration: 5000 }); handleUpdateDues(); }} className="bg-orange-50 border-orange-300 hover:bg-orange-100">
                          Update ({split.admission > 0 ? 'Admission' : 'Fees'} Dues collect)
                        </Button>
                      </div>
                    )}

                    {(sep || !(Array.isArray(selectedStudent.extraCharges) && selectedStudent.extraCharges.length > 0)) && (
                      <div className="rounded-lg border border-yellow-300 bg-yellow-50/50 p-3 space-y-2">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <p className="text-sm font-semibold">Extra Charges (class fee se alag)</p>
                          <Button size="sm" variant="outline" className="border-yellow-500 text-yellow-800 hover:bg-yellow-100" onClick={openExtraAdd}>
                            <Plus className="w-3 h-3 mr-1" />Add Extra Charge
                          </Button>
                        </div>
                        {extras.length === 0 && (
                          <p className="text-xs text-gray-500">Koi extra charge nahi hai. Jab bhi koi naya charge lena ho (jaise AC charge) to "Add Extra Charge" dabao.</p>
                        )}
                        {extras.length > 0 && (
                        <div className="overflow-x-auto">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>Charge</TableHead>
                                <TableHead>Amount</TableHead>
                                <TableHead>Paid</TableHead>
                                <TableHead>Dues</TableHead>
                                <TableHead></TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {extras.map((c, i) => {
                                const d = extraChargeDues(c);
                                return (
                                  <TableRow key={i}>
                                    <TableCell>{c.name}</TableCell>
                                    <TableCell>₹{c.amount}</TableCell>
                                    <TableCell>₹{parseFloat(String(c.paid)) || 0}</TableCell>
                                    <TableCell className={d > 0 ? 'text-red-600 font-semibold' : 'text-green-600'}>₹{d}</TableCell>
                                    <TableCell>
                                      <div className="flex items-center gap-2">
                                        {d > 0 ? (
                                          <Button size="sm" variant="outline" className="border-yellow-500 text-yellow-800 hover:bg-yellow-100" onClick={() => openExtraCollect(i)}>Collect</Button>
                                        ) : <span className="text-xs text-green-600">Paid ✓</span>}
                                        <Button size="sm" variant="outline" title="Edit charge" onClick={() => openExtraEdit(i)}><Pencil className="w-3 h-3" /></Button>
                                      </div>
                                    </TableCell>
                                  </TableRow>
                                );
                              })}
                            </TableBody>
                          </Table>
                        </div>
                        )}
                        {extras.length > 0 && <p className="text-xs text-gray-600">Total ₹{sumExtraCharges(extras)} · Paid ₹{sumExtraPaid(extras)} · Dues ₹{extraDues}</p>}
                      </div>
                    )}
                  </div>
                );
              })()}

              <Button onClick={handleAddPayment}>
                <Plus className="w-4 h-4 mr-2" />
                Add Payment
              </Button>

              {/* Payment History */}
              <div>
                <h3 className="mb-4">Payment History</h3>
                {paymentHistory.length > 0 ? (
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Payment Date</TableHead>
                          <TableHead>Duration</TableHead>
                          <TableHead>Total Amount</TableHead>
                          <TableHead>Paid Amount</TableHead>
                          <TableHead>Dues</TableHead>
                          <TableHead>Session Date</TableHead>
                          <TableHead>Session Expiry</TableHead>
                          <TableHead>Payment Mode</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paymentHistory.map((payment, index) => (
                          <TableRow key={index}>
                            <TableCell>{formatDate(payment.paymentDate)}</TableCell>
                            <TableCell>{payment.duration} {payment.durationType}</TableCell>
                            <TableCell>₹{payment.totalAmount}{hasDiscount(payment) && <span className="block text-xs text-green-700">Discount ₹{payment.discount} ({discountPercent(payment.totalAmount, payment.discount)}%)</span>}{payment.isDuesPayment && <span className="block text-xs text-orange-600">(Dues Payment)</span>}</TableCell>
                            <TableCell>₹{payment.paidAmount}</TableCell>
                            <TableCell>
                              ₹{payment.dues}
                              {(parseFloat(payment.dues) || 0) > 0 && payment.duesDate && (
                                <span className={`block text-xs ${isDuesDateOver(payment.duesDate, payment.dues) ? 'text-red-600' : 'text-orange-600'}`}>Pay by {formatDate(payment.duesDate)}</span>
                              )}
                            </TableCell>
                            <TableCell>{formatDate(payment.sessionDate)}</TableCell>
                            <TableCell>{formatDate(payment.sessionExpiryDate)}</TableCell>
                            <TableCell>{payment.paymentMode}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button size="sm" variant="outline" onClick={() => handlePrint(payment)}><FileText className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleEditPayment(payment)}><Edit className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleWhatsApp(payment)}><MessageCircle className="w-3 h-3" /></Button>
                                <Button size="sm" variant="outline" onClick={() => handleDeletePayment(payment)}><Trash2 className="w-3 h-3" /></Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                ) : (
                  <p className="text-center text-gray-500 py-8">No payment history found</p>
                )}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Mahine ka collection calendar — search section ke neeche */}
      <FeesCalendar refreshToken={paymentHistory} />

      {/* Extra Charge collect dialog */}
      <Dialog open={!!extraCollect} onOpenChange={(o) => { if (!o) setExtraCollect(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Collect Extra Charge</DialogTitle></DialogHeader>
          {extraCollect && selectedStudent && (() => {
            const c = (selectedStudent.extraCharges || [])[extraCollect.index];
            if (!c) return null;
            const due = Math.max(0, extraChargeDues(c));
            return (
              <div className="space-y-4">
                <div className="rounded-lg bg-yellow-50 border border-yellow-300 p-3 text-sm">
                  <p><b>{selectedStudent.name}</b> (Reg {selectedStudent.regNo})</p>
                  <p>{c.name}: ₹{c.amount} · Paid ₹{parseFloat(String(c.paid)) || 0} · <span className="text-red-600 font-semibold">Dues ₹{due}</span></p>
                </div>
                <div>
                  <Label>Amount (₹)</Label>
                  <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                    <Input type="number" min="0" className="pl-8" value={extraCollect.amount} onChange={(e) => setExtraCollect({ ...extraCollect, amount: e.target.value })} />
                  </div>
                </div>
                <div>
                  <Label>Payment Date</Label>
                  <Input type="date" value={extraCollect.date} onChange={(e) => setExtraCollect({ ...extraCollect, date: e.target.value })} />
                </div>
                <div>
                  <Label>Payment Mode *</Label>
                  <Select value={extraCollect.mode} onValueChange={(v) => setExtraCollect({ ...extraCollect, mode: v })}>
                    <SelectTrigger><SelectValue placeholder="Select payment mode" /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Cash">Cash</SelectItem>
                      <SelectItem value="Online">Online</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setExtraCollect(null)}>Cancel</Button>
                  <Button onClick={saveExtraCollect}>Save Payment</Button>
                </div>
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* Extra Charge add / edit dialog */}
      <Dialog open={!!extraEdit} onOpenChange={(o) => { if (!o) setExtraEdit(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>{extraEdit?.mode === 'add' ? 'Add Extra Charge' : 'Edit Extra Charge'}</DialogTitle></DialogHeader>
          {extraEdit && selectedStudent && (
            <div className="space-y-4">
              <div className="rounded-lg bg-yellow-50 border border-yellow-300 p-3 text-sm">
                <b>{selectedStudent.name}</b> (Reg {selectedStudent.regNo})
              </div>
              <div>
                <Label>Charge Name *</Label>
                <Input value={extraEdit.name} onChange={(e) => setExtraEdit({ ...extraEdit, name: e.target.value })} placeholder="e.g. AC Charge" />
                {extraEdit.mode === 'add' && (
                  <div className="flex flex-wrap gap-2 mt-2">
                    {['AC Charge', 'Dress Charge', 'ID Card Charge', 'Shoes Charge'].map((n) => (
                      <button key={n} type="button" className="text-xs px-2 py-1 rounded-full border border-yellow-400 text-yellow-800 hover:bg-yellow-100" onClick={() => setExtraEdit({ ...extraEdit, name: n })}>{n}</button>
                    ))}
                  </div>
                )}
              </div>
              <div>
                <Label>Charge Amount (₹) *</Label>
                <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" min="0" className="pl-8" value={extraEdit.amount} onChange={(e) => setExtraEdit({ ...extraEdit, amount: e.target.value })} placeholder="0" />
                </div>
              </div>
              {extraEdit.mode === 'edit' && (
                <>
                  <div>
                    <Label>Paid Amount (₹)</Label>
                    <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                      <Input type="number" min="0" className="pl-8" value={extraEdit.paid} onChange={(e) => setExtraEdit({ ...extraEdit, paid: e.target.value })} placeholder="0" />
                    </div>
                  </div>
                  {(parseFloat(extraEdit.paid) || 0) > (parseFloat(extraEdit.origPaid) || 0) && (
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <Label>Payment Date</Label>
                        <Input type="date" value={extraEdit.date} onChange={(e) => setExtraEdit({ ...extraEdit, date: e.target.value })} />
                      </div>
                      <div>
                        <Label>Payment Mode *</Label>
                        <Select value={extraEdit.payMode} onValueChange={(v) => setExtraEdit({ ...extraEdit, payMode: v })}>
                          <SelectTrigger><SelectValue placeholder="Mode" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Cash">Cash</SelectItem>
                            <SelectItem value="Online">Online</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  )}
                </>
              )}
              {(() => {
                const total = parseFloat(extraEdit.amount) || 0;
                const paid = extraEdit.mode === 'add' ? Math.max(0, parseFloat(extraEdit.paid) || 0) : (parseFloat(extraEdit.paid) || 0);
                const dues = Math.max(0, total - paid);
                const pct = total > 0 ? Math.min(100, Math.round((paid / total) * 100)) : 0;
                return (
                  <div className="rounded-lg border p-3 space-y-2">
                    <div className="grid grid-cols-3 gap-2 text-center">
                      <div className="rounded-md bg-gray-50 border p-2"><p className="text-xs text-gray-500">Total Amount</p><p className="font-bold">₹{total}</p></div>
                      <div className="rounded-md bg-green-50 border border-green-200 p-2"><p className="text-xs text-gray-500">Paid Amount</p><p className="font-bold text-green-700">₹{paid}</p></div>
                      <div className={`rounded-md border p-2 ${dues > 0 ? 'bg-red-50 border-red-200' : 'bg-green-50 border-green-200'}`}><p className="text-xs text-gray-500">Dues Amount</p><p className={`font-bold ${dues > 0 ? 'text-red-600' : 'text-green-700'}`}>₹{dues}</p></div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-gray-600 mb-1"><span>Kitna fill hua</span><span className="font-semibold">{pct}% (₹{paid} / ₹{total})</span></div>
                      <div className="h-2 rounded-full bg-gray-200 overflow-hidden"><div className="h-full bg-green-500 transition-all" style={{ width: `${pct}%` }} /></div>
                    </div>
                  </div>
                );
              })()}
              {extraEdit.mode === 'add' && (
                <>
                  <div>
                    <Label>Abhi collect kiya (₹) <span className="text-gray-400 text-xs">(Optional)</span></Label>
                    <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                      <Input type="number" min="0" className="pl-8" value={extraEdit.paid} onChange={(e) => setExtraEdit({ ...extraEdit, paid: e.target.value })} placeholder="0" />
                    </div>
                  </div>
                  {(parseFloat(extraEdit.paid) || 0) > 0 && (
                    <>
                      <div>
                        <Label>Payment Date</Label>
                        <Input type="date" value={extraEdit.date} onChange={(e) => setExtraEdit({ ...extraEdit, date: e.target.value })} />
                      </div>
                      <div>
                        <Label>Payment Mode *</Label>
                        <Select value={extraEdit.payMode} onValueChange={(v) => setExtraEdit({ ...extraEdit, payMode: v })}>
                          <SelectTrigger><SelectValue placeholder="Select payment mode" /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="Cash">Cash</SelectItem>
                            <SelectItem value="Online">Online</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </>
                  )}
                </>
              )}
              <div className="flex justify-between gap-2">
                <div>
                  {extraEdit.mode === 'edit' && (parseFloat(extraEdit.origPaid) || 0) === 0 && (
                    <Button variant="outline" className="text-red-600 border-red-300 hover:bg-red-50" onClick={deleteExtraCharge}><Trash2 className="w-4 h-4 mr-1" />Delete</Button>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setExtraEdit(null)}>Cancel</Button>
                  <Button onClick={saveExtraEdit}>{extraEdit.mode === 'add' ? 'Add Charge' : 'Save'}</Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment Form Dialog */}
      <Dialog open={showPaymentForm} onOpenChange={setShowPaymentForm}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editingPayment ? 'Edit Payment' : 'Add Payment'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded">
              <h3>Student Information</h3>
              <p>Reg No: {selectedStudent?.regNo}</p>
              <p>Name: {selectedStudent?.name}</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label>Payment Date *</Label>
                <Input type="date" value={paymentData.paymentDate} onChange={(e) => setPaymentData({...paymentData, paymentDate: e.target.value})} />
              </div>
              <div>
                <Label>Session Date *</Label>
                <Input type="date" value={paymentData.sessionDate} onChange={(e) => setPaymentData({...paymentData, sessionDate: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label>Duration *</Label>
                <Input type="number" value={paymentData.duration} onChange={(e) => setPaymentData({...paymentData, duration: e.target.value})} placeholder="Enter duration" min="1" />
              </div>
              <div>
                <Label>Duration Type *</Label>
                <Select value={paymentData.durationType} onValueChange={(value) => setPaymentData({...paymentData, durationType: value})}>
                  <SelectTrigger><SelectValue placeholder="Select duration type" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Days">Days</SelectItem>
                    <SelectItem value="Month">Month</SelectItem>
                    <SelectItem value="Year">Year</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Session Expiry Date</Label>
                <Input type="date" value={paymentData.sessionExpiryDate} disabled />
              </div>
            </div>
            <div className={`grid grid-cols-1 gap-4 ${showDiscount ? 'md:grid-cols-4' : 'md:grid-cols-3'}`}>
              <div>
                <Label>{payingDuesRef.current ? 'Dues Amount *' : 'Total Amount *'}</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.totalAmount} onChange={(e) => setPaymentData({...paymentData, totalAmount: e.target.value})} placeholder="0" className="pl-8" min="0" />
                </div>
              </div>
              {showDiscount && (
                <div>
                  <Label className="text-green-700">Discount (₹)</Label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5">₹</span>
                    <Input type="number" value={(paymentData as any).discount ?? ''} onChange={(e) => setPaymentData({...paymentData, discount: e.target.value} as any)} placeholder="0" className="pl-8 border-green-300" min="0" />
                  </div>
                  {discountPercent(paymentData.totalAmount, (paymentData as any).discount) > 0 && (
                    <p className="text-xs text-green-700 font-semibold mt-1">Discount {discountPercent(paymentData.totalAmount, (paymentData as any).discount)}%</p>
                  )}
                </div>
              )}
              <div>
                <Label>Paid Amount *</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.paidAmount} onChange={(e) => setPaymentData({...paymentData, paidAmount: e.target.value})} placeholder="0" className="pl-8" min="0" />
                </div>
              </div>
              <div>
                <Label>Dues</Label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" value={paymentData.dues} disabled className="pl-8" />
                </div>
              </div>
            </div>
            {/* Discount button: monthly payment / dues update dono me admin discount de sakta hai */}
            <div>
              {!showDiscount ? (
                <Button type="button" size="sm" variant="outline" className="border-green-300 text-green-700 hover:bg-green-50" onClick={() => setShowDiscount(true)}>
                  <Plus className="w-3 h-3 mr-1" />
                  Add Discount
                </Button>
              ) : (
                <Button type="button" size="sm" variant="ghost" className="text-red-600 hover:bg-red-50" onClick={() => { setShowDiscount(false); setPaymentData({...paymentData, discount: ''} as any); }}>
                  Remove Discount
                </Button>
              )}
            </div>
            {/* Dues Date (optional): "Update" button se khulne par (student ka dues ho) hamesha dikhta hai, purani date autofill hoti hai.
                Add Payment me sirf tab dikhta hai jab is payment ke baad dues bachega. */}
            {(((parseFloat(paymentData.totalAmount) || 0) - (parseFloat(paymentData.paidAmount) || 0) > 0) ||
              (payingDuesRef.current && !editingPayment && (parseFloat(selectedStudent?.dues) || 0) > 0)) && (
              <div className="md:w-1/2">
                <Label className="whitespace-nowrap">Pay Dues By (Dues Date) <span className="text-gray-400 text-xs">(Optional)</span></Label>
                <Input type="date" value={paymentData.duesDate || ''} onChange={(e) => setPaymentData({...paymentData, duesDate: e.target.value})} />
                {(parseFloat(paymentData.totalAmount) || 0) - (parseFloat(paymentData.paidAmount) || 0) <= 0 && (
                  <p className="text-xs text-gray-500 mt-1">Poora dues pay hone par date apne aap hat jayegi.</p>
                )}
              </div>
            )}
            <div>
              <Label>Payment Mode *</Label>
              <div className="flex gap-4 mt-2">
                {['Cash', 'Online'].map((mode) => (
                  <div key={mode} className="flex items-center gap-2">
                    <Checkbox checked={paymentData.paymentMode === mode} onCheckedChange={() => setPaymentData({...paymentData, paymentMode: mode})} />
                    <span>{mode}</span>
                  </div>
                ))}
              </div>
            </div>
            <Button onClick={handleSavePayment} className="w-full">
              {editingPayment ? 'Update Payment' : 'Save Payment & Generate Receipt'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Summary Dialog */}
      <Dialog open={showPaymentSummary} onOpenChange={setShowPaymentSummary}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Payment Summary</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-green-50 rounded">
              <h3 className="text-green-600 mb-2">Payment Saved Successfully!</h3>
              <div className="space-y-2">
                <p>Student: {savedPayment?.name}</p>
                <p>Reg No: {savedPayment?.regNo}</p>
                {hasDiscount(savedPayment) && <p className="text-green-700">Discount: {discountText(savedPayment)}</p>}
                <p>Amount Paid: ₹{savedPayment?.paidAmount}</p>
                <p>Session Expiry: {formatDate(savedPayment?.sessionExpiryDate)}</p>
              </div>
            </div>
            <div className="flex gap-2">
              <Button onClick={() => handleWhatsApp(savedPayment)} className="flex-1">
                <MessageCircle className="w-4 h-4 mr-2" />
                WhatsApp
              </Button>
              <Button onClick={() => handlePrint(savedPayment)} variant="outline" className="flex-1">
                <FileText className="w-4 h-4 mr-2" />
                Print
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
