import { useEffect, useMemo, useState } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Plus, Pencil, Trash2, Repeat, CalendarClock, CheckCircle2, Undo2 } from 'lucide-react';
import { toast } from 'sonner';
import {
  Expense, ExpenseOccurrence, getExpenses, saveExpenses, occurrencesForMonth, newExpenseId, monthKey, toYmd,
} from '../lib/expenses';

const inr = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
const fmtDate = (d: string) => {
  const [y, m, day] = d.split('-').map(Number);
  return new Date(y, m - 1, day).toLocaleDateString('en-GB');
};
const QUICK_NAMES = ['Teacher Payment', 'Studio Rent', 'Water Bill', 'Electricity Bill'];

interface FormState { id?: string; name: string; amount: string; date: string; recurring: boolean }

/**
 * Monthly Collection ke saath "Expenses" view: admin apne kharche (teacher payment, studio rent, bill...)
 * khud add karta hai. "Hamesha (har mahine)" chunne par wo har mahine us tareekh par apne aap aata rehta hai;
 * "Sirf is mahine" chunne par bas ek mahine ka. Due date se 3 din pehle Dashboard par warning aati hai.
 */
export function ExpenseManager({ year, month, collected }: { year: number; month: number; collected: number }) {
  const [list, setList] = useState<Expense[]>([]);
  const [form, setForm] = useState<FormState | null>(null);
  const [deleting, setDeleting] = useState<ExpenseOccurrence | null>(null);

  const mk = monthKey(year, month);
  const todayStr = toYmd(new Date());

  const load = async () => setList(await getExpenses());
  useEffect(() => {
    load();
    const h = () => { load(); };
    window.addEventListener('expensesUpdated', h);
    return () => window.removeEventListener('expensesUpdated', h);
  }, []);

  const occ = useMemo(() => occurrencesForMonth(list, mk), [list, mk]);
  const totals = useMemo(() => {
    const total = occ.reduce((s, o) => s + o.amount, 0);
    const paid = occ.filter((o) => o.isPaid).reduce((s, o) => s + o.amount, 0);
    return { total, paid, pending: total - paid };
  }, [occ]);

  const persist = async (next: Expense[]) => {
    setList(next);
    await saveExpenses(next);
  };

  const defaultDate = () => {
    const now = new Date();
    return (now.getFullYear() === year && now.getMonth() === month) ? toYmd(now) : `${mk}-01`;
  };

  const openAdd = () => setForm({ name: '', amount: '', date: defaultDate(), recurring: false });
  const openEdit = (o: ExpenseOccurrence) => setForm({
    id: o.expense.id,
    name: o.expense.name,
    amount: String(o.expense.amount),
    date: o.dueDate,
    recurring: o.expense.recurring,
  });

  const saveForm = async () => {
    if (!form) return;
    const name = form.name.trim();
    const amount = parseFloat(form.amount);
    if (!name) { toast.error('Kharche ka naam likho (jaise Studio Rent)'); return; }
    if (!amount || amount <= 0) { toast.error('Sahi amount daalo'); return; }
    if (!form.date) { toast.error('Date chuno'); return; }
    const day = Number(form.date.slice(8, 10)) || 1;
    if (form.id) {
      await persist(list.map((e) => e.id !== form.id ? e : {
        ...e,
        name, amount,
        recurring: form.recurring,
        dueDay: day,
        date: form.date,
        startMonth: form.recurring ? (e.recurring ? e.startMonth : form.date.slice(0, 7)) : e.startMonth,
        endMonth: form.recurring ? e.endMonth : undefined,
      }));
      toast.success('Expense update ho gaya');
    } else {
      const exp: Expense = {
        id: newExpenseId(), name, amount,
        recurring: form.recurring,
        dueDay: day,
        date: form.date,
        startMonth: form.date.slice(0, 7),
        paid: {},
        createdAt: new Date().toISOString(),
      };
      await persist([...list, exp]);
      toast.success(form.recurring ? `${name} har mahine ke liye set ho gaya` : `${name} is mahine ke liye add ho gaya`);
    }
    setForm(null);
  };

  const markPaid = async (o: ExpenseOccurrence) => {
    await persist(list.map((e) => e.id !== o.expense.id ? e : {
      ...e, paid: { ...e.paid, [o.month]: { paidDate: todayStr, amount: o.amount } },
    }));
    toast.success(`${o.expense.name} paid mark ho gaya`);
  };
  const undoPaid = async (o: ExpenseOccurrence) => {
    await persist(list.map((e) => {
      if (e.id !== o.expense.id) return e;
      const paid = { ...e.paid };
      delete paid[o.month];
      return { ...e, paid };
    }));
  };

  const deleteAll = async (o: ExpenseOccurrence) => {
    await persist(list.filter((e) => e.id !== o.expense.id));
    setDeleting(null);
    toast.success('Expense delete ho gaya');
  };
  const stopFromThisMonth = async (o: ExpenseOccurrence) => {
    const [y, m] = o.month.split('-').map(Number);
    const prev = new Date(y, m - 2, 1);
    const prevKey = monthKey(prev.getFullYear(), prev.getMonth());
    if (prevKey < o.expense.startMonth) return deleteAll(o);
    await persist(list.map((e) => e.id !== o.expense.id ? e : { ...e, endMonth: prevKey }));
    setDeleting(null);
    toast.success(`${o.expense.name} ab is mahine se aage nahi aayega`);
  };

  const statusOf = (o: ExpenseOccurrence) => {
    if (o.isPaid) return { text: `Paid ${o.paidDate ? fmtDate(o.paidDate) : ''}`, cls: 'text-green-700 bg-green-100' };
    if (o.dueDate < todayStr) return { text: 'Date nikal gayi', cls: 'text-red-700 bg-red-100' };
    const [y, m, d] = o.dueDate.split('-').map(Number);
    const t = new Date(); const base = new Date(t.getFullYear(), t.getMonth(), t.getDate());
    const left = Math.round((new Date(y, m - 1, d).getTime() - base.getTime()) / 86400000);
    if (left === 0) return { text: 'Aaj dena hai', cls: 'text-orange-700 bg-orange-100' };
    return { text: `${left} din baaki`, cls: left <= 3 ? 'text-orange-700 bg-orange-100' : 'text-gray-700 bg-gray-100' };
  };

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="rounded-xl border bg-red-50 px-3 py-2"><p className="text-xs text-gray-500">Total Expense</p><p className="text-lg font-bold text-red-700">{inr(totals.total)}</p><p className="text-[11px] text-gray-500">{occ.length} kharche</p></div>
        <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Paid</p><p className="font-semibold text-green-700">{inr(totals.paid)}</p></div>
        <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Baaki (Pending)</p><p className="font-semibold text-orange-600">{inr(totals.pending)}</p></div>
        <div className="rounded-xl border bg-white px-3 py-2"><p className="text-xs text-gray-500">Collection − Paid Expense</p><p className={`font-semibold ${collected - totals.paid >= 0 ? 'text-green-700' : 'text-red-600'}`}>{inr(collected - totals.paid)}</p></div>
      </div>

      <div className="flex justify-end">
        <Button onClick={openAdd}><Plus className="w-4 h-4 mr-1.5" /> Add Expense</Button>
      </div>

      {occ.length === 0 ? (
        <p className="text-center text-sm text-gray-500 py-8">Is mahine koi expense nahi hai. "Add Expense" se studio rent, teacher payment ya bill jodo.</p>
      ) : (
        <div className="space-y-2">
          {occ.map((o) => {
            const st = statusOf(o);
            return (
              <div key={o.key} className="flex flex-wrap items-center justify-between gap-3 rounded-lg border px-3 py-2.5">
                <div className="min-w-0">
                  <p className="font-medium truncate">{o.expense.name}</p>
                  <p className="text-xs text-gray-500 flex flex-wrap items-center gap-1.5 mt-0.5">
                    <span className="inline-flex items-center gap-1"><CalendarClock className="w-3.5 h-3.5" /> {fmtDate(o.dueDate)}</span>
                    {o.expense.recurring
                      ? <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-purple-100 text-purple-700 font-semibold"><Repeat className="w-3 h-3" /> Har mahine</span>
                      : <span className="px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-700 font-semibold">Sirf is mahine</span>}
                    <span className={`px-1.5 py-0.5 rounded-full font-semibold ${st.cls}`}>{st.text}</span>
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <p className="font-bold text-red-700 mr-1">{inr(o.amount)}</p>
                  {o.isPaid ? (
                    <Button size="sm" variant="outline" onClick={() => undoPaid(o)} title="Paid hatao"><Undo2 className="w-3.5 h-3.5 mr-1" /> Undo</Button>
                  ) : (
                    <Button size="sm" variant="outline" className="border-green-600 text-green-700 hover:bg-green-50" onClick={() => markPaid(o)}><CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Paid</Button>
                  )}
                  <Button size="icon" variant="outline" onClick={() => openEdit(o)} title="Edit"><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="outline" onClick={() => setDeleting(o)} title="Delete"><Trash2 className="w-4 h-4 text-red-500" /></Button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Add / Edit */}
      <Dialog open={!!form} onOpenChange={(o) => { if (!o) setForm(null); }}>
        <DialogContent className="w-[95vw] sm:max-w-md">
          <DialogHeader><DialogTitle>{form?.id ? 'Edit Expense' : 'Add Expense'}</DialogTitle></DialogHeader>
          {form && (
            <div className="space-y-4">
              <div>
                <Label>Expense Name</Label>
                <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="e.g. Studio Rent" />
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {QUICK_NAMES.map((n) => (
                    <button key={n} type="button" onClick={() => setForm({ ...form, name: n })} className="px-2.5 py-1 rounded-full border border-dashed border-purple-400 text-xs font-semibold text-purple-800 hover:bg-purple-50">{n}</button>
                  ))}
                </div>
              </div>
              <div>
                <Label>Amount (₹)</Label>
                <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                  <Input type="number" min="0" className="pl-8" value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0" />
                </div>
              </div>
              <div>
                <Label>Kis date ko dena hota hai</Label>
                <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
                <p className="text-xs text-gray-500 mt-1">Is date se 3 din pehle Dashboard par warning dikhegi.</p>
              </div>
              <div>
                <Label>Kab tak?</Label>
                <div className="grid grid-cols-1 gap-2 mt-1">
                  <button type="button" onClick={() => setForm({ ...form, recurring: true })} className={`text-left rounded-lg border px-3 py-2 text-sm ${form.recurring ? 'border-purple-500 bg-purple-50' : 'bg-white'}`}>
                    <b>Hamesha ke liye set rakho</b><br /><span className="text-xs text-gray-600">Har mahine isi tareekh par apne aap aata rahega</span>
                  </button>
                  <button type="button" onClick={() => setForm({ ...form, recurring: false })} className={`text-left rounded-lg border px-3 py-2 text-sm ${!form.recurring ? 'border-purple-500 bg-purple-50' : 'bg-white'}`}>
                    <b>Sirf is mahine ke liye</b><br /><span className="text-xs text-gray-600">Bas ek baar, us mahine ka kharcha</span>
                  </button>
                </div>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setForm(null)}>Cancel</Button>
                <Button onClick={saveForm}>{form.id ? 'Update' : 'Save'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete */}
      <Dialog open={!!deleting} onOpenChange={(o) => { if (!o) setDeleting(null); }}>
        <DialogContent className="w-[95vw] sm:max-w-md">
          <DialogHeader><DialogTitle>Delete "{deleting?.expense.name}"?</DialogTitle></DialogHeader>
          {deleting && (
            deleting.expense.recurring ? (
              <div className="space-y-2">
                <p className="text-sm text-gray-600">Ye har mahine aane wala kharcha hai. Kya karna hai?</p>
                <Button variant="outline" className="w-full justify-start" onClick={() => stopFromThisMonth(deleting)}>Is mahine se band karo (pichle mahine ka record rahega)</Button>
                <Button variant="outline" className="w-full justify-start text-red-600 border-red-300 hover:bg-red-50" onClick={() => deleteAll(deleting)}>Poora delete karo (sab mahine se hat jayega)</Button>
                <Button variant="ghost" className="w-full" onClick={() => setDeleting(null)}>Cancel</Button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-gray-600">{inr(deleting.amount)} · {fmtDate(deleting.dueDate)}</p>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setDeleting(null)}>Cancel</Button>
                  <Button variant="destructive" onClick={() => deleteAll(deleting)}>Delete</Button>
                </div>
              </div>
            )
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
