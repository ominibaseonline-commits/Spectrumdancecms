import { useEffect, useState } from 'react';
import { Bell, AlertTriangle, CheckCircle2, X } from 'lucide-react';
import { Button } from './ui/button';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { toast } from 'sonner';
import { Expense, getExpenses, saveExpenses, upcomingReminders, toYmd } from '../lib/expenses';

type Reminder = ReturnType<typeof upcomingReminders>[number];

const fmt = (d: string) => {
  const [y, m, day] = d.split('-').map(Number);
  return new Date(y, m - 1, day).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
};
const whenText = (o: Reminder) =>
  o.daysLeft < 0 ? `${Math.abs(o.daysLeft)} din pehle dena tha (${fmt(o.dueDate)})`
  : o.daysLeft === 0 ? `aaj (${fmt(o.dueDate)}) dena hai`
  : `${o.daysLeft} din baad (${fmt(o.dueDate)}) dena hai`;

// App kholte hi sirf ek baar upar likha hua dikhe, phir bell me chala jaye (Dashboard dobara khulne par nahi)
let flashShownThisSession = false;
const FLASH_MS = 6000;

/**
 * Dashboard header ka Bell icon. Expense (studio rent, teacher payment, bill...) ki date me 3 din ya kam
 * bache hon aur paid mark na ho, to bell me aata hai. Dashboard khulte hi ek baar upar message dikhta hai,
 * kuch second baad wo bell me chala jata hai. Bell me 3 tak warning dikhti hain, zyada ho to "View all".
 */
export function ExpenseBell() {
  const [list, setList] = useState<Expense[]>([]);
  const [flash, setFlash] = useState<'hidden' | 'show' | 'leaving'>('hidden');
  const [open, setOpen] = useState(false);
  const [showAll, setShowAll] = useState(false);

  const load = async () => setList(await getExpenses());
  useEffect(() => {
    load();
    const h = () => { load(); };
    window.addEventListener('expensesUpdated', h);
    const t = setInterval(load, 60 * 60 * 1000);
    return () => { window.removeEventListener('expensesUpdated', h); clearInterval(t); };
  }, []);

  const items = upcomingReminders(list, 3);

  // Pehli baar warning mile to upar flash dikhao, phir bell me bhej do
  useEffect(() => {
    if (flashShownThisSession || items.length === 0) return;
    flashShownThisSession = true;
    setFlash('show');
    const t1 = setTimeout(() => setFlash('leaving'), FLASH_MS);
    const t2 = setTimeout(() => setFlash('hidden'), FLASH_MS + 600);
    return () => { clearTimeout(t1); clearTimeout(t2); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items.length > 0]);

  const markPaid = async (o: Reminder) => {
    const next = list.map((e) => e.id !== o.expense.id ? e : { ...e, paid: { ...e.paid, [o.month]: { paidDate: toYmd(new Date()), amount: o.amount } } });
    setList(next);
    await saveExpenses(next);
    toast.success(`${o.expense.name} paid mark ho gaya`);
  };

  const row = (o: Reminder) => {
    const overdue = o.daysLeft < 0;
    return (
      <div key={o.key} className={`rounded-lg border px-3 py-2 text-sm flex items-center justify-between gap-2 ${overdue ? 'bg-red-50 border-red-300' : 'bg-yellow-50 border-yellow-300'}`}>
        <div className="min-w-0">
          <p className="font-semibold truncate">{o.expense.name} · ₹{o.amount.toLocaleString('en-IN')}</p>
          <p className={`text-xs ${overdue ? 'text-red-700' : 'text-yellow-800'}`}>{whenText(o)}</p>
        </div>
        <Button size="sm" variant="outline" className="bg-white shrink-0" onClick={() => markPaid(o)}>
          <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Paid
        </Button>
      </div>
    );
  };

  const first = items[0];
  const flashing = flash !== 'hidden' && items.length > 0;

  return (
    <>
      {/* Upar ka flash message (sirf dashboard khulte waqt) */}
      {flashing && first && (
        <div
          className={`fixed top-3 left-1/2 z-50 w-[92vw] max-w-xl -translate-x-1/2 transition-all duration-500 ${
            flash === 'leaving' ? 'opacity-0 -translate-y-4 scale-90 sm:translate-x-[22vw]' : 'opacity-100'
          }`}
        >
          <div className={`rounded-xl border shadow-lg px-4 py-3 flex items-center gap-3 text-sm ${first.daysLeft < 0 ? 'bg-red-50 border-red-400 text-red-900' : 'bg-yellow-50 border-yellow-400 text-yellow-900'}`}>
            <AlertTriangle className={`w-5 h-5 shrink-0 ${first.daysLeft < 0 ? 'text-red-600' : 'text-yellow-600'}`} />
            <div className="min-w-0 flex-1">
              {items.length === 1 ? (
                <span><strong>{first.expense.name}</strong> ka <strong>₹{first.amount.toLocaleString('en-IN')}</strong> pay karna hai — {whenText(first)}</span>
              ) : (
                <span><strong>{items.length} expenses</strong> ka payment due hai — <strong>{first.expense.name}</strong> {whenText(first)}</span>
              )}
            </div>
            <button type="button" onClick={() => setFlash('leaving')} className="shrink-0 text-gray-500 hover:text-gray-800" aria-label="Band karo"><X className="w-4 h-4" /></button>
          </div>
        </div>
      )}

      {/* Bell */}
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <button
            type="button"
            title="Expense reminders"
            className={`relative p-2 rounded-full border bg-white hover:bg-gray-50 ${flash === 'leaving' ? 'animate-bounce' : ''}`}
          >
            <Bell className={`w-5 h-5 ${items.length > 0 ? 'text-orange-600' : 'text-gray-500'}`} />
            {items.length > 0 && (
              <span className="absolute -top-1 -right-1 min-w-5 h-5 px-1 rounded-full bg-red-600 text-white text-[11px] font-bold flex items-center justify-center">{items.length}</span>
            )}
          </button>
        </PopoverTrigger>
        <PopoverContent align="end" className="w-[90vw] sm:w-96 space-y-2">
          <p className="font-semibold text-sm">Expense Reminders</p>
          {items.length === 0 ? (
            <p className="text-sm text-gray-500 py-3 text-center">Abhi koi payment due nahi hai.</p>
          ) : (
            <>
              {items.slice(0, 3).map(row)}
              {items.length > 3 && (
                <Button variant="outline" size="sm" className="w-full" onClick={() => { setOpen(false); setShowAll(true); }}>
                  View all ({items.length})
                </Button>
              )}
            </>
          )}
        </PopoverContent>
      </Popover>

      <Dialog open={showAll} onOpenChange={setShowAll}>
        <DialogContent className="w-[95vw] sm:max-w-lg max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Expense Reminders ({items.length})</DialogTitle></DialogHeader>
          <div className="space-y-2">
            {items.length === 0 ? <p className="text-sm text-gray-500 text-center py-4">Koi payment due nahi hai.</p> : items.map(row)}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
