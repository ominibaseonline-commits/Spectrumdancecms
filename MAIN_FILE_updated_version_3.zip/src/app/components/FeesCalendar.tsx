import { useEffect, useMemo, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { ChevronLeft, ChevronRight, SlidersHorizontal, CalendarDays, X, Wallet } from 'lucide-react';
import { ExpenseManager } from './ExpenseManager';
import { ExtraChargesList } from './ExtraChargesList';
import { getAllStudents, getAllPayments } from '../lib/indexedDB';
import { useLocationFilter } from '../contexts/LocationFilterContext';

type EntryType = 'admission' | 'fees' | 'extra';
interface Entry {
  key: string;
  type: EntryType;
  date: string; // YYYY-MM-DD
  regNo: string;
  name: string;
  amount: number;
  mode: string;
  note?: string; // extra charge ka naam
}

type CardId = 'total' | 'admission' | 'fees' | 'extra' | 'cash' | 'online';
type TypeFilter = 'all' | EntryType;
type ModeFilter = 'all' | 'Cash' | 'Online';

const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const WEEK = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

const pad = (n: number) => String(n).padStart(2, '0');
const ymd = (y: number, m: number, d: number) => `${y}-${pad(m + 1)}-${pad(d)}`;
const inr = (n: number) => `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
// Chhote cells ke liye: 1500 -> 1.5k, 120000 -> 1.2L
const compact = (n: number) => {
  if (n >= 100000) return `₹${(n / 100000).toFixed(n % 100000 === 0 ? 0 : 1)}L`;
  if (n >= 1000) return `₹${(n / 1000).toFixed(n % 1000 === 0 ? 0 : 1)}k`;
  return `₹${Math.round(n)}`;
};
const fmtLong = (d: string) => {
  const [y, m, day] = d.split('-').map(Number);
  return `${day} ${MONTHS[m - 1]} ${y}`;
};

// Admission = neela, Fees = hara, Extra Charge = peela
const TYPE_META: Record<EntryType, { label: string; rgb: string; badge: string; text: string; ring: string; count: (n: number) => string }> = {
  admission: { label: 'Admission', rgb: '59,130,246', badge: 'bg-blue-100 text-blue-700', text: 'text-blue-800', ring: 'hover:ring-blue-400', count: (n) => `${n} admission${n === 1 ? '' : 's'}` },
  fees: { label: 'Fees', rgb: '34,197,94', badge: 'bg-green-100 text-green-700', text: 'text-green-800', ring: 'hover:ring-green-400', count: (n) => `${n} fees payment${n === 1 ? '' : 's'}` },
  extra: { label: 'Extra Charge', rgb: '234,179,8', badge: 'bg-yellow-100 text-yellow-800', text: 'text-yellow-800', ring: 'hover:ring-yellow-400', count: (n) => `${n} extra charge${n === 1 ? '' : 's'}` },
};
const TYPE_ORDER: EntryType[] = ['admission', 'fees', 'extra'];

/**
 * Fees Management ke neeche: ek mahine ka collection calendar jaisa grid me.
 * Har date par us din kitna payment aaya dikhta hai. Admin mahina badal sakta hai
 * aur Filter se sirf Admission / sirf Fees payment ya Cash / Online dekh sakta hai.
 */
export function FeesCalendar({ refreshToken }: { refreshToken?: unknown }) {
  const { matchesLocation, selectedLocation } = useLocationFilter();
  const today = new Date();
  const [year, setYear] = useState(today.getFullYear());
  const [month, setMonth] = useState(today.getMonth()); // 0-11
  const [typeFilter, setTypeFilter] = useState<TypeFilter>('all');
  const [modeFilter, setModeFilter] = useState<ModeFilter>('all');
  const [showFilter, setShowFilter] = useState(false);
  const [openDay, setOpenDay] = useState<string | null>(null);
  const [openCard, setOpenCard] = useState<CardId | null>(null);
  const [view, setView] = useState<'collection' | 'expense' | 'extras'>('collection');
  const [students, setStudents] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    try {
      const [s, p] = await Promise.all([getAllStudents(), getAllPayments()]);
      setStudents(s || []);
      setPayments(p || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
    const onUpdate = () => { load(); };
    window.addEventListener('studentsUpdated', onUpdate);
    return () => window.removeEventListener('studentsUpdated', onUpdate);
  }, []);
  useEffect(() => { load(); /* eslint-disable-next-line */ }, [refreshToken]);

  // Saari entries: Admission payment + Fees payments (location filter ke hisaab se)
  const entries = useMemo<Entry[]>(() => {
    const byReg = new Map<string, any>();
    students.forEach((s) => byReg.set(String(s.regNo), s));
    const paidLater = new Map<string, number>();
    payments.forEach((p) => {
      const k = String(p.regNo);
      paidLater.set(k, (paidLater.get(k) || 0) + (parseFloat(p.paidAmount) || 0));
    });

    const list: Entry[] = [];
    students.forEach((s) => {
      if (!matchesLocation(s.location)) return;
      // student.paidAmount me baad ke fees payments bhi jud jaate hain, isliye admission wala hissa alag nikalte hain
      const admissionPaid = Math.max(0, (parseFloat(s.paidAmount) || 0) - (paidLater.get(String(s.regNo)) || 0));
      const date = String(s.admissionDate || '').slice(0, 10);
      if (admissionPaid > 0 && date) {
        list.push({ key: `a-${s.regNo}`, type: 'admission', date, regNo: String(s.regNo), name: s.name, amount: admissionPaid, mode: s.paymentMode || '' });
      }
    });
    // Extra charge collection: har extra payment (admission ke waqt ya baad me Fees Management se)
    students.forEach((s) => {
      if (!matchesLocation(s.location)) return;
      if (s.extraChargesSeparate !== true || !Array.isArray(s.extraPayments)) return;
      s.extraPayments.forEach((xp: any, i: number) => {
        const amount = parseFloat(xp?.amount) || 0;
        const date = String(xp?.date || '').slice(0, 10);
        if (amount > 0 && date) {
          list.push({ key: `x-${s.regNo}-${xp.id ?? i}`, type: 'extra', date, regNo: String(s.regNo), name: s.name, amount, mode: xp.mode || '', note: xp.name || '' });
        }
      });
    });
    payments.forEach((p, i) => {
      const st = byReg.get(String(p.regNo));
      if (st && !matchesLocation(st.location)) return;
      if (!st && selectedLocation !== 'all') return;
      const amount = parseFloat(p.paidAmount) || 0;
      const date = String(p.paymentDate || '').slice(0, 10);
      if (amount > 0 && date) {
        list.push({ key: `p-${p.id ?? i}`, type: 'fees', date, regNo: String(p.regNo), name: p.name || st?.name || '', amount, mode: p.paymentMode || '' });
      }
    });
    return list;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [students, payments, selectedLocation]);

  const monthPrefix = `${year}-${pad(month + 1)}`;
  const monthEntries = useMemo(
    () => entries.filter((e) =>
      e.date.startsWith(monthPrefix) &&
      (typeFilter === 'all' || e.type === typeFilter) &&
      (modeFilter === 'all' || e.mode === modeFilter)
    ),
    [entries, monthPrefix, typeFilter, modeFilter]
  );

  type DayInfo = { total: number; count: number; by: Record<EntryType, { amt: number; n: number }> };
  const byDay = useMemo(() => {
    const m = new Map<string, DayInfo>();
    monthEntries.forEach((e) => {
      const d = m.get(e.date) || { total: 0, count: 0, by: { admission: { amt: 0, n: 0 }, fees: { amt: 0, n: 0 }, extra: { amt: 0, n: 0 } } };
      d.total += e.amount;
      d.count += 1;
      d.by[e.type].amt += e.amount;
      d.by[e.type].n += 1;
      m.set(e.date, d);
    });
    return m;
  }, [monthEntries]);

  const totals = useMemo(() => {
    let total = 0, admission = 0, fees = 0, extra = 0, cash = 0, online = 0;
    const n = { total: 0, admission: 0, fees: 0, extra: 0, cash: 0, online: 0 };
    monthEntries.forEach((e) => {
      total += e.amount; n.total++;
      if (e.type === 'admission') { admission += e.amount; n.admission++; }
      else if (e.type === 'fees') { fees += e.amount; n.fees++; }
      else { extra += e.amount; n.extra++; }
      if (e.mode === 'Cash') { cash += e.amount; n.cash++; }
      if (e.mode === 'Online') { online += e.amount; n.online++; }
    });
    return { total, admission, fees, extra, cash, online, count: monthEntries.length, n };
  }, [monthEntries]);

  // Filter ke bina is mahine ka poora collection (Expense view me net nikalne ke liye)
  const monthCollectionAll = useMemo(
    () => entries.filter((e) => e.date.startsWith(monthPrefix)).reduce((s, e) => s + e.amount, 0),
    [entries, monthPrefix]
  );

  const maxDay = useMemo(() => Math.max(0, ...Array.from(byDay.values()).map((d: DayInfo) => d.total)), [byDay]);

  // Calendar cells (pehle khali cells, phir 1..last)
  const firstWeekday = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const cells: (number | null)[] = [...Array(firstWeekday).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => i + 1)];
  while (cells.length % 7 !== 0) cells.push(null);

  const todayKey = ymd(today.getFullYear(), today.getMonth(), today.getDate());
  const isCurrentMonth = year === today.getFullYear() && month === today.getMonth();

  const goMonth = (delta: number) => {
    const d = new Date(year, month + delta, 1);
    setYear(d.getFullYear());
    setMonth(d.getMonth());
    setOpenDay(null);
  };
  const activeFilters = (typeFilter !== 'all' ? 1 : 0) + (modeFilter !== 'all' ? 1 : 0);

  const cardEntries = useMemo(() => {
    if (!openCard) return [];
    const f = (e: Entry) =>
      openCard === 'total' ? true :
      openCard === 'cash' ? e.mode === 'Cash' :
      openCard === 'online' ? e.mode === 'Online' :
      e.type === openCard;
    return monthEntries.filter(f).sort((a, b) => (a.date < b.date ? -1 : a.date > b.date ? 1 : 0));
  }, [openCard, monthEntries]);
  const CARD_TITLE: Record<CardId, string> = { total: 'Total Collection', admission: 'Admission', fees: 'Fees Payment', extra: 'Extra Charge', cash: 'Cash', online: 'Online' };

  const dayEntries = openDay ? monthEntries.filter((e) => e.date === openDay) : [];

  const chip = (active: boolean) =>
    `px-3 py-1.5 rounded-full text-sm border transition-colors ${active ? 'bg-orange-500 border-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`;

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <CardTitle className="flex items-center gap-2">
            {view === 'collection'
              ? <><CalendarDays className="w-5 h-5 text-orange-600" /> Monthly Collection</>
              : view === 'expense'
                ? <><Wallet className="w-5 h-5 text-red-600" /> Monthly Expenses</>
                : <><Wallet className="w-5 h-5 text-yellow-600" /> Extra Charges List</>}
          </CardTitle>
          <div className="flex items-center gap-2">
            {/* Collection <-> Expense badalne wala */}
            <div className="inline-flex rounded-lg border overflow-hidden text-sm">
              <button type="button" onClick={() => setView('collection')} className={`px-3 py-1.5 ${view === 'collection' ? 'bg-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`}>Collection</button>
              <button type="button" onClick={() => { setView('expense'); setShowFilter(false); }} className={`px-3 py-1.5 border-l ${view === 'expense' ? 'bg-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`}>Expenses</button>
              <button type="button" onClick={() => { setView('extras'); setShowFilter(false); }} className={`px-3 py-1.5 border-l ${view === 'extras' ? 'bg-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`}>Extra Charges</button>
            </div>
            {view === 'collection' && (
              <Button variant="outline" size="sm" onClick={() => setShowFilter((v) => !v)} className={showFilter ? 'border-orange-400 bg-orange-50' : ''}>
                <SlidersHorizontal className="w-4 h-4 mr-1.5" /> Filter
                {activeFilters > 0 && <span className="ml-1.5 min-w-5 h-5 px-1 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">{activeFilters}</span>}
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Month selector */}
        <div className={`flex flex-wrap items-center gap-2 ${view === 'extras' ? 'hidden' : ''}`}>
          <Button variant="outline" size="icon" onClick={() => goMonth(-1)} aria-label="Pichla mahina"><ChevronLeft className="w-4 h-4" /></Button>
          <input
            type="month"
            value={monthPrefix}
            onChange={(e) => {
              const [y, m] = e.target.value.split('-').map(Number);
              if (y && m) { setYear(y); setMonth(m - 1); setOpenDay(null); }
            }}
            className="px-3 py-2 border rounded-lg bg-white text-sm font-medium"
            aria-label="Mahina chunein"
          />
          <Button variant="outline" size="icon" onClick={() => goMonth(1)} aria-label="Agla mahina"><ChevronRight className="w-4 h-4" /></Button>
          <span className="font-semibold ml-1">{MONTHS[month]} {year}</span>
          {!isCurrentMonth && (
            <Button variant="ghost" size="sm" onClick={() => { setYear(today.getFullYear()); setMonth(today.getMonth()); setOpenDay(null); }} className="text-orange-600">Is mahine par wapas</Button>
          )}
        </div>

        {/* Filter panel */}
        {showFilter && (
          <div className="rounded-xl border bg-gray-50 p-3 space-y-3">
            <div>
              <p className="text-xs text-gray-500 mb-1.5">Record type</p>
              <div className="flex flex-wrap gap-2">
                <button className={chip(typeFilter === 'all')} onClick={() => setTypeFilter('all')}>Sab</button>
                <button className={chip(typeFilter === 'admission')} onClick={() => setTypeFilter('admission')}>Sirf Admission</button>
                <button className={chip(typeFilter === 'fees')} onClick={() => setTypeFilter('fees')}>Sirf Fees Payment</button>
                <button className={chip(typeFilter === 'extra')} onClick={() => setTypeFilter('extra')}>Sirf Extra Charge</button>
              </div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1.5">Payment mode</p>
              <div className="flex flex-wrap gap-2">
                <button className={chip(modeFilter === 'all')} onClick={() => setModeFilter('all')}>Sab</button>
                <button className={chip(modeFilter === 'Cash')} onClick={() => setModeFilter('Cash')}>Cash</button>
                <button className={chip(modeFilter === 'Online')} onClick={() => setModeFilter('Online')}>Online</button>
              </div>
            </div>
            {activeFilters > 0 && (
              <button className="text-sm text-orange-600 flex items-center gap-1" onClick={() => { setTypeFilter('all'); setModeFilter('all'); }}>
                <X className="w-3.5 h-3.5" /> Filter hatayein
              </button>
            )}
          </div>
        )}

        {view === 'extras' ? (
          <ExtraChargesList students={students} />
        ) : view === 'expense' ? (
          <ExpenseManager year={year} month={month} collected={monthCollectionAll} />
        ) : (<>
        {/* Summary — har card par click karke uski detail dekho */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          {([
            { id: 'total', label: 'Total Collection', value: totals.total, n: totals.n.total, cls: 'bg-green-50 border-green-200', vcls: 'text-lg font-bold text-green-700' },
            { id: 'admission', label: 'Admission', value: totals.admission, n: totals.n.admission, cls: 'bg-blue-50 border-blue-200', vcls: 'font-semibold text-blue-700' },
            { id: 'fees', label: 'Fees Payment', value: totals.fees, n: totals.n.fees, cls: 'bg-white', vcls: 'font-semibold text-green-700' },
            { id: 'extra', label: 'Extra Charge', value: totals.extra, n: totals.n.extra, cls: 'bg-yellow-50 border-yellow-300', vcls: 'font-semibold text-yellow-700' },
            { id: 'cash', label: 'Cash', value: totals.cash, n: totals.n.cash, cls: 'bg-white', vcls: 'font-semibold text-blue-600' },
            { id: 'online', label: 'Online', value: totals.online, n: totals.n.online, cls: 'bg-white', vcls: 'font-semibold text-purple-600' },
          ] as { id: CardId; label: string; value: number; n: number; cls: string; vcls: string }[]).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setOpenCard(c.id)}
              className={`text-left rounded-xl border px-3 py-2 transition hover:shadow-md hover:ring-2 hover:ring-orange-300 active:scale-[0.98] ${c.cls} ${c.id === 'total' ? 'col-span-2 md:col-span-1' : ''}`}
            >
              <p className="text-xs text-gray-500">{c.label}</p>
              <p className={c.vcls}>{inr(c.value)}</p>
              <p className="text-[11px] text-gray-500">{c.n} payment{c.n === 1 ? '' : 's'} · details dekho</p>
            </button>
          ))}
        </div>

        {/* Calendar grid */}
        <div>
          <div className="grid grid-cols-7 gap-1 mb-1">
            {WEEK.map((w, i) => (
              <div key={w} className={`text-center text-xs font-medium py-1 ${i === 0 ? 'text-red-500' : 'text-gray-500'}`}>{w}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((day, idx) => {
              if (day === null) return <div key={`e-${idx}`} className="min-h-[56px] sm:min-h-[84px]" />;
              const key = ymd(year, month, day);
              const info = byDay.get(key);
              const isToday = key === todayKey;
              const intensity = info && maxDay > 0 ? info.total / maxDay : 0;
              // Cell ka rang: jis type ka paisa sabse zyada, uska (neela / hara / peela)
              const dominant: EntryType | null = info
                ? TYPE_ORDER.reduce((best, t) => (info.by[t].amt > info.by[best].amt ? t : best), 'admission' as EntryType)
                : null;
              const bg = info && dominant ? `rgba(${TYPE_META[dominant].rgb},${0.15 + intensity * 0.35})` : undefined;
              const present = info ? TYPE_ORDER.filter((t) => info.by[t].n > 0) : [];
              return (
                <button
                  key={key}
                  type="button"
                  disabled={!info}
                  onClick={() => info && setOpenDay(key)}
                  style={{ backgroundColor: bg }}
                  className={`min-h-[56px] sm:min-h-[96px] rounded-lg border p-1 sm:p-2 text-left flex flex-col justify-between transition ${
                    info && dominant ? `cursor-pointer hover:ring-2 ${TYPE_META[dominant].ring} active:scale-[0.97]` : 'bg-white cursor-default'
                  } ${isToday ? 'ring-2 ring-orange-400' : ''}`}
                >
                  <span className={`text-xs sm:text-sm font-semibold ${isToday ? 'text-orange-600' : info ? 'text-gray-800' : 'text-gray-400'}`}>{day}</span>
                  {info && dominant ? (
                    <span className="block">
                      <span className={`block text-[11px] sm:hidden font-bold leading-tight ${TYPE_META[dominant].text}`}>{compact(info.total)}</span>
                      <span className="flex sm:hidden gap-0.5 mt-0.5">
                        {present.map((t) => <span key={t} className="w-1.5 h-1.5 rounded-full" style={{ backgroundColor: `rgb(${TYPE_META[t].rgb})` }} />)}
                      </span>
                      <span className={`hidden sm:block text-sm font-bold leading-tight ${TYPE_META[dominant].text}`}>{inr(info.total)}</span>
                      <span className="hidden sm:block">
                        {present.map((t) => (
                          <span key={t} className="block text-[11px] text-gray-700 leading-tight">{TYPE_META[t].count(info.by[t].n)}</span>
                        ))}
                      </span>
                    </span>
                  ) : null}
                </button>
              );
            })}
          </div>
          <div className="flex flex-wrap gap-3 mt-3 text-xs text-gray-600">
            {TYPE_ORDER.map((t) => (
              <span key={t} className="inline-flex items-center gap-1.5"><span className="w-3 h-3 rounded" style={{ backgroundColor: `rgb(${TYPE_META[t].rgb})` }} />{t === 'admission' ? 'Admission (neela)' : t === 'fees' ? 'Fees (hara)' : 'Extra Charge (peela)'}</span>
            ))}
          </div>
          {!loading && totals.count === 0 && (
            <p className="text-center text-sm text-gray-500 py-4">{MONTHS[month]} {year} me koi payment record nahi hai{activeFilters > 0 ? ' (filter ke hisaab se)' : ''}.</p>
          )}
        </div>
        </>)}
      </CardContent>

      {/* Ek din ki detail */}
      <Dialog open={!!openDay} onOpenChange={(o) => { if (!o) setOpenDay(null); }}>
        <DialogContent className="w-[95vw] sm:max-w-xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{openDay ? fmtLong(openDay) : ''}</DialogTitle></DialogHeader>
          {openDay && byDay.get(openDay) && (
            <div className="grid grid-cols-4 gap-2 text-center">
              <div className="rounded-lg border bg-gray-50 p-2"><p className="text-xs text-gray-500">Total</p><p className="font-bold">{inr(byDay.get(openDay)!.total)}</p></div>
              {TYPE_ORDER.map((t) => (
                <div key={t} className={`rounded-lg border p-2 ${TYPE_META[t].badge}`}><p className="text-xs opacity-80">{TYPE_META[t].label}</p><p className="font-semibold">{inr(byDay.get(openDay)!.by[t].amt)}</p></div>
              ))}
            </div>
          )}
          <div className="space-y-2">
            {dayEntries.map((e) => (
              <div key={e.key} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                <div className="min-w-0">
                  <p className="font-medium truncate">{e.name || '—'}</p>
                  <p className="text-xs text-gray-500 flex flex-wrap items-center gap-1.5">
                    <span>Reg {e.regNo}</span>
                    <span className={`px-1.5 py-0.5 rounded-full font-semibold ${TYPE_META[e.type].badge}`}>{TYPE_META[e.type].label}{e.note ? `: ${e.note}` : ''}</span>
                    {e.mode && <span className="px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-700">{e.mode}</span>}
                  </p>
                </div>
                <p className="font-bold text-green-700 shrink-0">{inr(e.amount)}</p>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Card (Total / Admission / Fees / Extra / Cash / Online) ki detail */}
      <Dialog open={!!openCard} onOpenChange={(o) => { if (!o) setOpenCard(null); }}>
        <DialogContent className="w-[95vw] sm:max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader><DialogTitle>{openCard ? `${CARD_TITLE[openCard]} — ${MONTHS[month]} ${year}` : ''}</DialogTitle></DialogHeader>
          <div className="rounded-lg border bg-gray-50 px-3 py-2 flex justify-between text-sm">
            <span>{cardEntries.length} payment{cardEntries.length === 1 ? '' : 's'}</span>
            <span className="font-bold">{inr(cardEntries.reduce((s, e) => s + e.amount, 0))}</span>
          </div>
          {cardEntries.length === 0 ? (
            <p className="text-center text-sm text-gray-500 py-6">Is mahine me koi record nahi hai.</p>
          ) : (
            <div className="space-y-2">
              {cardEntries.map((e) => (
                <div key={e.key} className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2">
                  <div className="min-w-0">
                    <p className="font-medium truncate">{e.name || '—'}</p>
                    <p className="text-xs text-gray-500 flex flex-wrap items-center gap-1.5">
                      <span>{fmtLong(e.date)}</span>
                      <span>Reg {e.regNo}</span>
                      <span className={`px-1.5 py-0.5 rounded-full font-semibold ${TYPE_META[e.type].badge}`}>{TYPE_META[e.type].label}{e.note ? `: ${e.note}` : ''}</span>
                      {e.mode && <span className="px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-700">{e.mode}</span>}
                    </p>
                  </div>
                  <p className="font-bold shrink-0">{inr(e.amount)}</p>
                </div>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </Card>
  );
}
