import { useMemo, useState } from 'react';
import { Input } from './ui/input';
import { Search } from 'lucide-react';
import { hasSeparateExtras, extraChargeDues } from '../lib/admissionFields';
import { useLocationFilter } from '../contexts/LocationFilterContext';

// Extra Charges List — saare ACTIVE students (Deactivated nahi) ek table me:
// Reg No, Name, ID Card, Dress, AC, Other. Dikhata hai kis student ko extra charge laga hai aur kisko nahi.

type Col = 'id' | 'dress' | 'ac' | 'other';
const COLS: { key: Col; label: string }[] = [
  { key: 'id', label: 'ID Card Charge' },
  { key: 'dress', label: 'Dress Charge' },
  { key: 'ac', label: 'AC Charge' },
  { key: 'other', label: 'Other Charge' },
];

/** Charge ke naam se column tay karta hai. Jo ID / Dress / AC nahi wo "Other" me jata hai. */
function colOf(name: any): Col {
  const n = String(name ?? '').toLowerCase();
  if (/\bid\b|id\s*card|identity/.test(n)) return 'id';
  if (n.includes('dress') || n.includes('uniform')) return 'dress';
  if (/\bac\b|a\.c\.?|air\s*con/.test(n)) return 'ac';
  return 'other';
}

type Cell = { amount: number; paid: number; dues: number; names: string[] };
const emptyCell = (): Cell => ({ amount: 0, paid: 0, dues: 0, names: [] });
const inr = (n: number) => `₹${Math.round(n * 100) / 100}`;

type Filter = 'all' | 'charged' | 'not' | 'dues';

export function ExtraChargesList({ students }: { students: any[] }) {
  const { matchesLocation } = useLocationFilter();
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<Filter>('all');

  const rows = useMemo(() => {
    return (students || [])
      .filter((s) => !s.deactivated && matchesLocation(s.location))
      .map((s) => {
        const sep = hasSeparateExtras(s);
        const cells: Record<Col, Cell> = { id: emptyCell(), dress: emptyCell(), ac: emptyCell(), other: emptyCell() };
        const list: any[] = Array.isArray(s.extraCharges) ? s.extraCharges : [];
        list.forEach((c) => {
          const amount = parseFloat(String(c?.amount)) || 0;
          if (!c || (!amount && !String(c.name || '').trim())) return;
          const cell = cells[colOf(c.name)];
          cell.amount += amount;
          if (sep) {
            const paid = parseFloat(String(c.paid)) || 0;
            cell.paid += paid;
            cell.dues += Math.max(0, extraChargeDues(c));
          } else {
            cell.paid += amount; // purane student: charge class total ke andar hai
          }
          cell.names.push(String(c.name || ''));
        });
        const charged = COLS.some((col) => cells[col.key].amount > 0);
        const totalDues = COLS.reduce((sum, col) => sum + cells[col.key].dues, 0);
        return { s, sep, cells, charged, totalDues };
      })
      .sort((a, b) => (parseInt(a.s.regNo) || 0) - (parseInt(b.s.regNo) || 0));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [students, matchesLocation]);

  const stats = useMemo(() => {
    const charged = rows.filter((r) => r.charged).length;
    const perCol = {} as Record<Col, number>;
    COLS.forEach((c) => { perCol[c.key] = rows.filter((r) => r.cells[c.key].amount > 0).length; });
    return { total: rows.length, charged, not: rows.length - charged, dues: rows.filter((r) => r.totalDues > 0).length, perCol };
  }, [rows]);

  const q = search.trim().toLowerCase();
  const shown = rows.filter((r) => {
    if (filter === 'charged' && !r.charged) return false;
    if (filter === 'not' && r.charged) return false;
    if (filter === 'dues' && r.totalDues <= 0) return false;
    if (!q) return true;
    return String(r.s.name || '').toLowerCase().includes(q) || String(r.s.regNo || '').includes(q) || String(r.s.mobile || '').includes(q);
  });

  const totals = useMemo(() => {
    const t = {} as Record<Col, Cell>;
    COLS.forEach((c) => { t[c.key] = emptyCell(); });
    shown.forEach((r) => COLS.forEach((c) => {
      t[c.key].amount += r.cells[c.key].amount;
      t[c.key].paid += r.cells[c.key].paid;
      t[c.key].dues += r.cells[c.key].dues;
    }));
    return t;
  }, [shown]);

  const chip = (active: boolean) =>
    `px-3 py-1.5 rounded-full text-sm border transition-colors ${active ? 'bg-orange-500 border-orange-500 text-white font-medium' : 'bg-white hover:bg-gray-50'}`;

  return (
    <div className="space-y-4">
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
        <div className="rounded-lg border bg-gray-50 p-3"><p className="text-xs text-gray-500">Total Active Students</p><p className="text-lg font-bold">{stats.total}</p></div>
        <div className="rounded-lg border bg-green-50 border-green-200 p-3"><p className="text-xs text-gray-600">Extra charge diya</p><p className="text-lg font-bold text-green-700">{stats.charged}</p></div>
        <div className="rounded-lg border bg-red-50 border-red-200 p-3"><p className="text-xs text-gray-600">Extra charge nahi diya</p><p className="text-lg font-bold text-red-600">{stats.not}</p></div>
        <div className="rounded-lg border bg-yellow-50 border-yellow-300 p-3"><p className="text-xs text-gray-600">Extra dues baaki</p><p className="text-lg font-bold text-yellow-700">{stats.dues} <span className="text-xs font-normal">students</span></p></div>
      </div>
      <div className="flex flex-wrap gap-2 text-xs text-gray-600">
        {COLS.map((c) => (
          <span key={c.key} className="px-2 py-1 rounded-full bg-gray-100">{c.label}: <b>{stats.perCol[c.key]}</b> students ne diya · <b>{stats.total - stats.perCol[c.key]}</b> ne nahi</span>
        ))}
      </div>

      {/* Search + filter */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
          <Input className="pl-9" placeholder="Name, Reg No ya Mobile se search..." value={search} onChange={(e) => setSearch(e.target.value)} />
        </div>
        <button className={chip(filter === 'all')} onClick={() => setFilter('all')}>Sab ({stats.total})</button>
        <button className={chip(filter === 'charged')} onClick={() => setFilter('charged')}>Diya ({stats.charged})</button>
        <button className={chip(filter === 'not')} onClick={() => setFilter('not')}>Nahi diya ({stats.not})</button>
        <button className={chip(filter === 'dues')} onClick={() => setFilter('dues')}>Dues baaki ({stats.dues})</button>
      </div>

      {/* Table */}
      <div className="overflow-auto max-h-[70vh] rounded-lg border">
        <table className="w-full text-sm">
          <thead className="bg-gray-50 sticky top-0 z-10">
            <tr className="text-left">
              <th className="px-3 py-2 font-semibold whitespace-nowrap">Reg No</th>
              <th className="px-3 py-2 font-semibold whitespace-nowrap">Student Name</th>
              {COLS.map((c) => <th key={c.key} className="px-3 py-2 font-semibold whitespace-nowrap">{c.label}</th>)}
              <th className="px-3 py-2 font-semibold whitespace-nowrap">Status</th>
            </tr>
          </thead>
          <tbody>
            {shown.length === 0 && (
              <tr><td colSpan={COLS.length + 3} className="text-center text-gray-500 py-8">Koi student nahi mila.</td></tr>
            )}
            {shown.map((r) => (
              <tr key={r.s.regNo} className="border-t hover:bg-gray-50/60">
                <td className="px-3 py-2 whitespace-nowrap">{r.s.regNo}</td>
                <td className="px-3 py-2 whitespace-nowrap">{r.s.name}</td>
                {COLS.map((c) => {
                  const cell = r.cells[c.key];
                  if (cell.amount <= 0) return <td key={c.key} className="px-3 py-2 text-gray-300">—</td>;
                  return (
                    <td key={c.key} className="px-3 py-2 whitespace-nowrap" title={cell.names.join(', ')}>
                      <span className={`font-semibold ${cell.dues > 0 ? 'text-red-600' : 'text-green-700'}`}>{inr(cell.amount)}</span>
                      {c.key === 'other' && cell.names.length > 0 && <span className="block text-xs text-gray-500 max-w-[140px] truncate">{cell.names.join(', ')}</span>}
                      {r.sep
                        ? (cell.dues > 0
                          ? <span className="block text-xs text-red-600">Paid {inr(cell.paid)} · Dues {inr(cell.dues)}</span>
                          : <span className="block text-xs text-green-600">Paid ✓</span>)
                        : <span className="block text-xs text-gray-400">total me shamil</span>}
                    </td>
                  );
                })}
                <td className="px-3 py-2 whitespace-nowrap">
                  {!r.charged
                    ? <span className="text-xs px-2 py-0.5 rounded-full bg-gray-100 text-gray-600">Nahi diya</span>
                    : r.totalDues > 0
                      ? <span className="text-xs px-2 py-0.5 rounded-full bg-red-100 text-red-700">Dues {inr(r.totalDues)}</span>
                      : <span className="text-xs px-2 py-0.5 rounded-full bg-green-100 text-green-700">Diya ✓</span>}
                </td>
              </tr>
            ))}
          </tbody>
          {shown.length > 0 && (
            <tfoot className="bg-gray-50 sticky bottom-0">
              <tr className="border-t font-semibold">
                <td className="px-3 py-2" colSpan={2}>Total ({shown.length} students)</td>
                {COLS.map((c) => (
                  <td key={c.key} className="px-3 py-2 whitespace-nowrap">
                    {inr(totals[c.key].amount)}
                    {totals[c.key].dues > 0 && <span className="block text-xs font-normal text-red-600">Dues {inr(totals[c.key].dues)}</span>}
                  </td>
                ))}
                <td className="px-3 py-2" />
              </tr>
            </tfoot>
          )}
        </table>
      </div>
    </div>
  );
}
