import * as React from "react";
import { Calendar } from "lucide-react";

import { cn } from "./utils";

const INPUT_CLASS =
  "file:text-foreground placeholder:text-muted-foreground selection:bg-primary selection:text-primary-foreground dark:bg-input/30 border-input flex h-9 w-full min-w-0 rounded-md border px-3 py-1 text-base bg-input-background transition-[color,box-shadow] outline-none file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm focus-visible:border-ring focus-visible:ring-ring/50 focus-visible:ring-[3px] aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 aria-invalid:border-destructive";

// ---------------------------------------------------------------------------
// Date input: HAMESHA dd/mm/yyyy dikhata hai (Windows / Mac / Android / iPhone —
// device ya browser ki language kuch bhi ho). Native <input type="date"> device
// ke locale ke hisaab se mm/dd/yyyy dikha deta tha, isliye ab hum khud text box
// dikhate hain. Value (onChange me e.target.value) pehle ki tarah yyyy-mm-dd hi
// rehti hai, isliye baaki code me kuch badalna nahi padta.
// ---------------------------------------------------------------------------

const isoToDmy = (iso?: string | null): string => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso ?? ""));
  return m ? `${m[3]}/${m[2]}/${m[1]}` : "";
};

const maskDmy = (raw: string): string => {
  const d = raw.replace(/\D/g, "").slice(0, 8);
  if (d.length <= 2) return d;
  if (d.length <= 4) return `${d.slice(0, 2)}/${d.slice(2)}`;
  return `${d.slice(0, 2)}/${d.slice(2, 4)}/${d.slice(4)}`;
};

// "dd/mm/yyyy" -> "yyyy-mm-dd" (real calendar date ho tabhi), warna ""
const dmyToIso = (dmy: string): string => {
  const m = /^(\d{2})\/(\d{2})\/(\d{4})$/.exec(dmy);
  if (!m) return "";
  const day = +m[1], mon = +m[2], yr = +m[3];
  const dt = new Date(yr, mon - 1, day);
  if (yr < 1000 || dt.getFullYear() !== yr || dt.getMonth() !== mon - 1 || dt.getDate() !== day) return "";
  return `${m[3]}-${m[2]}-${m[1]}`;
};

type DateInputProps = Omit<React.ComponentProps<"input">, "type" | "value" | "onChange" | "min" | "max"> & {
  value?: string | number | readonly string[];
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  min?: string | number;
  max?: string | number;
};

function DateInput({ className, value, onChange, min, max, disabled, id, name, onBlur, placeholder, readOnly, ...rest }: DateInputProps) {
  const iso = typeof value === "string" ? value.slice(0, 10) : "";
  const minIso = typeof min === "string" ? min.slice(0, 10) : "";
  const maxIso = typeof max === "string" ? max.slice(0, 10) : "";
  const [text, setText] = React.useState(isoToDmy(iso));
  const lastEmitted = React.useRef(iso);

  // Bahar se value badli (form reset, edit, auto-calculated expiry...) -> text bhi badlo
  React.useEffect(() => {
    if (iso !== lastEmitted.current) {
      lastEmitted.current = iso;
      setText(isoToDmy(iso));
    }
  }, [iso]);

  const emit = (next: string) => {
    lastEmitted.current = next;
    onChange?.({ target: { value: next, name, id }, currentTarget: { value: next, name, id } } as any);
  };

  const outOfRange = (v: string) => (minIso && v < minIso) || (maxIso && v > maxIso);
  const invalid = text.length === 10 && (!dmyToIso(text) || !!outOfRange(dmyToIso(text)));

  const handleText = (e: React.ChangeEvent<HTMLInputElement>) => {
    const masked = maskDmy(e.target.value);
    setText(masked);
    const parsed = dmyToIso(masked);
    if (parsed && !outOfRange(parsed)) emit(parsed);
    else if (lastEmitted.current !== "") emit(""); // adhoori / galat date = khali (native date jaisa)
  };

  return (
    <div className="relative w-full">
      <input
        {...rest}
        id={id}
        name={name}
        type="text"
        inputMode="numeric"
        autoComplete="off"
        maxLength={10}
        data-slot="input"
        placeholder={placeholder || "dd/mm/yyyy"}
        value={text}
        disabled={disabled}
        readOnly={readOnly}
        aria-invalid={invalid || undefined}
        onChange={handleText}
        onBlur={onBlur}
        className={cn(INPUT_CLASS, "pr-10", className)}
      />
      <Calendar className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
      {/* Asli calendar picker: sirf icon ke upar transparent rakha hai (iPhone par bhi seedha tap lagta hai) */}
      {!disabled && !readOnly && (
        <input
          type="date"
          tabIndex={-1}
          aria-label="Open calendar"
          value={iso}
          min={minIso || undefined}
          max={maxIso || undefined}
          onChange={(e) => {
            const v = e.target.value;
            if (!v) return;
            setText(isoToDmy(v));
            emit(v);
          }}
          className="absolute right-0 top-0 h-full w-10 cursor-pointer opacity-0 [&::-webkit-calendar-picker-indicator]:absolute [&::-webkit-calendar-picker-indicator]:inset-0 [&::-webkit-calendar-picker-indicator]:h-full [&::-webkit-calendar-picker-indicator]:w-full [&::-webkit-calendar-picker-indicator]:cursor-pointer"
        />
      )}
    </div>
  );
}

function Input({ className, type, ...props }: React.ComponentProps<"input">) {
  if (type === "date") {
    return <DateInput className={className} {...(props as any)} />;
  }
  return (
    <input
      type={type}
      data-slot="input"
      className={cn(INPUT_CLASS, className)}
      {...props}
    />
  );
}

export { Input, DateInput };
