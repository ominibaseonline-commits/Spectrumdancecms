import { useState, useEffect, useRef } from 'react';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Save, FileText, MessageCircle, Upload, Camera, RotateCcw, Check, Plus, Trash2, IdCard } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import {
  saveStudent,
  getStudent,
  getAllBatches,
  getAllLocations,
  migrateFromLocalStorage,
  saveBatch,
  saveLocation,
  getAllCategories
} from '../lib/indexedDB';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';
import { getFieldValue, getExtraChargesEnabled, sumExtraCharges, sumExtraPaid, sumExtraDues, extraChargeDues, hasSeparateExtras, syncExtraPayments, MAX_EXTRA_CHARGES, ExtraCharge } from '../lib/admissionFields';
import { useFormLayout, validateRequired, blankHiddenFields } from '../lib/formLayout';
import { AdmissionFormRenderer } from './AdmissionFormRenderer';
import { AdmissionRequest, takeAdmissionPrefill, releaseAdmissionRequest, removeAdmissionRequest, fetchAdmissionPhoto, sendAdmissionReceiptMail, onlineAdmissionError } from '../lib/onlineAdmission';
import { calcDues, discountPercent } from '../lib/dues';
import { getNextRegNo, isValidRegNo } from '../lib/regNo';
import { compressPhotoToTarget, compressDocumentToTarget } from '../lib/imageCompress';
import { batchMatches, getBatchTargets } from '../lib/batchTime';
import { useIdCardSettings, printIdCard } from '../lib/idCard';

export function OfflineAdmission() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const { selectedLocation: activeLocation } = useLocationFilter();
  const defaultLocation = activeLocation === 'all' ? '' : activeLocation;
  const [batches, setBatches] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');
  // Online request ka Sub-Category / Batch: ye category ke baad, option list ban jaane par step-by-step lagta hai
  const pendingOnlineRef = useRef<{ sub: string; batchTime: string; subDone?: boolean } | null>(null);
  const [availableSubCategories, setAvailableSubCategories] = useState<string[]>([]);
  const [filteredBatches, setFilteredBatches] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [savedStudent, setSavedStudent] = useState<any>(null);
  const { settings: idCardSettings } = useIdCardSettings();   // Settings -> ID Card (ON/OFF + design)
  const [idCardBusy, setIdCardBusy] = useState(false);
  // Admission Form Layout (Settings -> Admission Form Layout). `enabledFields` = visible extra + custom fields.
  const { fields: layoutFields, extraDefs: enabledFields, isVisible, label: lbl } = useFormLayout();

  // Extra Charges (Settings -> Admission Fields -> Add Extra Charges)
  const [extraChargesEnabled, setExtraChargesEnabled] = useState(false);
  const [extraChargesChecked, setExtraChargesChecked] = useState(false);
  const [extraCharges, setExtraCharges] = useState<ExtraCharge[]>([{ name: '', amount: '', paid: '' }]);
  const extraChargesTotal = extraChargesEnabled && extraChargesChecked ? sumExtraCharges(extraCharges) : 0;
  const extraChargesPaidTotal = extraChargesEnabled && extraChargesChecked ? sumExtraPaid(extraCharges) : 0;
  const extraChargesDuesTotal = extraChargesEnabled && extraChargesChecked ? sumExtraDues(extraCharges) : 0;

  const [formData, setFormData] = useState({
    regNo: '',
    admissionDate: new Date().toISOString().split('T')[0],
    name: '',
    gender: '',
    dob: '',
    photo: '',
    aadhaarFront: '',
    aadhaarBack: '',
    mobile: '',
    alternateMobile: '',
    aadhaarNumber: '',
    guardianName: '',
    guardianRelation: '',
    learnedBefore: '',
    address: '',
    category: '',
    subCategory: '',
    batchTime: '',
    location: defaultLocation,
    duration: '',
    durationType: '',
    expiryDate: '',
    totalAmount: '',
    paidAmount: '',
    discountAmount: '',
    duesDate: '',
    dues: 0,
    paymentMode: '',
    email: '',
    status: 'active',
    userId: '',
    password: '',
    customFields: {} as Record<string, string>
  });

  // Online Admission: Approve dabane par request ka data yaha pehle se bhar diya jata hai
  const [dataReady, setDataReady] = useState(false);
  const [onlineReq, setOnlineReq] = useState<AdmissionRequest | null>(null);
  const onlineReqRef = useRef<AdmissionRequest | null>(null);
  useEffect(() => { onlineReqRef.current = onlineReq; }, [onlineReq]);
  // Bina save kiye page chhod diya to request dusre computer / baad ke liye free kar do
  useEffect(() => () => { if (onlineReqRef.current) releaseAdmissionRequest(onlineReqRef.current.id); }, []);

  // Photo for preview only (not saved to localStorage)
  const [photoPreview, setPhotoPreview] = useState('');

  // Photo source chooser (Live Camera / Upload) + webcam capture
  const [showPhotoChoice, setShowPhotoChoice] = useState(false);
  // Kis cheez ki photo le rahe hain: student photo ya Aadhaar front / back
  const [photoTarget, setPhotoTarget] = useState<'photo' | 'aadhaarFront' | 'aadhaarBack'>('photo');
  const photoTargetRef = useRef<'photo' | 'aadhaarFront' | 'aadhaarBack'>('photo');
  const isDocTarget = photoTarget !== 'photo';
  const targetTitle = photoTarget === 'aadhaarFront' ? 'Aadhaar Front Photo' : photoTarget === 'aadhaarBack' ? 'Aadhaar Back Photo' : 'Student Photo';
  const openPhotoChooser = (fieldId: string) => {
    const t = (fieldId === 'aadhaarFront' || fieldId === 'aadhaarBack') ? fieldId : 'photo';
    photoTargetRef.current = t;
    setPhotoTarget(t);
    setShowPhotoChoice(true);
  };
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState('');
  const [cameraError, setCameraError] = useState('');
  const photoFileInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const attachVideo = (el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (el && streamRef.current && el.srcObject !== streamRef.current) {
      el.srcObject = streamRef.current;
    }
  };

  const startCamera = async () => {
    setCameraError('');
    stopCamera();
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error('Camera is not supported on this device');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: photoTargetRef.current === 'photo' ? 'user' : { ideal: 'environment' }, width: { ideal: 1920 }, height: { ideal: 1080 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err: any) {
      console.error('Camera error:', err);
      setCameraError(
        err?.name === 'NotAllowedError'
          ? 'Camera permission denied. Please allow camera access and try again.'
          : err?.name === 'NotFoundError'
          ? 'No camera found. Please connect a webcam and try again. (Mac: System Settings → Privacy & Security → Camera mein Ominibase CMS ko allow karo.)'
          : 'Could not start the camera. Please check that no other app is using it.'
      );
    }
  };

  const openLiveCamera = () => {
    setShowPhotoChoice(false);
    setCapturedImage('');
    setShowCamera(true);
  };

  const closeCamera = () => {
    stopCamera();
    setCapturedImage('');
    setCameraError('');
    setShowCamera(false);
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) {
      toast.error('Camera is not ready yet');
      return;
    }
    // Resize to max 800px so the saved photo stays light
    const maxSize = photoTargetRef.current === 'photo' ? 800 : 1400;
    const scale = Math.min(1, maxSize / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCapturedImage(canvas.toDataURL('image/jpeg', 0.85));
    stopCamera();
  };

  const retakePhoto = () => {
    setCapturedImage('');
    startCamera();
  };

  const useCapturedPhoto = async () => {
    if (!capturedImage) return;
    const target = photoTargetRef.current;
    if (target !== 'photo') {
      let doc = capturedImage;
      try { doc = await compressDocumentToTarget(capturedImage); } catch { /* original rakh lo */ }
      setFormData((prev: any) => ({ ...prev, [target]: doc }));
      closeCamera();
      return;
    }
    let photo = capturedImage;
    try { photo = await compressPhotoToTarget(capturedImage); } catch { /* original rakh lo */ }
    setFormData((prev: any) => ({ ...prev, photo }));
    setPhotoPreview(photo);
    setTempPhoto(photo);
    closeCamera();
  };

  // Start camera when the dialog opens (and no photo has been captured yet)
  useEffect(() => {
    if (showCamera && !capturedImage) startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showCamera]);

  // Always release the camera on unmount
  useEffect(() => () => stopCamera(), []);

  // Photo for printing (temporary)
  const [tempPhoto, setTempPhoto] = useState('');

  useEffect(() => {
    // Load which extra fields are turned ON from Settings -> Admission Fields
    getExtraChargesEnabled().then(setExtraChargesEnabled);
  }, []);

  useEffect(() => {
    // Initialize IndexedDB and migrate data
    const initializeData = async () => {
      try {
        // Run migration from localStorage to IndexedDB
        await migrateFromLocalStorage();
        
        // Load batches from IndexedDB
        const batchesData = await getAllBatches();
        if (batchesData.length === 0) {
          // Fallback to localStorage if IndexedDB is empty
          const localBatches = localStorage.getItem('batches');
          if (localBatches) {
            const parsedBatches = JSON.parse(localBatches);
            setBatches(parsedBatches);
            // Save to IndexedDB for future use
            for (const batch of parsedBatches) {
              await saveBatch(batch);
            }
          }
        } else {
          setBatches(batchesData);
        }

        // Load locations from IndexedDB
        const locationsData = await getAllLocations();
        if (locationsData.length === 0) {
          // Fallback to localStorage if IndexedDB is empty
          const localLocations = localStorage.getItem('locations');
          if (localLocations) {
            const parsedLocations = JSON.parse(localLocations);
            setLocations(parsedLocations);
            // Save to IndexedDB for future use
            for (const location of parsedLocations) {
              await saveLocation(location);
            }
          }
        } else {
          setLocations(locationsData);
        }

        // Load categories from IndexedDB
        const categoriesData = await getAllCategories();
        setCategories(categoriesData);

        // Generate unique registration number
        generateRegNo();
        setDataReady(true);
      } catch (error) {
        console.error('Error initializing data:', error);
        // Fallback to localStorage in case of error
        const localBatches = localStorage.getItem('batches');
        const localLocations = localStorage.getItem('locations');
        if (localBatches) setBatches(JSON.parse(localBatches));
        if (localLocations) setLocations(JSON.parse(localLocations));
        generateRegNo();
        setDataReady(true);
      }
    };

    initializeData();

    // Listen for storage changes to reload batches and locations
    const handleStorageChange = async (e: StorageEvent) => {
      if (e.key === 'batches' || e.key === 'locations') {
        console.log('🔄 Storage changed, reloading batches and locations...');
        const batchesData = await getAllBatches();
        const locationsData = await getAllLocations();
        setBatches(batchesData);
        setLocations(locationsData);
      }
    };

    // Add custom event listener for batch/location updates
    const handleDataUpdate = async () => {
      console.log('🔄 Data updated, reloading batches and locations...');
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      setBatches(batchesData);
      setLocations(locationsData);
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('batchesUpdated', handleDataUpdate);
    window.addEventListener('locationsUpdated', handleDataUpdate);

    // Poll for updates every 2 seconds to ensure sync
    const pollInterval = setInterval(async () => {
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      
      // Only update if data changed
      if (JSON.stringify(batchesData) !== JSON.stringify(batches)) {
        console.log('🔄 Batches updated from polling');
        setBatches(batchesData);
      }
      if (JSON.stringify(locationsData) !== JSON.stringify(locations)) {
        console.log('🔄 Locations updated from polling');
        setLocations(locationsData);
      }
    }, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('batchesUpdated', handleDataUpdate);
      window.removeEventListener('locationsUpdated', handleDataUpdate);
      clearInterval(pollInterval);
    };
  }, []);

  // Batches / categories load hone ke baad prefill lagta hai. setTimeout isliye: data load hote hi category/batch ke
  // "reset" effects bhi ek baar chalte hain, wo prefill ke BAAD chalte to sub-category / batch khali kar dete the.
  useEffect(() => {
    if (!dataReady) return;
    const t = setTimeout(() => {
      const pre = takeAdmissionPrefill();
      if (!pre) return;
      const core = pre.req.data.core || {};
      const custom = pre.req.data.custom || {};
      const same = (a: any, b: any) => String(a ?? '').trim().toLowerCase() === String(b ?? '').trim().toLowerCase();
      // Online form me jo naam aaya use CMS ke exact naam se match karo (extra space / capital ka farak na pade)
      const catObj = categories.find((c: any) => same(c.name, core.category));
      const category = catObj ? catObj.name : String(core.category || '');
      const sub = (catObj?.subCategories || []).find((x: string) => same(x, core.subCategory)) || String(core.subCategory || '');
      const batchObj = batches.find((b: any) => same(b.batchTime, core.batchTime) && getBatchTargets(b).some((t) => same(t.category, category) && same(t.subCategory, sub)))
        || batches.find((b: any) => same(b.batchTime, core.batchTime));
      const batchTime = batchObj ? batchObj.batchTime : String(core.batchTime || '');
      const locObj = locations.find((l: any) => same(l.name, core.location));
      const location = locObj ? locObj.name : String(core.location || '');

      const KEYS = ['name', 'mobile', 'gender', 'dob', 'alternateMobile', 'aadhaarNumber', 'guardianName', 'guardianRelation', 'learnedBefore', 'address', 'email'];
      const patch: Record<string, any> = {};
      KEYS.forEach((k) => { if (core[k]) patch[k] = String(core[k]); });
      if (category) patch.category = category;
      if (location) patch.location = location;
      // Sub-Category aur Batch abhi nahi: dropdown ke options category chunne ke BAAD bante hain. Option bante hi
      // value set karte hain (neeche 2 effects), warna Select value ko khali kar deta tha.
      pendingOnlineRef.current = sub ? { sub, batchTime } : null;
      // Online form me student ko jo Reg No mila tha (mail / PDF me gaya) wahi yaha aata hai — agar wo number free ho
      const onlineRegNo = String(pre.req.data.regNo || '').trim();
      if (isValidRegNo(onlineRegNo)) {
        getStudent(onlineRegNo).then((existing: any) => {
          if (existing) toast.warning(`Online form ka Reg No ${onlineRegNo} ab kisi aur student ka hai, isliye naya Reg No diya gaya hai.`);
          else setFormData((prev: any) => ({ ...prev, regNo: onlineRegNo }));
        }).catch(() => { /* default Reg No hi rahega */ });
      }
      setSelectedCategory(category);
      setFormData((prev: any) => ({ ...prev, ...patch, customFields: { ...prev.customFields, ...custom } }));
      setOnlineReq(pre.req);
      toast.success('Online request ka data bhar diya gaya hai. Fees bharke Save karein.');
      // Student ne jo photo online form me di thi (Google Drive me hai) wo bhi Admission Form me aa jati hai
      // Aadhaar front / back photo (agar student ne online form me di thi)
      (['aadhaarFront', 'aadhaarBack'] as const).forEach((key) => {
        const id = pre.req.data[key === 'aadhaarFront' ? 'aadhaarFrontId' : 'aadhaarBackId'];
        if (!id) return;
        fetchAdmissionPhoto(id)
          .then(async (uri) => {
            if (!uri) return;
            let doc = uri;
            try { doc = await compressDocumentToTarget(uri); } catch { /* original rakh lo */ }
            setFormData((prev: any) => ({ ...prev, [key]: doc }));
          })
          .catch(() => toast.warning('Student ki Aadhaar photo download nahi ho payi. Khud add karein.'));
      });
      const photoId = pre.req.data.photoId;
      if (photoId) {
        fetchAdmissionPhoto(photoId)
          .then(async (uri) => {
            if (!uri) return;
            let photo = uri;
            try { photo = await compressPhotoToTarget(uri); } catch { /* original rakh lo */ }
            setFormData((prev: any) => ({ ...prev, photo }));
            setPhotoPreview(photo);
            setTempPhoto(photo);
          })
          .catch(() => toast.warning('Student ki photo download nahi ho payi. Photo khud add karein.'));
      }
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataReady]);

  useEffect(() => {
    // Calculate expiry date based on duration
    if (formData.admissionDate && formData.duration && formData.durationType) {
      const startDate = new Date(formData.admissionDate);
      let expiryDate = new Date(startDate);

      const duration = parseInt(formData.duration);
      
      if (formData.durationType === 'Days') {
        expiryDate.setDate(expiryDate.getDate() + duration);
      } else if (formData.durationType === 'Month') {
        expiryDate.setMonth(expiryDate.getMonth() + duration);
      } else if (formData.durationType === 'Year') {
        expiryDate.setFullYear(expiryDate.getFullYear() + duration);
      }

      setFormData(prev => ({
        ...prev,
        expiryDate: expiryDate.toISOString().split('T')[0]
      }));
    }
  }, [formData.admissionDate, formData.duration, formData.durationType]);

  useEffect(() => {
    // Calculate dues
    // Final total = Total Amount typed by admin + Extra Charges (if any)
    // Dues = Total - Paid - Discount (sirf class fee; extra charges ka dues alag hai). Dues na bache to Dues Date khali ho jati hai.
    const total = parseFloat(formData.totalAmount) || 0;
    const dues = calcDues(total, formData.paidAmount, formData.discountAmount);
    setFormData(prev => ({
      ...prev,
      dues,
      duesDate: dues > 0 ? prev.duesDate : ''
    }));
  }, [formData.totalAmount, formData.paidAmount, formData.discountAmount]);

  const updateExtraCharge = (index: number, field: 'name' | 'amount' | 'paid', value: string) => {
    setExtraCharges((prev) => prev.map((c, i) => (i === index ? { ...c, [field]: value } : c)));
  };

  const addExtraChargeRow = () => {
    setExtraCharges((prev) => (prev.length >= MAX_EXTRA_CHARGES ? prev : [...prev, { name: '', amount: '', paid: '' }]));
  };

  // Quick buttons (AC / Dress / ID Card): same naam ki row pehle se ho to dobara nahi judti.
  const EXTRA_CHARGE_PRESETS = ['AC Charge', 'Dress Charge', 'ID Card Charge'];
  const addPresetCharge = (name: string) => {
    setExtraCharges((prev) => {
      if (prev.some((c) => String(c.name).trim().toLowerCase() === name.toLowerCase())) return prev;
      const blankIdx = prev.findIndex((c) => !String(c.name).trim() && !String(c.amount ?? '').trim());
      if (blankIdx >= 0) return prev.map((c, i) => (i === blankIdx ? { name, amount: '', paid: '' } : c));
      return prev.length >= MAX_EXTRA_CHARGES ? prev : [...prev, { name, amount: '', paid: '' }];
    });
  };

  const removeExtraChargeRow = (index: number) => {
    setExtraCharges((prev) => (prev.length <= 1 ? [{ name: '', amount: '', paid: '' }] : prev.filter((_, i) => i !== index)));
  };

  // Handle category selection - update available sub-categories
  useEffect(() => {
    if (selectedCategory) {
      const category = categories.find(c => c.name === selectedCategory);
      if (category) {
        setAvailableSubCategories(category.subCategories || []);
        // Reset sub-category if current selection is invalid
        if (!category.subCategories.includes(selectedSubCategory)) {
          setSelectedSubCategory('');
          setFormData(prev => ({ ...prev, subCategory: '' }));
        }
      }
    } else {
      setAvailableSubCategories([]);
      setSelectedSubCategory('');
      setFormData(prev => ({ ...prev, category: '', subCategory: '' }));
    }
  }, [selectedCategory, categories]);

  // Handle sub-category selection - filter batches
  useEffect(() => {
    if (selectedCategory && selectedSubCategory) {
      // Filter batches by selected category and sub-category
      const filtered = batches.filter(
        batch => batchMatches(batch, selectedCategory, selectedSubCategory)
      );
      setFilteredBatches(filtered);

      // Reset batch selection if current batch is not in filtered list
      const currentBatchValid = filtered.some(b => b.batchTime === formData.batchTime);
      if (!currentBatchValid) {
        setFormData(prev => ({ ...prev, batchTime: '' }));
      }
    } else {
      setFilteredBatches([]);
      setFormData(prev => ({ ...prev, batchTime: '' }));
    }
  }, [selectedCategory, selectedSubCategory, batches]);

  // Online request: sub-category options ban jaayein to sub-category lagao
  useEffect(() => {
    const p = pendingOnlineRef.current;
    if (!p || p.subDone || !selectedCategory) return;
    if (availableSubCategories.includes(p.sub)) {
      p.subDone = true;
      setSelectedSubCategory(p.sub);
      setFormData((prev: any) => ({ ...prev, subCategory: p.sub }));
    }
  }, [availableSubCategories, selectedCategory]);

  // ...phir batch options ban jaayein to batch lagao
  useEffect(() => {
    const p = pendingOnlineRef.current;
    if (!p || !p.subDone) return;
    if (!p.batchTime) { pendingOnlineRef.current = null; return; }
    if (filteredBatches.some((b: any) => b.batchTime === p.batchTime)) {
      pendingOnlineRef.current = null;
      setFormData((prev: any) => ({ ...prev, batchTime: p.batchTime }));
    }
  }, [filteredBatches]);

  // 5-digit serial Reg No (26135 se shuru): Student List ka sabse bada Reg No + 1. Delete hone par wahi number wapas aata hai.
  const generateRegNo = () => {
    getNextRegNo()
      .then((regNo) => {
        if (!regNo) toast.error('5-digit Reg No khatam ho gaye (99999). Kripya Reg No khud likhein.');
        // Online request khuli ho aur uska Reg No lag chuka ho to use na badlo
        setFormData(prev => ({ ...prev, regNo: onlineReqRef.current && isValidRegNo(prev.regNo) ? prev.regNo : regNo }));
      })
      .catch(() => setFormData(prev => ({ ...prev, regNo: '' })));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation — required flags come from the Admission Form Layout
    const requiredError = validateRequired(layoutFields, { ...formData, photo: tempPhoto || formData.photo });
    if (requiredError) {
      toast.error(requiredError);
      return;
    }

    if (formData.mobile.length !== 10) {
      toast.error('Mobile Number 10 digits का होना चाहिए');
      return;
    }

    if (!/^\d+$/.test(formData.mobile)) {
      toast.error('Mobile Number में केवल numbers होने चाहिए');
      return;
    }

    // Registration No: sirf 5 digit, aur kisi aur student ka na ho (deactivated bhi nahi) — warna purana student overwrite ho jata
    const regNoToSave = String(formData.regNo || '').trim();
    if (!isValidRegNo(regNoToSave)) {
      toast.error('Registration No 5 digit ka hona chahiye');
      return;
    }
    if (await getStudent(regNoToSave)) {
      toast.error(`Registration No ${regNoToSave} pehle se kisi student ka hai. Doosra number likhein.`);
      return;
    }

    // Extra charges: ignore fully empty rows, but a half-filled row is an error
    let cleanedExtraCharges: { name: string; amount: number; paid: number }[] = [];
    if (extraChargesEnabled && extraChargesChecked) {
      for (const c of extraCharges) {
        const name = String(c.name || '').trim();
        const amountStr = String(c.amount ?? '').trim();
        if (!name && !amountStr) continue;
        if (!name) {
          toast.error('कृपया Extra Charge का नाम भरें');
          return;
        }
        const amt = parseFloat(amountStr);
        if (!amountStr || isNaN(amt) || amt < 0) {
          toast.error(`कृपया "${name}" का सही amount भरें`);
          return;
        }
        const paidStr = String(c.paid ?? '').trim();
        const paidAmt = paidStr ? parseFloat(paidStr) : 0;
        if (isNaN(paidAmt) || paidAmt < 0) {
          toast.error(`कृपया "${name}" का सही Paid amount भरें`);
          return;
        }
        if (paidAmt > amt) {
          toast.error(`"${name}" ka Paid (₹${paidAmt}) uske Charge (₹${amt}) se zyada nahi ho sakta`);
          return;
        }
        cleanedExtraCharges.push({ name, amount: amt, paid: paidAmt });
      }
    }
    const extrasTotalToSave = cleanedExtraCharges.reduce((sum, c) => sum + c.amount, 0);
    const extrasPaidToSave = cleanedExtraCharges.reduce((sum, c) => sum + c.paid, 0);
    const extrasDuesToSave = cleanedExtraCharges.reduce((sum, c) => sum + Math.max(0, c.amount - c.paid), 0);
    // Admission ke waqt jo extra charge paid hua, wo admission date par 'Extra Charge' collection ban jata hai.
    const extraPaymentsToSave = syncExtraPayments(cleanedExtraCharges, [], String(formData.admissionDate || '').slice(0, 10), String(formData.paymentMode || ''));
    // Total Amount = sirf class fee. Extra charges alag (extraChargesSeparate) save hote hain.
    const finalTotalAmount = String(parseFloat(formData.totalAmount) || 0);

    // Discount: class total se zyada nahi ho sakta. Dues = Total - Paid - Discount.
    const discountToSave = Math.max(0, parseFloat(String(formData.discountAmount)) || 0);
    if (discountToSave > Number(finalTotalAmount)) {
      toast.error('Discount Total Amount se zyada nahi ho sakta');
      return;
    }
    const duesToSave = calcDues(finalTotalAmount, formData.paidAmount, discountToSave);
    const duesDateToSave = duesToSave > 0 ? String(formData.duesDate || '') : '';
    // Online request ka email (CMS me Email column hidden ho tab bhi) — payment receipt isi par jayegi
    const receiptEmail = String(formData.email || onlineReq?.data?.core?.email || '').trim();
    const fromOnlineRequest = !!onlineReq;

    // All validation passed - Save student
    try {
      // Create student data with photo
      const studentDataToSave = blankHiddenFields({
        ...formData,
        regNo: regNoToSave,
        totalAmount: finalTotalAmount,
        extraCharges: cleanedExtraCharges,
        extraChargesSeparate: true,
        extraPayments: extraPaymentsToSave,
        discountAmount: discountToSave,
        duesDate: duesDateToSave,
        dues: duesToSave,
        // Balance left at admission time = Admission Dues (Monthly Dues start at 0)
        admissionDues: Math.max(0, duesToSave),
        monthlyDues: 0,
        photo: tempPhoto // Save photo in IndexedDB
      }, layoutFields);
      
      // Save to IndexedDB (will also sync to localStorage automatically)
      await saveStudent(studentDataToSave);
      window.dispatchEvent(new CustomEvent('studentsUpdated')); // Google Sheet ko jaldi sync ho
      toast.success('Student admission saved successfully!');
      // Online request se aayi admission thi to ab wo request Sheet se hata do
      if (onlineReq) {
        const doneId = onlineReq.id;
        onlineReqRef.current = null;
        setOnlineReq(null);
        removeAdmissionRequest(doneId);
      }
      
      // Save the complete data with photo for preview and print
      const savedStudentWithPhoto = blankHiddenFields({
        ...formData,
        regNo: regNoToSave,
        totalAmount: finalTotalAmount,
        extraCharges: cleanedExtraCharges,
        extraChargesSeparate: true,
        extraPayments: extraPaymentsToSave,
        discountAmount: discountToSave,
        duesDate: duesDateToSave,
        dues: duesToSave,
        photo: tempPhoto // Use temporary photo for print/preview
      }, layoutFields);
      setSavedStudent(savedStudentWithPhoto);
      setShowPreview(true);

      // Online request se aayi admission: payment set karte hi student ko receipt mail (background me, save ko nahi rokta)
      if (fromOnlineRequest) {
        if (!receiptEmail) {
          toast.info('Student ka email nahi hai, isliye payment receipt mail nahi gayi.');
        } else {
          sendAdmissionReceiptMail({
            regNo: regNoToSave, name: String(formData.name), mobile: String(formData.mobile), email: receiptEmail,
            admissionDate: String(formData.admissionDate), category: String(formData.category), subCategory: String(formData.subCategory),
            batchTime: String(formData.batchTime), location: String(formData.location),
            duration: String(formData.duration), durationType: String(formData.durationType), expiryDate: String(formData.expiryDate),
            extraCharges: cleanedExtraCharges, grandTotal: Number(finalTotalAmount) + extrasTotalToSave, discount: discountToSave,
            paid: (parseFloat(String(formData.paidAmount)) || 0) + extrasPaidToSave, dues: Math.max(0, duesToSave) + extrasDuesToSave, duesDate: duesDateToSave,
            paymentMode: String(formData.paymentMode),
          })
            .then((r) => {
              if (r.sent) toast.success(`Payment receipt ${receiptEmail} par mail ho gayi`);
              else if (r.reason === 'mail_off') toast.info('Student ko mail OFF hai (Settings → Online Admission → Email Settings), isliye receipt mail nahi gayi.');
              else if (r.reason === 'no_email') toast.info('Student ka email sahi nahi hai, receipt mail nahi gayi.');
            })
            .catch((e) => toast.error(`Admission save ho gayi, par receipt mail nahi ja saki: ${onlineAdmissionError(e)}`));
        }
      }

      // Reset form
      setFormData({
        regNo: '',
        admissionDate: new Date().toISOString().split('T')[0],
        name: '',
        gender: '',
        dob: '',
        photo: '',
        aadhaarFront: '',
        aadhaarBack: '',
        mobile: '',
        alternateMobile: '',
        aadhaarNumber: '',
        guardianName: '',
        guardianRelation: '',
        learnedBefore: '',
        address: '',
        category: '',
        subCategory: '',
        batchTime: '',
        location: defaultLocation,
        duration: '',
        durationType: '',
        expiryDate: '',
        totalAmount: '',
        paidAmount: '',
        discountAmount: '',
        duesDate: '',
        dues: 0,
        paymentMode: '',
        email: '',
        status: 'active',
        userId: '',
        password: '',
        customFields: {}
      });
      // Reset category/sub-category dropdown states too — otherwise the
      // dropdown keeps showing the old selection while formData.category
      // is actually empty, causing a false "select category" validation error
      setSelectedCategory('');
      setSelectedSubCategory('');
      setAvailableSubCategories([]);
      setFilteredBatches([]);
      setPhotoPreview('');
      setTempPhoto('');
      setExtraChargesChecked(false);
      setExtraCharges([{ name: '', amount: '', paid: '' }]);
      generateRegNo();
    } catch (error) {
      console.error('Error saving student:', error);
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        toast.error('Storage limit exceeded! कृपया Settings में जाकर पुराने data को export करें और delete करें।');
      } else {
        toast.error('Student save करते समय error आई। कृपया फिर से try करें।');
      }
    }
  };

  const escapeHtml = (v: any) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const getSavedExtraCharges = (): { name: string; amount: number }[] =>
    Array.isArray(savedStudent?.extraCharges)
      ? savedStudent.extraCharges.filter((c: any) => c && (c.name || parseFloat(c.amount)))
      : [];

  const handlePrint = async () => {
    if (!savedStudent) return;
    const extraChargesList = getSavedExtraCharges();
    const extraChargesSum = extraChargesList.reduce((sum, c) => sum + (parseFloat(String(c.amount)) || 0), 0);
    const isSep = hasSeparateExtras(savedStudent);
    // Naye students: totalAmount sirf class fee hai. Purane students me extra charges totalAmount ke andar hote the.
    const baseTotalAmount = isSep ? (parseFloat(String(savedStudent.totalAmount)) || 0) : (parseFloat(String(savedStudent.totalAmount)) || 0) - extraChargesSum;

    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-GB');
    };

    const photoSection = savedStudent.photo ? `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="${savedStudent.photo}" alt="Student Photo" style="width: 150px; height: 150px; object-fit: cover; border-radius: 8px; border: 3px solid #F9CDAA;" />
      </div>
    ` : '';

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${savedStudent.name} - Admission Receipt</title>
        <style>
          @page { size: A4; margin: 15mm; }
          body { 
            font-family: Arial, sans-serif; 
            padding: 15px;
            max-width: 210mm;
            margin: 0 auto;
            font-size: 11pt;
          }
          .header { 
            background-color: #E8630A; 
            padding: 15px; 
            text-align: center;
            margin-bottom: 15px;
            color: white;
          }
          .header h1 { margin: 0; color: white; font-size: 18pt; }
          .header p { margin: 5px 0 0 0; color: white; font-size: 11pt; }
          .section { margin-bottom: 12px; }
          .section h2 { 
            background-color: #FCE6D4; 
            padding: 8px; 
            margin-bottom: 8px;
            font-size: 12pt;
          }
          .row { 
            display: flex; 
            padding: 4px 0; 
            border-bottom: 1px solid #eee;
          }
          .label { 
            font-weight: bold; 
            width: 180px; 
            font-size: 10pt;
          }
          .value { flex: 1; font-size: 10pt; }
          @media print {
            body { padding: 10px; }
          }
        </style>
      </head>
      <body>
        ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Admission Receipt')}
        
        ${photoSection}
        
        <div class="section">
          <h2>Personal Information</h2>
          <div class="row">
            <div class="label">${lbl('regNo', 'Registration No')}:</div>
            <div class="value">${savedStudent.regNo}</div>
          </div>
          <div class="row">
            <div class="label">${lbl('admissionDate', 'Admission Date')}:</div>
            <div class="value">${formatDate(savedStudent.admissionDate)}</div>
          </div>
          <div class="row">
            <div class="label">${lbl('name', 'Student Name')}:</div>
            <div class="value">${savedStudent.name}</div>
          </div>
          ${isVisible('gender') ? `
          <div class="row">
            <div class="label">${lbl('gender', 'Gender')}:</div>
            <div class="value">${savedStudent.gender}</div>
          </div>
          ` : ''}
          ${isVisible('dob') ? `
          <div class="row">
            <div class="label">${lbl('dob', 'Date of Birth')}:</div>
            <div class="value">${formatDate(savedStudent.dob)}</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">${lbl('mobile', 'Mobile')}:</div>
            <div class="value">${savedStudent.mobile}</div>
          </div>
          ${savedStudent.alternateMobile ? `
          <div class="row">
            <div class="label">${lbl('alternateMobile', 'Alternate Mobile')}:</div>
            <div class="value">${savedStudent.alternateMobile}</div>
          </div>
          ` : ''}
          ${savedStudent.aadhaarNumber ? `
          <div class="row">
            <div class="label">${lbl('aadhaarNumber', 'Aadhaar Number')}:</div>
            <div class="value">${savedStudent.aadhaarNumber}</div>
          </div>
          ` : ''}
          ${savedStudent.email ? `
          <div class="row">
            <div class="label">${lbl('email', 'Email')}:</div>
            <div class="value">${savedStudent.email}</div>
          </div>
          ` : ''}
          ${savedStudent.learnedBefore ? `
          <div class="row">
            <div class="label">${lbl('learnedBefore', 'Learned Before')}:</div>
            <div class="value">${savedStudent.learnedBefore}</div>
          </div>
          ` : ''}
        </div>

        ${enabledFields.length > 0 ? `
        <div class="section">
          <h2>Additional Information</h2>
          ${enabledFields.map((field) => {
            const val = getFieldValue(savedStudent.customFields, field.id);
            return val ? `
          <div class="row">
            <div class="label">${field.label}:</div>
            <div class="value">${val}</div>
          </div>
            ` : '';
          }).join('')}
        </div>
        ` : ''}

        ${(isVisible('guardianName') || isVisible('guardianRelation') || isVisible('address')) ? `
        <div class="section">
          <h2>Guardian Information</h2>
          ${isVisible('guardianName') ? `
          <div class="row">
            <div class="label">${lbl('guardianName', 'Guardian Name')}:</div>
            <div class="value">${savedStudent.guardianName}</div>
          </div>
          ` : ''}
          ${isVisible('guardianRelation') ? `
          <div class="row">
            <div class="label">${lbl('guardianRelation', 'Relation')}:</div>
            <div class="value">${savedStudent.guardianRelation}</div>
          </div>
          ` : ''}
          ${isVisible('address') ? `
          <div class="row">
            <div class="label">${lbl('address', 'Address')}:</div>
            <div class="value">${savedStudent.address}</div>
          </div>
          ` : ''}
        </div>
        ` : ''}

        <div class="section">
          <h2>Course Information</h2>
          <div class="row">
            <div class="label">Category:</div>
            <div class="value">${savedStudent.category}</div>
          </div>
          ${savedStudent.subCategory ? `
          <div class="row">
            <div class="label">Sub-Category:</div>
            <div class="value">${savedStudent.subCategory}</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Batch Time:</div>
            <div class="value">${savedStudent.batchTime}</div>
          </div>
          <div class="row">
            <div class="label">Location:</div>
            <div class="value">${savedStudent.location}</div>
          </div>
          <div class="row">
            <div class="label">Duration:</div>
            <div class="value">${savedStudent.duration} ${savedStudent.durationType}</div>
          </div>
          <div class="row">
            <div class="label">Expiry Date:</div>
            <div class="value">${formatDate(savedStudent.expiryDate)}</div>
          </div>
        </div>

        ${extraChargesList.length > 0 ? (isSep ? `
        <div class="section">
          <h2>Extra Charges</h2>
          ${extraChargesList.map((c) => {
            const cd = extraChargeDues(c);
            return `
          <div class="row">
            <div class="label">${escapeHtml(c.name)}:</div>
            <div class="value">₹${c.amount} &nbsp;|&nbsp; Paid ₹${parseFloat(String(c.paid)) || 0} &nbsp;|&nbsp; <span style="color:${cd > 0 ? 'red' : 'green'};">Dues ₹${cd}</span></div>
          </div>`;
          }).join('')}
          <div class="row">
            <div class="label">Total Extra Charges:</div>
            <div class="value" style="font-weight: bold;">₹${extraChargesSum} &nbsp;|&nbsp; Paid ₹${sumExtraPaid(extraChargesList)} &nbsp;|&nbsp; <span style="color:${sumExtraDues(extraChargesList) > 0 ? 'red' : 'green'};">Dues ₹${sumExtraDues(extraChargesList)}</span></div>
          </div>
        </div>
        ` : `
        <div class="section">
          <h2>Extra Charges</h2>
          ${extraChargesList.map((c) => `
          <div class="row">
            <div class="label">${escapeHtml(c.name)}:</div>
            <div class="value">₹${c.amount}</div>
          </div>`).join('')}
          <div class="row">
            <div class="label">Total Extra Charges:</div>
            <div class="value" style="font-weight: bold;">₹${extraChargesSum} <span style="font-weight: normal;">(included in Grand Total)</span></div>
          </div>
        </div>
        `) : ''}

        <div class="section">
          <h2>Payment Information</h2>
          <div class="row">
            <div class="label">Total Amount:</div>
            <div class="value">₹${baseTotalAmount}</div>
          </div>
          ${extraChargesList.length > 0 && !isSep ? `
          <div class="row">
            <div class="label">Grand Total:</div>
            <div class="value" style="font-weight: bold;">₹${savedStudent.totalAmount} <span style="font-weight: normal;">(Total Amount + Extra Charges)</span></div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Paid Amount:</div>
            <div class="value">₹${savedStudent.paidAmount}</div>
          </div>
          ${(Number(savedStudent.discountAmount) || 0) > 0 ? `
          <div class="row">
            <div class="label">Discount:</div>
            <div class="value" style="color: green; font-weight: bold;">₹${savedStudent.discountAmount} (${discountPercent(savedStudent.totalAmount, savedStudent.discountAmount)}%)</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Dues:</div>
            <div class="value" style="color: ${(savedStudent.dues || 0) > 0 ? 'red' : 'green'};">₹${savedStudent.dues}</div>
          </div>
          ${(savedStudent.dues || 0) > 0 && savedStudent.duesDate ? `
          <div class="row">
            <div class="label">Pay Dues By:</div>
            <div class="value" style="color: red; font-weight: bold;">${formatDate(savedStudent.duesDate)}</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Payment Mode:</div>
            <div class="value">${savedStudent.paymentMode}</div>
          </div>
        </div>

        ${buildBrandingFooter({ businessName, businessPhone })}

        <div class="terms" style="margin-top: 14px; padding-top: 8px; border-top: 1px dashed #bbb; font-size: 9.5pt; color: #333;">
          <p style="margin: 0; font-weight: bold;">Terms &amp; Conditions</p>
          <p style="margin: 3px 0 0 0;">Payment not refundable.</p>
        </div>
      </body>
      </html>
    `;

    await printDocument(html, `${savedStudent.name}_Admission_Receipt`, { fitOnePage: true });
  };

  const handleWhatsApp = () => {
    if (!savedStudent) return;
    
    if (!savedStudent.mobile) {
      toast.error('Mobile number not found!');
      return;
    }
    
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-GB');
    };

    const waExtraCharges = getSavedExtraCharges();
    const waExtraSum = waExtraCharges.reduce((sum, c) => sum + (parseFloat(String(c.amount)) || 0), 0);
    const waSep = hasSeparateExtras(savedStudent);
    const waExtraSection = waExtraCharges.length > 0
      ? (waSep
        ? `\n*Extra Charges:*\n${waExtraCharges.map((c) => `${c.name}: ₹${c.amount} | Paid ₹${parseFloat(String(c.paid)) || 0} | Dues ₹${extraChargeDues(c)}`).join('\n')}\nTotal Extra: ₹${waExtraSum} | Paid ₹${sumExtraPaid(waExtraCharges)} | Dues ₹${sumExtraDues(waExtraCharges)}\n`
        : `\n*Extra Charges:*\n${waExtraCharges.map((c) => `${c.name}: ₹${c.amount}`).join('\n')}\nTotal Extra Charges: ₹${waExtraSum} (included in Grand Total)\n`)
      : '';

    // Custom WhatsApp message format with proper encoding
    const message = 
`*${businessName.toUpperCase()}*
*Admission Successful!*

*Admission Details:*
Name: ${savedStudent.name}
Registration No: ${savedStudent.regNo}
Admission Date: ${formatDate(savedStudent.admissionDate)}
${enabledFields.filter((field) => getFieldValue(savedStudent.customFields, field.id)).map((field) => `${field.label}: ${getFieldValue(savedStudent.customFields, field.id)}`).join('\n')}
Location: ${savedStudent.location}
Batch Time: ${savedStudent.batchTime}
Category: ${savedStudent.category}${savedStudent.subCategory ? ` - ${savedStudent.subCategory}` : ''}
Duration: ${savedStudent.duration} ${savedStudent.durationType}
Expiry Date: ${formatDate(savedStudent.expiryDate)}
${waExtraSection}
*Payment Details:*
Total Amount: ₹${waSep ? (parseFloat(String(savedStudent.totalAmount)) || 0) : (parseFloat(String(savedStudent.totalAmount)) || 0) - waExtraSum}${waExtraCharges.length > 0 && !waSep ? `\nGrand Total (with Extra Charges): ₹${savedStudent.totalAmount}` : ''}
Paid Amount: ₹${savedStudent.paidAmount}${(Number(savedStudent.discountAmount) || 0) > 0 ? `\nDiscount: ₹${savedStudent.discountAmount} (${discountPercent(savedStudent.totalAmount, savedStudent.discountAmount)}%)` : ''}
Dues: ₹${savedStudent.dues}${(savedStudent.dues || 0) > 0 && savedStudent.duesDate ? `\nPay Dues By: ${formatDate(savedStudent.duesDate)}` : ''}


Thank you for joining us!
For any queries, contact academy administration.

*Terms & Conditions*
Payment not refundable.`;

    // Encode the message for WhatsApp
    const encodedMessage = encodeURIComponent(message);
    
    window.open(`https://wa.me/91${savedStudent.mobile}?text=${encodedMessage}`, '_blank');
  };

  // ID Card: Print button jaisa hi — PDF save wali window khulti hai, file ka naam "<Student Name>_ID_Card" aata hai
  const handleIdCard = async () => {
    if (!savedStudent) return;
    setIdCardBusy(true);
    try {
      await printIdCard(savedStudent, idCardSettings);
    } catch (e) {
      console.error('ID card error:', e);
      toast.error('ID Card nahi ban paya. Dobara try karein.');
    } finally {
      setIdCardBusy(false);
    }
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>Admission Form</CardTitle>
        </CardHeader>
        <CardContent>
          {onlineReq && (
            <div className="mb-4 flex items-center justify-between gap-3 rounded-lg border border-green-300 bg-green-50 p-3 text-sm text-green-900">
              <span><strong>Online request:</strong> {onlineReq.data.core.name} ({onlineReq.data.core.mobile}). Save karte hi ye request apne aap hat jayegi.</span>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  releaseAdmissionRequest(onlineReq.id);
                  onlineReqRef.current = null;
                  setOnlineReq(null);
                  setSelectedCategory('');
                  setSelectedSubCategory('');
                  setFormData((prev: any) => ({
                    ...prev, name: '', gender: '', dob: '', mobile: '', alternateMobile: '', aadhaarNumber: '', aadhaarFront: '', aadhaarBack: '', guardianName: '',
                    guardianRelation: '', learnedBefore: '', address: '', email: '', category: '', subCategory: '', batchTime: '',
                    location: defaultLocation, customFields: {},
                  }));
                }}
              >
                Request wapas rakhein
              </Button>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-6">
            <AdmissionFormRenderer
              fields={layoutFields}
              formData={formData}
              onChange={(patch) => setFormData((prev: any) => ({ ...prev, ...patch }))}
              onCustomChange={(id, value) =>
                setFormData((prev: any) => ({ ...prev, customFields: { ...prev.customFields, [id]: value } }))
              }
              onAttachPhoto={openPhotoChooser}
              block={{
                categories,
                selectedCategory,
                selectedSubCategory,
                availableSubCategories,
                filteredBatches,
                locations,
                onCategoryChange: (value) => {
                  setSelectedCategory(value);
                  setFormData((prev: any) => ({ ...prev, category: value, subCategory: '', batchTime: '' }));
                },
                onSubCategoryChange: (value) => {
                  setSelectedSubCategory(value);
                  setFormData((prev: any) => ({ ...prev, subCategory: value, batchTime: '' }));
                },
              }}
              extraChargesSlot={extraChargesEnabled ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="add-extra-charges"
                    checked={extraChargesChecked}
                    onCheckedChange={(checked) => setExtraChargesChecked(checked === true)}
                  />
                  <Label htmlFor="add-extra-charges" className="cursor-pointer">Add Extra Charges</Label>
                </div>

                {extraChargesChecked && (
                  <div className="p-4 border rounded-lg bg-orange-50/50 space-y-4">
                    {/* Quick buttons - admin ek click me common charge jod sakta hai */}
                    <div className="flex flex-wrap gap-2">
                      {EXTRA_CHARGE_PRESETS.map((name) => {
                        const added = extraCharges.some((c) => String(c.name).trim().toLowerCase() === name.toLowerCase());
                        return (
                          <button
                            key={name}
                            type="button"
                            onClick={() => addPresetCharge(name)}
                            disabled={added || extraCharges.length >= MAX_EXTRA_CHARGES}
                            className={`px-4 py-1.5 rounded-full border-2 border-dashed text-sm font-semibold transition ${
                              added
                                ? 'border-green-500 text-green-700 bg-green-50 cursor-default'
                                : 'border-purple-400 text-purple-800 hover:bg-purple-50'
                            }`}
                          >
                            {added ? '✓' : '+'} {name}
                          </button>
                        );
                      })}
                    </div>

                    {extraCharges.map((charge, index) => {
                      const rowDues = extraChargeDues(charge);
                      return (
                      <div key={index} className="grid grid-cols-1 sm:grid-cols-[1.3fr_1fr_1fr_1fr_auto] gap-3 items-end">
                        <div>
                          <Label className="text-sm">Charge Name</Label>
                          <Input
                            value={charge.name}
                            onChange={(e) => updateExtraCharge(index, 'name', e.target.value)}
                            placeholder="e.g. Shoes Charge"
                          />
                        </div>
                        <div>
                          <Label className="text-sm">Charge (₹)</Label>
                          <div className="relative">
                            <span className="absolute left-3 top-2.5">₹</span>
                            <Input
                              type="number"
                              value={charge.amount}
                              onChange={(e) => updateExtraCharge(index, 'amount', e.target.value)}
                              placeholder="0"
                              className="pl-8"
                              min="0"
                            />
                          </div>
                        </div>
                        <div>
                          <Label className="text-sm">Paid (₹)</Label>
                          <div className="relative">
                            <span className="absolute left-3 top-2.5">₹</span>
                            <Input
                              type="number"
                              value={charge.paid ?? ''}
                              onChange={(e) => updateExtraCharge(index, 'paid', e.target.value)}
                              placeholder="0"
                              className="pl-8"
                              min="0"
                            />
                          </div>
                        </div>
                        <div>
                          <Label className="text-sm">Dues (₹)</Label>
                          <div className="relative">
                            <span className="absolute left-3 top-2.5">₹</span>
                            <Input
                              readOnly
                              disabled
                              value={rowDues.toFixed(2)}
                              className={`pl-8 ${rowDues > 0 ? 'text-red-600 font-semibold' : ''}`}
                            />
                          </div>
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          onClick={() => removeExtraChargeRow(index)}
                          className="text-red-600 border-red-300 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4 mr-1" /> Remove
                        </Button>
                      </div>
                      );
                    })}

                    <Button
                      type="button"
                      variant="outline"
                      onClick={addExtraChargeRow}
                      disabled={extraCharges.length >= MAX_EXTRA_CHARGES}
                      className="flex items-center gap-2 border-green-600 text-green-700 hover:bg-green-50"
                    >
                      <Plus className="w-4 h-4" /> Add Charge
                      <span className="text-xs text-gray-500">({extraCharges.length}/{MAX_EXTRA_CHARGES})</span>
                    </Button>

                    {/* Grand summary (payment.html jaisa): class fee + extra charges, sab ek saath count */}
                    {(() => {
                      const classTotal = parseFloat(formData.totalAmount) || 0;
                      const classPaid = parseFloat(formData.paidAmount) || 0;
                      const classDues = parseFloat(String(formData.dues)) || 0;
                      const grandTotal = classTotal + extraChargesTotal;
                      const grandPaid = classPaid + extraChargesPaidTotal;
                      const grandDues = classDues + extraChargesDuesTotal;
                      return (
                        <div className="rounded-md bg-purple-50 border border-purple-100 px-4 py-3 text-sm flex flex-wrap gap-x-6 gap-y-1">
                          <span>Total Charge: <b>₹{grandTotal.toFixed(2)}</b></span>
                          <span>Total Paid: <b>₹{grandPaid.toFixed(2)}</b></span>
                          <span>Total Dues: <b className={grandDues > 0 ? 'text-red-600' : ''}>₹{grandDues.toFixed(2)}</b></span>
                        </div>
                      );
                    })()}
                    <p className="text-xs text-gray-500">Upar ka Total Charge / Paid / Dues = class fee + extra charges, sab ek saath. Save mein extra charges class fee se alag rehte hain.</p>
                  </div>
                )}
              </div>
              ) : null}
            />

            {/* NOTE: plain <input> on purpose — the shared <Input> component doesn't forward refs
                (React 18), so photoFileInputRef.current was null and .click() did nothing. */}
            <input
              type="file"
              accept="image/*"
              ref={photoFileInputRef}
              onChange={(e) => {
                const file = e.target.files?.[0];
                const target = photoTargetRef.current;
                if (file && target !== 'photo') {
                  compressDocumentToTarget(file)
                    .then((doc) => setFormData((prev: any) => ({ ...prev, [target]: doc })))
                    .catch(() => toast.error('Photo could not be read. Please choose another one.'));
                } else if (file) {
                  compressPhotoToTarget(file)
                    .then((photo) => {
                      setFormData((prev: any) => ({ ...prev, photo }));
                      setPhotoPreview(photo);
                      setTempPhoto(photo);
                    })
                    .catch(() => toast.error('Photo could not be read. Please choose another one.'));
                }
                e.target.value = '';
              }}
              className="hidden"
              id="photo-upload"
            />

            {/* Submit Button */}
            <div className="flex gap-4">
              <Button type="submit" className="flex items-center gap-2">
                <Save className="w-4 h-4" />
                Save Admission
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Photo Source Chooser Dialog */}
      <Dialog open={showPhotoChoice} onOpenChange={setShowPhotoChoice}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{targetTitle}</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={openLiveCamera}
              className="flex flex-col items-center gap-2 p-5 border rounded-lg hover:bg-orange-50 hover:border-orange-300 transition-colors"
            >
              <Camera className="w-8 h-8 text-orange-500" />
              <span className="font-medium">Live Camera</span>
              <span className="text-xs text-gray-500">Take photo now</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setShowPhotoChoice(false);
                photoFileInputRef.current?.click();
              }}
              className="flex flex-col items-center gap-2 p-5 border rounded-lg hover:bg-orange-50 hover:border-orange-300 transition-colors"
            >
              <Upload className="w-8 h-8 text-orange-500" />
              <span className="font-medium">Upload Photo</span>
              <span className="text-xs text-gray-500">Choose from device</span>
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Live Camera Dialog */}
      <Dialog open={showCamera} onOpenChange={(open) => { if (!open) closeCamera(); }}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{capturedImage ? `Preview — ${targetTitle}` : `Live Camera — ${targetTitle}`}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center">
              {capturedImage ? (
                <img src={capturedImage} alt="Captured" className="w-full h-full object-contain" />
              ) : cameraError ? (
                <p className="text-sm text-red-300 px-6 text-center">{cameraError}</p>
              ) : (
                <video ref={attachVideo} autoPlay playsInline muted className="w-full h-full object-contain" />
              )}
            </div>
            <div className="flex justify-end gap-2">
              {capturedImage ? (
                <>
                  <Button type="button" variant="outline" onClick={retakePhoto} className="flex items-center gap-2">
                    <RotateCcw className="w-4 h-4" /> Retake
                  </Button>
                  <Button type="button" onClick={useCapturedPhoto} className="flex items-center gap-2">
                    <Check className="w-4 h-4" /> Use Photo
                  </Button>
                </>
              ) : (
                <>
                  <Button type="button" variant="outline" onClick={closeCamera}>Cancel</Button>
                  {cameraError ? (
                    <Button type="button" onClick={startCamera}>Try Again</Button>
                  ) : (
                    <Button type="button" onClick={capturePhoto} className="flex items-center gap-2">
                      <Camera className="w-4 h-4" /> Capture
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Admission Saved Successfully!</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Student has been successfully admitted with Registration No: <strong>{savedStudent?.regNo}</strong></p>
            {getSavedExtraCharges().length > 0 && (
              <div className="rounded-md border p-3 text-sm space-y-1">
                <p className="font-semibold">Extra Charges</p>
                {getSavedExtraCharges().map((c, i) => (
                  <div key={i} className="flex justify-between gap-3">
                    <span>{c.name}</span>
                    <span>₹{c.amount} · Paid ₹{parseFloat(String(c.paid)) || 0} · <span className={extraChargeDues(c) > 0 ? 'text-red-600 font-semibold' : 'text-green-600'}>Dues ₹{extraChargeDues(c)}</span></span>
                  </div>
                ))}
                <div className="flex justify-between font-semibold border-t pt-1 gap-3">
                  <span>Total Extra Charges</span>
                  <span>₹{sumExtraCharges(getSavedExtraCharges())} · Paid ₹{sumExtraPaid(getSavedExtraCharges())} · Dues ₹{sumExtraDues(getSavedExtraCharges())}</span>
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Print
              </Button>
              <Button onClick={handleWhatsApp} variant="outline" className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </Button>
              {idCardSettings.enabled && (
                <Button onClick={handleIdCard} disabled={idCardBusy} variant="outline" className="flex items-center gap-2">
                  <IdCard className="w-4 h-4" />
                  {idCardBusy ? 'ID Card ban raha hai...' : 'ID Card'}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
