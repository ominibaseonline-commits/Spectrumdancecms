// Central library of "extra" admission-form fields the admin can turn ON/OFF
// from Settings -> Admission Fields. Each field, once enabled, automatically
// shows up in: Admission Form, Student List (table + edit dialog), the
// Admission Receipt PDF, the Student Details PDF, and the WhatsApp message —
// all of them read from this same list, so there is only one place to
// add/edit a field definition.
//
// Values entered by the admin are stored per-student in `student.customFields`
// (an object keyed by field id) — no database schema change needed.

import { getSetting, saveSetting } from './indexedDB';

export type AdmissionFieldType = 'text' | 'number' | 'date' | 'select' | 'textarea' | 'phone';

export interface AdmissionFieldDef {
  id: string;            // unique key, used as customFields[id]
  label: string;         // shown on form / list / PDF / WhatsApp
  type: AdmissionFieldType;
  options?: string[];    // for type: 'select'
  businessTypes: string[]; // which business categories usually use this field (for grouping in Settings UI)
}

// Grouping labels shown in Settings UI
export const BUSINESS_TYPES = [
  'Gym / Fitness',
  'Coaching / Tuition',
  'Sports Academy',
  'Salon / Spa',
  'Corporate / Skill Training',
  'Art / Music / Dance',
] as const;

export const ALL_ADMISSION_FIELDS: AdmissionFieldDef[] = [
  // Gym / Fitness
  { id: 'height', label: 'Height (cm)', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'weight', label: 'Weight (kg)', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'fitnessGoal', label: 'Fitness Goal', type: 'select', options: ['Weight Loss', 'Weight Gain', 'General Fitness', 'Muscle Building'], businessTypes: ['Gym / Fitness'] },
  { id: 'medicalCondition', label: 'Medical Condition / Injury History', type: 'textarea', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'bloodGroup', label: 'Blood Group', type: 'select', options: ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'], businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'emergencyContact', label: 'Emergency Contact Number', type: 'text', businessTypes: ['Gym / Fitness', 'Sports Academy'] },
  { id: 'trainerAssigned', label: 'Trainer Assigned', type: 'text', businessTypes: ['Gym / Fitness'] },
  { id: 'membershipType', label: 'Membership Type', type: 'select', options: ['General', 'Personal Training', 'Couple'], businessTypes: ['Gym / Fitness'] },
  { id: 'lockerNumber', label: 'Locker Number', type: 'text', businessTypes: ['Gym / Fitness'] },

  // Coaching / Tuition
  { id: 'schoolName', label: 'School / College Name', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'classGrade', label: 'Class / Grade', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'subjectsEnrolled', label: 'Subjects Enrolled', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'previousMarks', label: 'Previous Marks / Percentage', type: 'text', businessTypes: ['Coaching / Tuition'] },
  { id: 'board', label: 'Board', type: 'select', options: ['CBSE', 'ICSE', 'State Board', 'Other'], businessTypes: ['Coaching / Tuition'] },
  { id: 'parentOccupation', label: "Parent's Occupation", type: 'text', businessTypes: ['Coaching / Tuition'] },

  // Sports Academy
  { id: 'sportRole', label: 'Sport-specific Role (e.g. Bowler, Batsman)', type: 'text', businessTypes: ['Sports Academy'] },
  { id: 'skillLevel', label: 'Skill Level', type: 'select', options: ['Beginner', 'Intermediate', 'Advanced'], businessTypes: ['Sports Academy'] },
  { id: 'medicalFitnessCert', label: 'Medical Fitness Certificate Submitted', type: 'select', options: ['Yes', 'No'], businessTypes: ['Sports Academy'] },
  { id: 'kitSize', label: 'Kit / Jersey Size', type: 'text', businessTypes: ['Sports Academy'] },
  { id: 'tournamentExperience', label: 'Previous Tournament Experience', type: 'textarea', businessTypes: ['Sports Academy'] },

  // Salon / Spa
  { id: 'skinHairType', label: 'Skin / Hair Type', type: 'text', businessTypes: ['Salon / Spa'] },
  { id: 'allergyInfo', label: 'Allergy Information', type: 'textarea', businessTypes: ['Salon / Spa'] },
  { id: 'packageName', label: 'Package Name', type: 'text', businessTypes: ['Salon / Spa'] },
  { id: 'sessionsTotal', label: 'Sessions Total', type: 'number', businessTypes: ['Salon / Spa'] },
  { id: 'sessionsUsed', label: 'Sessions Used', type: 'number', businessTypes: ['Salon / Spa'] },
  { id: 'preferredStaff', label: 'Preferred Staff / Stylist', type: 'text', businessTypes: ['Salon / Spa'] },

  // Corporate / Skill Training
  { id: 'companyName', label: 'Company Name', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'designation', label: 'Designation', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'qualification', label: 'Qualification', type: 'text', businessTypes: ['Corporate / Skill Training'] },
  { id: 'certificateIssued', label: 'Certificate Issued', type: 'select', options: ['Yes', 'No'], businessTypes: ['Corporate / Skill Training'] },

  // Art / Music / Dance
  { id: 'instrumentArtForm', label: 'Instrument / Art Form', type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'performanceGrade', label: 'Performance Level / Grade', type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'studentOccupation', label: "Student's Occupation", type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'currentAddress', label: 'Current Address', type: 'textarea', businessTypes: ['Art / Music / Dance'] },
  { id: 'guardianMobile', label: 'Guardian Mobile No', type: 'phone', businessTypes: ['Art / Music / Dance'] },
  { id: 'guardianOccupation', label: "Guardian's Occupation", type: 'text', businessTypes: ['Art / Music / Dance'] },
  { id: 'permanentAddress', label: 'Permanent Address', type: 'textarea', businessTypes: ['Art / Music / Dance'] },
];

const SETTING_KEY = 'enabledAdmissionFields';

export async function getEnabledFieldIds(): Promise<string[]> {
  try {
    const saved = await getSetting(SETTING_KEY);
    return Array.isArray(saved) ? saved : [];
  } catch (error) {
    console.error('Error loading enabled admission fields:', error);
    return [];
  }
}

export async function saveEnabledFieldIds(ids: string[]): Promise<void> {
  await saveSetting(SETTING_KEY, ids);
}

export function getEnabledFieldDefs(enabledIds: string[]): AdmissionFieldDef[] {
  const idSet = new Set(enabledIds);
  return ALL_ADMISSION_FIELDS.filter((f) => idSet.has(f.id));
}

export function getFieldValue(customFields: Record<string, any> | undefined, id: string): string {
  if (!customFields) return '';
  const val = customFields[id];
  return val === undefined || val === null ? '' : String(val);
}

// ---------------------------------------------------------------------------
// Extra Charges (AC charges, dress, ID card, shoes, security ...)
// Admin turns this ON from Settings -> Admission Fields. Once ON, the Admission
// Form gets an "Add Extra Charges" checkbox where up to MAX_EXTRA_CHARGES
// name + amount rows can be added. The breakdown is stored per-student in
// `student.extraCharges` ([{name, amount, paid}]). NEW students (extraChargesSeparate = true) keep
// extra charges SEPARATE from the class fee: totalAmount / paidAmount / dues are class-only, and
// every extra charge has its own paid + dues. OLD students (flag missing) still have the extra
// charges included inside totalAmount.
// The breakdown is shown only in Student List -> Edit dialog and Student
// Details PDF.
// ---------------------------------------------------------------------------

export interface ExtraCharge {
  name: string;
  amount: string | number;
  paid?: string | number;   // is extra charge me ab tak kitna paid hua
}

export const MAX_EXTRA_CHARGES = 10;

const EXTRA_CHARGES_KEY = 'extraChargesEnabled';

export async function getExtraChargesEnabled(): Promise<boolean> {
  try {
    const saved = await getSetting(EXTRA_CHARGES_KEY);
    return saved === true;
  } catch (error) {
    console.error('Error loading extra charges setting:', error);
    return false;
  }
}

export async function saveExtraChargesEnabled(enabled: boolean): Promise<void> {
  await saveSetting(EXTRA_CHARGES_KEY, enabled);
}

export function sumExtraCharges(charges: ExtraCharge[] | undefined | null): number {
  if (!Array.isArray(charges)) return 0;
  return charges.reduce((sum, c) => sum + (parseFloat(String(c?.amount)) || 0), 0);
}

export function sumExtraPaid(charges: ExtraCharge[] | undefined | null): number {
  if (!Array.isArray(charges)) return 0;
  return charges.reduce((sum, c) => sum + (parseFloat(String(c?.paid)) || 0), 0);
}

/** Ek extra charge ka baaki (amount - paid). */
export function extraChargeDues(c: ExtraCharge | undefined | null): number {
  return (parseFloat(String(c?.amount)) || 0) - (parseFloat(String(c?.paid)) || 0);
}

export function sumExtraDues(charges: ExtraCharge[] | undefined | null): number {
  if (!Array.isArray(charges)) return 0;
  return charges.reduce((sum, c) => sum + Math.max(0, extraChargeDues(c)), 0);
}

/** true = naya student jiske extra charges class fee se alag hain. */
export function hasSeparateExtras(student: any): boolean {
  return student?.extraChargesSeparate === true;
}

// ---------- Extra charge payments (kab kitna extra charge collect hua) ----------
// student.extraPayments = [{ id, date: 'YYYY-MM-DD', name: <charge name>, amount, mode }]
// Monthly Collection me "Extra Charge" isi se banta hai. Har charge ka paid hamesha uski payments ke
// jod ke barabar rakhne ke liye syncExtraPayments use hota hai (admission, edit, fees management teeno me).
export interface ExtraPayment {
  id: string;
  date: string;
  name: string;
  amount: number;
  mode: string;
}

const norm = (v: any) => String(v ?? '').trim().toLowerCase();

export function todayYmd(): string {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

/**
 * charges ke paid ke hisaab se payments list ko barabar karta hai.
 *  - paid zyada hua  -> nayi payment (date, mode ke saath) judti hai
 *  - paid kam hua    -> sabse nayi payments me se utna ghat jata hai
 *  - charge hata diya -> uski payments bhi hat jati hain
 */
export function syncExtraPayments(
  charges: ExtraCharge[] | undefined | null,
  payments: ExtraPayment[] | undefined | null,
  date: string,
  mode: string,
): ExtraPayment[] {
  const list: ExtraPayment[] = Array.isArray(payments) ? payments.map((p) => ({ ...p })) : [];
  const names = new Set((charges || []).map((c) => norm(c?.name)));
  let out = list.filter((p) => names.has(norm(p.name)));
  const paidByName = new Map<string, number>();
  (charges || []).forEach((c) => {
    const k = norm(c?.name);
    paidByName.set(k, (paidByName.get(k) || 0) + (parseFloat(String(c?.paid)) || 0));
  });
  paidByName.forEach((paid, k) => {
    const logged = out.filter((p) => norm(p.name) === k).reduce((s, p) => s + p.amount, 0);
    const diff = Math.round((paid - logged) * 100) / 100;
    if (diff > 0) {
      const display = (charges || []).find((c) => norm(c?.name) === k)?.name || k;
      out.push({ id: `xp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, date, name: String(display), amount: diff, mode });
    } else if (diff < 0) {
      let toCut = -diff;
      const mine = out.filter((p) => norm(p.name) === k).sort((a, b) => (a.date < b.date ? 1 : -1));
      for (const p of mine) {
        if (toCut <= 0) break;
        const cut = Math.min(p.amount, toCut);
        p.amount = Math.round((p.amount - cut) * 100) / 100;
        toCut -= cut;
      }
      out = out.filter((p) => p.amount > 0);
    }
  });
  return out;
}
