import { getSetting, saveSetting } from './indexedDB';

// Admin ke apne kharche: Teacher payment, Studio rent, Water bill, ...
//  recurring = true  -> har mahine (dueDay tareekh ko) aata rehta hai, jab tak admin band/delete na kare
//  recurring = false -> sirf ek mahine ka (date par)
// paid[YYYY-MM] = us mahine ka kharcha chuka diya (reminder band ho jaata hai)

export interface ExpensePaid { paidDate: string; amount: number }
export interface Expense {
  id: string;
  name: string;
  amount: number;
  recurring: boolean;
  dueDay: number;          // recurring: mahine ki tareekh (1-31)
  date: string;            // one-time: YYYY-MM-DD
  startMonth: string;      // recurring: YYYY-MM se shuru
  endMonth?: string;       // recurring: is mahine tak (band karne par)
  paid: Record<string, ExpensePaid>;
  createdAt: string;
}
export interface ExpenseOccurrence {
  key: string;             // id + month
  expense: Expense;
  month: string;           // YYYY-MM
  dueDate: string;         // YYYY-MM-DD
  amount: number;
  isPaid: boolean;
  paidDate?: string;
}

const KEY = 'expenses';
const pad = (n: number) => String(n).padStart(2, '0');

export async function getExpenses(): Promise<Expense[]> {
  try {
    const v = await getSetting(KEY);
    return Array.isArray(v) ? v : [];
  } catch { return []; }
}
export async function saveExpenses(list: Expense[]): Promise<void> {
  await saveSetting(KEY, list);
  window.dispatchEvent(new CustomEvent('expensesUpdated'));
}

export const monthKey = (y: number, m0: number) => `${y}-${pad(m0 + 1)}`;
export const toYmd = (d: Date) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function dueDateFor(e: Expense, month: string): string {
  const [y, m] = month.split('-').map(Number);
  const last = new Date(y, m, 0).getDate();
  return `${month}-${pad(Math.min(Math.max(1, e.dueDay || 1), last))}`;
}

/** Ek mahine (YYYY-MM) ke saare kharche (recurring + one-time), due date ke hisaab se. */
export function occurrencesForMonth(list: Expense[], month: string): ExpenseOccurrence[] {
  const out: ExpenseOccurrence[] = [];
  for (const e of list) {
    let due: string | null = null;
    if (e.recurring) {
      if (month >= e.startMonth && (!e.endMonth || month <= e.endMonth)) due = dueDateFor(e, month);
    } else if (String(e.date).startsWith(month)) {
      due = String(e.date).slice(0, 10);
    }
    if (!due) continue;
    const p = e.paid?.[month];
    out.push({ key: `${e.id}-${month}`, expense: e, month, dueDate: due, amount: p ? p.amount : e.amount, isPaid: !!p, paidDate: p?.paidDate });
  }
  return out.sort((a, b) => (a.dueDate < b.dueDate ? -1 : 1));
}

/** Dashboard reminder: unpaid kharche jinki date 'days' din ke andar hai (ya nikal chuki hai). */
export function upcomingReminders(list: Expense[], days = 3, today = new Date()): (ExpenseOccurrence & { daysLeft: number })[] {
  const base = new Date(today.getFullYear(), today.getMonth(), today.getDate());
  const months = new Set<string>();
  for (let i = -1; i <= 1; i++) {
    const d = new Date(base.getFullYear(), base.getMonth() + i, 1);
    months.add(monthKey(d.getFullYear(), d.getMonth()));
  }
  const res: (ExpenseOccurrence & { daysLeft: number })[] = [];
  months.forEach((mo) => {
    occurrencesForMonth(list, mo).forEach((o) => {
      if (o.isPaid) return;
      const [y, m, d] = o.dueDate.split('-').map(Number);
      const daysLeft = Math.round((new Date(y, m - 1, d).getTime() - base.getTime()) / 86400000);
      // aane wale 'days' din ke andar, ya haal hi (10 din tak) nikal chuke unpaid kharche
      if (daysLeft <= days && daysLeft >= -10) res.push({ ...o, daysLeft });
    });
  });
  return res.sort((a, b) => a.daysLeft - b.daysLeft);
}

export const newExpenseId = () => `exp-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
