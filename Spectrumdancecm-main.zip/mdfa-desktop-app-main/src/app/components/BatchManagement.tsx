import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import { Plus, Edit, Trash2, Users, AlertTriangle, Calendar, Pin, ChevronUp, ChevronDown } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { getAllBatches, saveBatch, deleteBatch, getAllCategories, getAllStudents, saveStudent, getAllLocations } from '../lib/indexedDB';

const WEEKDAYS = [
  { id: 'monday', label: 'Monday' },
  { id: 'tuesday', label: 'Tuesday' },
  { id: 'wednesday', label: 'Wednesday' },
  { id: 'thursday', label: 'Thursday' },
  { id: 'friday', label: 'Friday' },
  { id: 'saturday', label: 'Saturday' },
  { id: 'sunday', label: 'Sunday' }
];

export function BatchManagement() {
  const [batches, setBatches] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [students, setStudents] = useState<any[]>([]);
  const [batchTime, setBatchTime] = useState('');
  const [batchName, setBatchName] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');
  const [availableSubCategories, setAvailableSubCategories] = useState<string[]>([]);
  const [selectedDays, setSelectedDays] = useState<string[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [selectedLocation, setSelectedLocation] = useState('');
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [oldBatchTime, setOldBatchTime] = useState('');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingBatch, setDeletingBatch] = useState<any>(null);
  const [deletingIndex, setDeletingIndex] = useState<number | null>(null);

  // Popup: list of students in a batch
  const [showBatchStudents, setShowBatchStudents] = useState(false);
  const [viewingBatch, setViewingBatch] = useState<any>(null);

  // Confirm popup: apply new batch time to already-enrolled students or not
  const [showTimeChangeConfirm, setShowTimeChangeConfirm] = useState(false);
  const [pendingTimeChange, setPendingTimeChange] = useState<{ oldBatchTime: string; newBatchTime: string; students: any[] } | null>(null);

  useEffect(() => {
    loadBatches(); loadCategories(); loadLocations(); loadStudents();
    const handler = () => loadStudents();
    window.addEventListener('studentsUpdated', handler);
    return () => window.removeEventListener('studentsUpdated', handler);
  }, []);

  useEffect(() => {
    if (selectedCategory) {
      const category = categories.find(c => c.name === selectedCategory);
      if (category) {
        setAvailableSubCategories(category.subCategories || []);
        if (!category.subCategories.includes(selectedSubCategory)) setSelectedSubCategory('');
      }
    } else {
      setAvailableSubCategories([]);
      setSelectedSubCategory('');
    }
  }, [selectedCategory, categories]);

  const loadBatches = async () => { setBatches(await getAllBatches()); };
  const loadLocations = async () => { setLocations(await getAllLocations()); };
  const loadCategories = async () => { setCategories(await getAllCategories()); };
  const loadStudents = async () => { setStudents(await getAllStudents()); };

  const { matchesLocation } = useLocationFilter();
  const visibleBatches = batches.filter((b: any) => matchesLocation(b.location));
  const getStudentsForBatch = (time: string) => students.filter((s: any) => s.batchTime === time && matchesLocation(s.location));

  const resetForm = () => {
    setBatchTime(''); setBatchName(''); setSelectedLocation(''); setSelectedCategory(''); setSelectedSubCategory(''); setSelectedDays([]); setEditingIndex(null); setOldBatchTime('');
  };

  const handleAddBatch = async () => {
    if (!batchTime || !batchName) { toast.error('Please fill all fields'); return; }
    if (!selectedLocation) { toast.error('Please select a location'); return; }
    if (!selectedCategory || !selectedSubCategory) { toast.error('Please select category and sub-category'); return; }
    if (selectedDays.length === 0) { toast.error('Please select at least one day'); return; }

    // When editing, keep the batch's original position (order) and createdAt so it stays in the same place in the list
    const originalBatch = editingIndex !== null ? batches[editingIndex] : null;
    const batchData: any = { batchTime, batchName, location: selectedLocation, category: selectedCategory, subCategory: selectedSubCategory, weeklySchedule: selectedDays };
    if (originalBatch) {
      if (originalBatch.order !== undefined) batchData.order = originalBatch.order;
      if (originalBatch.createdAt) batchData.createdAt = originalBatch.createdAt;
    }

    // If editing and batch time changed, update the batch entry itself right away.
    // Whether to also update already-enrolled students is asked via a confirm popup.
    if (editingIndex !== null && oldBatchTime && oldBatchTime !== batchTime) {
      await deleteBatch(oldBatchTime);
      await saveBatch(batchData);

      const allStudents = await getAllStudents();
      const affected = allStudents.filter((s: any) => s.batchTime === oldBatchTime);

      loadBatches();
      window.dispatchEvent(new CustomEvent('batchesUpdated'));
      resetForm();

      if (affected.length > 0) {
        setPendingTimeChange({ oldBatchTime, newBatchTime: batchTime, students: affected });
        setShowTimeChangeConfirm(true);
      } else {
        toast.success('Batch updated!');
      }
    } else {
      await saveBatch(batchData);
      toast.success(editingIndex !== null ? 'Batch updated!' : 'Batch added!');
      resetForm();
      loadBatches();
      window.dispatchEvent(new CustomEvent('batchesUpdated'));
    }
  };

  // Admin clicked "Yes" — apply the new batch time to every student who was in the old batch
  const confirmApplyTimeToStudents = async () => {
    if (!pendingTimeChange) return;
    const { newBatchTime, students: affected } = pendingTimeChange;
    for (const student of affected) {
      await saveStudent({ ...student, batchTime: newBatchTime });
    }
    await loadStudents();
    window.dispatchEvent(new CustomEvent('studentsUpdated'));
    toast.success(`${affected.length} student(s) batch time updated to "${newBatchTime}"`);
    setShowTimeChangeConfirm(false);
    setPendingTimeChange(null);
  };

  // Admin clicked "No" — batch time is already updated, but existing students keep their current time
  const skipApplyTimeToStudents = () => {
    toast.success('Batch time updated. Existing students keep their current batch time.');
    setShowTimeChangeConfirm(false);
    setPendingTimeChange(null);
  };

  const handleEdit = (index: number) => {
    const batch = batches[index];
    setBatchTime(batch.batchTime);
    setBatchName(batch.batchName);
    setSelectedLocation(batch.location || '');
    setSelectedCategory(batch.category || '');
    setSelectedSubCategory(batch.subCategory || '');
    setSelectedDays(batch.weeklySchedule || []);
    setEditingIndex(index);
    setOldBatchTime(batch.batchTime);
  };

  // Move a batch up/down (swaps with the neighbouring batch that is currently visible in the list)
  const moveBatch = async (batch: any, direction: 'up' | 'down') => {
    const visIdx = visibleBatches.indexOf(batch);
    const targetVis = direction === 'up' ? visIdx - 1 : visIdx + 1;
    if (visIdx < 0 || targetVis < 0 || targetVis >= visibleBatches.length) return;

    const target = visibleBatches[targetVis];
    const reordered = [...batches];
    const a = reordered.indexOf(batch);
    const b = reordered.indexOf(target);
    if (a < 0 || b < 0) return;
    [reordered[a], reordered[b]] = [reordered[b], reordered[a]];

    // Re-number every batch (1..n) so order values are always unique and consistent
    const renumbered = reordered.map((bt, i) => ({ ...bt, order: i + 1 }));
    setBatches(renumbered); // instant UI update
    for (const bt of renumbered) {
      const prev = batches.find((x: any) => x.batchTime === bt.batchTime);
      if (!prev || prev.order !== bt.order) await saveBatch(bt);
    }
    await loadBatches();
    window.dispatchEvent(new CustomEvent('batchesUpdated'));
  };

  const handleDayToggle = (dayId: string) => {
    setSelectedDays(prev => prev.includes(dayId) ? prev.filter(d => d !== dayId) : [...prev, dayId]);
  };

  const handleDeleteClick = async (index: number) => {
    const batch = batches[index];
    const allStudents = await getAllStudents();
    const studentCount = allStudents.filter((s: any) => s.batchTime === batch.batchTime).length;
    setDeletingBatch({ ...batch, studentCount });
    setDeletingIndex(index);
    setShowDeleteConfirm(true);
  };

  const confirmDelete = async () => {
    if (deletingIndex === null) return;
    const batch = batches[deletingIndex];
    await deleteBatch(batch.batchTime);
    loadBatches();
    setShowDeleteConfirm(false);
    setDeletingBatch(null);
    setDeletingIndex(null);
    toast.success('Batch deleted! (Student data retained)');
    window.dispatchEvent(new CustomEvent('batchesUpdated'));
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader><CardTitle>{editingIndex !== null ? 'Edit Batch' : 'Add Batch'}</CardTitle></CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Category *</Label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger><SelectValue placeholder="Select Category" /></SelectTrigger>
                <SelectContent>
                  {categories.length > 0 ? categories.map((c: any) => (<SelectItem key={c.id} value={c.name}>{c.name}</SelectItem>)) : <SelectItem value="no-categories" disabled>No categories available</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Sub-Category *</Label>
              <Select value={selectedSubCategory} onValueChange={setSelectedSubCategory} disabled={!selectedCategory || availableSubCategories.length === 0}>
                <SelectTrigger><SelectValue placeholder="Select Sub-Category" /></SelectTrigger>
                <SelectContent>
                  {availableSubCategories.length > 0 ? availableSubCategories.map((s: string, i: number) => (<SelectItem key={i} value={s}>{s}</SelectItem>)) : <SelectItem value="none" disabled>Select category first</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Location *</Label>
              <Select value={selectedLocation} onValueChange={setSelectedLocation}>
                <SelectTrigger><SelectValue placeholder={locations.length === 0 ? "Add location first" : "Select Location"} /></SelectTrigger>
                <SelectContent>
                  {locations.length > 0 ? locations.map((l: any) => (
                    <SelectItem key={l.name} value={l.name}>{l.name}</SelectItem>
                  )) : <SelectItem value="none" disabled>No locations — add from Location section</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Batch Time (e.g., 7:30 AM - 9:00 AM)</Label>
              <Input value={batchTime} onChange={(e) => setBatchTime(e.target.value)} placeholder="Enter batch time" />
            </div>
            <div>
              <Label>Batch Name</Label>
              <Input value={batchName} onChange={(e) => setBatchName(e.target.value)} placeholder="Enter batch name" />
            </div>
          </div>

          {editingIndex !== null && oldBatchTime && oldBatchTime !== batchTime && (
            <div className="mt-3 p-3 bg-yellow-50 border border-yellow-300 rounded text-sm text-yellow-800">
              <AlertTriangle className="inline w-4 h-4 -mt-0.5 mr-1" /> Changing this batch's time — you'll be asked whether to also update students already assigned to "<strong>{oldBatchTime}</strong>"
            </div>
          )}

          <div className="mt-4">
            <Label className="mb-2 block">Weekly Schedule *</Label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {WEEKDAYS.map((day) => (
                <div key={day.id} className="flex items-center space-x-2 p-2 rounded border hover:bg-gray-50">
                  <Checkbox id={day.id} checked={selectedDays.includes(day.id)} onCheckedChange={() => handleDayToggle(day.id)} />
                  <label htmlFor={day.id} className="text-sm font-medium cursor-pointer">{day.label}</label>
                </div>
              ))}
            </div>
            {selectedDays.length > 0 && (
              <p className="text-sm text-gray-600 mt-2">Selected: {selectedDays.map(d => WEEKDAYS.find(w => w.id === d)?.label).join(', ')}</p>
            )}
          </div>

          <div className="flex gap-2 mt-4">
            <Button onClick={handleAddBatch}><Plus className="w-4 h-4 mr-2" />{editingIndex !== null ? 'Update Batch' : 'Add Batch'}</Button>
            {editingIndex !== null && (
              <Button variant="outline" onClick={resetForm}>Cancel</Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Batch List</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-4">
            {visibleBatches.length > 0 ? visibleBatches.map((batch, visIndex) => { const index = batches.indexOf(batch); return (
              <div key={batch.batchTime} className="flex items-center justify-between p-4 rounded-lg" style={{ backgroundColor: 'var(--app-bg)' }}>
                <div className="flex items-center gap-3">
                  <div className="flex items-center justify-center w-8 h-8 rounded-full bg-orange-500 text-white font-bold">{visIndex + 1}</div>
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <p className="font-semibold">{batch.batchTime}</p>
                      <span className="text-gray-400">•</span>
                      <p className="text-gray-600">{batch.batchName}</p>
                    </div>
                    {batch.category && (
                      <div className="flex items-center gap-2 text-sm">
                        <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded">{batch.category}</span>
                        {batch.subCategory && <><span className="text-gray-400">→</span><span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded">{batch.subCategory}</span></>}
                      </div>
                    )}
                    {batch.weeklySchedule?.length > 0 && (
                      <p className="text-xs text-gray-600 mt-1 flex items-center gap-1"><Calendar className="w-3.5 h-3.5" /> {batch.weeklySchedule.map((d: string) => WEEKDAYS.find(w => w.id === d)?.label.slice(0, 3)).join(', ')}</p>
                    )}
                    <button
                      type="button"
                      onClick={() => { setViewingBatch(batch); setShowBatchStudents(true); }}
                      className="flex items-center gap-1 text-xs mt-2 px-2 py-1 rounded bg-white border border-orange-300 text-orange-700 hover:bg-orange-50"
                    >
                      <Users className="w-3.5 h-3.5" />
                      {getStudentsForBatch(batch.batchTime).length} student{getStudentsForBatch(batch.batchTime).length !== 1 ? 's' : ''}
                    </button>
                  </div>
                </div>
                <div className="flex gap-2 items-center">
                  <div className="flex flex-col gap-1">
                    <Button size="sm" variant="outline" className="h-6 w-8 p-0" title="Move up" disabled={visIndex === 0} onClick={() => moveBatch(batch, 'up')}><ChevronUp className="w-4 h-4" /></Button>
                    <Button size="sm" variant="outline" className="h-6 w-8 p-0" title="Move down" disabled={visIndex === visibleBatches.length - 1} onClick={() => moveBatch(batch, 'down')}><ChevronDown className="w-4 h-4" /></Button>
                  </div>
                  <Button size="sm" variant="outline" onClick={() => handleEdit(index)}><Edit className="w-4 h-4" /></Button>
                  <Button size="sm" variant="outline" onClick={() => handleDeleteClick(index)}><Trash2 className="w-4 h-4" /></Button>
                </div>
              </div>
            ); }) : <p className="text-center text-gray-500 py-8">No batches added yet</p>}
          </div>
        </CardContent>
      </Card>

      {/* Delete Confirm Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Delete Batch</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded">
              <p className="font-semibold text-yellow-800 flex items-center gap-1.5"><AlertTriangle className="w-4 h-4" /> Are you sure?</p>
              <p className="text-sm text-yellow-700 mt-2">
                Batch "<strong>{deletingBatch?.batchTime}</strong>" will be deleted.
              </p>
              {deletingBatch?.studentCount > 0 && (
                <p className="text-sm text-orange-700 mt-1">
                  <Pin className="inline w-3.5 h-3.5 -mt-0.5 mr-1" /> <strong>{deletingBatch.studentCount} student(s)</strong> are in this batch — their data will NOT be deleted, only the batch will be removed.
                </p>
              )}
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setShowDeleteConfirm(false)} className="flex-1">Cancel</Button>
              <Button onClick={confirmDelete} className="flex-1 bg-red-600 hover:bg-red-700 text-white">Delete Batch</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Students-in-batch popup */}
      <Dialog open={showBatchStudents} onOpenChange={setShowBatchStudents}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Students in "{viewingBatch?.batchTime}" — {viewingBatch?.batchName}</DialogTitle>
          </DialogHeader>
          <div className="space-y-2 max-h-80 overflow-y-auto">
            {viewingBatch && getStudentsForBatch(viewingBatch.batchTime).length > 0 ? (
              getStudentsForBatch(viewingBatch.batchTime).map((student: any) => (
                <div key={student.regNo} className="flex items-center justify-between p-2 rounded border">
                  <div>
                    <p className="font-medium">{student.name}</p>
                    <p className="text-xs text-gray-500">Reg No: {student.regNo} • {student.mobile}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-center text-gray-500 py-6">No students in this batch yet</p>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Batch time changed — apply to existing students? */}
      <Dialog open={showTimeChangeConfirm} onOpenChange={(open) => { if (!open) skipApplyTimeToStudents(); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Update students' batch time too?</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded">
              <p className="text-sm text-yellow-800">
                Batch time changed from "<strong>{pendingTimeChange?.oldBatchTime}</strong>" to "<strong>{pendingTimeChange?.newBatchTime}</strong>".
              </p>
              <p className="text-sm text-yellow-800 mt-2">
                <Pin className="inline w-3.5 h-3.5 -mt-0.5 mr-1" /> <strong>{pendingTimeChange?.students.length} student(s)</strong> are currently assigned to this batch. Do you want to update their batch time to "<strong>{pendingTimeChange?.newBatchTime}</strong>" as well?
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={skipApplyTimeToStudents} className="flex-1">No, keep their time</Button>
              <Button onClick={confirmApplyTimeToStudents} className="flex-1 bg-orange-500 hover:bg-orange-600 text-white">Yes, update all</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
