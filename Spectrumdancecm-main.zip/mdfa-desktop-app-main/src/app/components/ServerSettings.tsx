import { useState, useSyncExternalStore } from 'react';
import { Server, CheckCircle2, Cloud, RefreshCw, AlertTriangle, Copy, WifiOff } from 'lucide-react';
import { toast } from 'sonner';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import {
  connectServer,
  syncNow,
  subscribeServerSync,
  getServerSyncState,
} from '../lib/serverSync';
import { SERVER_SCHEMA_SQL } from '../lib/serverSchema';
import { getStoredLicenseKey } from '../lib/googleSheetLicense';

const hostOf = (url: string) => {
  try {
    return new URL(url).host;
  } catch {
    return url;
  }
};

const maskKey = (key: string | null) =>
  key && key.length > 8 ? `${key.slice(0, 4)}••••${key.slice(-4)}` : key || '-';

export function ServerSettings() {
  const state = useSyncExternalStore(subscribeServerSync, getServerSyncState);
  const [busy, setBusy] = useState(false);
  const licenseKey = getStoredLicenseKey();

  const run = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
    } finally {
      setBusy(false);
    }
  };

  const handleConnect = () =>
    run(async () => {
      const result = await connectServer();
      if (result.status === 'ready') {
        toast.success('Server connect ho gaya! Ab data kisi bhi device par milega.');
      }
    });

  const handleSync = () =>
    run(async () => {
      if (await syncNow()) toast.success('Sync complete');
    });

  const copySql = async () => {
    try {
      await navigator.clipboard.writeText(SERVER_SCHEMA_SQL);
      toast.success('SQL copy ho gaya. Supabase → SQL Editor mein paste karke Run karein.');
    } catch {
      toast.error('Copy nahi hua. Neeche wale box se select karke copy karein.');
    }
  };

  const connected = state.status === 'ready';

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Server className="w-5 h-5" /> Server (Cloud Sync)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {connected && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-4 space-y-2">
            <div className="flex items-center gap-2 text-green-800 font-medium">
              <CheckCircle2 className="w-5 h-5" /> Server connected
            </div>
            <div className="text-sm text-gray-700 space-y-1">
              <div>
                Server: <span className="font-mono">{hostOf(state.url)}</span>
              </div>
              <div>
                License: <span className="font-mono">{maskKey(licenseKey)}</span>
              </div>
              <div>
                Last sync: {state.lastSyncAt ? new Date(state.lastSyncAt).toLocaleTimeString() : '-'} · Pending
                changes: {state.pending}
              </div>
              {state.message && <div className="text-amber-700">{state.message}</div>}
            </div>
            <p className="text-sm text-gray-600">
              Kisi bhi naye device par yahi link kholein aur yahi license key daalein, data apne aap aa jayega.
            </p>
            <Button variant="outline" size="sm" onClick={handleSync} disabled={busy || state.syncing}>
              <RefreshCw className={`w-4 h-4 mr-2 ${state.syncing ? 'animate-spin' : ''}`} /> Sync now
            </Button>
          </div>
        )}

        {state.status === 'unclaimed' && (
          <div className="rounded-lg border border-blue-200 bg-blue-50 p-4 space-y-3">
            <div className="flex items-center gap-2 text-blue-800 font-medium">
              <Cloud className="w-5 h-5" /> Aapka server taiyar hai ({hostOf(state.url)})
            </div>
            <p className="text-sm text-gray-700">
              Ek click mein connect karein. Is device ka abhi ka sara data server par chala jayega aur ye server
              sirf aapki license key se jud jayega.
            </p>
            <Button onClick={handleConnect} disabled={busy}>
              {busy ? 'Connect ho raha hai...' : 'Connect Server'}
            </Button>
          </div>
        )}

        {state.status === 'checking' && (
          <div className="rounded-lg border p-4 text-sm text-gray-700 flex items-center gap-2">
            <RefreshCw className="w-4 h-4 animate-spin" /> {state.message || 'Server check ho raha hai...'}
          </div>
        )}

        {state.status === 'schema-missing' && (
          <div className="rounded-lg border border-amber-300 bg-amber-50 p-4 space-y-3">
            <div className="flex items-center gap-2 text-amber-800 font-medium">
              <AlertTriangle className="w-5 h-5" /> Server ka database setup baaki hai
            </div>
            <ol className="text-sm text-gray-700 list-decimal ml-5 space-y-1">
              <li>
                Supabase dashboard kholein → <b>SQL Editor</b> → <b>New query</b>
              </li>
              <li>
                Neeche ka button dabakar SQL copy karein aur paste karke <b>Run</b> dabayein (sirf ek baar)
              </li>
              <li>
                Wapas aakar <b>Check again</b> dabayein
              </li>
            </ol>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={copySql}>
                <Copy className="w-4 h-4 mr-2" /> Copy SQL
              </Button>
              <Button size="sm" onClick={handleConnect} disabled={busy}>
                Check again
              </Button>
            </div>
            <textarea
              readOnly
              value={SERVER_SCHEMA_SQL}
              className="w-full h-32 text-xs font-mono border rounded p-2 bg-white"
            />
          </div>
        )}

        {state.status === 'mismatch' && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-800 space-y-1">
            <div className="flex items-center gap-2 font-medium">
              <AlertTriangle className="w-5 h-5" /> License match nahi hua
            </div>
            <p>Ye server kisi dusri license key se juda hai. Sahi license key se login karein.</p>
          </div>
        )}

        {(state.status === 'offline' || state.status === 'error') && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-4 space-y-2">
            <div className="flex items-center gap-2 text-red-800 font-medium">
              <WifiOff className="w-5 h-5" />{' '}
              {state.status === 'offline' ? 'Server tak pahunch nahi paye' : 'Server error'}
            </div>
            <p className="text-sm text-gray-700">{state.message}</p>
            <Button size="sm" onClick={handleConnect} disabled={busy}>
              Dobara try karein
            </Button>
          </div>
        )}

        {state.status === 'no-license' && (
          <p className="text-sm text-gray-600">Server connect karne ke liye pehle license key daalna zaroori hai.</p>
        )}

        {state.status === 'no-config' && (
          <p className="text-sm text-gray-600">Is license / link par server enable nahi hai.</p>
        )}
      </CardContent>
    </Card>
  );
}
