import { useEffect, useMemo, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { getStudent, getPaymentsByRegNo } from '../lib/indexedDB';
import { getBatches } from '../lib/storageAdapter';
import { getCachedAttendance, getCachedAttendanceDates } from '../lib/attendance';
import { AdmissionFieldDef, getFieldValue } from '../lib/admissionFields';
import { useFormLayout } from '../lib/formLayout';
import { StudentPhoto } from './StudentPhoto';
import { discountPercent, isDuesDateOver } from '../lib/dues';

const DAY_NAMES = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];

const fmtDate = (d?: string) => {
  if (!d) return 'N/A';
  const x = new Date(d);
  return isNaN(x.getTime()) ? String(d) : x.toLocaleDateString('en-GB');
};
const fmtYmd = (ymd: string) => {
  const [y, m, d] = ymd.split('-');
  return `${d}/${m}/${y}`;
};
const money = (v: any) => `₹${Number(v) || 0}`;

interface AttendanceRow { date: string; present: boolean; checkIn: string; checkOut: string }

/**
 * Student List -> "View": everything about one student in one place (profile, payment record and
 * attendance record). Read-only; the admin can only look here.
 */
export function StudentDetailsDialog({
  open,
  student,
  enabledFields,
  onClose,
  onOpenPhoto,
}: {
  open: boolean;
  student: any | null;
  enabledFields: AdmissionFieldDef[];
  onClose: () => void;
  onOpenPhoto: (photo: string) => void;
}) {
  const { isVisible, label: lbl } = useFormLayout(); // hidden fields are skipped, renamed fields show the new name
  const [full, setFull] = useState<any | null>(null);
  const [payments, setPayments] = useState<any[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRow[]>([]);
  const [loadingAtt, setLoadingAtt] = useState(false);

  const regNo = student?.regNo ? String(student.regNo) : '';

  useEffect(() => {
    if (!open || !regNo) return;
    let alive = true;
    setFull(null);
    setPayments([]);
    setAttendance([]);

    (async () => {
      const [f, pay] = await Promise.all([getStudent(regNo).catch(() => null), getPaymentsByRegNo(regNo).catch(() => [])]);
      if (!alive) return;
      setFull(f || student);
      setPayments([...(pay || [])].sort((a, b) => String(b.paymentDate || '').localeCompare(String(a.paymentDate || ''))));

      // Attendance: every day saved on this computer
      setLoadingAtt(true);
      try {
        const [dates, batches] = await Promise.all([getCachedAttendanceDates(), getBatches().catch(() => [])]);
        const base = f || student;
        const sched: string[] | undefined = (batches || []).find((b: any) => b.batchTime === base?.batchTime)?.weeklySchedule;
        const admitted = String(base?.admissionDate || '').slice(0, 10);
        const key = regNo.toLowerCase();
        const rows: AttendanceRow[] = [];
        const days = await Promise.all(dates.map(async (d) => ({ d, res: await getCachedAttendance(d) })));
        for (const { d, res } of days) {
          if (!res) continue;
          const rec = res.records[key];
          if (rec?.checkIn) {
            rows.push({ date: d, present: true, checkIn: rec.checkIn, checkOut: rec.checkOut || '' });
            continue;
          }
          // Absent only on days the class actually ran (someone checked in), after admission, on the batch's days
          if (admitted && d < admitted) continue;
          const classRan = Object.values(res.records).some((r) => !!r.checkIn);
          if (!classRan) continue;
          const dayName = DAY_NAMES[new Date(`${d}T00:00:00`).getDay()];
          const scheduled = !sched || sched.length === 0 || sched.includes(dayName);
          if (scheduled) rows.push({ date: d, present: false, checkIn: '', checkOut: '' });
        }
        rows.sort((a, b) => b.date.localeCompare(a.date));
        if (alive) setAttendance(rows);
      } finally {
        if (alive) setLoadingAtt(false);
      }
    })();

    return () => { alive = false; };
  }, [open, regNo]);

  const s = full || student;

  const attStats = useMemo(() => {
    const present = attendance.filter((r) => r.present).length;
    const absent = attendance.length - present;
    const ym = new Date().toLocaleDateString('en-CA').slice(0, 7);
    const monthPresent = attendance.filter((r) => r.present && r.date.startsWith(ym)).length;
    const monthAbsent = attendance.filter((r) => !r.present && r.date.startsWith(ym)).length;
    return { present, absent, monthPresent, monthAbsent };
  }, [attendance]);

  const totalPaid = useMemo(() => payments.reduce((sum, p) => sum + (Number(p.paidAmount) || 0), 0), [payments]);

  const expired = s?.expiryDate ? new Date(s.expiryDate) < new Date() : false;

  const Field = ({ label, value, className = '' }: { label: string; value: any; className?: string }) => (
    <div className="rounded-lg border bg-gray-50 px-3 py-2">
      <p className="text-xs text-gray-500">{label}</p>
      <p className={`text-sm font-medium break-words ${className}`}>{value === undefined || value === null || value === '' ? 'N/A' : value}</p>
    </div>
  );

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="w-[95vw] sm:max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Student Details</DialogTitle>
        </DialogHeader>

        {s && (
          <div className="space-y-4">
            {/* top: photo + name + quick numbers */}
            <div className="flex items-center gap-4 flex-wrap rounded-xl border bg-orange-50/60 p-4">
              <StudentPhoto regNo={String(s.regNo)} name={s.name} hasPhoto={!!(s.hasPhoto || s.photo)} onOpen={onOpenPhoto} />
              <div className="min-w-0 flex-1">
                <p className="text-xl font-bold truncate">{s.name}</p>
                <p className="text-sm text-gray-600">Reg No: <b>{s.regNo}</b>{s.mobile ? <> &nbsp;•&nbsp; {s.mobile}</> : null}</p>
                <div className="flex items-center gap-2 flex-wrap mt-1 text-xs">
                  <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-semibold">{s.batchTime || 'No Batch'}</span>
                  <span className={`px-2 py-0.5 rounded-full font-semibold ${expired ? 'bg-red-100 text-red-700' : 'bg-green-100 text-green-700'}`}>
                    {expired ? 'Expired' : 'Active'} • {fmtDate(s.expiryDate)}
                  </span>
                  {s.deactivated && <span className="px-2 py-0.5 rounded-full bg-gray-200 text-gray-700 font-semibold">Deactivated</span>}
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="rounded-lg bg-white border px-3 py-1.5"><p className="text-[11px] text-gray-500">Total</p><p className="font-bold">{money(s.totalAmount)}</p></div>
                <div className="rounded-lg bg-white border px-3 py-1.5"><p className="text-[11px] text-gray-500">Paid</p><p className="font-bold text-green-700">{money(s.paidAmount)}</p></div>
                <div className="rounded-lg bg-white border px-3 py-1.5"><p className="text-[11px] text-gray-500">Dues</p><p className={`font-bold ${(Number(s.dues) || 0) > 0 ? 'text-red-600' : 'text-green-700'}`}>{money(s.dues)}</p></div>
              </div>
            </div>

            <Tabs defaultValue="details" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="details">Details</TabsTrigger>
                <TabsTrigger value="payments">Payment Record ({payments.length})</TabsTrigger>
                <TabsTrigger value="attendance">Attendance Record</TabsTrigger>
              </TabsList>

              {/* ---- details ---- */}
              <TabsContent value="details" className="mt-3">
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <Field label="Admission Date" value={fmtDate(s.admissionDate)} />
                  <Field label={lbl('name', 'Name')} value={s.name} />
                  <Field label={lbl('mobile', 'Mobile')} value={s.mobile} />
                  {isVisible('alternateMobile') && <Field label={lbl('alternateMobile', 'Alternate Mobile')} value={s.alternateMobile} />}
                  {isVisible('email') && <Field label={lbl('email', 'Email')} value={s.email} />}
                  {isVisible('guardianName') && <Field label={lbl('guardianName', 'Guardian Name')} value={s.guardianName} />}
                  {isVisible('guardianRelation') && <Field label={lbl('guardianRelation', 'Guardian Relation')} value={s.guardianRelation} />}
                  {isVisible('address') && <Field label={lbl('address', 'Address')} value={s.address} className="whitespace-pre-wrap" />}
                  <Field label="Category" value={s.category} />
                  <Field label="Sub Category" value={s.subCategory} />
                  <Field label="Batch Time" value={s.batchTime} />
                  <Field label="Location" value={s.location} />
                  <Field label="Duration" value={s.duration ? `${s.duration} ${s.durationType || ''}` : ''} />
                  <Field label="Expiry Date" value={fmtDate(s.expiryDate)} className={expired ? 'text-red-600' : 'text-green-600'} />
                  <Field label="Payment Mode (Admission)" value={s.paymentMode} />
                  {Number(s.discountAmount) > 0 && (
                    <Field label="Discount" value={`₹${s.discountAmount} (${discountPercent(s.totalAmount, s.discountAmount)}%)`} className="text-green-700" />
                  )}
                  {(Number(s.dues) || 0) > 0 && s.duesDate && (
                    <Field label="Pay Dues By" value={fmtDate(s.duesDate)} className={isDuesDateOver(s.duesDate, s.dues) ? 'text-red-600' : 'text-orange-600'} />
                  )}
                  {enabledFields.map((f) => (
                    <Field key={f.id} label={f.label} value={getFieldValue(s.customFields, f.id)} />
                  ))}
                </div>
              </TabsContent>

              {/* ---- payments ---- */}
              <TabsContent value="payments" className="mt-3 space-y-3">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg border bg-gray-50 p-2"><p className="text-xs text-gray-500">Admission Total</p><p className="font-bold">{money(s.totalAmount)}</p></div>
                  <div className="rounded-lg border bg-green-50 p-2"><p className="text-xs text-gray-500">Fees Payments Total</p><p className="font-bold text-green-700">{money(totalPaid)}</p></div>
                  <div className="rounded-lg border bg-red-50 p-2"><p className="text-xs text-gray-500">Current Dues</p><p className="font-bold text-red-600">{money(s.dues)}</p></div>
                </div>
                <div className="overflow-x-auto rounded-lg border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Payment Date</TableHead>
                        <TableHead>Duration</TableHead>
                        <TableHead>Session Expiry</TableHead>
                        <TableHead>Total</TableHead>
                        <TableHead>Paid</TableHead>
                        <TableHead>Dues</TableHead>
                        <TableHead>Mode</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {/* the admission payment itself */}
                      <TableRow className="bg-orange-50/50">
                        <TableCell>{fmtDate(s.admissionDate)} <span className="text-[11px] text-orange-700 font-semibold">(Admission)</span></TableCell>
                        <TableCell>{s.duration ? `${s.duration} ${s.durationType || ''}` : 'N/A'}</TableCell>
                        <TableCell>—</TableCell>
                        <TableCell>{money(s.totalAmount)}</TableCell>
                        <TableCell className="text-green-700">{money(s.paidAmount)}</TableCell>
                        <TableCell>—</TableCell>
                        <TableCell>{s.paymentMode || 'N/A'}</TableCell>
                      </TableRow>
                      {payments.map((p, i) => (
                        <TableRow key={p.id ?? i}>
                          <TableCell>{fmtDate(p.paymentDate)}</TableCell>
                          <TableCell>{p.duration ? `${p.duration} ${p.durationType || ''}` : 'N/A'}</TableCell>
                          <TableCell>{fmtDate(p.sessionExpiryDate)}</TableCell>
                          <TableCell>{money(p.totalAmount)}</TableCell>
                          <TableCell className="text-green-700">{money(p.paidAmount)}</TableCell>
                          <TableCell className={(Number(p.dues) || 0) > 0 ? 'text-red-600' : ''}>{money(p.dues)}</TableCell>
                          <TableCell>{p.paymentMode || 'N/A'}</TableCell>
                        </TableRow>
                      ))}
                      {payments.length === 0 && (
                        <TableRow><TableCell colSpan={7} className="text-center py-4 text-gray-500">Admission ke baad koi aur fees payment nahi hui.</TableCell></TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>

              {/* ---- attendance ---- */}
              <TabsContent value="attendance" className="mt-3 space-y-3">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-center">
                  <div className="rounded-lg border bg-green-50 p-2"><p className="text-xs text-gray-500">Total Present</p><p className="font-bold text-green-700 text-lg">{attStats.present}</p></div>
                  <div className="rounded-lg border bg-red-50 p-2"><p className="text-xs text-gray-500">Total Absent</p><p className="font-bold text-red-600 text-lg">{attStats.absent}</p></div>
                  <div className="rounded-lg border bg-green-50 p-2"><p className="text-xs text-gray-500">Is Mahine Present</p><p className="font-bold text-green-700 text-lg">{attStats.monthPresent}</p></div>
                  <div className="rounded-lg border bg-red-50 p-2"><p className="text-xs text-gray-500">Is Mahine Absent</p><p className="font-bold text-red-600 text-lg">{attStats.monthAbsent}</p></div>
                </div>
                <p className="text-xs text-gray-500">Ye is computer par saved attendance ke hisaab se hai (Reports me jo mahine khole gaye hain, wo bhi judte jaate hain).</p>
                <div className="overflow-x-auto rounded-lg border max-h-[40vh] overflow-y-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Check In</TableHead>
                        <TableHead>Check Out</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {attendance.map((r) => (
                        <TableRow key={r.date}>
                          <TableCell>{fmtYmd(r.date)}</TableCell>
                          <TableCell>
                            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${r.present ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                              {r.present ? 'Present' : 'Absent'}
                            </span>
                          </TableCell>
                          <TableCell>{r.checkIn || '—'}</TableCell>
                          <TableCell>{r.checkOut || '—'}</TableCell>
                        </TableRow>
                      ))}
                      {attendance.length === 0 && (
                        <TableRow>
                          <TableCell colSpan={4} className="text-center py-6 text-gray-500">
                            {loadingAtt ? 'Attendance load ho rahi hai...' : 'Abhi is student ka koi attendance record saved nahi hai.'}
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
