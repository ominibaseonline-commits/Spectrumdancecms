import { compressPhotoToTarget } from '../lib/imageCompress';
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Upload, X, Plus, Trash2 } from 'lucide-react';
import { AdmissionFieldDef, MAX_EXTRA_CHARGES, sumExtraCharges } from '../lib/admissionFields';
import { useFormLayout } from '../lib/formLayout';
import { calcDues, discountPercent } from '../lib/dues';

// This dialog owns its OWN copy of the student being edited (formState below)
// instead of sharing state with StudentList. That is the whole point of this
// file: previously the edit form lived inside StudentList itself, so every
// keystroke re-rendered the ENTIRE students table (including every row's
// photo) along with the form. With thousands of students that made typing
// feel frozen. Because this component is isolated, typing here only
// re-renders this small dialog — the table behind it is untouched.
interface EditStudentDialogProps {
  open: boolean;
  student: any | null;
  categories: any[];
  batches: any[];
  locations: any[];
  enabledFields: AdmissionFieldDef[];
  extraChargesEnabled?: boolean;
  onClose: () => void;
  onSave: (student: any) => Promise<void> | void;
}

export function EditStudentDialog({
  open,
  student,
  categories,
  batches,
  locations,
  enabledFields,
  extraChargesEnabled = false,
  onClose,
  onSave,
}: EditStudentDialogProps) {
  const [formState, setFormState] = useState<any>(student);
  // Admission Form Layout: hidden fields are not shown here (their saved data stays untouched)
  const { isVisible, label: lbl } = useFormLayout();

  // Re-sync local state whenever a *different* student is opened for editing.
  useEffect(() => {
    setFormState(student);
  }, [student?.regNo]);

  if (!formState) return null;

  const getSubCategories = (categoryName: string) => {
    const cat = categories.find((c: any) => c.name === categoryName);
    return cat?.subCategories || [];
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 25 * 1024 * 1024) {
        return;
      }
      compressPhotoToTarget(file)
        .then((photo) => setFormState((prev: any) => ({ ...prev, photo })))
        .catch(() => {});
    }
  };

  const handleRemovePhoto = () => setFormState((prev: any) => ({ ...prev, photo: '' }));

  // ----- Extra Charges (breakdown). Student's totalAmount already includes them,
  // so any change here adjusts totalAmount + dues by the difference only.
  const extraCharges: { name: string; amount: string | number }[] = Array.isArray(formState.extraCharges) ? formState.extraCharges : [];
  const hasExtraCharges = extraCharges.length > 0;
  const showExtraChargesSection = extraChargesEnabled || hasExtraCharges;

  const applyExtraCharges = (next: { name: string; amount: string | number }[]) => {
    setFormState((prev: any) => {
      const oldSum = sumExtraCharges(prev.extraCharges);
      const newSum = sumExtraCharges(next);
      const newTotal = Math.max(0, (parseFloat(prev.totalAmount) || 0) - oldSum + newSum);
      const paid = parseFloat(prev.paidAmount) || 0;
      return { ...prev, extraCharges: next, totalAmount: String(newTotal), dues: calcDues(newTotal, paid, prev.discountAmount) };
    });
  };

  const updateExtraCharge = (index: number, field: 'name' | 'amount', value: string) =>
    applyExtraCharges(extraCharges.map((c, i) => (i === index ? { ...c, [field]: value } : c)));

  const addExtraChargeRow = () => {
    if (extraCharges.length >= MAX_EXTRA_CHARGES) return;
    applyExtraCharges([...extraCharges, { name: '', amount: '' }]);
  };

  const removeExtraChargeRow = (index: number) =>
    applyExtraCharges(extraCharges.filter((_, i) => i !== index));

  const handleSave = () => {
    // Drop fully-empty rows before saving
    const cleaned = extraCharges
      .map((c) => ({ name: String(c.name || '').trim(), amount: parseFloat(String(c.amount)) || 0 }))
      .filter((c) => c.name || c.amount);
    const discount = Math.max(0, parseFloat(String(formState.discountAmount)) || 0);
    // Dues bache nahi to Dues Date bhi hat jati hai (dues ko yaha dobara calculate nahi karte: fees payments ke baad wo total-paid se alag ho sakta hai)
    const hasDues = (Number(formState.dues) || 0) > 0;
    onSave({ ...formState, extraCharges: cleaned, discountAmount: discount, duesDate: hasDues ? (formState.duesDate || '') : '' });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Edit Student Details</DialogTitle></DialogHeader>
        <div className="space-y-4">
          {isVisible('photo') && (
          <>
          <div className="flex flex-col items-center gap-4 p-4 bg-gray-50 rounded-lg">
            {formState.photo ? (
              <div className="relative">
                <img src={formState.photo} alt="Student" className="w-32 h-32 rounded-full object-cover border-4 border-[#F9CDAA]" />
                <Button size="sm" variant="destructive" className="absolute -top-2 -right-2 rounded-full w-8 h-8 p-0" onClick={handleRemovePhoto}><X className="w-4 h-4" /></Button>
              </div>
            ) : (
              <div className="w-32 h-32 rounded-full bg-gray-200 flex items-center justify-center"><span className="text-gray-500">No Photo</span></div>
            )}
            <div>
              <Label htmlFor="edit-photo-upload" className="cursor-pointer">
                <div className="flex items-center gap-2 px-4 py-2 bg-[#F9CDAA] text-white rounded hover:bg-[#f8c199] transition-colors">
                  <Upload className="w-4 h-4" />
                  <span>{formState.photo ? 'Change Photo' : 'Upload Photo'}</span>
                </div>
              </Label>
              <Input id="edit-photo-upload" type="file" accept="image/*" className="hidden" onChange={handlePhotoChange} />
            </div>
          </div>
          </>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div><Label>{lbl('name', 'Name')} *</Label><Input value={formState.name || ''} onChange={(e) => setFormState({ ...formState, name: e.target.value })} /></div>
            <div><Label>{lbl('mobile', 'Mobile')} *</Label><Input value={formState.mobile || ''} onChange={(e) => setFormState({ ...formState, mobile: e.target.value })} /></div>
            {isVisible('alternateMobile') && (<div><Label>{lbl('alternateMobile', 'Alternate Mobile')}</Label><Input value={formState.alternateMobile || ''} onChange={(e) => setFormState({ ...formState, alternateMobile: e.target.value })} /></div>)}
            {isVisible('email') && (<div><Label>{lbl('email', 'Email')}</Label><Input type="email" value={formState.email || ''} onChange={(e) => setFormState({ ...formState, email: e.target.value })} /></div>)}
            {isVisible('guardianName') && (<div><Label>{lbl('guardianName', 'Guardian Name')}</Label><Input value={formState.guardianName || ''} onChange={(e) => setFormState({ ...formState, guardianName: e.target.value })} /></div>)}
            {isVisible('guardianRelation') && (<div><Label>{lbl('guardianRelation', 'Guardian Relation')}</Label><Input value={formState.guardianRelation || ''} onChange={(e) => setFormState({ ...formState, guardianRelation: e.target.value })} /></div>)}
            {isVisible('address') && (<div><Label>{lbl('address', 'Address')}</Label><Input value={formState.address || ''} onChange={(e) => setFormState({ ...formState, address: e.target.value })} /></div>)}
            {isVisible('dob') && (<div><Label>{lbl('dob', 'Date of Birth')}</Label><Input type="date" value={formState.dob || ''} onChange={(e) => setFormState({ ...formState, dob: e.target.value })} /></div>)}
            {isVisible('aadhaarNumber') && (
            <div>
              <Label>{lbl('aadhaarNumber', 'Aadhar Card Number')}</Label>
              <Input
                type="text"
                value={formState.aadhaarNumber || ''}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 12);
                  setFormState({ ...formState, aadhaarNumber: val });
                }}
                placeholder="12-digit Aadhar number"
                maxLength={12}
              />
              {formState.aadhaarNumber && formState.aadhaarNumber.length > 0 && formState.aadhaarNumber.length < 12 && (
                <p className="text-xs text-red-500 mt-1">Aadhar number must be 12 digits</p>
              )}
            </div>
            )}
            {isVisible('gender') && (
            <div>
              <Label>{lbl('gender', 'Gender')}</Label>
              <Select value={formState.gender || ''} onValueChange={(value) => setFormState({ ...formState, gender: value })}>
                <SelectTrigger><SelectValue placeholder="Select gender" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            )}
            <div>
              <Label>Category *</Label>
              <Select value={formState.category || ''} onValueChange={(value) => setFormState({ ...formState, category: value, subCategory: '' })}>
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {categories.length > 0 ? categories.map((cat: any) => (
                    <SelectItem key={cat.name} value={cat.name}>{cat.name}</SelectItem>
                  )) : (
                    <>
                      <SelectItem value="Dance">Dance</SelectItem>
                      <SelectItem value="Fitness">Fitness</SelectItem>
                      <SelectItem value="Yoga">Yoga</SelectItem>
                    </>
                  )}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Sub Category</Label>
              <Select value={formState.subCategory || ''} onValueChange={(value) => setFormState({ ...formState, subCategory: value })}>
                <SelectTrigger><SelectValue placeholder="Select sub category" /></SelectTrigger>
                <SelectContent>
                  {getSubCategories(formState.category).length > 0 ? getSubCategories(formState.category).map((sub: string) => (
                    <SelectItem key={sub} value={sub}>{sub}</SelectItem>
                  )) : <SelectItem value="none">No sub categories</SelectItem>}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Batch Time *</Label>
              <Select value={formState.batchTime || ''} onValueChange={(value) => setFormState({ ...formState, batchTime: value })}>
                <SelectTrigger><SelectValue placeholder="Select batch time" /></SelectTrigger>
                <SelectContent>
                  {batches.map((batch) => (<SelectItem key={batch.batchTime} value={batch.batchTime}>{batch.batchTime}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Location *</Label>
              <Select value={formState.location || ''} onValueChange={(value) => setFormState({ ...formState, location: value })}>
                <SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger>
                <SelectContent>
                  {locations.map((location) => (<SelectItem key={location.name} value={location.name}>{location.name}</SelectItem>))}
                </SelectContent>
              </Select>
            </div>
            <div><Label>Admission Date</Label><Input type="date" value={formState.admissionDate || ''} onChange={(e) => setFormState({ ...formState, admissionDate: e.target.value })} /></div>
            <div>
              <Label>Duration</Label>
              <Input type="number" value={formState.duration || ''} onChange={(e) => setFormState({ ...formState, duration: e.target.value })} placeholder="e.g. 1" min="1" />
            </div>
            <div>
              <Label>Duration Type</Label>
              <Select value={formState.durationType || ''} onValueChange={(value) => setFormState({ ...formState, durationType: value })}>
                <SelectTrigger><SelectValue placeholder="Select type" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Days">Days</SelectItem>
                  <SelectItem value="Month">Month</SelectItem>
                  <SelectItem value="Year">Year</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Total Amount</Label>
              <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                <Input type="number" className="pl-8" value={formState.totalAmount || ''} onChange={(e) => { const total = parseFloat(e.target.value) || 0; const paid = parseFloat(formState.paidAmount) || 0; setFormState({ ...formState, totalAmount: e.target.value, dues: calcDues(total, paid, formState.discountAmount) }); }} />
              </div>
            </div>
            <div>
              <Label>Paid Amount</Label>
              <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                <Input type="number" className="pl-8" value={formState.paidAmount || ''} onChange={(e) => { const total = parseFloat(formState.totalAmount) || 0; const paid = parseFloat(e.target.value) || 0; setFormState({ ...formState, paidAmount: e.target.value, dues: calcDues(total, paid, formState.discountAmount) }); }} />
              </div>
            </div>
            <div>
              <Label>Discount Amount</Label>
              <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                <Input type="number" className="pl-8" min="0" value={formState.discountAmount ?? ''} onChange={(e) => { const oldD = parseFloat(String(formState.discountAmount)) || 0; const newD = parseFloat(e.target.value) || 0; setFormState({ ...formState, discountAmount: e.target.value, dues: (Number(formState.dues) || 0) + oldD - newD }); }} />
              </div>
              {discountPercent(formState.totalAmount, formState.discountAmount) > 0 && <p className="text-xs text-green-700 font-semibold mt-1">Discount {discountPercent(formState.totalAmount, formState.discountAmount)}%</p>}
            </div>
            <div>
              <Label>Dues</Label>
              <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                <Input type="number" className="pl-8" value={formState.dues || 0} disabled />
              </div>
            </div>
            {(Number(formState.dues) || 0) > 0 && (
              <div>
                <Label>Pay Dues By (Dues Date)</Label>
                <Input type="date" value={formState.duesDate || ''} onChange={(e) => setFormState({ ...formState, duesDate: e.target.value })} />
              </div>
            )}
          </div>

          {/* Extra Charges breakdown */}
          {showExtraChargesSection && (
            <div className="p-3 bg-orange-50/50 rounded-lg border space-y-3">
              <p className="text-sm text-gray-500">Extra Charges</p>
              {!hasExtraCharges && (
                <p className="text-xs text-gray-400">Koi extra charge nahi hai. "Add" dabakar naya extra charge jodo.</p>
              )}
              {extraCharges.map((charge, index) => (
                <div key={index} className="grid grid-cols-[1fr_1fr_auto] gap-3 items-center">
                  <Input
                    value={charge.name}
                    onChange={(e) => updateExtraCharge(index, 'name', e.target.value)}
                    placeholder="Extra charge name"
                  />
                  <div className="relative"><span className="absolute left-3 top-2.5">₹</span>
                    <Input
                      type="number"
                      className="pl-8"
                      min="0"
                      value={charge.amount}
                      onChange={(e) => updateExtraCharge(index, 'amount', e.target.value)}
                      placeholder="0"
                    />
                  </div>
                  <Button type="button" variant="outline" size="icon" onClick={() => removeExtraChargeRow(index)} title="Remove">
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </Button>
                </div>
              ))}
              <div className="flex items-center justify-between flex-wrap gap-3">
                <Button
                  type="button"
                  variant="outline"
                  onClick={addExtraChargeRow}
                  disabled={extraCharges.length >= MAX_EXTRA_CHARGES}
                  className="flex items-center gap-2"
                >
                  <Plus className="w-4 h-4" /> Add
                  <span className="text-xs text-gray-500">({extraCharges.length}/{MAX_EXTRA_CHARGES})</span>
                </Button>
                <div className="text-sm">
                  Total Extra Charges: <span className="font-semibold">₹{sumExtraCharges(extraCharges)}</span>
                </div>
              </div>
              <p className="text-xs text-gray-500">Ye charges upar ke Total Amount mein pehle se shamil hain.</p>
            </div>
          )}

          {/* Extra Fields — turned ON/OFF from Settings -> Admission Fields */}
          {enabledFields.length > 0 && (
            <div className="p-3 bg-gray-50 rounded-lg border">
              <p className="text-sm text-gray-500 mb-3">Additional Information</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {enabledFields.map((field) => (
                  <div key={field.id}>
                    <Label>{field.label}</Label>
                    {field.type === 'select' ? (
                      <Select
                        value={formState.customFields?.[field.id] || ''}
                        onValueChange={(value) =>
                          setFormState({ ...formState, customFields: { ...formState.customFields, [field.id]: value } })
                        }
                      >
                        <SelectTrigger><SelectValue placeholder={`Select ${field.label}`} /></SelectTrigger>
                        <SelectContent>
                          {(field.options || []).map((opt) => (
                            <SelectItem key={opt} value={opt}>{opt}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    ) : field.type === 'textarea' ? (
                      <textarea
                        className="flex w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-xs min-h-16"
                        value={formState.customFields?.[field.id] || ''}
                        onChange={(e) =>
                          setFormState({ ...formState, customFields: { ...formState.customFields, [field.id]: e.target.value } })
                        }
                      />
                    ) : field.type === 'phone' ? (
                      <Input
                        type="tel"
                        value={formState.customFields?.[field.id] || ''}
                        onChange={(e) => {
                          const digitsOnly = e.target.value.replace(/\D/g, '').slice(0, 10);
                          setFormState({ ...formState, customFields: { ...formState.customFields, [field.id]: digitsOnly } });
                        }}
                        placeholder="10-digit mobile number"
                        maxLength={10}
                      />
                    ) : (
                      <Input
                        type={field.type === 'number' ? 'number' : field.type === 'date' ? 'date' : 'text'}
                        value={formState.customFields?.[field.id] || ''}
                        onChange={(e) =>
                          setFormState({ ...formState, customFields: { ...formState.customFields, [field.id]: e.target.value } })
                        }
                      />
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          <Button onClick={handleSave} className="w-full">Save Changes</Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
