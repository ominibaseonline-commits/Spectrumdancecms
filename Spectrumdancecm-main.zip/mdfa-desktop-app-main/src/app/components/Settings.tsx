import { compressPhotoToTarget } from '../lib/imageCompress';
import { useState, useEffect, useSyncExternalStore } from 'react';
import { Lock, User, Pause, Ban, Play, Search, Download, Upload, FileJson, FileSpreadsheet, Calendar, FileText, Users, Plus, Edit, Trash2, Building2, Tag, Key, Shield, ListChecks, Lightbulb, Info, MapPin, ClipboardList, PieChart, AlertTriangle, Cloud, CheckCircle2, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { EnquirySettings } from './EnquirySettings';
import { OnlineAdmissionSettings } from './OnlineAdmissionSettings';
import { ReviewSettings } from './ReviewSettings';
import { EventFormsSettings } from './EventFormsSettings';
import { ThemeSettings } from './ThemeSettings';
import { ServerSettings } from './ServerSettings';
import { subscribeServerSync, getServerSyncState, syncNow } from '../lib/serverSync';
import { Switch } from './ui/switch';
import { ALL_ADMISSION_FIELDS, BUSINESS_TYPES, getEnabledFieldIds, saveEnabledFieldIds, getExtraChargesEnabled, saveExtraChargesEnabled, MAX_EXTRA_CHARGES } from '../lib/admissionFields';
import { AdmissionFormLayoutSettings } from './AdmissionFormLayoutSettings';
import { useFormLayout } from '../lib/formLayout';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { toast } from 'sonner';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import {
  getAllStudents,
  saveStudent,
  getSetting,
  saveSetting,
  getAllPayments,
  getAllTeachers,
  getAllBatches,
  getAllLocations,
  importAllData,
  exportEverything,
  getAllEnquiries,
  getAllData,
  getAllCategories,
  saveCategory,
  deleteCategory,
  saveLicenseKey,
  getLicenseKey
} from '../lib/indexedDB';
import {
  isDriveBackupAvailable,
  connectGoogleDrive,
  disconnectGoogleDrive,
  getGoogleDriveStatus,
  refreshGoogleDriveStatus,
  backupToGoogleDrive,
  restoreLatestGoogleDriveBackup,
  DriveStatus
} from '../lib/driveBackup';
import { useBusinessName } from '../contexts/BusinessContext';
import { AttendanceSetup } from './AttendanceSetup';
import { getCachedAttendanceDates, getCachedAttendance, getAttendanceDaysWithData } from '../lib/attendance';
import { generateLicenseKey, isLicenseValid, getDaysUntilExpiry, formatExpiryDate, LicenseKey } from '../lib/licenseKey';

export function Settings() {
  // Server (Cloud Sync) - "Server" tab sirf tab dikhta hai jab is license / link par server config mila ho
  const serverState = useSyncExternalStore(subscribeServerSync, getServerSyncState);
  // Admission Form Layout — hidden fields are left out of the Excel exports
  const { isVisible: formFieldVisible } = useFormLayout();
  const HIDEABLE_EXPORT_COLUMNS: Record<string, string> = {
    'Gender': 'gender',
    'Date of Birth': 'dob',
    'Alternate Mobile': 'alternateMobile',
    'Guardian Name': 'guardianName',
    'Guardian Relation': 'guardianRelation',
    'Have you learned dance before': 'learnedBefore',
    'Address': 'address',
    'Email': 'email',
  };
  const hideColumns = (row: any) => {
    const out: any = { ...row };
    Object.entries(HIDEABLE_EXPORT_COLUMNS).forEach(([col, id]) => {
      if (!formFieldVisible(id)) delete out[col];
    });
    return out;
  };
  const { businessName, updateBusinessName, businessLogo, updateBusinessLogo, businessAddress, updateBusinessAddress, businessPhone, updateBusinessPhone } = useBusinessName();
  const [adminEmail, setAdminEmail] = useState('');
  const [adminPassword, setAdminPassword] = useState('');
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');

  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<any>(null);
  const [studentUserId, setStudentUserId] = useState('');
  const [studentPassword, setStudentPassword] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [importing, setImporting] = useState(false);
  const [resumeDate, setResumeDate] = useState('');
  const [pushDate, setPushDate] = useState(''); // Add pushDate state for manual push date selection
  const [reportMonth, setReportMonth] = useState(new Date().toISOString().slice(0, 7)); // YYYY-MM format (kept for backward-compat, unused by new report UI)
  const [reportFromDate, setReportFromDate] = useState(() => {
    const d = new Date();
    d.setDate(1);
    return d.toISOString().split('T')[0];
  });
  const [reportToDate, setReportToDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [reportLocation, setReportLocation] = useState('all');
  const [reportLocationsList, setReportLocationsList] = useState<any[]>([]);
  const [showPushedReport, setShowPushedReport] = useState(false);
  const [showBlockedReport, setShowBlockedReport] = useState(false);
  const [pushedStudents, setPushedStudents] = useState<any[]>([]);
  const [blockedStudents, setBlockedStudents] = useState<any[]>([]);

  // Category Management states
  const [categories, setCategories] = useState<any[]>([]);
  const [categoryName, setCategoryName] = useState('');
  const [subCategories, setSubCategories] = useState<string[]>(['']);
  const [editingCategory, setEditingCategory] = useState<any>(null);

  // Business Settings states
  const [newBusinessName, setNewBusinessName] = useState('');
  const [newBusinessAddress, setNewBusinessAddress] = useState('');
  const [newBusinessPhone, setNewBusinessPhone] = useState('');
  const [logoPreview, setLogoPreview] = useState('');
  const [uploadingLogo, setUploadingLogo] = useState(false);

  // License Key states
  const [currentLicense, setCurrentLicense] = useState<LicenseKey | null>(null);
  const [newLicenseExpiry, setNewLicenseExpiry] = useState('');
  const [showLicenseManagement, setShowLicenseManagement] = useState(false);
  const [adminSecretCode, setAdminSecretCode] = useState('');
  const [enabledAdmissionFields, setEnabledAdmissionFields] = useState<string[]>([]);
  const [extraChargesEnabled, setExtraChargesEnabled] = useState(false);

  // Data counts for UI display
  const [dataCounts, setDataCounts] = useState({
    students: 0,
    payments: 0,
    teachers: 0,
    batches: 0,
    locations: 0,
    categories: 0,
    activeStudents: 0,
    deactivatedStudents: 0,
    expiryStudents: 0,
    duesStudents: 0,
    enquiries: 0,
    attendanceDays: 0,
    teacherPayments: 0,
    campaignTemplates: 0,
    events: 0,
    eventTemplates: 0,
    eventSubmissions: 0,
    settingsCount: 0
  });

  // Google Drive Auto Backup states
  const [driveStatus, setDriveStatus] = useState<DriveStatus>({ connected: false, email: null, lastBackupTime: null });
  const [driveConnecting, setDriveConnecting] = useState(false);
  const [driveBackingUp, setDriveBackingUp] = useState(false);
  const [driveRefreshing, setDriveRefreshing] = useState(false);
  const [driveRestoring, setDriveRestoring] = useState(false);

  useEffect(() => {
    loadData();
    loadDataCounts();
    getEnabledFieldIds().then(setEnabledAdmissionFields);
    getExtraChargesEnabled().then(setExtraChargesEnabled);
    if (isDriveBackupAvailable()) {
      getGoogleDriveStatus().then(setDriveStatus);
    }
  }, []);

  const handleDriveConnect = async () => {
    setDriveConnecting(true);
    try {
      const result = await connectGoogleDrive();
      if (result.success) {
        toast.success(`Google Drive connected${result.email ? ` (${result.email})` : ''}!`);
        const status = await getGoogleDriveStatus();
        setDriveStatus(status);
      } else {
        toast.error(result.error || 'Google Drive connect nahi ho paya');
      }
    } catch (error) {
      console.error('Drive connect error:', error);
      toast.error('Google Drive connect nahi ho paya');
    } finally {
      setDriveConnecting(false);
    }
  };

  const handleDriveDisconnect = async () => {
    try {
      await disconnectGoogleDrive();
      setDriveStatus({ connected: false, email: null, lastBackupTime: null });
      toast.success('Google Drive disconnect ho gaya');
    } catch (error) {
      console.error('Drive disconnect error:', error);
      toast.error('Disconnect nahi ho paya');
    }
  };

  const handleDriveBackupNow = async () => {
    setDriveBackingUp(true);
    try {
      const result = await backupToGoogleDrive(businessName);
      if (result.success && result.unchanged) {
        toast.info('Already backed up — data unchanged since the last backup.');
      } else if (result.success) {
        toast.success(`Backup successful! Saved as "${result.fileName}" in the Ominibase CMS Drive folder.`);
      } else if (result.code === 'not_connected') {
        toast.error('Pehle Google Drive connect karein.');
      } else if (result.code === 'empty_cms') {
        toast.error('CMS me koi data nahi hai, isliye backup nahi liya gaya.');
      } else {
        toast.error(result.error || 'Backup fail ho gaya');
      }
      const status = await getGoogleDriveStatus();
      setDriveStatus(status);
    } catch (error) {
      console.error('Drive backup error:', error);
      toast.error('Backup fail ho gaya');
    } finally {
      setDriveBackingUp(false);
    }
  };

  // Re-checks Drive itself (not just the cached local status) — reflects a
  // backup made from another device, or a file removed manually from Drive.
  const handleDriveRefreshStatus = async () => {
    setDriveRefreshing(true);
    try {
      const status = await refreshGoogleDriveStatus();
      setDriveStatus(status);
    } catch (error) {
      console.error('Drive refresh error:', error);
      toast.error('Refresh nahi ho paya');
    } finally {
      setDriveRefreshing(false);
    }
  };

  const handleDriveRestore = async () => {
    const ok = window.confirm(
      'Drive se latest backup restore karein?\n\nYe is device par maujooda data ko overwrite kar dega (matching records replace ho jayenge).'
    );
    if (!ok) return;

    setDriveRestoring(true);
    try {
      const result = await restoreLatestGoogleDriveBackup();
      if (result.success) {
        toast.success(`Restored from "${result.fileName}"! Reloading...`, { duration: 3000 });
        setTimeout(() => window.location.reload(), 1500);
      } else if (result.code === 'not_connected') {
        toast.error('Pehle Google Drive connect karein.');
      } else if (result.code === 'no_backups') {
        toast.error('Drive par abhi koi backup nahi mila.');
      } else {
        toast.error(result.error || 'Restore fail ho gaya');
      }
    } catch (error) {
      console.error('Drive restore error:', error);
      toast.error('Restore fail ho gaya');
    } finally {
      setDriveRestoring(false);
    }
  };

  const handleToggleExtraCharges = async (checked: boolean) => {
    setExtraChargesEnabled(checked);
    try {
      await saveExtraChargesEnabled(checked);
      toast.success(checked ? 'Add Extra Charges admission form mein ON ho gaya' : 'Add Extra Charges OFF ho gaya');
    } catch (error) {
      console.error('Error saving extra charges toggle:', error);
      setExtraChargesEnabled(!checked);
      toast.error('Setting save karne mein error aayi');
    }
  };

  const handleToggleAdmissionField = async (fieldId: string, checked: boolean) => {
    const updated = checked
      ? [...enabledAdmissionFields, fieldId]
      : enabledAdmissionFields.filter((id) => id !== fieldId);
    setEnabledAdmissionFields(updated);
    try {
      await saveEnabledFieldIds(updated);
      toast.success(checked ? 'Field admission form mein add ho gaya' : 'Field admission form se hat gaya');
    } catch (error) {
      console.error('Error saving admission field toggle:', error);
      toast.error('Field save karne mein error aayi');
    }
  };

  const loadData = async () => {
    try {
      // Load admin credentials from IndexedDB
      const adminUser = await getSetting('adminUser') || 'admin@1234';
      const adminPass = await getSetting('adminPass') || 'admin@1234';
      setAdminEmail(adminUser);
      setAdminPassword(adminPass);
      setNewAdminEmail(adminUser);
      setNewAdminPassword(adminPass);

      // Set new business name to current business name
      setNewBusinessName(businessName);
      setNewBusinessAddress(businessAddress);
      setNewBusinessPhone(businessPhone);
      setLogoPreview(businessLogo);

      const studentsData = await getAllStudents();
      setStudents(studentsData);

      // Load categories
      const categoriesData = await getAllCategories();
      setCategories(categoriesData);

      // Load license key
      const license = await getLicenseKey();
      setCurrentLicense(license);

      // Load locations for the Monthly Reports location filter
      const locationsForReport = await getAllLocations();
      setReportLocationsList(locationsForReport);
    } catch (error) {
      console.error('Error loading settings data:', error);
    }
  };

  // Date range presets for the report filter
  const applyReportDatePreset = (preset: 'today' | 'thisMonth' | 'lastMonth' | 'last7' | 'last15' | 'last30' | 'thisYear') => {
    const now = new Date();
    const toISO = (d: Date) => d.toISOString().split('T')[0];
    let from = new Date();
    let to = new Date();

    switch (preset) {
      case 'today':
        from = new Date();
        to = new Date();
        break;
      case 'last7':
        from = new Date();
        from.setDate(now.getDate() - 6);
        to = new Date();
        break;
      case 'last15':
        from = new Date();
        from.setDate(now.getDate() - 14);
        to = new Date();
        break;
      case 'last30':
        from = new Date();
        from.setDate(now.getDate() - 29);
        to = new Date();
        break;
      case 'thisMonth':
        from = new Date(now.getFullYear(), now.getMonth(), 1);
        to = new Date();
        break;
      case 'lastMonth':
        from = new Date(now.getFullYear(), now.getMonth() - 1, 1);
        to = new Date(now.getFullYear(), now.getMonth(), 0);
        break;
      case 'thisYear':
        from = new Date(now.getFullYear(), 0, 1);
        to = new Date();
        break;
    }

    setReportFromDate(toISO(from));
    setReportToDate(toISO(to));
  };

  const loadDataCounts = async () => {
    try {
      const students = await getAllStudents();
      const payments = await getAllPayments();
      const teachers = await getAllTeachers();
      const batches = await getAllBatches();
      const locations = await getAllLocations();
      const categories = await getAllCategories();

      const activeStudentsList = students.filter((s: any) => !s.deactivated);
      const deactivatedStudentsList = students.filter((s: any) => s.deactivated);
      const expiryStudentsList = activeStudentsList.filter((s: any) => s.expiryDate && new Date(s.expiryDate) < new Date());
      const duesStudentsList = activeStudentsList.filter((s: any) => (s.dues || 0) > 0);

      setDataCounts({
        students: students.length,
        payments: payments.length,
        teachers: teachers.length,
        batches: batches.length,
        locations: locations.length,
        categories: categories.length,
        activeStudents: activeStudentsList.length,
        deactivatedStudents: deactivatedStudentsList.length,
        expiryStudents: expiryStudentsList.length,
        duesStudents: duesStudentsList.length,
        enquiries: ((await getAllEnquiries()) || []).length,
        attendanceDays: ((await getAttendanceDaysWithData()) || []).length,
        teacherPayments: ((await getAllData('teacherPayments')) || []).length,
        campaignTemplates: ((await getAllData('campaignTemplates')) || []).length,
        events: ((await getAllData('event_events')) || []).length,
        eventTemplates: ((await getAllData('event_templates')) || []).length,
        eventSubmissions: ((await getAllData('event_submissions')) || []).length,
        settingsCount: ((await getAllData('settings')) || []).length
      });
    } catch (error) {
      console.error('Error loading data counts:', error);
    }
  };

  const loadPushedStudents = async () => {
    const studentsData = await getAllStudents();
    const pushed = studentsData.filter((s: any) => s.status === 'pushed');
    setPushedStudents(pushed);
    setShowPushedReport(true);
  };

  const loadBlockedStudents = async () => {
    const studentsData = await getAllStudents();
    const blocked = studentsData.filter((s: any) => s.status === 'blocked');
    setBlockedStudents(blocked);
    setShowBlockedReport(true);
  };

  const handleExportPushedStudents = () => {
    if (pushedStudents.length === 0) {
      toast.error('No pushed students to export!');
      return;
    }

    const exportData = pushedStudents.map((student: any) => {
      const pushedDate = new Date(student.pushedDate);
      const today = new Date();
      const daysPushed = Math.floor((today.getTime() - pushedDate.getTime()) / (1000 * 60 * 60 * 24));
      
      return {
        'Reg No': student.regNo,
        'Name': student.name,
        'Mobile': student.mobile,
        'Location': student.location || 'N/A',
        'Batch': student.batchTime || 'N/A',
        'Pushed Date': formatDate(student.pushedDate),
        'Original Expiry': formatDate(student.originalExpiryDate || student.expiryDate),
        'Days Pushed': daysPushed,
        'Status': student.status
      };
    });

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Pushed Students');
    XLSX.writeFile(workbook, `Pushed_Students_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Pushed students report exported successfully!');
  };

  const handleExportBlockedStudents = () => {
    if (blockedStudents.length === 0) {
      toast.error('No blocked students to export!');
      return;
    }

    const exportData = blockedStudents.map((student: any) => ({
      'Reg No': student.regNo,
      'Name': student.name,
      'Mobile': student.mobile,
      'Email': student.email || 'N/A',
      'Location': student.location || 'N/A',
      'Batch': student.batchTime || 'N/A',
      'Expiry Date': formatDate(student.expiryDate),
      'Dues': student.dues || 0,
      'Status': student.status
    }));

    const worksheet = XLSX.utils.json_to_sheet(exportData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Blocked Students');
    XLSX.writeFile(workbook, `Blocked_Students_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
    toast.success('Blocked students report exported successfully!');
  };

  const handleUpdateAdminCredentials = async () => {
    if (!newAdminEmail || !newAdminPassword) {
      toast.error('Please fill all fields');
      return;
    }

    try {
      await saveSetting('adminUser', newAdminEmail);
      await saveSetting('adminPass', newAdminPassword);
      setAdminEmail(newAdminEmail);
      setAdminPassword(newAdminPassword);
      void syncNow(); // Supabase me turant save
      toast.success('Admin credentials updated successfully!');
    } catch (error) {
      console.error('Error updating admin credentials:', error);
      toast.error('Failed to update credentials');
    }
  };

  // Category Management Functions
  const handleAddSubCategory = () => {
    setSubCategories([...subCategories, '']);
  };

  const handleRemoveSubCategory = (index: number) => {
    const newSubCategories = subCategories.filter((_, i) => i !== index);
    setSubCategories(newSubCategories.length > 0 ? newSubCategories : ['']);
  };

  const handleSubCategoryChange = (index: number, value: string) => {
    const newSubCategories = [...subCategories];
    newSubCategories[index] = value;
    setSubCategories(newSubCategories);
  };

  const handleSaveCategory = async () => {
    if (!categoryName.trim()) {
      toast.error('Please enter category name');
      return;
    }

    const validSubCategories = subCategories.filter(sub => sub.trim() !== '');
    if (validSubCategories.length === 0) {
      toast.error('Please add at least one sub-category');
      return;
    }

    try {
      const categoryData = {
        id: editingCategory?.id,
        name: categoryName,
        subCategories: validSubCategories
      };

      await saveCategory(categoryData);
      await loadData();
      await loadDataCounts();

      setCategoryName('');
      setSubCategories(['']);
      setEditingCategory(null);
      toast.success(editingCategory ? 'Category updated successfully!' : 'Category added successfully!');
    } catch (error) {
      console.error('Error saving category:', error);
      toast.error('Failed to save category');
    }
  };

  const handleEditCategory = (category: any) => {
    setEditingCategory(category);
    setCategoryName(category.name);
    setSubCategories(category.subCategories.length > 0 ? category.subCategories : ['']);
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Are you sure you want to delete this category?')) return;

    try {
      await deleteCategory(id);
      await loadData();
      await loadDataCounts();
      toast.success('Category deleted successfully!');
    } catch (error) {
      console.error('Error deleting category:', error);
      toast.error('Failed to delete category');
    }
  };

  const handleCancelEditCategory = () => {
    setEditingCategory(null);
    setCategoryName('');
    setSubCategories(['']);
  };

  // Business Settings Function
  const handleUpdateBusinessName = async () => {
    if (!newBusinessName.trim()) {
      toast.error('Please enter business name');
      return;
    }

    try {
      await updateBusinessName(newBusinessName);
      toast.success('Business name updated successfully! It will reflect across all documents.');
    } catch (error) {
      console.error('Error updating business name:', error);
      toast.error('Failed to update business name');
    }
  };

  const handleLogoFileChange = (e: any) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!['image/png', 'image/jpeg', 'image/jpg'].includes(file.type)) {
      toast.error('Sirf PNG ya JPG image allowed hai');
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      toast.error('Logo file 3MB se chhoti honi chahiye');
      return;
    }

    setUploadingLogo(true);
    const reader = new FileReader();
    reader.onload = (ev) => {
      const img = new Image();
      img.onload = () => {
        // Fixed size — every logo is normalized to 300x300 so PDFs/forms look consistent
        const FIXED_SIZE = 300;
        const canvas = document.createElement('canvas');
        canvas.width = FIXED_SIZE;
        canvas.height = FIXED_SIZE;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(0, 0, FIXED_SIZE, FIXED_SIZE);
          // Fit image into square canvas while preserving aspect ratio
          const scale = Math.min(FIXED_SIZE / img.width, FIXED_SIZE / img.height);
          const w = img.width * scale;
          const h = img.height * scale;
          const x = (FIXED_SIZE - w) / 2;
          const y = (FIXED_SIZE - h) / 2;
          ctx.drawImage(img, x, y, w, h);
          const dataUrl = canvas.toDataURL('image/png');
          // Logo bhi 10 KB ke andar
          compressPhotoToTarget(dataUrl, undefined, FIXED_SIZE)
            .then((small) => setLogoPreview(small))
            .catch(() => setLogoPreview(dataUrl))
            .finally(() => setUploadingLogo(false));
          return;
        }
        setUploadingLogo(false);
      };
      img.src = ev.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleSaveLogo = async () => {
    if (!logoPreview) {
      toast.error('Pehle ek logo select karo');
      return;
    }
    try {
      await updateBusinessLogo(logoPreview);
      toast.success('Logo saved! Ab ye saari PDFs mein dikhega.');
    } catch (error) {
      console.error('Error saving logo:', error);
      toast.error('Logo save nahi ho paya');
    }
  };

  const handleRemoveLogo = async () => {
    try {
      await updateBusinessLogo('');
      setLogoPreview('');
      toast.success('Logo removed');
    } catch (error) {
      toast.error('Logo remove nahi ho paya');
    }
  };

  const handleUpdateBusinessAddress = async () => {
    try {
      await updateBusinessAddress(newBusinessAddress);
      toast.success('Address saved! Ab ye saari PDFs mein dikhega.');
    } catch (error) {
      console.error('Error updating address:', error);
      toast.error('Address save nahi ho paya');
    }
  };

  const handleUpdateBusinessPhone = async () => {
    try {
      await updateBusinessPhone(newBusinessPhone);
      toast.success('Contact number saved! Ab ye saari PDFs mein dikhega.');
    } catch (error) {
      console.error('Error updating phone:', error);
      toast.error('Contact number save nahi ho paya');
    }
  };

  // License Key Functions
  const handleUnlockLicenseManagement = () => {
    // Secret code to unlock license management (change this to your preferred code)
    const SECRET_CODE = 'ADMIN2024';

    if (adminSecretCode === SECRET_CODE) {
      setShowLicenseManagement(true);
      setAdminSecretCode('');
      toast.success('License management unlocked!');
    } else {
      toast.error('Invalid admin code!');
    }
  };

  const handleGenerateLicenseKey = async () => {
    if (!newLicenseExpiry) {
      toast.error('Please select expiry date for license key');
      return;
    }

    const expiryDate = new Date(newLicenseExpiry);
    const today = new Date();

    if (expiryDate <= today) {
      toast.error('Expiry date must be in the future');
      return;
    }

    try {
      const newLicense: LicenseKey = {
        key: generateLicenseKey(),
        expiryDate: newLicenseExpiry,
        isActive: true,
        createdDate: new Date().toISOString()
      };

      await saveLicenseKey(newLicense);
      setCurrentLicense(newLicense);
      setNewLicenseExpiry('');

      const daysRemaining = getDaysUntilExpiry(newLicense.expiryDate);
      toast.success(`License key generated successfully! Valid for ${daysRemaining} days.`);
    } catch (error) {
      console.error('Error generating license key:', error);
      toast.error('Failed to generate license key');
    }
  };

  const handleDeactivateLicense = async () => {
    if (!currentLicense) return;

    const confirmed = window.confirm('Are you sure you want to deactivate the current license key? This will lock the system.');
    if (!confirmed) return;

    try {
      const deactivatedLicense = {
        ...currentLicense,
        isActive: false
      };

      await saveLicenseKey(deactivatedLicense);
      setCurrentLicense(deactivatedLicense);
      toast.success('License key deactivated successfully! System will be locked on next login.');
    } catch (error) {
      console.error('Error deactivating license:', error);
      toast.error('Failed to deactivate license');
    }
  };

  const handleSearchStudent = async () => {
    const studentsData = await getAllStudents();
    const student = studentsData.find((s: any) => 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.regNo.includes(searchTerm) ||
      s.mobile.includes(searchTerm)
    );

    if (student) {
      setSelectedStudent(student);
      setStudentUserId(student.userId || '');
      setStudentPassword(student.password || '');
      toast.success('Student found!');
    } else {
      toast.error('Student not found!');
      setSelectedStudent(null);
    }
  };

  const handleGenerateStudentCredentials = async () => {
    if (!selectedStudent) return;
    if (!studentUserId || !studentPassword) {
      toast.error('Please enter user ID and password');
      return;
    }

    try {
      const updatedStudent = {
        ...selectedStudent,
        userId: studentUserId,
        password: studentPassword
      };
      
      await saveStudent(updatedStudent);
      await loadData();
      toast.success('Student credentials generated successfully!');
    } catch (error) {
      console.error('Error updating credentials:', error);
      toast.error('Failed to update credentials');
    }
  };

  const handlePushStudent = async () => {
    if (!selectedStudent) return;

    try {
      const pushDateToUse = pushDate || new Date().toISOString().split('T')[0];
      const updatedStudent = {
        ...selectedStudent,
        status: 'pushed',
        pushedDate: pushDateToUse,
        originalExpiryDate: selectedStudent.expiryDate
      };
      
      await saveStudent(updatedStudent);
      await loadData();
      setSelectedStudent(updatedStudent);
      
      const pushDateFormatted = formatDate(pushDateToUse);
      toast.success(`Student pushed on ${pushDateFormatted}. Expiry date frozen.`);
      setPushDate(''); // Clear push date input after successful push
    } catch (error) {
      console.error('Error pushing student:', error);
      toast.error('Failed to push student');
    }
  };

  const handleBlockStudent = async () => {
    if (!selectedStudent) return;

    try {
      const updatedStudent = {
        ...selectedStudent,
        status: 'blocked'
      };
      
      await saveStudent(updatedStudent);
      await loadData();
      setSelectedStudent(updatedStudent);
      toast.success('Student blocked successfully!');
    } catch (error) {
      console.error('Error blocking student:', error);
      toast.error('Failed to block student');
    }
  };

  const handleResumeStudent = async () => {
    if (!selectedStudent) return;

    try {
      let studentToUpdate = { ...selectedStudent };
      
      if (studentToUpdate.status === 'pushed' && studentToUpdate.pushedDate) {
        // Use provided resume date or current date
        const resumeDateToUse = resumeDate || new Date().toISOString().split('T')[0];
        
        // Calculate days pushed (difference between resume date and push date)
        const pushedDate = new Date(studentToUpdate.pushedDate);
        const resumeDateObj = new Date(resumeDateToUse);
        const daysPushed = Math.floor((resumeDateObj.getTime() - pushedDate.getTime()) / (1000 * 60 * 60 * 24));
        
        // Use original expiry date if stored, otherwise use current expiry
        const originalExpiry = studentToUpdate.originalExpiryDate || studentToUpdate.expiryDate;
        const expiryDate = new Date(originalExpiry);
        
        // Extend expiry date by days pushed
        expiryDate.setDate(expiryDate.getDate() + daysPushed);
        studentToUpdate.expiryDate = expiryDate.toISOString().split('T')[0];
        
        const pushedFormatted = formatDate(studentToUpdate.pushedDate);
        const resumeFormatted = formatDate(resumeDateToUse);
        const newExpiryFormatted = formatDate(studentToUpdate.expiryDate);
        
        toast.success(
          `Student Resumed!\n` +
          `Pushed: ${pushedFormatted}\n` +
          `Resumed: ${resumeFormatted}\n` +
          `Days Extended: ${daysPushed}\n` +
          `New Expiry: ${newExpiryFormatted}`,
          { duration: 5000 }
        );
      }
      
      // Clean up push-related fields
      studentToUpdate.status = 'active';
      delete studentToUpdate.pushedDate;
      delete studentToUpdate.originalExpiryDate;
      
      await saveStudent(studentToUpdate);
      await loadData();
      setSelectedStudent({...studentToUpdate});
      setResumeDate(''); // Clear resume date input
    } catch (error) {
      console.error('Error resuming student:', error);
      toast.error('Failed to resume student');
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB');
  };

  // Shared: collect fee-payment + admission records for the selected date range & location
  const getReportRangeData = async () => {
    const payments = await getAllPayments();
    const students = await getAllStudents();

    const fromDate = new Date(reportFromDate + 'T00:00:00');
    const toDate = new Date(reportToDate + 'T23:59:59');

    const inRange = (dateStr: string) => {
      if (!dateStr) return false;
      const d = new Date(dateStr);
      return d >= fromDate && d <= toDate;
    };

    const matchesLocation = (studentLoc: string) => {
      return reportLocation === 'all' || studentLoc === reportLocation;
    };

    // Fee payments within range
    const rangePayments = payments.filter((payment: any) => {
      const student = students.find((s: any) => s.regNo === payment.regNo);
      return inRange(payment.paymentDate || payment.date) && matchesLocation(student?.location);
    });

    // New admissions within range
    const rangeAdmissions = students.filter((student: any) => {
      return inRange(student.admissionDate) && matchesLocation(student.location);
    });

    const feeRows = rangePayments.map((payment: any) => {
      const student = students.find((s: any) => s.regNo === payment.regNo);
      const paid = Number(payment.paidAmount) || Number(payment.amount) || 0;
      const dues = Number(payment.dues) || 0;
      return {
        regNo: payment.regNo || 'N/A',
        name: student?.name || payment.name || 'N/A',
        mobile: student?.mobile || 'N/A',
        category: student?.category || 'N/A',
        location: student?.location || 'N/A',
        batchTime: student?.batchTime || 'N/A',
        date: payment.paymentDate || payment.date,
        paid,
        dues,
        mode: (payment.paymentMode || payment.mode || 'N/A')
      };
    });

    const admissionRows = rangeAdmissions.map((student: any) => {
      const paid = Number(student.paidAmount) || 0;
      const total = Number(student.totalAmount) || paid;
      const dues = Number(student.dues) || Math.max(total - paid, 0);
      return {
        regNo: student.regNo || 'N/A',
        name: student.name || 'N/A',
        mobile: student.mobile || 'N/A',
        category: student.category || 'N/A',
        location: student.location || 'N/A',
        batchTime: student.batchTime || 'N/A',
        date: student.admissionDate,
        paid,
        dues,
        mode: (student.paymentMode || 'N/A')
      };
    });

    const sumMode = (rows: any[], mode: string) =>
      rows.reduce((s, r) => (String(r.mode).toLowerCase() === mode ? s + r.paid : s), 0);

    const feeTotal = feeRows.reduce((s, r) => s + r.paid, 0);
    const admissionTotal = admissionRows.reduce((s, r) => s + r.paid, 0);
    const admissionDues = admissionRows.reduce((s, r) => s + r.dues, 0);

    return {
      feeRows,
      admissionRows,
      feeTotal,
      admissionTotal,
      grandTotal: feeTotal + admissionTotal,
      totalRecords: feeRows.length + admissionRows.length,
      feeCash: sumMode(feeRows, 'cash'),
      feeOnline: sumMode(feeRows, 'online'),
      admissionCash: sumMode(admissionRows, 'cash'),
      admissionOnline: sumMode(admissionRows, 'online'),
      admissionDues
    };
  };

  const getReportLocationLabel = () =>
    reportLocation === 'all' ? 'All Locations' : reportLocation;

  // Generate Income Report as Excel (date-range + location aware)
  const handleGenerateMonthlyReport = async () => {
    try {
      const data = await getReportRangeData();

      if (data.totalRecords === 0) {
        toast.error('No transactions found for the selected date range!');
        return;
      }

      const feeSheetData = data.feeRows.map((r) => ({
        'Reg No': r.regNo,
        'Student Name': r.name,
        'Mobile': r.mobile,
        'Category': r.category,
        'Location': r.location,
        'Batch': r.batchTime,
        'Payment Date': formatDate(r.date),
        'Amount Paid': r.paid,
        'Dues': r.dues,
        'Mode': r.mode
      }));

      const admissionSheetData = data.admissionRows.map((r) => ({
        'Reg No': r.regNo,
        'Student Name': r.name,
        'Mobile': r.mobile,
        'Category': r.category,
        'Location': r.location,
        'Batch': r.batchTime,
        'Admission Date': formatDate(r.date),
        'Amount Paid': r.paid,
        'Dues': r.dues,
        'Mode': r.mode
      }));

      const summaryData = [
        { 'Description': 'Report Period', 'Value': `${formatDate(reportFromDate)} to ${formatDate(reportToDate)}` },
        { 'Description': 'Location', 'Value': getReportLocationLabel() },
        { 'Description': 'Total Records', 'Value': data.totalRecords },
        { 'Description': 'Grand Total Collected', 'Value': `₹${data.grandTotal}` },
        { 'Description': '— Fee Payments —', 'Value': '' },
        { 'Description': 'Fee Payment Records', 'Value': data.feeRows.length },
        { 'Description': 'Fee Total Collected', 'Value': `₹${data.feeTotal}` },
        { 'Description': 'Fee Cash', 'Value': `₹${data.feeCash}` },
        { 'Description': 'Fee Online', 'Value': `₹${data.feeOnline}` },
        { 'Description': '— New Admissions —', 'Value': '' },
        { 'Description': 'Admission Records', 'Value': data.admissionRows.length },
        { 'Description': 'Admission Total Collected', 'Value': `₹${data.admissionTotal}` },
        { 'Description': 'Admission Cash', 'Value': `₹${data.admissionCash}` },
        { 'Description': 'Admission Online', 'Value': `₹${data.admissionOnline}` },
        { 'Description': 'Admission Dues Pending', 'Value': `₹${data.admissionDues}` }
      ];

      const workbook = XLSX.utils.book_new();
      const summarySheet = XLSX.utils.json_to_sheet(summaryData);
      XLSX.utils.book_append_sheet(workbook, summarySheet, 'Summary');

      const feeSheet = XLSX.utils.json_to_sheet(feeSheetData.length ? feeSheetData : [{ 'Info': 'No fee payments in this range' }]);
      XLSX.utils.book_append_sheet(workbook, feeSheet, 'Fee Payments');

      const admissionSheet = XLSX.utils.json_to_sheet(admissionSheetData.length ? admissionSheetData : [{ 'Info': 'No admissions in this range' }]);
      XLSX.utils.book_append_sheet(workbook, admissionSheet, 'New Admissions');

      const fileTag = `${reportFromDate}_to_${reportToDate}`;
      XLSX.writeFile(workbook, `Payment_Report_${fileTag}.xlsx`);

      toast.success(`Report generated! Grand Total: ₹${data.grandTotal} | Records: ${data.totalRecords}`, {
        duration: 5000
      });
    } catch (error) {
      console.error('Error generating report:', error);
      toast.error('Failed to generate report');
    }
  };

  // Generate Income Report as a colored, branded PDF (date-range + location aware)
  const handleGenerateMonthlyReportPDF = async () => {
    try {
      const data = await getReportRangeData();

      if (data.totalRecords === 0) {
        toast.error('No transactions found for the selected date range!');
        return;
      }

      const doc = new jsPDF();
      const pageWidth = doc.internal.pageSize.getWidth();

      // Brand color palette
      const brandPink: [number, number, number] = [219, 39, 119];
      const brandBlue: [number, number, number] = [37, 99, 235];
      const brandGreen: [number, number, number] = [22, 163, 74];
      const lightPink: [number, number, number] = [253, 242, 248];

      // ---- Header band ----
      doc.setFillColor(...brandPink);
      doc.rect(0, 0, pageWidth, 28, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(16);
      doc.setFont('helvetica', 'bold');
      doc.text(businessName || 'Studio', 14, 12);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `Complete Payment Report — ${formatDate(reportFromDate)} to ${formatDate(reportToDate)}`,
        14,
        20
      );
      doc.text(`Location: ${getReportLocationLabel()}`, 14, 26);

      doc.setTextColor(0, 0, 0);
      let yPos = 36;

      // ---- Summary strip ----
      doc.setFillColor(...lightPink);
      doc.rect(10, yPos, pageWidth - 20, 12, 'F');
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(`Total Records: ${data.totalRecords}`, 14, yPos + 8);
      doc.text(`Grand Total Collected: Rs ${data.grandTotal}`, pageWidth / 2, yPos + 8);
      yPos += 18;

      // ---- Fee Payments Section ----
      doc.setFontSize(12);
      doc.setTextColor(...brandBlue);
      doc.setFont('helvetica', 'bold');
      doc.text(`Monthly Fees Payments (${data.feeRows.length})`, 14, yPos);
      doc.setFontSize(9);
      doc.setTextColor(60, 60, 60);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `Total Payments: ${data.feeRows.length}   Total Collected: Rs ${data.feeTotal}   Cash: Rs ${data.feeCash}   Online: Rs ${data.feeOnline}`,
        14,
        yPos + 6
      );
      yPos += 10;

      if (data.feeRows.length > 0) {
        const feeBody = data.feeRows.map((r) => [
          r.regNo, r.name, r.mobile, r.category, r.location, r.batchTime,
          formatDate(r.date), `Rs ${r.paid}`, `Rs ${r.dues}`, r.mode
        ]);
        autoTable(doc, {
          startY: yPos,
          head: [['Reg No', 'Name', 'Mobile', 'Category', 'Location', 'Batch', 'Date', 'Paid', 'Dues', 'Mode']],
          body: feeBody,
          theme: 'grid',
          headStyles: { fillColor: brandBlue, fontSize: 7.5 },
          bodyStyles: { fontSize: 7.5 },
          alternateRowStyles: { fillColor: [239, 246, 255] },
          margin: { left: 10, right: 10 }
        });
        yPos = (doc as any).lastAutoTable.finalY + 10;
      } else {
        doc.setFontSize(9);
        doc.text('No fee payments in this range.', 14, yPos);
        yPos += 10;
      }

      // Page break if needed before admissions section
      if (yPos > doc.internal.pageSize.getHeight() - 40) {
        doc.addPage();
        yPos = 20;
      }

      // ---- New Admissions Section ----
      doc.setFontSize(12);
      doc.setTextColor(...brandGreen);
      doc.setFont('helvetica', 'bold');
      doc.text(`New Admissions (${data.admissionRows.length})`, 14, yPos);
      doc.setFontSize(9);
      doc.setTextColor(60, 60, 60);
      doc.setFont('helvetica', 'normal');
      doc.text(
        `Total Admissions: ${data.admissionRows.length}   Total Fees: Rs ${data.admissionTotal}   Cash: Rs ${data.admissionCash}   Online: Rs ${data.admissionOnline}   Dues: Rs ${data.admissionDues}`,
        14,
        yPos + 6
      );
      yPos += 10;

      if (data.admissionRows.length > 0) {
        const admissionBody = data.admissionRows.map((r) => [
          r.regNo, r.name, r.mobile, r.category, r.location, r.batchTime,
          formatDate(r.date), `Rs ${r.paid}`, `Rs ${r.dues}`, r.mode
        ]);
        autoTable(doc, {
          startY: yPos,
          head: [['Reg No', 'Name', 'Mobile', 'Category', 'Location', 'Batch', 'Admn. Date', 'Paid', 'Dues', 'Mode']],
          body: admissionBody,
          theme: 'grid',
          headStyles: { fillColor: brandGreen, fontSize: 7.5 },
          bodyStyles: { fontSize: 7.5 },
          alternateRowStyles: { fillColor: [240, 253, 244] },
          margin: { left: 10, right: 10 }
        });
        yPos = (doc as any).lastAutoTable.finalY + 8;
      } else {
        doc.setFontSize(9);
        doc.text('No new admissions in this range.', 14, yPos);
        yPos += 8;
      }

      // ---- Footer ----
      doc.setFontSize(8);
      doc.setTextColor(120, 120, 120);
      doc.text(`Generated on: ${new Date().toLocaleString('en-IN')}`, 14, doc.internal.pageSize.getHeight() - 8);

      const fileTag = `${reportFromDate}_to_${reportToDate}`;
      doc.save(`Payment_Report_${fileTag}.pdf`);

      toast.success(`PDF report generated! Grand Total: ₹${data.grandTotal}, Records: ${data.totalRecords}`, {
        duration: 5000
      });
    } catch (error) {
      console.error('Error generating PDF report:', error);
      toast.error('Failed to generate PDF report');
    }
  };

  // JSON Export Function - Export ALL Dashboard Data
  const handleExportJSON = async () => {
    try {
      // Get all data from IndexedDB using the export function
      const allData = await exportEverything();

      // Add metadata
      const exportData = {
        ...allData,
        exportDate: new Date().toISOString(),
        version: '3.0',
        source: businessName + ' POS'
      };

      // Create and download JSON file
      const jsonString = JSON.stringify(exportData, null, 2);
      const blob = new Blob([jsonString], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${businessName.replace(/[^a-zA-Z0-9]/g, '_')}_Complete_Data_${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);

      toast.success('Complete data exported successfully!');
    } catch (error) {
      console.error('Error exporting JSON:', error);
      toast.error('Failed to export data');
    }
  };

  // JSON Import Function - Import ALL Dashboard Data
  const handleImportJSON = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setImporting(true);
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string;
        const importedData = JSON.parse(content);

        // Validate data structure - check if it has at least students array
        if (!importedData.students && !importedData.batches && !importedData.locations && !importedData.enquiries && !importedData.settingsAll && !importedData.eventEvents) {
          throw new Error('Invalid data format - No valid data found');
        }

        console.log('📥 Importing data:', {
          students: importedData.students?.length || 0,
          batches: importedData.batches?.length || 0,
          locations: importedData.locations?.length || 0,
          teachers: importedData.teachers?.length || 0,
          payments: importedData.payments?.length || 0
        });

        // Import to IndexedDB using the import function
        await importAllData(importedData);
        
        // Reload all data
        await loadData();
        await loadDataCounts();
        
        toast.success('Data imported successfully! Reloading...', {
          duration: 3000
        });
        
        // Reload page to reflect all changes
        setTimeout(() => {
          window.location.reload();
        }, 1500);
      } catch (error) {
        console.error('Import error:', error);
        toast.error(`Failed to import data. ${error instanceof Error ? error.message : 'Please check file format.'}`);
      } finally {
        setImporting(false);
        event.target.value = '';
      }
    };

    reader.onerror = () => {
      toast.error('Failed to read file');
      setImporting(false);
      event.target.value = '';
    };

    reader.readAsText(file);
  };

  // Excel Export Functions (existing functionality)
  const handleExportStudents = async () => {
    try {
      const allStudents = await getAllStudents();
      const studentsData = allStudents.filter((s: any) => !s.deactivated);
      if (studentsData.length === 0) {
        toast.error('No students data to export!');
        return;
      }

      const exportData = studentsData.map((student: any) => ({
        'Registration No': student.regNo,
        'Admission Date': formatDate(student.admissionDate),
        'Student Name': student.name,
        'Gender': student.gender || 'N/A',
        'Date of Birth': formatDate(student.dob),
        'Mobile No': student.mobile,
        'Alternate Mobile': student.alternateMobile || 'N/A',
        'Guardian Name': student.guardianName || 'N/A',
        'Guardian Relation': student.guardianRelation || 'N/A',
        'Have you learned dance before': student.learnedBefore || 'N/A',
        'Address': student.address || 'N/A',
        'Email': student.email || 'N/A',
        'Category': student.category || 'N/A',
        'Batch Time': student.batchTime || 'N/A',
        'Location': student.location || 'N/A',
        'Duration': student.duration || 'N/A',
        'Duration Type': student.durationType || 'N/A',
        'Expiry Date': formatDate(student.expiryDate),
        'Total Amount': student.totalAmount || 0,
        'Paid Amount': student.paidAmount || 0,
        'Dues': student.dues || 0,
        'Payment Mode': student.paymentMode || 'N/A',
        'Status': student.status || 'active',
        'User ID': student.userId || 'N/A',
        'Password': student.password || 'N/A',
        'Pushed Date': formatDate(student.pushedDate) || 'N/A',
        'Original Expiry Date': formatDate(student.originalExpiryDate) || 'N/A'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData.map(hideColumns));
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Students');
      XLSX.writeFile(workbook, `Students_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Students data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export students');
    }
  };

  const handleExportDeactivatedStudents = async () => {
    try {
      const allStudents = await getAllStudents();
      const studentsData = allStudents.filter((s: any) => s.deactivated);
      if (studentsData.length === 0) {
        toast.error('No deactivated students data to export!');
        return;
      }

      const exportData = studentsData.map((student: any) => ({
        'Registration No': student.regNo,
        'Admission Date': formatDate(student.admissionDate),
        'Student Name': student.name,
        'Gender': student.gender || 'N/A',
        'Date of Birth': formatDate(student.dob),
        'Mobile No': student.mobile,
        'Alternate Mobile': student.alternateMobile || 'N/A',
        'Guardian Name': student.guardianName || 'N/A',
        'Guardian Relation': student.guardianRelation || 'N/A',
        'Have you learned dance before': student.learnedBefore || 'N/A',
        'Address': student.address || 'N/A',
        'Email': student.email || 'N/A',
        'Category': student.category || 'N/A',
        'Batch Time': student.batchTime || 'N/A',
        'Location': student.location || 'N/A',
        'Duration': student.duration || 'N/A',
        'Duration Type': student.durationType || 'N/A',
        'Expiry Date': formatDate(student.expiryDate),
        'Total Amount': student.totalAmount || 0,
        'Paid Amount': student.paidAmount || 0,
        'Dues': student.dues || 0,
        'Payment Mode': student.paymentMode || 'N/A',
        'Status': student.status || 'active',
        'User ID': student.userId || 'N/A',
        'Password': student.password || 'N/A',
        'Pushed Date': formatDate(student.pushedDate) || 'N/A',
        'Original Expiry Date': formatDate(student.originalExpiryDate) || 'N/A'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData.map(hideColumns));
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Deactivated Students');
      XLSX.writeFile(workbook, `Deactivated_Students_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Deactivated students data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export deactivated students');
    }
  };

  const handleExportExpiryStudents = async () => {
    try {
      const allStudents = await getAllStudents();
      const studentsData = allStudents.filter((s: any) => !s.deactivated && s.expiryDate && new Date(s.expiryDate) < new Date());
      if (studentsData.length === 0) {
        toast.error('No expiry students data to export!');
        return;
      }

      const exportData = studentsData.map((student: any) => ({
        'Registration No': student.regNo,
        'Admission Date': formatDate(student.admissionDate),
        'Student Name': student.name,
        'Mobile No': student.mobile,
        'Alternate Mobile': student.alternateMobile || 'N/A',
        'Guardian Name': student.guardianName || 'N/A',
        'Address': student.address || 'N/A',
        'Email': student.email || 'N/A',
        'Category': student.category || 'N/A',
        'Batch Time': student.batchTime || 'N/A',
        'Location': student.location || 'N/A',
        'Duration': student.duration || 'N/A',
        'Duration Type': student.durationType || 'N/A',
        'Expiry Date': formatDate(student.expiryDate),
        'Total Amount': student.totalAmount || 0,
        'Paid Amount': student.paidAmount || 0,
        'Dues': student.dues || 0,
        'Status': student.status || 'active'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData.map(hideColumns));
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Expiry Students');
      XLSX.writeFile(workbook, `Expiry_Students_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Expiry students data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export expiry students');
    }
  };

  const handleExportDuesStudents = async () => {
    try {
      const allStudents = await getAllStudents();
      const studentsData = allStudents.filter((s: any) => !s.deactivated && (s.dues || 0) > 0);
      if (studentsData.length === 0) {
        toast.error('No dues students data to export!');
        return;
      }

      const exportData = studentsData.map((student: any) => ({
        'Registration No': student.regNo,
        'Admission Date': formatDate(student.admissionDate),
        'Student Name': student.name,
        'Mobile No': student.mobile,
        'Alternate Mobile': student.alternateMobile || 'N/A',
        'Guardian Name': student.guardianName || 'N/A',
        'Address': student.address || 'N/A',
        'Email': student.email || 'N/A',
        'Category': student.category || 'N/A',
        'Batch Time': student.batchTime || 'N/A',
        'Location': student.location || 'N/A',
        'Expiry Date': formatDate(student.expiryDate),
        'Total Amount': student.totalAmount || 0,
        'Paid Amount': student.paidAmount || 0,
        'Dues': student.dues || 0,
        'Status': student.status || 'active'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData.map(hideColumns));
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Dues Students');
      XLSX.writeFile(workbook, `Dues_Students_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Dues students data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export dues students');
    }
  };

  const handleExportPayments = async () => {
    try {
      const paymentsData = await getAllPayments();
      const studentsData = await getAllStudents();
      
      if (paymentsData.length === 0) {
        toast.error('No payments data to export!');
        return;
      }

      const exportData = paymentsData.map((payment: any) => {
        const student = studentsData.find((s: any) => s.regNo === payment.regNo);
        return {
          'Payment ID': payment.id || 'N/A',
          'Registration No': payment.regNo,
          'Student Name': student?.name || payment.name || 'N/A',
          'Mobile': student?.mobile || 'N/A',
          'Location': student?.location || 'N/A',
          'Batch Time': student?.batchTime || 'N/A',
          'Payment Date': formatDate(payment.paymentDate || payment.date),
          'Session Date': formatDate(payment.sessionDate),
          'Duration': payment.duration || 'N/A',
          'Duration Type': payment.durationType || 'N/A',
          'Session Expiry Date': formatDate(payment.sessionExpiryDate || payment.sessionDate),
          'Total Amount': payment.totalAmount || 0,
          'Paid Amount': payment.paidAmount || payment.amount || 0,
          'Dues': payment.dues || 0,
          'Payment Mode': payment.paymentMode || payment.mode || 'N/A',
          'Received By': payment.receivedBy || 'Admin',
          'Remarks': payment.remarks || 'N/A'
        };
      });

      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Payments');
      XLSX.writeFile(workbook, `Payments_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Payments data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export payments');
    }
  };

  const handleExportTeachers = async () => {
    try {
      const teachersData = await getAllTeachers();
      if (teachersData.length === 0) {
        toast.error('No teachers data to export!');
        return;
      }

      const exportData = teachersData.map((teacher: any) => ({
        'Teacher ID': teacher.id,
        'Teacher Name': teacher.name,
        'Mobile No': teacher.mobile,
        'Email': teacher.email || 'N/A',
        'Specialization': teacher.specialization || 'N/A',
        'Address': teacher.address || 'N/A',
        'Joining Date': formatDate(teacher.joiningDate) || 'N/A',
        'Salary': teacher.salary || 'N/A',
        'Status': teacher.status || 'Active'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Teachers');
      XLSX.writeFile(workbook, `Teachers_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Teachers data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export teachers');
    }
  };

  const handleExportBatches = async () => {
    try {
      const batchesData = await getAllBatches();
      if (batchesData.length === 0) {
        toast.error('No batches data to export!');
        return;
      }

      const exportData = batchesData.map((batch: any) => ({
        'Batch ID': batch.id || 'N/A',
        'Batch Time': batch.batchTime,
        'Location': batch.location || 'N/A',
        'Teacher': batch.teacher || 'N/A',
        'Category': batch.category || 'N/A',
        'Capacity': batch.capacity || 'N/A',
        'Current Students': batch.currentStudents || 0,
        'Days': batch.days || 'N/A',
        'Status': batch.status || 'Active'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Batches');
      XLSX.writeFile(workbook, `Batches_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Batches data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export batches');
    }
  };

  const handleExportLocations = async () => {
    try {
      const locationsData = await getAllLocations();
      if (locationsData.length === 0) {
        toast.error('No locations data to export!');
        return;
      }

      const exportData = locationsData.map((location: any) => ({
        'Location ID': location.id || 'N/A',
        'Location Name': location.name || location.locationName,
        'Address': location.address || 'N/A',
        'City': location.city || 'N/A',
        'State': location.state || 'N/A',
        'Pincode': location.pincode || 'N/A',
        'Contact Person': location.contactPerson || 'N/A',
        'Contact Mobile': location.contactMobile || 'N/A',
        'Email': location.email || 'N/A',
        'Rent': location.rent || 'N/A',
        'Status': location.status || 'Active'
      }));

      const worksheet = XLSX.utils.json_to_sheet(exportData);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Locations');
      XLSX.writeFile(workbook, `Locations_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Locations data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export locations');
    }
  };

  // ---- Enquiries (separate Excel) ----
  const handleExportEnquiries = async () => {
    try {
      const list = ((await getAllEnquiries()) || []) as any[];
      if (list.length === 0) { toast.error('No enquiries data to export!'); return; }
      const dt = (v: any) => (v ? new Date(v).toLocaleDateString('en-GB') : '');
      const exportData = [...list]
        .sort((a: any, b: any) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
        .map((e: any) => ({
          'Enquiry Date': dt(e.createdAt),
          'Name': e.name || '',
          'Phone': e.phone || '',
          'Course': e.course || '',
          'Source': e.source || '',
          'Status': e.status || '',
          'Follow-up Date': dt(e.followUpDate),
          'Follow-up Note': e.followUpNote || '',
          'Converted': e.converted === 'admission' ? 'Admission' : e.converted === 'demo' ? 'Demo' : '',
          'Converted On': dt(e.convertedAt),
          'From QR Form': e.fromQr ? 'Yes' : 'No'
        }));
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(exportData), 'Enquiries');
      XLSX.writeFile(workbook, `Enquiries_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Enquiries data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export enquiries');
    }
  };

  // ---- QR Attendance (separate Excel) - every saved day, one row per check-in ----
  const handleExportAttendance = async () => {
    try {
      const dates = ((await getAttendanceDaysWithData()) || []) as string[];
      if (dates.length === 0) { toast.error('No attendance data to export!'); return; }
      const studentsData = await getAllStudents();
      const byReg = new Map<string, any>(studentsData.map((st: any) => [String(st.regNo).toLowerCase(), st] as [string, any]));
      const rows: any[] = [];
      for (const d of [...dates].sort().reverse()) {
        const res = await getCachedAttendance(d);
        if (!res) continue;
        Object.values(res.records).forEach((r: any) => {
          if (!r.checkIn && !r.checkOut) return;
          const st = byReg.get(String(r.regNo).toLowerCase());
          rows.push({
            'Date': new Date(d).toLocaleDateString('en-GB'),
            'Registration No': r.regNo,
            'Student Name': st?.name || 'N/A',
            'Mobile': st?.mobile || 'N/A',
            'Batch Time': st?.batchTime || 'N/A',
            'Location': st?.location || 'N/A',
            'Check-in': r.checkIn || '',
            'Check-out': r.checkOut || ''
          });
        });
      }
      if (rows.length === 0) { toast.error('No attendance data to export!'); return; }
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(rows), 'QR Attendance');
      XLSX.writeFile(workbook, `QR_Attendance_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('QR Attendance data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export attendance');
    }
  };

  const handleExportAllData = async () => {
    try {
      const studentsData = await getAllStudents();
      const paymentsData = await getAllPayments();
      const teachersData = await getAllTeachers();
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      
      if (studentsData.length === 0 && paymentsData.length === 0 && teachersData.length === 0 && batchesData.length === 0 && locationsData.length === 0) {
        toast.error('No data to export!');
        return;
      }

      const workbook = XLSX.utils.book_new();

      // Students Sheet
      if (studentsData.length > 0) {
        const studentsExport = studentsData.map((s: any) => ({
          'Registration No': s.regNo,
          'Admission Date': formatDate(s.admissionDate),
          'Student Name': s.name,
          'Gender': s.gender || 'N/A',
          'Date of Birth': formatDate(s.dob),
          'Mobile No': s.mobile,
          'Alternate Mobile': s.alternateMobile || 'N/A',
          'Guardian Name': s.guardianName || 'N/A',
          'Guardian Relation': s.guardianRelation || 'N/A',
          'Have you learned dance before': s.learnedBefore || 'N/A',
          'Address': s.address || 'N/A',
          'Email': s.email || 'N/A',
          'Category': s.category || 'N/A',
          'Batch Time': s.batchTime || 'N/A',
          'Location': s.location || 'N/A',
          'Duration': s.duration || 'N/A',
          'Duration Type': s.durationType || 'N/A',
          'Expiry Date': formatDate(s.expiryDate),
          'Total Amount': s.totalAmount || 0,
          'Paid Amount': s.paidAmount || 0,
          'Dues': s.dues || 0,
          'Payment Mode': s.paymentMode || 'N/A',
          'Status': s.status || 'active',
          'User ID': s.userId || 'N/A',
          'Password': s.password || 'N/A',
          'Pushed Date': formatDate(s.pushedDate) || 'N/A',
          'Original Expiry Date': formatDate(s.originalExpiryDate) || 'N/A'
        }));
        const studentsSheet = XLSX.utils.json_to_sheet(studentsExport.map(hideColumns));
        XLSX.utils.book_append_sheet(workbook, studentsSheet, 'Students');
      }

      // Payments Sheet
      if (paymentsData.length > 0) {
        const paymentsExport = paymentsData.map((p: any) => {
          const student = studentsData.find((s: any) => s.regNo === p.regNo);
          return {
            'Payment ID': p.id || 'N/A',
            'Registration No': p.regNo,
            'Student Name': student?.name || p.name || 'N/A',
            'Mobile': student?.mobile || 'N/A',
            'Location': student?.location || 'N/A',
            'Batch Time': student?.batchTime || 'N/A',
            'Payment Date': formatDate(p.paymentDate || p.date),
            'Session Date': formatDate(p.sessionDate),
            'Duration': p.duration || 'N/A',
            'Duration Type': p.durationType || 'N/A',
            'Session Expiry Date': formatDate(p.sessionExpiryDate || p.sessionDate),
            'Total Amount': p.totalAmount || 0,
            'Paid Amount': p.paidAmount || p.amount || 0,
            'Dues': p.dues || 0,
            'Payment Mode': p.paymentMode || p.mode || 'N/A',
            'Received By': p.receivedBy || 'Admin',
            'Remarks': p.remarks || 'N/A'
          };
        });
        const paymentsSheet = XLSX.utils.json_to_sheet(paymentsExport);
        XLSX.utils.book_append_sheet(workbook, paymentsSheet, 'Payments');
      }

      // Teachers Sheet
      if (teachersData.length > 0) {
        const teachersExport = teachersData.map((t: any) => ({
          'Teacher ID': t.id,
          'Teacher Name': t.name,
          'Mobile No': t.mobile,
          'Email': t.email || 'N/A',
          'Specialization': t.specialization || 'N/A',
          'Address': t.address || 'N/A',
          'Joining Date': formatDate(t.joiningDate) || 'N/A',
          'Salary': t.salary || 'N/A',
          'Status': t.status || 'Active'
        }));
        const teachersSheet = XLSX.utils.json_to_sheet(teachersExport);
        XLSX.utils.book_append_sheet(workbook, teachersSheet, 'Teachers');
      }

      // Batches Sheet
      if (batchesData.length > 0) {
        const batchesExport = batchesData.map((b: any) => ({
          'Batch ID': b.id || 'N/A',
          'Batch Time': b.batchTime,
          'Location': b.location || 'N/A',
          'Teacher': b.teacher || 'N/A',
          'Category': b.category || 'N/A',
          'Capacity': b.capacity || 'N/A',
          'Current Students': b.currentStudents || 0,
          'Days': b.days || 'N/A',
          'Status': b.status || 'Active'
        }));
        const batchesSheet = XLSX.utils.json_to_sheet(batchesExport);
        XLSX.utils.book_append_sheet(workbook, batchesSheet, 'Batches');
      }

      // Locations Sheet
      if (locationsData.length > 0) {
        const locationsExport = locationsData.map((l: any) => ({
          'Location Name': l.name || l.locationName,
          'Address': l.address || 'N/A'
        }));
        const locationsSheet = XLSX.utils.json_to_sheet(locationsExport);
        XLSX.utils.book_append_sheet(workbook, locationsSheet, 'Locations');
      }

      XLSX.writeFile(workbook, `Complete_Data_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success('Complete data exported successfully!');
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export data');
    }
  };

  return (
    <div className="p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="w-6 h-6" />
            Settings & Management
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="admin" className="w-full">
            <TabsList className="grid w-full h-auto grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 p-2">
              <TabsTrigger value="admin" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Admin Credentials</TabsTrigger>
              <TabsTrigger value="student" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Management & Setup</TabsTrigger>
              <TabsTrigger value="categories" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Business Settings</TabsTrigger>
              <TabsTrigger value="admissionFields" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Admission Fields</TabsTrigger>
              <TabsTrigger value="formLayout" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Admission Form Layout</TabsTrigger>
              <TabsTrigger value="onlineAdmission" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Online Admission</TabsTrigger>
              <TabsTrigger value="enquirySettings" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Enquiry Settings</TabsTrigger>
              <TabsTrigger value="googleReview" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Google Review</TabsTrigger>
              <TabsTrigger value="eventForms" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Event Forms</TabsTrigger>
              <TabsTrigger value="theme" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Theme</TabsTrigger>
              <TabsTrigger value="reports" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Monthly Reports</TabsTrigger>
              <TabsTrigger value="export" className="w-full h-auto min-h-11 px-3 py-2.5 whitespace-normal text-center leading-tight border border-gray-300 bg-white shadow-sm hover:bg-gray-50 data-[state=active]:border-orange-500 data-[state=active]:bg-orange-50 data-[state=active]:text-orange-700">Data Export & Import</TabsTrigger>
            </TabsList>

            {/* Admin Credentials Tab */}
            <TabsContent value="admin" className="space-y-4">
              <div className="p-4 bg-gray-50 rounded-lg">
                <h3 className="flex items-center gap-2 mb-4">
                  <Lock className="w-5 h-5" />
                  Current Admin Credentials
                </h3>
                <div className="space-y-2 text-sm">
                  <p><strong>Email:</strong> {adminEmail}</p>
                  <p><strong>Password:</strong> {'•'.repeat(adminPassword.length)}</p>
                </div>
              </div>

              <div className="space-y-3">
                <h4>Update Admin Credentials</h4>
                <div>
                  <Label>New Email</Label>
                  <Input
                    type="email"
                    value={newAdminEmail}
                    onChange={(e) => setNewAdminEmail(e.target.value)}
                    placeholder="Enter new email"
                  />
                </div>
                <div>
                  <Label>New Password</Label>
                  <Input
                    type="text"
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    placeholder="Enter new password"
                  />
                </div>
                <Button onClick={handleUpdateAdminCredentials}>
                  Update Admin Credentials
                </Button>
              </div>
            </TabsContent>

            {/* Student Management Tab */}
            <TabsContent value="student" className="space-y-4">
              <div>
                <Label>Search Student</Label>
                <div className="flex gap-2">
                  <Input
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Search by Name, Reg No, or Mobile"
                    onKeyPress={(e) => e.key === 'Enter' && handleSearchStudent()}
                  />
                  <Button onClick={handleSearchStudent}>
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </div>

              {selectedStudent && (
                <Card className="p-4 bg-blue-50">
                  <h4 className="mb-3">Student Details</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm mb-4">
                    <p><strong>Reg No:</strong> {selectedStudent.regNo}</p>
                    <p><strong>Name:</strong> {selectedStudent.name}</p>
                    <p><strong>Mobile:</strong> {selectedStudent.mobile}</p>
                    <p><strong>Email:</strong> {selectedStudent.email || 'N/A'}</p>
                    <p><strong>Location:</strong> {selectedStudent.location || 'N/A'}</p>
                    <p><strong>Batch:</strong> {selectedStudent.batchTime || 'N/A'}</p>
                    <p><strong>Expiry:</strong> {formatDate(selectedStudent.expiryDate)}</p>
                    <p><strong>Status:</strong> <span className={`px-2 py-1 rounded ${
                      selectedStudent.status === 'active' ? 'bg-green-200' :
                      selectedStudent.status === 'pushed' ? 'bg-orange-200' :
                      selectedStudent.status === 'blocked' ? 'bg-red-200' : 'bg-gray-200'
                    }`}>{selectedStudent.status || 'active'}</span></p>
                    {selectedStudent.status === 'pushed' && selectedStudent.pushedDate && (
                      <>
                        <p><strong>Pushed Date:</strong> <span className="text-orange-600">{formatDate(selectedStudent.pushedDate)}</span></p>
                        <p><strong>Original Expiry:</strong> {formatDate(selectedStudent.originalExpiryDate || selectedStudent.expiryDate)}</p>
                      </>
                    )}
                  </div>

                  <div className="space-y-3">
                    <div className="grid grid-cols-2 gap-2">
                      <div>
                        <Label>User ID</Label>
                        <Input
                          value={studentUserId}
                          onChange={(e) => setStudentUserId(e.target.value)}
                          placeholder="Enter User ID"
                        />
                      </div>
                      <div>
                        <Label>Password</Label>
                        <Input
                          value={studentPassword}
                          onChange={(e) => setStudentPassword(e.target.value)}
                          placeholder="Enter Password"
                        />
                      </div>
                    </div>
                    <Button onClick={handleGenerateStudentCredentials} className="w-full">
                      <User className="w-4 h-4 mr-2" />
                      Generate/Update Credentials
                    </Button>

                    {/* Manual Push Date Input - Only for non-pushed students */}
                    {selectedStudent.status !== 'pushed' && (
                      <div>
                        <Label>Push Date (optional, defaults to today)</Label>
                        <Input
                          type="date"
                          value={pushDate}
                          onChange={(e) => setPushDate(e.target.value)}
                        />
                      </div>
                    )}

                    <div className="grid grid-cols-2 gap-2">
                      <Button 
                        onClick={handlePushStudent} 
                        variant="outline"
                        className="bg-orange-50"
                        disabled={selectedStudent.status === 'pushed'}
                      >
                        <Pause className="w-4 h-4 mr-2" />
                        Push Student
                      </Button>
                      <Button 
                        onClick={handleBlockStudent} 
                        variant="outline"
                        className="bg-red-50"
                        disabled={selectedStudent.status === 'blocked'}
                      >
                        <Ban className="w-4 h-4 mr-2" />
                        Block Student
                      </Button>
                    </div>

                    {(selectedStudent.status === 'pushed' || selectedStudent.status === 'blocked') && (
                      <div className="p-3 bg-green-50 rounded-lg border-2 border-green-200">
                        <h5 className="flex items-center gap-2 mb-2 text-green-700">
                          <Play className="w-4 h-4" />
                          Resume Student Section
                        </h5>
                        <div className="space-y-2">
                          <Label className="text-green-700">Select Resume Date (Optional)</Label>
                          <Input
                            type="date"
                            value={resumeDate}
                            onChange={(e) => setResumeDate(e.target.value)}
                            className="border-green-300"
                          />
                          <p className="text-xs text-gray-600">
                            <Lightbulb className="inline w-3.5 h-3.5 -mt-0.5 mr-1" /> Leave empty to use today's date. Or select a custom resume date.
                          </p>
                          <Button onClick={handleResumeStudent} className="w-full mt-2 bg-green-600 hover:bg-green-700">
                            <Play className="w-4 h-4 mr-2" />
                            Resume Student
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                </Card>
              )}

              {/* Pushed & Blocked Students Reports */}
              <div className="grid grid-cols-2 gap-4 mt-4">
                <Button onClick={loadPushedStudents} variant="outline" className="bg-orange-50">
                  <Pause className="w-4 h-4 mr-2" />
                  View Pushed Students
                </Button>
                <Button onClick={loadBlockedStudents} variant="outline" className="bg-red-50">
                  <Ban className="w-4 h-4 mr-2" />
                  View Blocked Students
                </Button>
              </div>

              {/* QR Attendance setup (Google Apps Script) */}
              <AttendanceSetup />
            </TabsContent>

            {/* Categories & Business Settings Tab */}
            <TabsContent value="categories" className="space-y-6">
              {/* Business Name Settings */}
              <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
                <h3 className="flex items-center gap-2 mb-4">
                  <Building2 className="w-5 h-5 text-orange-600" />
                  Business Settings
                </h3>

                <div className="space-y-3">
                  <div className="p-3 bg-white rounded border">
                    <p className="text-sm mb-2"><strong>Current Business Name:</strong></p>
                    <p className="text-lg text-orange-600">{businessName}</p>
                  </div>

                  <div className="flex gap-4 items-start">
                    <div className="flex-1">
                      <Label>New Business Name</Label>
                      <Input
                        value={newBusinessName}
                        onChange={(e) => setNewBusinessName(e.target.value)}
                        placeholder="Enter new business name"
                        className="border-orange-300"
                      />
                    </div>

                    {/* Logo upload — fixed 300x300 size, shown next to Business Name */}
                    <div className="flex-shrink-0">
                      <Label>Studio Logo (PNG/JPG)</Label>
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-16 rounded border-2 border-orange-300 bg-white flex items-center justify-center overflow-hidden">
                          {logoPreview ? (
                            <img src={logoPreview} alt="Logo preview" className="w-full h-full object-contain" />
                          ) : (
                            <span className="text-[10px] text-gray-400 text-center px-1">No Logo</span>
                          )}
                        </div>
                        <div className="flex flex-col gap-1">
                          <label className="text-xs bg-orange-600 hover:bg-orange-700 text-white px-2 py-1 rounded cursor-pointer text-center">
                            Choose
                            <input
                              type="file"
                              accept="image/png,image/jpeg"
                              className="hidden"
                              onChange={handleLogoFileChange}
                              disabled={uploadingLogo}
                            />
                          </label>
                          {logoPreview && (
                            <button
                              onClick={handleRemoveLogo}
                              className="text-xs text-red-600 underline"
                              type="button"
                            >
                              Remove
                            </button>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button onClick={handleUpdateBusinessName} className="flex-1 bg-orange-600 hover:bg-orange-700">
                      <Building2 className="w-4 h-4 mr-2" />
                      Update Business Name
                    </Button>
                    <Button onClick={handleSaveLogo} className="flex-1 bg-orange-600 hover:bg-orange-700" disabled={uploadingLogo}>
                      Save Logo
                    </Button>
                  </div>

                  <div>
                    <Label>Business Address</Label>
                    <Input
                      value={newBusinessAddress}
                      onChange={(e) => setNewBusinessAddress(e.target.value)}
                      placeholder="e.g. MDFA Studio, Patna, Bihar"
                      className="border-orange-300"
                    />
                  </div>
                  <Button onClick={handleUpdateBusinessAddress} className="w-full bg-orange-600 hover:bg-orange-700">
                    Update Address
                  </Button>

                  <div>
                    <Label>Contact Number (for inquiries — shown on receipts/PDFs)</Label>
                    <Input
                      value={newBusinessPhone}
                      onChange={(e) => setNewBusinessPhone(e.target.value)}
                      placeholder="e.g. 9876543210"
                      className="border-orange-300"
                    />
                  </div>
                  <Button onClick={handleUpdateBusinessPhone} className="w-full bg-orange-600 hover:bg-orange-700">
                    Update Contact Number
                  </Button>

                  <div className="p-3 bg-yellow-50 rounded border border-yellow-200 text-sm">
                    <p className="text-yellow-800">
                      <Info className="inline w-3.5 h-3.5 -mt-0.5 mr-1" /> Business name, logo, address, and contact details will automatically appear in all PDFs (Admission Form, Fee Receipt, Student List, Teacher Report).
                    </p>
                  </div>
                </div>
              </Card>


            </TabsContent>

            {/* Enquiry Settings Tab — Course & Query Source lists for the Enquiry section */}
            <TabsContent value="enquirySettings" className="space-y-6">
              <EnquirySettings />
            </TabsContent>

            {/* Theme Tab — light/dark, colour theme, dashboard sections on/off + order */}
            <TabsContent value="theme" className="space-y-6">
              <ThemeSettings />
            </TabsContent>

            {/* Online Admission Tab — ON/OFF toggle + QR / link */}
            <TabsContent value="onlineAdmission" className="space-y-6">
              <OnlineAdmissionSettings />
            </TabsContent>

            {/* Google Review Tab — Groq key, review link, keywords, QR / link */}
            <TabsContent value="googleReview" className="space-y-6">
              <ReviewSettings />
            </TabsContent>

            {/* Event Forms Tab — ON/OFF toggle (Events section sidebar me tabhi aata hai) */}
            <TabsContent value="eventForms" className="space-y-6">
              <EventFormsSettings />
            </TabsContent>

            {/* Admission Form Layout Tab */}
            <TabsContent value="formLayout" className="space-y-6">
              <AdmissionFormLayoutSettings />
            </TabsContent>

            {/* Admission Fields Tab */}
            <TabsContent value="admissionFields" className="space-y-6">
              <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
                <h3 className="flex items-center gap-2 mb-2">
                  <ListChecks className="w-5 h-5 text-orange-600" />
                  Admission Form — Extra Fields
                </h3>
                <p className="text-sm text-gray-600 mb-4">
                  Fields turned ON here will instantly reflect in the Admission Form, Student List, PDFs (Receipt & Details), and WhatsApp messages. Mix and match fields from any group as needed.
                </p>

                {/* Add Extra Charges toggle */}
                <div className="bg-white rounded border-2 border-orange-300 p-3 mb-5">
                  <div className="flex items-center justify-between gap-3">
                    <div>
                      <Label htmlFor="extra-charges-toggle" className="cursor-pointer text-sm">
                        Add Extra Charges
                      </Label>
                      <p className="text-xs text-gray-500 mt-1">
                        Turning this ON adds a checkbox to the Admission Form. Admins can add up to {MAX_EXTRA_CHARGES} extra charges (e.g., AC, Dress, ID Card) with amounts. These charges add to the Total Amount and show up in the Student List (Edit) and PDFs.
                      </p>
                    </div>
                    <Switch
                      id="extra-charges-toggle"
                      checked={extraChargesEnabled}
                      onCheckedChange={handleToggleExtraCharges}
                    />
                  </div>
                </div>

                <div className="space-y-5">
                  {BUSINESS_TYPES.map((bt) => {
                    const fieldsForType = ALL_ADMISSION_FIELDS.filter((f) => f.businessTypes.includes(bt));
                    if (fieldsForType.length === 0) return null;
                    return (
                      <div key={bt} className="bg-white rounded border p-3">
                        <p className="text-sm mb-3 text-orange-700">{bt}</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {fieldsForType.map((field) => (
                            <div key={field.id} className="flex items-center justify-between gap-3 p-2 rounded hover:bg-orange-50">
                              <Label htmlFor={`field-${field.id}`} className="cursor-pointer text-sm font-normal">
                                {field.label}
                              </Label>
                              <Switch
                                id={`field-${field.id}`}
                                checked={enabledAdmissionFields.includes(field.id)}
                                onCheckedChange={(checked) => handleToggleAdmissionField(field.id, checked)}
                              />
                            </div>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="p-3 bg-yellow-50 rounded border border-yellow-200 text-sm mt-4">
                  <p className="text-yellow-800">
                    <Info className="inline w-3.5 h-3.5 -mt-0.5 mr-1" /> Currently {enabledAdmissionFields.length} extra field{enabledAdmissionFields.length !== 1 ? 's' : ''} ON hai{enabledAdmissionFields.length !== 1 ? 'n' : ''}. Ye setting is device par admission form ko customize karti hai.
                  </p>
                </div>
              </Card>
            </TabsContent>

            {/* Monthly Reports Tab */}
            <TabsContent value="reports" className="space-y-4">
              <div className="p-4 bg-white rounded-lg border-2 border-pink-200">
                <h3 className="flex items-center gap-2 mb-3 text-pink-700">
                  <Calendar className="w-5 h-5" />
                  Payment Report by Date Range
                </h3>

                {/* Date range */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-3">
                  <div>
                    <Label>From</Label>
                    <Input
                      type="date"
                      value={reportFromDate}
                      onChange={(e) => setReportFromDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label>To</Label>
                    <Input
                      type="date"
                      value={reportToDate}
                      onChange={(e) => setReportToDate(e.target.value)}
                    />
                  </div>
                </div>

                {/* Quick presets */}
                <div className="flex flex-wrap gap-2 mb-4">
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('today')}>
                    Today
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('last7')}>
                    Last 7 Days
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('last15')}>
                    Last 15 Days
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('thisMonth')}>
                    This Month
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('lastMonth')}>
                    Last Month
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('last30')}>
                    Last 30 Days
                  </Button>
                  <Button size="sm" variant="secondary" className="bg-pink-100 hover:bg-pink-200 text-pink-800" onClick={() => applyReportDatePreset('thisYear')}>
                    This Year
                  </Button>
                </div>

                {/* Location filter */}
                <div className="p-3 bg-pink-50 rounded border border-pink-200 mb-4">
                  <Label className="mb-1 flex items-center gap-1.5"><MapPin className="w-4 h-4" /> Location Filter (Optional)</Label>
                  <div className="flex flex-col sm:flex-row gap-2 items-stretch sm:items-end">
                    <div className="flex-1">
                      <Select value={reportLocation} onValueChange={setReportLocation}>
                        <SelectTrigger>
                          <SelectValue placeholder="All Locations" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Locations</SelectItem>
                          {reportLocationsList.map((loc: any) => (
                            <SelectItem key={loc.name} value={loc.name}>{loc.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setReportLocation('all')}
                      className="border-pink-300"
                    >
                      Clear Filter
                    </Button>
                  </div>
                </div>

                <div className="p-3 bg-white rounded border mb-4">
                  <p className="text-sm mb-2 flex items-center gap-1.5"><ClipboardList className="w-4 h-4" /> <strong>Report Includes:</strong></p>
                  <div className="space-y-1 text-sm text-gray-700">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-blue-500 rounded-full"></span>
                      <span>Student details (Name, Reg No, Mobile, Location, Batch)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                      <span>Fee payments and new admissions shown as separate sections</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-purple-500 rounded-full"></span>
                      <span>Payment details (Amount, Dues, Mode)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 bg-orange-500 rounded-full"></span>
                      <span>Summary (Total records, Grand total, Cash/Online breakdown)</span>
                    </div>
                  </div>
                </div>

                {/* Generate Buttons */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  <Button 
                    onClick={handleGenerateMonthlyReport}
                    className="w-full bg-green-600 hover:bg-green-700"
                    size="lg"
                  >
                    <FileSpreadsheet className="w-5 h-5 mr-2" />
                    Export Excel
                  </Button>
                  
                  <Button 
                    onClick={handleGenerateMonthlyReportPDF}
                    className="w-full bg-red-600 hover:bg-red-700"
                    size="lg"
                  >
                    <FileText className="w-5 h-5 mr-2" />
                    Export PDF
                  </Button>
                </div>

                {/* Export Info */}
                <div className="p-4 bg-gradient-to-r from-blue-50 to-red-50 border-2 border-gray-200 rounded-lg mt-4">
                  <p className="text-gray-800 mb-2 flex items-center gap-1.5"><PieChart className="w-4 h-4" /> Export Formats Available:</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div className="p-2 bg-blue-100 rounded">
                      <p className="text-blue-800 mb-1">Excel (.xlsx)</p>
                      <p className="text-blue-700 text-xs">• Summary + Fee Payments + New Admissions sheets</p>
                      <p className="text-blue-700 text-xs">• Editable in Excel/Sheets</p>
                    </div>
                    <div className="p-2 bg-red-100 rounded">
                      <p className="text-red-800 mb-1">PDF (.pdf)</p>
                      <p className="text-red-700 text-xs">• Colored, studio-branded report</p>
                      <p className="text-red-700 text-xs">• Fee Payments & New Admissions shown separately</p>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Data Export & Import Tab */}
            <TabsContent value="export" className="space-y-4">
              {/* Server (Cloud Sync) — sirf tab jab is license / link par server config mila ho */}
              {serverState.status !== 'no-config' && <ServerSettings />}

              {/* Google Drive Auto Backup Section (desktop app only) */}
              {isDriveBackupAvailable() && (
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-100">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="flex items-center gap-2">
                      <Cloud className="w-5 h-5" />
                      Google Drive Auto Backup
                    </h3>
                    {driveStatus.connected ? (
                      <span className="flex items-center gap-1 text-green-700 text-sm">
                        <CheckCircle2 className="w-4 h-4" /> Connected{driveStatus.email ? ` · ${driveStatus.email}` : ''}
                      </span>
                    ) : (
                      <span className="text-gray-500 text-sm">Not connected</span>
                    )}
                  </div>
                  <p className="text-sm text-gray-600 mb-3">
                    Automatic daily backup at 9 PM. Your data stays safe and up to date.
                  </p>

                  <div className="flex gap-2">
                    {driveStatus.connected ? (
                      <>
                        <Button
                          onClick={handleDriveBackupNow}
                          disabled={driveBackingUp}
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                        >
                          <RefreshCw className={`w-4 h-4 mr-2 ${driveBackingUp ? 'animate-spin' : ''}`} />
                          {driveBackingUp ? 'Backing up...' : 'Backup Now'}
                        </Button>
                        <Button
                          onClick={handleDriveDisconnect}
                          variant="outline"
                          className="text-red-600 border-red-200 hover:bg-red-50"
                        >
                          Disconnect
                        </Button>
                      </>
                    ) : (
                      <Button
                        onClick={handleDriveConnect}
                        disabled={driveConnecting}
                        className="w-full bg-blue-600 hover:bg-blue-700"
                      >
                        <Cloud className="w-4 h-4 mr-2" />
                        {driveConnecting ? 'Connecting... (browser mein login karein)' : 'Connect Google Drive'}
                      </Button>
                    )}
                  </div>

                  {driveStatus.connected && (
                    <div className="flex items-center justify-between mt-3 pt-3 border-t border-blue-100 gap-2">
                      <div className="text-xs text-gray-500 min-w-0">
                        <p>Latest backup on Drive</p>
                        <p className="truncate">
                          {driveStatus.lastBackupTime
                            ? new Date(driveStatus.lastBackupTime).toLocaleString('en-IN')
                            : 'No backups yet — click "Backup Now" to create the first one.'}
                        </p>
                        {driveStatus.lastFileName && (
                          <p className="truncate text-gray-400">{driveStatus.lastFileName}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={handleDriveRefreshStatus}
                          disabled={driveRefreshing}
                          className="text-xs text-blue-700 underline"
                        >
                          {driveRefreshing ? 'Refreshing...' : 'Refresh'}
                        </button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={handleDriveRestore}
                          disabled={driveRestoring || !driveStatus.lastBackupTime}
                          className="h-7 px-2 text-xs"
                        >
                          {driveRestoring ? 'Restoring...' : 'Restore'}
                        </Button>
                      </div>
                    </div>
                  )}

                  <p className="text-xs text-gray-400 mt-2 flex items-start gap-1">
                    <AlertTriangle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                    Restore replaces matching records on this device with the latest Drive backup — use it when setting up a new/replacement system.
                  </p>
                </div>
              )}

              {/* JSON Export/Import Section */}
              <div className="p-4 bg-green-50 rounded-lg">
                <h3 className="flex items-center gap-2 mb-3">
                  <FileJson className="w-5 h-5" />
                  Complete Database Backup (JSON Format)
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* JSON Export */}
                  <Card className="p-4 bg-white border-2 border-green-200 md:col-span-2">
                    <div className="space-y-2">
                      <h4 className="flex items-center gap-1.5"><Upload className="w-4 h-4" /> Export Complete Data</h4>
                      <p className="text-sm text-gray-600">
                        Download everything in one JSON file
                      </p>
                      <div className="grid grid-cols-2 gap-x-4 text-xs text-gray-500 mb-2">
                        <div className="space-y-1">
                          <p>• Students: {dataCounts.activeStudents}</p>
                          <p>• Deactivated Students: {dataCounts.deactivatedStudents}</p>
                          <p>• Payments: {dataCounts.payments}</p>
                          <p>• Teachers: {dataCounts.teachers}</p>
                          <p>• Batches: {dataCounts.batches}</p>
                          <p>• Locations: {dataCounts.locations}</p>
                        </div>
                        <div className="space-y-1 border-l pl-4">
                          <p>• Categories: {dataCounts.categories}</p>
                          <p>• Teacher Payments: {dataCounts.teacherPayments}</p>
                          <p>• Campaign Templates: {dataCounts.campaignTemplates}</p>
                          <p>• Enquiries (incl. QR Enquiry): {dataCounts.enquiries}</p>
                          <p>• QR Attendance days: {dataCounts.attendanceDays}</p>
                          <p>• Events: {dataCounts.events} (Templates: {dataCounts.eventTemplates}, Registrations: {dataCounts.eventSubmissions})</p>
                          <p>• Online Admission, Google Review, Theme &amp; all settings: {dataCounts.settingsCount}</p>
                        </div>
                      </div>
                      <Button 
                        onClick={handleExportJSON} 
                        className="w-full bg-green-600 hover:bg-green-700"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Export JSON File
                      </Button>
                    </div>
                  </Card>

                  {/* JSON Import */}
                  <Card className="p-4 bg-white border-2 border-blue-200">
                    <div className="space-y-2">
                      <h4 className="flex items-center gap-1.5"><Download className="w-4 h-4" /> Import Complete Data</h4>
                      <p className="text-sm text-gray-600">
                        Restore all dashboard data from JSON file
                      </p>
                      <p className="text-xs text-red-600 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" /> This will replace all existing data!
                      </p>
                      <label htmlFor="import-json-file">
                        <Button
                          disabled={importing}
                          className="w-full bg-blue-600 hover:bg-blue-700"
                          onClick={() => document.getElementById('import-json-file')?.click()}
                          type="button"
                        >
                          <Upload className="w-4 h-4 mr-2" />
                          {importing ? 'Importing...' : 'Import JSON File'}
                        </Button>
                      </label>
                      <input
                        id="import-json-file"
                        type="file"
                        accept=".json"
                        onChange={handleImportJSON}
                        className="hidden"
                      />
                    </div>
                  </Card>
                </div>

                <div className="text-xs text-gray-600 p-3 bg-white rounded border border-gray-200 mt-4">
                  <p className="flex items-start gap-1.5"><Lightbulb className="w-4 h-4 flex-shrink-0 mt-0.5" /> <span><strong>Use Case:</strong> Perfect for complete backup, transferring data to another device, or restoring after browser data clear.</span></p>
                </div>
              </div>

              {/* Excel Export Section - Individual & Complete */}
              <div className="p-4 bg-blue-50 rounded-lg">
                <h3 className="flex items-center gap-2 mb-3">
                  <Download className="w-5 h-5" />
                  Individual Excel Exports
                </h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Students Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.activeStudents} records
                      </p>
                      <Button onClick={handleExportStudents} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Students
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Deactivated Students</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.deactivatedStudents} records
                      </p>
                      <Button onClick={handleExportDeactivatedStudents} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Deactivated Students
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Expiry Students</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.expiryStudents} records
                      </p>
                      <Button onClick={handleExportExpiryStudents} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Expiry Students
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Dues Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.duesStudents} records
                      </p>
                      <Button onClick={handleExportDuesStudents} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Dues Data
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Payments Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.payments} records
                      </p>
                      <Button onClick={handleExportPayments} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Payments
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Teachers Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.teachers} records
                      </p>
                      <Button onClick={handleExportTeachers} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Teachers
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Batches Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.batches} records
                      </p>
                      <Button onClick={handleExportBatches} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Batches
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Locations Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.locations} records
                      </p>
                      <Button onClick={handleExportLocations} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Locations
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>Enquiries Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.enquiries} records
                      </p>
                      <Button onClick={handleExportEnquiries} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Enquiries
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4">
                    <div className="space-y-2">
                      <h4>QR Attendance Data</h4>
                      <p className="text-sm text-gray-500">
                        Total: {dataCounts.attendanceDays} days saved
                      </p>
                      <Button onClick={handleExportAttendance} className="w-full" variant="outline">
                        <Download className="w-4 h-4 mr-2" />
                        Export Attendance
                      </Button>
                    </div>
                  </Card>

                  <Card className="p-4 bg-orange-50 border-orange-200">
                    <div className="space-y-2">
                      <h4>Complete Excel Backup</h4>
                      <p className="text-sm text-gray-600">
                        All tables in one file
                      </p>
                      <Button onClick={handleExportAllData} className="w-full bg-orange-600 hover:bg-orange-700">
                        <Download className="w-4 h-4 mr-2" />
                        Export All Excel
                      </Button>
                    </div>
                  </Card>
                </div>

                <div className="text-sm text-gray-600 p-3 bg-yellow-50 border border-yellow-200 rounded mt-4">
                  <p><strong>Note:</strong> JSON format includes complete database and can be imported back. Excel format is for reporting only and cannot be imported.</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Pushed Students Report Dialog */}
      <Dialog open={showPushedReport} onOpenChange={setShowPushedReport}>
        <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Pause className="w-5 h-5 text-orange-600" />
              Pushed Students Report
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-600">Total Pushed Students: {pushedStudents.length}</p>
              <Button onClick={handleExportPushedStudents} size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export to Excel
              </Button>
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reg No</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead>Pushed Date</TableHead>
                  <TableHead>Original Expiry</TableHead>
                  <TableHead>Days Pushed</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pushedStudents.map((student: any) => {
                  const pushedDate = new Date(student.pushedDate);
                  const today = new Date();
                  const daysPushed = Math.floor((today.getTime() - pushedDate.getTime()) / (1000 * 60 * 60 * 24));
                  
                  return (
                    <TableRow key={student.regNo}>
                      <TableCell>{student.regNo}</TableCell>
                      <TableCell>{student.name}</TableCell>
                      <TableCell>{student.mobile}</TableCell>
                      <TableCell>{student.location || 'N/A'}</TableCell>
                      <TableCell>{student.batchTime || 'N/A'}</TableCell>
                      <TableCell>{formatDate(student.pushedDate)}</TableCell>
                      <TableCell>{formatDate(student.originalExpiryDate || student.expiryDate)}</TableCell>
                      <TableCell className="text-orange-600">{daysPushed} days</TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>

      {/* Blocked Students Report Dialog */}
      <Dialog open={showBlockedReport} onOpenChange={setShowBlockedReport}>
        <DialogContent className="max-w-6xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Ban className="w-5 h-5 text-red-600" />
              Blocked Students Report
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <p className="text-sm text-gray-600">Total Blocked Students: {blockedStudents.length}</p>
              <Button onClick={handleExportBlockedStudents} size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export to Excel
              </Button>
            </div>
            
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Reg No</TableHead>
                  <TableHead>Name</TableHead>
                  <TableHead>Mobile</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Dues</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {blockedStudents.map((student: any) => (
                  <TableRow key={student.regNo}>
                    <TableCell>{student.regNo}</TableCell>
                    <TableCell>{student.name}</TableCell>
                    <TableCell>{student.mobile}</TableCell>
                    <TableCell>{student.email || 'N/A'}</TableCell>
                    <TableCell>{student.location || 'N/A'}</TableCell>
                    <TableCell>{student.batchTime || 'N/A'}</TableCell>
                    <TableCell>{formatDate(student.expiryDate)}</TableCell>
                    <TableCell className="text-red-600">₹{student.dues || 0}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
