/* =========================================================
 *  ONLINE ADMISSION  (form  ->  Admissions tab  ->  CMS)  +  MAIL + STUDENT ID CARD
 *  Ye hissa attendance script ke saath jud kar chalta hai (same script, same URL).
 *  Public link:  <web app url>?page=admission
 *
 *  Flow:
 *   1) Student form bharta hai (photo + Spectrum design)  -> admSubmit()
 *        - photo Drive folder me save, request "Admissions" tab me (Status = pending)
 *        - student ko mail (form PDF + ID card), admin ko mail (same PDF)
 *   2) CMS har 15-20 sec me adm_version dekhta hai, badla ho to adm_list leta hai
 *   3) CMS Approve dabata hai  -> adm_claim (sirf ek computer le sakta hai, 10 min me expire)
 *      Photo adm_photo se CMS me aati hai aur Admission Form me bhar jati hai.
 *   4) Admission CMS me save hone ke baad -> adm_delete (row + Drive photo delete)
 *
 *  Sab naye functions ka naam adm... se shuru hota hai, taaki attendance ke naam se na takraein.
 *
 *  PEHLI BAAR (ya script update ke baad): Apps Script me function list se  admAuthorize  chuno -> Run
 *  (Mail + Drive ki permission do). Phir Deploy -> Manage deployments -> Edit -> New version -> Deploy.
 * ========================================================= */

var SHEET_ADM = 'Admissions';
var ADM_HEADERS = ['ReqId', 'Time', 'Status', 'Name', 'Mobile', 'Category', 'Batch', 'Location', 'ClaimBy', 'ClaimAt', 'Data'];
var ADM_CLAIM_MS = 10 * 60 * 1000;   // claim 10 minute me apne aap khatam
var ADM_MAX_PENDING = 500;           // isse zyada pending ho to nayi request nahi leta (sheet bhaari na ho)
var ADM_MAX_DATA = 8000;             // ek request ka data (characters) - cell limit se bahut neeche
var ADM_RATE_PER_MIN = 30;           // poore form par ek minute me max submissions
var ADM_MOBILE_TRIES = 3;            // ek mobile se 10 minute me max koshish
var ADM_MAX_PHOTO_BYTES = 400 * 1024;   // resized photo (jpeg) ki limit
var ADM_MAX_CARD_BYTES = 700 * 1024;    // ID card image (jpeg) ki limit
var ADM_MAIL_PER_EMAIL = 2;          // ek email par 1 ghante me max itne mail (koi dusre ke email se spam na kare)
var ADM_PHOTO_FOLDER = 'Online Admission Photos';
var ADM_HTML = __ADM_HTML__;
var ADM_THEME = __ADM_THEME__;

/* ---------------------------------------------------------
 *  SHEET + CONFIG
 * --------------------------------------------------------- */
function admSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  return ss.getSheetByName(SHEET_ADM) || ensureSheet_(ss, SHEET_ADM, ADM_HEADERS);
}

function admEmptyCfg_() {
  return {
    open: false, fields: [],
    photo: { enabled: false, required: false },
    mail: { student: false, admin: false, adminEmail: '' },
    options: { categories: [], batches: [], locations: [] }
  };
}

// Config sheet ki key "admCfg" me CMS ka bheja hua form layout + dropdown options + mail settings rakha hota hai.
function admCfg_() {
  var cache = CacheService.getScriptCache();
  var c = cache.get('admcfg');
  if (c) { try { return JSON.parse(c); } catch (e) {} }
  var cfg = admEmptyCfg_();
  try { var raw = readConfig_().admCfg; if (raw) cfg = JSON.parse(raw); } catch (e) {}
  if (!cfg.photo) cfg.photo = { enabled: false, required: false };
  if (!cfg.mail) cfg.mail = { student: false, admin: false, adminEmail: '' };
  try { cache.put('admcfg', JSON.stringify(cfg), 300); } catch (e) {}
  return cfg;
}

function admStr_(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').trim().slice(0, max);
}

var ADM_EMAIL_RE = /^[^\s@,;<>]+@[^\s@,;<>]+\.[^\s@,;<>]+$/;

// "a@x.com, b@y.com" -> ['a@x.com','b@y.com'] (sirf sahi emails, max 3)
function admEmails_(s) {
  var parts = String(s || '').split(/[,;\s]+/);
  var out = [];
  for (var i = 0; i < parts.length && out.length < 3; i++) {
    var e = admStr_(parts[i], 120).toLowerCase();
    if (e && ADM_EMAIL_RE.test(e) && out.indexOf(e) < 0) out.push(e);
  }
  return out;
}

var ADM_TYPES = ['text', 'email', 'number', 'date', 'select', 'textarea', 'phone', 'yesno'];

function admSaveConfig_(body) {
  var fields = [];
  var src = body.fields || [];
  for (var i = 0; i < src.length && fields.length < 80; i++) {
    var f = src[i] || {};
    var id = String(f.id || '');
    if (!/^[A-Za-z0-9_]{1,40}$/.test(id)) continue;
    var type = ADM_TYPES.indexOf(f.type) >= 0 ? f.type : 'text';
    var opts = [];
    var so = f.options || [];
    for (var j = 0; j < so.length && opts.length < 30; j++) { var o = admStr_(so[j], 60); if (o) opts.push(o); }
    fields.push({
      id: id,
      label: admStr_(f.label, 60) || id,
      type: type,
      kind: f.kind === 'core' ? 'core' : 'custom',   // custom = extra + owner-made (student.customFields)
      required: f.required === true,
      width: f.width === 'full' || f.width === 'third' ? f.width : 'half',
      group: admStr_(f.group, 60),
      options: type === 'yesno' ? ['Yes', 'No'] : opts
    });
  }
  var o2 = body.options || {};
  var cats = [], batches = [], locs = [];
  var sc = o2.categories || [];
  for (var a = 0; a < sc.length && cats.length < 100; a++) {
    var subs = [];
    var ss = (sc[a] && sc[a].subs) || [];
    for (var b = 0; b < ss.length && subs.length < 100; b++) { var s = admStr_(ss[b], 80); if (s) subs.push(s); }
    var cn = admStr_(sc[a] && sc[a].name, 80);
    if (cn) cats.push({ name: cn, subs: subs });
  }
  var sb = o2.batches || [];
  for (var c = 0; c < sb.length && batches.length < 600; c++) {
    var bt = admStr_(sb[c] && sb[c].t, 80);
    if (bt) batches.push({ t: bt, c: admStr_(sb[c].c, 80), s: admStr_(sb[c].s, 80) });
  }
  var sl = o2.locations || [];
  for (var d = 0; d < sl.length && locs.length < 100; d++) { var l = admStr_(sl[d], 80); if (l) locs.push(l); }

  var ph = body.photo || {};
  var mi = body.mail || {};
  var adminEmails = admEmails_(mi.adminEmail);

  var cfg = {
    open: body.open === true,
    fields: fields,
    photo: { enabled: ph.enabled === true, required: ph.enabled === true && ph.required === true },
    mail: { student: mi.student === true, admin: mi.admin === true && adminEmails.length > 0, adminEmail: adminEmails.join(',') },
    options: { categories: cats, batches: batches, locations: locs }
  };
  var json = JSON.stringify(cfg);
  if (json.length > 45000) return { success: false, error: 'Form ka config bahut bada ho gaya (category / batch list chhoti karein)' };
  writeConfigKey_('admCfg', json);
  CacheService.getScriptCache().remove('admcfg');
  admSheet_(); // tab pehle se bana ho
  return { success: true, ver: admVer_() };
}

/* ---------------------------------------------------------
 *  VERSION (CMS bina list mange pata kar leta hai kuch badla ya nahi)
 * --------------------------------------------------------- */
function admVer_() { return Number(getProp_('admVer', '0')); }
function admBump_() {
  var next = admVer_() + 1;
  setProp_('admVer', String(next));
  return next;
}

/* ---------------------------------------------------------
 *  PUBLIC PAGE  (google.script.run se: admInit, admSubmit)
 *  Ye functions koi bhi chala sakta hai, isliye inme sirf public cheezein hain.
 *  (Admin ka email / mail settings yaha se kabhi bahar nahi jate.)
 * --------------------------------------------------------- */
function admPage_() {
  var html = ADM_HTML.replace('__BANNER_SRC__', function () { return ADM_THEME.banner; });
  return HtmlService.createHtmlOutput(html)
    .setTitle('Admission Form')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
}

function admInit() {
  var cfg = admCfg_();
  var base = getConfigCached_();
  if (!cfg.open) return { open: false, businessName: base.businessName };
  return {
    open: true,
    businessName: base.businessName,
    theme: { cardBanner: ADM_THEME.cardBanner, dancer: ADM_THEME.dancer },
    fields: cfg.fields,
    options: cfg.options,
    photo: cfg.photo,
    mail: { student: cfg.mail.student === true }
  };
}

// Student ke bheje data ko layout ke hisaab se check + saaf karta hai.
function admValidate_(cfg, data) {
  var input = (data && data.f) || {};
  var core = {}, custom = {};
  var opt = cfg.options || {};
  var cat = admStr_(input.category, 80), sub = admStr_(input.subCategory, 80);
  var haveMobile = false, haveName = false;

  for (var i = 0; i < cfg.fields.length; i++) {
    var f = cfg.fields[i];
    var max = f.type === 'textarea' ? 1000 : 300;
    var v = admStr_(input[f.id], max);
    if (v === '') {
      if (f.required || f.id === 'name' || f.id === 'mobile') return { error: f.label + ' is required.' };
      continue;
    }
    if (f.type === 'phone' && !/^\d{10}$/.test(v)) return { error: f.label + ' must be a 10-digit number.' };
    if (f.id === 'aadhaarNumber' && !/^\d{12}$/.test(v)) return { error: f.label + ' must be a 12-digit number.' };
    if (f.type === 'email' && !ADM_EMAIL_RE.test(v)) return { error: f.label + ' is not a valid email address.' };
    if (f.type === 'number' && isNaN(Number(v))) return { error: f.label + ' must be a number.' };
    if (f.type === 'date' && !/^\d{4}-\d{2}-\d{2}$/.test(v)) return { error: f.label + ' is not a valid date.' };

    if (f.id === 'category') {
      if (!admFind_(opt.categories, function (x) { return x.name === v; })) return { error: f.label + ' is not valid.' };
    } else if (f.id === 'subCategory') {
      var cobj = admFind_(opt.categories, function (x) { return x.name === cat; });
      if (!cobj || cobj.subs.indexOf(v) < 0) return { error: f.label + ' is not valid.' };
    } else if (f.id === 'batchTime') {
      if (!admFind_(opt.batches, function (x) { return x.t === v && x.c === cat && x.s === sub; })) return { error: f.label + ' is not valid.' };
    } else if (f.id === 'location') {
      if ((opt.locations || []).indexOf(v) < 0) return { error: f.label + ' is not valid.' };
    } else if ((f.type === 'select' || f.type === 'yesno') && f.options.length && f.options.indexOf(v) < 0) {
      return { error: f.label + ' is not valid.' };
    }

    if (f.kind === 'core') core[f.id] = v; else custom[f.id] = v;
    if (f.id === 'mobile') haveMobile = true;
    if (f.id === 'name') haveName = true;
  }
  if (!haveMobile || !haveName) return { error: 'Name and mobile number are required.' };
  if (JSON.stringify({ core: core, custom: custom }).length > ADM_MAX_DATA) return { error: 'The form data is too large.' };
  return {
    name: core.name, mobile: core.mobile, email: core.email || '',
    category: core.category || '', batch: core.batchTime || '', location: core.location || '',
    core: core, custom: custom
  };
}

function admFind_(list, fn) {
  list = list || [];
  for (var i = 0; i < list.length; i++) if (fn(list[i])) return list[i];
  return null;
}

// Student ki bheji image ko sirf tab maanta hai jab wo asli JPEG ho aur chhoti ho.
function admDecodeJpeg_(b64, maxBytes, name) {
  if (!b64 || typeof b64 !== 'string' || b64.length > maxBytes * 1.4 + 16) return null;
  var bytes;
  try { bytes = Utilities.base64Decode(b64); } catch (e) { return null; }
  if (!bytes || bytes.length < 200 || bytes.length > maxBytes) return null;
  if ((bytes[0] & 255) !== 0xFF || (bytes[1] & 255) !== 0xD8 || (bytes[2] & 255) !== 0xFF) return null;
  return Utilities.newBlob(bytes, 'image/jpeg', name);
}

function admSubmit(data) {
  try {
    if (!data || typeof data !== 'object') return { ok: false, message: 'Invalid request.' };
    if (data._hp) return { ok: true, ref: 'OK' };   // honeypot: bot ko "success" dikhao, par kuch save nahi hota
    var cfg = admCfg_();
    if (!cfg.open) return { ok: false, message: 'Admissions are closed right now.' };

    var cache = CacheService.getScriptCache();
    var minKey = 'admrate_' + Math.floor(Date.now() / 60000);
    var n = Number(cache.get(minKey) || 0);
    if (n >= ADM_RATE_PER_MIN) return { ok: false, message: 'Too many requests right now. Please try again in a few minutes.' };
    cache.put(minKey, String(n + 1), 120);

    var v = admValidate_(cfg, data);
    if (v.error) return { ok: false, message: v.error };
    if (data.agree !== true) return { ok: false, message: 'Please read and accept the Academy Rules.' };

    var photoBlob = (data.photo && data.photo.b) ? admDecodeJpeg_(data.photo.b, ADM_MAX_PHOTO_BYTES, 'photo.jpg') : null;
    if (cfg.photo.enabled && cfg.photo.required && !photoBlob) return { ok: false, message: 'Please add a valid photo.' };
    if (!cfg.photo.enabled) photoBlob = null;
    var frontBlob = admDecodeJpeg_(data.idFront, ADM_MAX_CARD_BYTES, 'id-front.jpg');
    var backBlob = admDecodeJpeg_(data.idBack, ADM_MAX_CARD_BYTES, 'id-back.jpg');

    var mk = 'admmob_' + v.mobile;
    var tries = Number(cache.get(mk) || 0);
    if (tries >= ADM_MOBILE_TRIES) return { ok: false, message: 'Too many attempts from this number. Please try again after 10 minutes.' };
    cache.put(mk, String(tries + 1), 600);

    var id = 'ADM-' + Utilities.formatDate(new Date(), TZ, 'yyMMddHHmmss') + '-' + Math.floor(1000 + Math.random() * 9000);
    var stamp = Utilities.formatDate(new Date(), TZ, "yyyy-MM-dd'T'HH:mm:ss");

    var lock = LockService.getScriptLock();
    if (!lock.tryLock(15000)) return { ok: false, message: 'The server is busy. Please try again.' };
    try {
      var sh = admSheet_();
      var last = sh.getLastRow();
      if (last - 1 >= ADM_MAX_PENDING) return { ok: false, message: 'Too many requests are pending. Please contact the academy.' };
      if (last >= 2) {
        var dup = sh.getRange(2, 5, last - 1, 1).createTextFinder(v.mobile).matchEntireCell(true).findNext();
        if (dup) return { ok: false, message: 'A request with this mobile number is already pending.' };
      }
      var photoId = '';
      if (photoBlob) {
        try { photoId = admFolder_().createFile(photoBlob.setName(id + '.jpg')).getId(); } catch (pe) { photoId = ''; }
        if (!photoId && cfg.photo.required) return { ok: false, message: 'The photo could not be saved. Please try again.' };
      }
      var payload = JSON.stringify({ core: v.core, custom: v.custom, photoId: photoId });
      sh.appendRow([id, stamp, 'pending', v.name, v.mobile, v.category, v.batch, v.location, '', '', payload]);
      admBump_();
    } finally {
      try { lock.releaseLock(); } catch (x) {}
    }

    // Mail lock ke BAHAR: request save ho chuki hai, mail fail ho to bhi student ko success hi dikhta hai.
    var mailRes = { student: false, admin: false };
    try {
      mailRes = admSendMails_(cfg, { id: id, core: v.core, custom: v.custom, email: v.email, name: v.name, mobile: v.mobile,
        photoBlob: photoBlob, front: frontBlob, back: backBlob });
    } catch (me) {
      try { setProp_('admMailErr', admStr_(me && me.message ? me.message : me, 300)); } catch (x2) {}
    }
    return { ok: true, ref: id, mail: mailRes };
  } catch (err) {
    return { ok: false, message: 'Something went wrong. Please try again.' };
  }
}

/* ---------------------------------------------------------
 *  MAIL + PDF   (Spectrum header design; sirf wahi columns jo CMS me ON hain)
 * --------------------------------------------------------- */
function admEsc_(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function admFmtDate_(iso) {
  var p = String(iso || '').split('-');
  return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : String(iso || '');
}

// cfg.fields (CMS me jo columns ON hain) ke hisaab se [label, value] rows
function admRows_(cfg, core, custom) {
  var rows = [];
  for (var i = 0; i < cfg.fields.length; i++) {
    var f = cfg.fields[i];
    var v = f.kind === 'core' ? core[f.id] : custom[f.id];
    if (v == null || v === '') continue;
    rows.push([f.label, f.type === 'date' ? admFmtDate_(v) : v]);
  }
  return rows;
}

function admRowsHtml_(rows) {
  var out = '';
  for (var i = 0; i < rows.length; i++) {
    out += '<tr><td style="padding:6px 10px;font-weight:bold;color:#4a1a7a;border-bottom:1px solid #eee;width:38%;vertical-align:top;">' + admEsc_(rows[i][0]) + '</td>' +
      '<td style="padding:6px 10px;border-bottom:1px solid #eee;">' + admEsc_(rows[i][1]) + '</td></tr>';
  }
  return out;
}

function admDataUriBlob_(uri, name) {
  var m = /^data:([a-z\/+.-]+);base64,(.+)$/.exec(String(uri || ''));
  if (!m) return null;
  return Utilities.newBlob(Utilities.base64Decode(m[2]), m[1], name);
}

function admBase64_(blob) { return Utilities.base64Encode(blob.getBytes()); }

function admAcademy_() {
  try { return getConfigCached_().businessName || 'Spectrum Dance Academy'; } catch (e) { return 'Spectrum Dance Academy'; }
}

// JPEG ke header se asli width/height (photo PDF me dabke / chipke nahi, isliye)
function admJpegSize_(bytes) {
  var i = 2, n = bytes.length;
  while (i + 9 < n) {
    if ((bytes[i] & 255) !== 0xFF) { i++; continue; }
    var m = bytes[i + 1] & 255;
    if (m === 0xD8 || m === 0x01 || m === 0xFF || (m >= 0xD0 && m <= 0xD7)) { i += (m === 0xFF ? 1 : 2); continue; }
    var len = ((bytes[i + 2] & 255) << 8) | (bytes[i + 3] & 255);
    if (m >= 0xC0 && m <= 0xCF && m !== 0xC4 && m !== 0xC8 && m !== 0xCC) {
      return { h: ((bytes[i + 5] & 255) << 8) | (bytes[i + 6] & 255), w: ((bytes[i + 7] & 255) << 8) | (bytes[i + 8] & 255) };
    }
    if (len < 2) return null;
    i += 2 + len;
  }
  return null;
}

// photo ko box (maxW x maxH) me uske asli aspect ratio ke saath fit karta hai
function admFitPhoto_(blob, maxW, maxH) {
  var w = maxW, h = maxH;
  try {
    var d = admJpegSize_(blob.getBytes());
    if (d && d.w > 0 && d.h > 0) {
      var sc = Math.min(maxW / d.w, maxH / d.h);
      w = Math.max(1, Math.round(d.w * sc));
      h = Math.max(1, Math.round(d.h * sc));
    }
  } catch (e) {}
  return { w: w, h: h };
}

function admBuildPdf_(ctx) {
  var photoImg = '';
  if (ctx.photoBlob) {
    var fit = admFitPhoto_(ctx.photoBlob, 120, 150);
    photoImg = '<img src="data:image/jpeg;base64,' + admBase64_(ctx.photoBlob) + '" width="' + fit.w + '" height="' + fit.h +
      '" style="width:' + fit.w + 'px;height:' + fit.h + 'px;border:1px solid #ccc;">';
  }
  var cards = '';
  if (ctx.front && ctx.back) {
    var pg = function (blob) {
      return '<div style="page-break-before:always;text-align:center;padding-top:30px;"><img src="data:image/jpeg;base64,' + admBase64_(blob) +
        '" style="width:300px;height:475px;"></div>';
    };
    cards = pg(ctx.front) + pg(ctx.back);
  }
  var html =
    '<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#2a2130;">' +
    '<img src="' + ADM_THEME.banner + '" width="680" style="width:680px;height:auto;">' +
    '<table width="100%" style="margin-top:10px;"><tr>' +
    '<td><div style="font-size:20px;font-weight:bold;color:#4a1a7a;">Admission Form</div>' +
    '<div style="font-size:12px;color:#555;">Online request &middot; ' + admEsc_(ctx.when) + '</div></td>' +
    '<td align="right">' + photoImg + '</td></tr></table>' +
    '<hr style="border:1px solid #e4dcee;">' +
    '<table width="100%" style="border-collapse:collapse;font-size:13px;">' + admRowsHtml_(ctx.rows) + '</table>' +
    '<p style="margin-top:16px;font-size:12px;color:#2a2130;">Academy Rules &amp; Terms: <b>Accepted</b></p>' +
    '<p style="margin-top:10px;font-size:11px;color:#8a7fa0;">Note: Payment once made is non-refundable, as per academy terms and conditions. This is an online admission request; it is confirmed once the academy approves it. Please retain this document for your records.</p>' +
    cards + '</body></html>';
  var blob = HtmlService.createHtmlOutput(html).getAs('application/pdf');
  var safe = String(ctx.name || 'Student').replace(/[^A-Za-z0-9]+/g, '_').slice(0, 40);
  blob.setName('Admission_' + safe + '.pdf');
  return blob;
}

function admMailShell_(academy, inner) {
  return '<div style="max-width:640px;margin:0 auto;font-family:Arial,sans-serif;color:#2a2130;border:1px solid #e4dcee;border-radius:12px;overflow:hidden;">' +
    '<img src="cid:banner" style="width:100%;display:block;" alt="' + admEsc_(academy) + '">' +
    '<div style="padding:18px;font-size:14px;line-height:1.55;">' + inner + '</div>' +
    '<div style="background:#0d0d0d;color:#f2c14e;padding:10px;text-align:center;font-size:12px;">' + admEsc_(academy) + '</div></div>';
}

function admMailAllowed_(email) {
  var cache = CacheService.getScriptCache();
  var k = 'admmail_' + Utilities.base64EncodeWebSafe(email).slice(0, 120);
  var n = Number(cache.get(k) || 0);
  if (n >= ADM_MAIL_PER_EMAIL) return false;
  cache.put(k, String(n + 1), 3600);
  return true;
}

function admSendMails_(cfg, ctx) {
  var res = { student: false, admin: false };
  var wantStudent = cfg.mail.student === true && ADM_EMAIL_RE.test(ctx.email || '');
  var adminList = cfg.mail.admin === true ? admEmails_(cfg.mail.adminEmail) : [];
  if (!wantStudent && !adminList.length) return res;

  var academy = admAcademy_();
  ctx.when = Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy hh:mm a');
  ctx.rows = admRows_(cfg, ctx.core, ctx.custom);
  var pdf = admBuildPdf_(ctx);
  var rowsTable = '<table style="border-collapse:collapse;font-size:13px;width:100%;margin:10px 0;">' + admRowsHtml_(ctx.rows) + '</table>';

  var images = { banner: admDataUriBlob_(ADM_THEME.banner, 'banner.jpg') };
  var cardHtml = '';
  if (ctx.front && ctx.back) {
    images.idfront = ctx.front.setName('id-front.jpg');
    images.idback = ctx.back.setName('id-back.jpg');
    cardHtml = '<p><b>Your Student ID Card</b></p><table><tr>' +
      '<td><img src="cid:idfront" width="250" style="width:250px;border:1px solid #ddd;border-radius:8px;"></td>' +
      '<td style="width:10px;"></td>' +
      '<td><img src="cid:idback" width="250" style="width:250px;border:1px solid #ddd;border-radius:8px;"></td></tr></table>';
  }

  var quota = 0;
  try { quota = MailApp.getRemainingDailyQuota(); } catch (e) { quota = 0; }
  var needed = (wantStudent ? 1 : 0) + (adminList.length ? 1 : 0);
  if (quota < needed) throw new Error('Daily mail limit khatam ho gayi hai.');

  if (adminList.length) {
    var skipAdmin = adminList.length === 1 && adminList[0] === String(ctx.email || '').toLowerCase();
    if (!skipAdmin) {
      MailApp.sendEmail({
        to: adminList.join(','),
        subject: 'New Online Admission Request — ' + ctx.name + ' (' + ctx.mobile + ')',
        htmlBody: admMailShell_(academy,
          '<p><b>A new online admission request has been received.</b></p>' + rowsTable + cardHtml +
          '<p>Open <b>CMS &rarr; Online Admission</b> to review it and click <b>Approve</b>. The form PDF is attached.</p>'),
        inlineImages: images,
        attachments: [pdf],
        name: academy
      });
      res.admin = true;
    }
  }

  if (wantStudent && admMailAllowed_(String(ctx.email).toLowerCase())) {
    var adminReply = adminList.length ? adminList[0] : '';
    var opts = {
      to: ctx.email,
      subject: academy + ' — Admission Request Received',
      htmlBody: admMailShell_(academy,
        '<p>Dear ' + admEsc_(ctx.name) + ',</p>' +
        '<p>Thank you for applying to <b>' + admEsc_(academy) + '</b>. Your online admission request has been received. Our team will review it and contact you soon.</p>' +
        rowsTable + cardHtml +
        '<p>Your admission form (PDF) is attached for your records.</p><p>Regards,<br>' + admEsc_(academy) + '</p>'),
      inlineImages: images,
      attachments: [pdf],
      name: academy
    };
    if (adminReply) opts.replyTo = adminReply;
    MailApp.sendEmail(opts);
    res.student = true;
  }
  return res;
}

/* ---------------------------------------------------------
 *  PAYMENT RECEIPT MAIL
 *  Online request approve hone ke baad admin CMS me payment (fees / discount / dues date) bharke Save karta hai
 *  -> CMS "adm_receipt" bhejta hai -> student ko Spectrum banner wali receipt mail + PDF jati hai.
 *  Mail tabhi jati hai jab "Student ko mail bhejein" ON ho aur student ka email ho.
 * --------------------------------------------------------- */
function admNum_(v) {
  var n = parseFloat(v);
  return isNaN(n) ? 0 : Math.round(n * 100) / 100;
}

function admMoney_(n) {
  var s = (Math.round(n * 100) / 100).toFixed(2).replace(/\.00$/, '');
  return '&#8377;' + s;
}

function admIsoDate_(v) {
  var s = admStr_(v, 10);
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : '';
}

// CMS ka bheja data saaf karke (strings chhote, numbers pakke) receipt ke liye taiyaar
function admReceiptClean_(b) {
  var extras = [];
  var se = b.extraCharges || [];
  for (var i = 0; i < se.length && extras.length < 10; i++) {
    var nm = admStr_(se[i] && se[i].name, 60);
    var am = admNum_(se[i] && se[i].amount);
    if (nm || am) extras.push({ name: nm || 'Extra Charge', amount: am });
  }
  var extraSum = 0;
  for (var j = 0; j < extras.length; j++) extraSum += extras[j].amount;
  var grand = admNum_(b.grandTotal);
  var discount = admNum_(b.discount);
  var paid = admNum_(b.paid);
  var dues = Math.max(0, admNum_(b.dues));
  return {
    regNo: admStr_(b.regNo, 12), name: admStr_(b.name, 80), mobile: admStr_(b.mobile, 15), email: admStr_(b.email, 120).toLowerCase(),
    admissionDate: admIsoDate_(b.admissionDate), category: admStr_(b.category, 80), subCategory: admStr_(b.subCategory, 80),
    batchTime: admStr_(b.batchTime, 80), location: admStr_(b.location, 80),
    duration: admStr_(b.duration, 10), durationType: admStr_(b.durationType, 10), expiryDate: admIsoDate_(b.expiryDate),
    extras: extras, extraSum: extraSum,
    baseTotal: Math.max(0, grand - extraSum), grand: grand,
    discount: discount, discountPct: grand > 0 && discount > 0 ? Math.round(discount / grand * 1000) / 10 : 0,
    paid: paid, dues: dues, duesDate: dues > 0 ? admIsoDate_(b.duesDate) : '',
    paymentMode: admStr_(b.paymentMode, 20)
  };
}

function admReceiptTables_(r) {
  var student = [['Registration No', r.regNo], ['Student Name', r.name], ['Mobile No', r.mobile],
    ['Admission Date', admFmtDate_(r.admissionDate)], ['Category', r.category + (r.subCategory ? ' - ' + r.subCategory : '')],
    ['Batch Time', r.batchTime], ['Location', r.location],
    ['Duration', r.duration ? r.duration + ' ' + r.durationType : ''], ['Expiry Date', admFmtDate_(r.expiryDate)]];
  var rows = [];
  for (var i = 0; i < student.length; i++) if (student[i][1]) rows.push(student[i]);
  var html = '<table style="border-collapse:collapse;font-size:13px;width:100%;margin:8px 0;">' + admRowsHtml_(rows) + '</table>';

  // payment: yaha value me &#8377; hona chahiye, isliye rows alag se banate hain
  var td1 = 'padding:6px 10px;font-weight:bold;color:#4a1a7a;border-bottom:1px solid #eee;width:38%;vertical-align:top;';
  var td2 = 'padding:6px 10px;border-bottom:1px solid #eee;';
  var pay = '';
  var add = function (label, valueHtml, color) {
    pay += '<tr><td style="' + td1 + '">' + admEsc_(label) + '</td><td style="' + td2 + (color ? 'color:' + color + ';font-weight:bold;' : '') + '">' + valueHtml + '</td></tr>';
  };
  add('Total Amount', admMoney_(r.baseTotal));
  for (var e = 0; e < r.extras.length; e++) add(r.extras[e].name, admMoney_(r.extras[e].amount));
  if (r.extras.length) add('Grand Total', admMoney_(r.grand));
  if (r.discount > 0) add('Discount', admMoney_(r.discount) + (r.discountPct ? ' (' + r.discountPct + '%)' : ''), '#1e8f5f');
  add('Paid Amount', admMoney_(r.paid));
  add('Dues', admMoney_(r.dues), r.dues > 0 ? '#c0392b' : '#1e8f5f');
  if (r.dues > 0 && r.duesDate) add('Pay Dues By', admEsc_(admFmtDate_(r.duesDate)), '#c0392b');
  if (r.paymentMode) add('Payment Mode', admEsc_(r.paymentMode));
  html += '<div style="font-size:14px;font-weight:bold;color:#4a1a7a;margin-top:12px;">Payment Details</div>' +
    '<table style="border-collapse:collapse;font-size:13px;width:100%;margin:6px 0;">' + pay + '</table>';
  return html;
}

function admBuildReceiptPdf_(r, when) {
  var html =
    '<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;color:#2a2130;">' +
    '<img src="' + ADM_THEME.banner + '" width="680" style="width:680px;height:auto;">' +
    '<div style="margin-top:10px;font-size:20px;font-weight:bold;color:#4a1a7a;">Admission Payment Receipt</div>' +
    '<div style="font-size:12px;color:#555;">' + admEsc_(when) + '</div>' +
    '<hr style="border:1px solid #e4dcee;">' + admReceiptTables_(r) +
    (r.dues > 0 && r.duesDate
      ? '<p style="margin-top:12px;font-size:13px;color:#c0392b;font-weight:bold;">Please pay the remaining dues of ' + admMoney_(r.dues) + ' on or before ' + admEsc_(admFmtDate_(r.duesDate)) + '.</p>'
      : '') +
    '<p style="margin-top:14px;font-size:11px;color:#c0392b;">Terms &amp; Conditions: Your money will not be refundable, as per the academy\'s admission terms and conditions.</p>' +
    '</body></html>';
  var blob = HtmlService.createHtmlOutput(html).getAs('application/pdf');
  blob.setName('Receipt_' + String(r.name || 'Student').replace(/[^A-Za-z0-9]+/g, '_').slice(0, 40) + '.pdf');
  return blob;
}

function admReceipt_(body) {
  var cfg = admCfg_();
  if (cfg.mail.student !== true) return { success: true, ok: false, reason: 'mail_off' };
  var r = admReceiptClean_(body);
  if (!ADM_EMAIL_RE.test(r.email)) return { success: true, ok: false, reason: 'no_email' };
  if (!r.name) return { success: false, error: 'Student ka naam nahi mila.' };
  try {
    var quota = 0;
    try { quota = MailApp.getRemainingDailyQuota(); } catch (qe) { quota = 0; }
    if (quota < 1) return { success: false, error: 'Daily mail limit khatam ho gayi hai.' };

    var academy = admAcademy_();
    var when = Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy hh:mm a');
    var pdf = admBuildReceiptPdf_(r, when);
    var intro = '<p>Dear ' + admEsc_(r.name) + ',</p>' +
      '<p>Your admission at <b>' + admEsc_(academy) + '</b> is confirmed and your payment has been recorded. Your receipt is below and attached as a PDF.</p>';
    var dueNote = (r.dues > 0)
      ? '<p style="color:#c0392b;"><b>Pending dues: ' + admMoney_(r.dues) + '</b>' +
        (r.duesDate ? ' &mdash; please pay on or before <b>' + admEsc_(admFmtDate_(r.duesDate)) + '</b>.' : '.') + '</p>'
      : '';
    var opts = {
      to: r.email,
      subject: academy + ' — Admission Payment Receipt (Reg No ' + r.regNo + ')',
      htmlBody: admMailShell_(academy,
        intro + admReceiptTables_(r) + dueNote +
        '<p style="font-size:12px;color:#c0392b;"><b>Terms &amp; Conditions:</b> Your money will not be refundable, as per the academy\'s admission terms and conditions.</p>' +
        '<p>Regards,<br>' + admEsc_(academy) + '</p>'),
      inlineImages: { banner: admDataUriBlob_(ADM_THEME.banner, 'banner.jpg') },
      attachments: [pdf],
      name: academy
    };
    var adminList = cfg.mail.admin === true ? admEmails_(cfg.mail.adminEmail) : [];
    if (adminList.length) opts.replyTo = adminList[0];
    MailApp.sendEmail(opts);
    return { success: true, ok: true, remaining: MailApp.getRemainingDailyQuota() };
  } catch (e) {
    return { success: false, error: 'Receipt mail nahi ja saki: ' + (e && e.message ? e.message : e) };
  }
}

/* ---------------------------------------------------------
 *  DRIVE PHOTO
 * --------------------------------------------------------- */
function admFolder_() {
  var fid = getProp_('admFolderId', '');
  if (fid) { try { return DriveApp.getFolderById(fid); } catch (e) {} }
  var folder = DriveApp.createFolder(ADM_PHOTO_FOLDER);
  setProp_('admFolderId', folder.getId());
  return folder;
}

// Sirf apne photo folder ki file ko haath lagata hai
function admOwnFile_(id) {
  var clean = String(id || '').replace(/[^A-Za-z0-9_-]/g, '');
  if (!clean) return null;
  try {
    var file = DriveApp.getFileById(clean);
    var fid = getProp_('admFolderId', '');
    var parents = file.getParents();
    while (parents.hasNext()) { if (parents.next().getId() === fid) return file; }
  } catch (e) {}
  return null;
}

function admPhoto_(p) {
  var file = admOwnFile_(p.id);
  if (!file) return { success: false, error: 'photo not found' };
  var blob = file.getBlob();
  return { success: true, mime: blob.getContentType() || 'image/jpeg', b64: Utilities.base64Encode(blob.getBytes()) };
}

/* ---------------------------------------------------------
 *  CMS ACTIONS  (ADMIN_KEY ke saath - doGet / doPost me pehle hi check ho chuka hota hai)
 * --------------------------------------------------------- */
function admGet_(p) {
  if (p.action === 'adm_version') return { success: true, ver: admVer_() };
  if (p.action === 'adm_list') return admList_();
  if (p.action === 'adm_photo') return admPhoto_(p);
  return { success: false, error: 'unknown action' };
}

function admPost_(body) {
  if (body.action === 'adm_config') return admSaveConfig_(body);
  if (body.action === 'adm_claim') return admClaim_(body);
  if (body.action === 'adm_unclaim') return admUnclaim_(body);
  if (body.action === 'adm_delete') return admDelete_(body);
  if (body.action === 'adm_testmail') return admTestMail_(body);
  if (body.action === 'adm_receipt') return admReceipt_(body);
  return { success: false, error: 'unknown action' };
}

function admList_() {
  var sh = admSheet_();
  var last = sh.getLastRow();
  var items = [];
  if (last >= 2) {
    var rows = sh.getRange(2, 1, last - 1, ADM_HEADERS.length).getValues();
    var now = Date.now();
    for (var i = 0; i < rows.length; i++) {
      var r = rows[i];
      if (String(r[2]) !== 'pending') continue;
      var data = { core: {}, custom: {}, photoId: '' };
      try { data = JSON.parse(String(r[10])); } catch (e) {}
      var by = String(r[8] || '');
      var at = Number(r[9]) || 0;
      items.push({
        id: String(r[0]), time: String(r[1]),
        claimBy: by && now - at < ADM_CLAIM_MS ? by : '',
        data: data
      });
    }
  }
  return { success: true, ver: admVer_(), items: items };
}

function admFindRow_(id) {
  var sh = admSheet_();
  var key = String(id || '').trim();
  if (!key || sh.getLastRow() < 2) return 0;
  var cell = sh.getRange(2, 1, sh.getLastRow() - 1, 1).createTextFinder(key).matchEntireCell(true).findNext();
  return cell ? cell.getRow() : 0;
}

function admClaimState_(sh, row) {
  var v = sh.getRange(row, 9, 1, 2).getValues()[0];
  var by = String(v[0] || '');
  var at = Number(v[1]) || 0;
  return { by: by, active: !!by && Date.now() - at < ADM_CLAIM_MS };
}

function admClaim_(body) {
  var by = admStr_(body.by, 60);
  if (!by) return { success: false, error: 'by missing' };
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: false, reason: 'gone' };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.active && st.by !== by) return { success: true, ok: false, reason: 'taken' };
  sh.getRange(row, 9, 1, 2).setValues([[by, String(Date.now())]]);
  admBump_();
  return { success: true, ok: true };
}

function admUnclaim_(body) {
  var by = admStr_(body.by, 60);
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: true };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.by === by) {
    sh.getRange(row, 9, 1, 2).setValues([['', '']]);
    admBump_();
  }
  return { success: true, ok: true };
}

// Row physically delete hoti hai (aur uski Drive photo bhi). Row pehle se na ho to bhi ok (retry queue ke liye safe).
// Agar koi aur computer us request ko abhi approve kar raha hai to delete nahi hota.
function admDelete_(body) {
  var by = admStr_(body.by, 60);
  var row = admFindRow_(body.id);
  if (!row) return { success: true, ok: true };
  var sh = admSheet_();
  var st = admClaimState_(sh, row);
  if (st.active && st.by !== by) return { success: true, ok: false, reason: 'claimed' };
  var photoId = '';
  try { photoId = String((JSON.parse(String(sh.getRange(row, 11).getValue())) || {}).photoId || ''); } catch (e) {}
  sh.deleteRow(row);
  admBump_();
  if (photoId) {
    try { var pf = admOwnFile_(photoId); if (pf) pf.setTrashed(true); } catch (e2) {}
  }
  return { success: true, ok: true };
}

/* ---------------------------------------------------------
 *  SETUP / TEST
 * --------------------------------------------------------- */
// Pehli baar chalao: Mail + Drive ki permission maangta hai.
function admAuthorize() {
  MailApp.getRemainingDailyQuota();
  DriveApp.getRootFolder();
  return 'OK - Mail aur Drive ki permission mil gayi. Ab Deploy -> Manage deployments -> New version.';
}

// CMS se "Test mail" dabane par: admin email par sample mail + sample PDF jata hai (design + permission check).
function admTestMail_(body) {
  var to = admEmails_(body.to)[0];
  if (!to) return { success: false, error: 'Admin email sahi nahi hai.' };
  try {
    var academy = admAcademy_();
    var sample = {
      name: 'Sample Student', mobile: '9999999999', photoBlob: null, front: null, back: null,
      when: Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy hh:mm a'),
      rows: [['Student Name', 'Sample Student'], ['Mobile No', '9999999999'], ['Email', to], ['Category', 'Dance']]
    };
    var pdf = admBuildPdf_(sample);
    MailApp.sendEmail({
      to: to,
      subject: 'Test — Online Admission mail',
      htmlBody: admMailShell_(academy, '<p><b>This is a test mail.</b></p><p>If you can see the academy banner above and a sample PDF is attached, student / admin mails will arrive in this design.</p>' +
        '<table style="border-collapse:collapse;font-size:13px;width:100%;">' + admRowsHtml_(sample.rows) + '</table>'),
      inlineImages: { banner: admDataUriBlob_(ADM_THEME.banner, 'banner.jpg') },
      attachments: [pdf],
      name: academy
    });
    return { success: true, ok: true, remaining: MailApp.getRemainingDailyQuota() };
  } catch (e) {
    return { success: false, error: 'Mail nahi ja saka: ' + (e && e.message ? e.message : e) + ' (Apps Script me admAuthorize chalakar permission dein, phir dobara Deploy karein)' };
  }
}

// SIRF TEST KE LIYE (CMS jodne se pehle page check karna ho to)
// Function list se admTestSetup chuno -> Run. Phir <web app url>?page=admission kholo.
// CMS jab apna config bhejta hai to ye test config apne aap badal jata hai.
function admTestSetup() {
  admSaveConfig_({
    open: true,
    photo: { enabled: true, required: true },
    mail: { student: true, admin: false, adminEmail: '' },
    fields: [
      { id: 'name', label: 'Student Name', type: 'text', kind: 'core', required: true, width: 'third' },
      { id: 'gender', label: 'Gender', type: 'select', kind: 'core', required: true, width: 'full', options: ['Male', 'Female', 'Other'] },
      { id: 'dob', label: 'Date of Birth', type: 'date', kind: 'core', required: false, width: 'third' },
      { id: 'mobile', label: 'Mobile No', type: 'phone', kind: 'core', required: true, width: 'third' },
      { id: 'email', label: 'Email', type: 'email', kind: 'core', required: true, width: 'half' },
      { id: 'address', label: 'Address', type: 'text', kind: 'core', required: false, width: 'half' },
      { id: 'bloodGroup', label: 'Blood Group', type: 'select', kind: 'extra', required: false, width: 'half', group: 'Additional Information', options: ['A+', 'B+', 'O+'] },
      { id: 'category', label: 'Category', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'subCategory', label: 'Sub-Category', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'batchTime', label: 'Batch Time', type: 'select', kind: 'core', required: true, width: 'third' },
      { id: 'location', label: 'Location', type: 'select', kind: 'core', required: true, width: 'half' }
    ],
    options: {
      categories: [{ name: 'Dance', subs: ['Classical', 'Western'] }, { name: 'Fitness', subs: ['Zumba'] }],
      batches: [{ t: '07:00 AM To 08:00 AM', c: 'Dance', s: 'Classical' }, { t: '06:00 PM To 07:00 PM', c: 'Dance', s: 'Western' }, { t: '08:00 AM To 09:00 AM', c: 'Fitness', s: 'Zumba' }],
      locations: ['Main Branch', 'City Branch']
    }
  });
  return 'OK - ab ?page=admission kholo';
}
