// Registration No: 5 digit, serial, 26100 se shuru.
//
//  - Agle student ka number = Student List (deactivated bhi) ka sabse bada 5-digit Reg No + 1.
//  - Student DELETE ho jaye to uska number wapas free ho jata hai (sabse bada wahi tha to agla number wahi ban jata hai).
//    Deactivate karne par student list me hi rehta hai, isliye uska number reuse nahi hota.
//  - Purane 6-digit Reg No (100000+) ko ignore kiya jata hai, taaki serial 5-digit hi rahe.

import { getStudentsLite } from './indexedDB';

export const REG_NO_START = 26100;
export const REG_NO_MAX = 99999;

export const isValidRegNo = (v: any) => /^\d{5}$/.test(String(v ?? '').trim());

/** Pure function (test karna aasan): maujooda Reg No list se agla Reg No. '' = 5-digit ke saare number bhar chuke. */
export function nextRegNoFrom(existing: Array<string | number | null | undefined>): string {
  const used = new Set(existing.map((r) => String(r ?? '').trim()));
  let max = REG_NO_START - 1;
  used.forEach((r) => {
    if (/^\d{5}$/.test(r)) max = Math.max(max, Number(r));
  });
  let next = max + 1;
  if (next > REG_NO_MAX) {
    // 99999 tak pahunch gaye: 26100 se pehla khali number
    next = REG_NO_START;
    while (next <= REG_NO_MAX && used.has(String(next))) next++;
    if (next > REG_NO_MAX) return '';
  }
  return String(next);
}

export async function getNextRegNo(): Promise<string> {
  const students = await getStudentsLite();
  return nextRegNoFrom(students.map((s: any) => s.regNo));
}
