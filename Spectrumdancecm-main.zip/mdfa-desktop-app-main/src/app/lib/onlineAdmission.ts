// Online Admission (QR form) — CMS side.
//
// Flow:  Settings -> Online Admission (toggle ON)  ->  sidebar me "Online Admission" section aata hai
//        Student QR / link kholkar form bharta hai  ->  Google Sheet ke "Admissions" tab me request aati hai
//        CMS wo requests yaha dikhata hai  ->  Approve = Admission Form me data pehle se bhara khulta hai
//        Admission save hote hi request Sheet se delete ho jati hai.   Reject = request seedha delete.
//
// Approve ab LOCAL list se turant hota hai (Google ka wait nahi). Admission save / Reject par request pehle CMS se turant
// hat jati hai, phir Google Sheet se background me delete hoti hai (net na ho to queue me rehkar baad me).
//
// Ye Attendance wale Google Apps Script ka hi extra hissa hai (same web app URL, koi alag script nahi), isliye pehle
// Settings -> Management & Setup -> Attendance Setup me script connect hona chahiye.

import { useEffect, useState } from 'react';
import { getSetting, saveSetting, getAllBatches, getAllCategories, getAllLocations } from './indexedDB';
import { getAttendanceConfig, scriptGet, scriptPost } from './attendance';
import { loadFormLayout, resolveFields, FormFieldLayout, FORM_LAYOUT_EVENT } from './formLayout';
import { getEnabledFieldIds } from './admissionFields';

const KEY_ENABLED = 'onlineAdmissionEnabled';
const KEY_CFG_HASH = 'onlineAdmissionCfgHash';
const KEY_CLAIM_BY = 'onlineAdmissionClaimBy';
const KEY_DELETE_QUEUE = 'onlineAdmissionDeleteQueue';
const KEY_MAIL_STUDENT = 'onlineAdmissionMailStudent';   // submit par student ko mail (form PDF + ID card)
const KEY_MAIL_ADMIN = 'onlineAdmissionMailAdmin';       // submit par admin ko mail
const KEY_MAIL_ADMIN_EMAIL = 'onlineAdmissionAdminEmail';
const KEY_CACHE = 'onlineAdmissionCache';   // last dekhi hui requests (local), taaki app khulte hi list turant dikhe

export const ONLINE_ADMISSION_EVENT = 'onlineAdmissionChanged';

export interface AdmissionRequest {
  id: string;
  time: string;
  claimBy: string;                                   // koi aur computer is request ko abhi approve kar raha ho to uska naam
  data: { core: Record<string, string>; custom: Record<string, string>; photoId?: string };
}

// ---------- on / off ----------

export async function getOnlineAdmissionEnabled(): Promise<boolean> {
  return (await getSetting(KEY_ENABLED)) === true;
}

/** Toggle save hota hai aur turant sidebar update hota hai. Sheet ko batana (open / band) best-effort hai. */
export async function setOnlineAdmissionEnabled(enabled: boolean): Promise<{ pushed: boolean; error?: string }> {
  await saveSetting(KEY_ENABLED, enabled);
  window.dispatchEvent(new CustomEvent(ONLINE_ADMISSION_EVENT));
  try {
    const sent = await pushOnlineAdmissionConfig(true);
    return { pushed: sent };
  } catch (e: any) {
    return { pushed: false, error: friendlyError(e) };
  }
}

// ---------- mail settings ----------

export interface OnlineAdmissionMail {
  student: boolean;     // student ko mail (form PDF + ID card)
  admin: boolean;       // admin ko mail
  adminEmail: string;   // admin email(s), comma se alag (max 3)
}

export async function getOnlineAdmissionMail(): Promise<OnlineAdmissionMail> {
  const [st, ad, em] = await Promise.all([getSetting(KEY_MAIL_STUDENT), getSetting(KEY_MAIL_ADMIN), getSetting(KEY_MAIL_ADMIN_EMAIL)]);
  return { student: st !== false, admin: ad !== false, adminEmail: String(em || '') };
}

/** Mail settings save karke turant Google Sheet ko bhej deta hai. */
export async function saveOnlineAdmissionMail(m: OnlineAdmissionMail): Promise<void> {
  await saveSetting(KEY_MAIL_STUDENT, m.student);
  await saveSetting(KEY_MAIL_ADMIN, m.admin);
  await saveSetting(KEY_MAIL_ADMIN_EMAIL, m.adminEmail.trim());
  await pushOnlineAdmissionConfig(true);
}

/** Admin email par sample mail + sample PDF bhejta hai (design + Google permission check). */
export async function sendOnlineAdmissionTestMail(to: string): Promise<{ remaining: number }> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Pehle QR Attendance me Google Sheet connect karein.');
  const d = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_testmail', to }, 60000);
  return { remaining: Number(d.remaining) || 0 };
}

// ---------- payment receipt mail (online request approve -> payment bharke Save) ----------

export interface AdmissionReceiptData {
  regNo: string; name: string; mobile: string; email: string; admissionDate: string;
  category: string; subCategory: string; batchTime: string; location: string;
  duration: string; durationType: string; expiryDate: string;
  extraCharges: { name: string; amount: number }[];
  grandTotal: number;       // total + extra charges
  discount: number;
  paid: number;
  dues: number;
  duesDate: string;         // YYYY-MM-DD ('' = koi deadline nahi)
  paymentMode: string;
}

/** Student ko Spectrum banner wali payment receipt (PDF ke saath) mail karta hai.
 *  sent=false + reason: 'mail_off' (Student mail OFF), 'no_email' (student ka email nahi). Net / script error par throw karta hai. */
export async function sendAdmissionReceiptMail(data: AdmissionReceiptData): Promise<{ sent: boolean; reason?: string }> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return { sent: false, reason: 'no_script' };
  const d = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_receipt', ...data }, 90000);
  return { sent: !!d.ok, reason: d.reason };
}

function friendlyError(e: any): string {
  const msg = String(e?.message || e || '');
  if (/admPost_|admGet_|is not defined|unknown action/i.test(msg)) {
    return 'Google Script purani hai. Settings → Management & Setup → Attendance Setup se naya code copy karke Apps Script me paste karein aur dobara Deploy karein (script ek hi hai).';
  }
  return msg || 'Google Sheet se baat nahi ho payi.';
}

export { friendlyError as onlineAdmissionError };

export async function getOnlineAdmissionLink(): Promise<string> {
  const cfg = await getAttendanceConfig();
  return cfg.webAppUrl ? `${cfg.webAppUrl}?page=admission` : '';
}

// ---------- form config -> Google Sheet ----------

// Ye fields online form me nahi aate: regNo / photo / admission date / fees wala hissa admin approve karte time bharta hai.
const SELECT_IDS = ['category', 'subCategory', 'batchTime', 'location'];
const ADMIN_ONLY = new Set([
  'regNo', 'admissionDate', 'photo', 'duration', 'durationType', 'expiryDate',
  'totalAmount', 'paidAmount', 'dues', 'paymentMode',
]);

export async function buildAdmissionConfig(open: boolean) {
  const [layout, enabledIds, categories, batches, locations, mail] = await Promise.all([
    loadFormLayout(), getEnabledFieldIds(), getAllCategories(), getAllBatches(), getAllLocations(), getOnlineAdmissionMail(),
  ]);
  const all: FormFieldLayout[] = resolveFields(layout, enabledIds);

  const cats = (categories || []).map((c: any) => ({ name: String(c.name || ''), subs: (c.subCategories || []).map(String) }))
    .filter((c: any) => c.name);
  const locs = (locations || []).map((l: any) => String(l.name || '')).filter(Boolean);
  // Category -> Sub-Category -> Batch ka cascade tabhi chalta hai jab har category ki sub-category ho
  const cascadeOk = cats.length > 0 && cats.every((c: any) => c.subs.length > 0);
  const bts = (batches || [])
    .filter((b: any) => b.batchTime)
    .map((b: any) => ({ t: String(b.batchTime), c: String(b.category || ''), s: String(b.subCategory || '') }));

  const fields = all
    .filter((f) => f.visible && f.type !== 'photo' && !ADMIN_ONLY.has(f.id))
    .filter((f) => {
      if (f.id === 'location') return locs.length > 0;
      if (['category', 'subCategory', 'batchTime'].includes(f.id)) return cascadeOk;
      return true;
    })
    .map((f) => ({
      id: f.id,
      label: f.label,
      type: f.type,
      kind: f.kind === 'core' ? 'core' : 'custom',
      required: f.required || f.id === 'name' || f.id === 'mobile' || SELECT_IDS.includes(f.id),
      width: f.width,
      group: f.group || '',
      options: f.options || [],
    }));

  // Student ko mail tabhi ja sakti hai jab uska email ho: mail ON ho to Email field zaroori ho jata hai
  // (layout me Email hidden ho tab bhi online form me aata hai).
  if (mail.student) {
    const em = fields.find((f) => f.id === 'email');
    if (em) em.required = true;
    else fields.push({ id: 'email', label: 'Email', type: 'email', kind: 'core', required: true, width: 'half', group: '', options: [] });
  }

  // Photo (ID card ke liye): Admission Form Layout me Photo field visible ho to online form me photo maangta hai
  const photoField = all.find((f) => f.id === 'photo' && f.visible);

  return {
    open,
    fields,
    photo: { enabled: !!photoField, required: !!photoField?.required },
    mail: {
      student: mail.student,
      admin: mail.admin && !!mail.adminEmail.trim(),
      adminEmail: mail.adminEmail.trim(),
    },
    options: { categories: cats, batches: bts, locations: locs },
  };
}

/** Form layout / batches / categories badalne par Sheet ko naya config bhejta hai. Pehle jaisa ho to kuch nahi bhejta. */
export async function pushOnlineAdmissionConfig(force = false): Promise<boolean> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) return false;
  const enabled = await getOnlineAdmissionEnabled();
  const body = await buildAdmissionConfig(enabled);
  const hash = JSON.stringify([cfg.webAppUrl, body]);
  if (!force && (await getSetting(KEY_CFG_HASH)) === hash) return false;
  await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_config', ...body }, 60000);
  await saveSetting(KEY_CFG_HASH, hash);
  return true;
}

// ---------- requests ----------

async function claimName(): Promise<string> {
  let by = (await getSetting(KEY_CLAIM_BY)) as string;
  if (!by) {
    by = 'CMS-' + Math.random().toString(36).slice(2, 7);
    await saveSetting(KEY_CLAIM_BY, by);
  }
  return by;
}

export async function fetchAdmissionRequests(): Promise<{ items: AdmissionRequest[]; ver: number }> {
  const cfg = await getAttendanceConfig();
  if (!cfg.webAppUrl) throw new Error('Pehle QR Attendance me Google Sheet connect karein.');
  const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'adm_list' });
  const me = await claimName();
  const items: AdmissionRequest[] = (d.items || []).map((i: any) => ({
    id: String(i.id), time: String(i.time || ''),
    claimBy: i.claimBy && i.claimBy !== me ? String(i.claimBy) : '',
    data: { core: i.data?.core || {}, custom: i.data?.custom || {}, photoId: String(i.data?.photoId || '') },
  }));
  items.sort((a, b) => b.time.localeCompare(a.time));
  // Jinka delete Sheet par abhi baaki hai (admission save / reject ho chuka) wo wapas list me na aayein
  const pending = new Set(((await getSetting(KEY_DELETE_QUEUE)) || []) as string[]);
  return { items: items.filter((i) => !pending.has(i.id)), ver: Number(d.ver) || 0 };
}

/** Request ki photo (Google Drive se) data-URL me. Approve par Admission Form me photo bharne ke liye. */
export async function fetchAdmissionPhoto(photoId: string): Promise<string> {
  if (!photoId) return '';
  const cfg = await getAttendanceConfig();
  const d = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'adm_photo', id: photoId });
  return d.b64 ? `data:${d.mime || 'image/jpeg'};base64,${d.b64}` : '';
}

/** Approve dabane par: request sirf is computer ke liye reserve hoti hai (10 min). false = kisi aur ne le li / delete ho gayi. */
export async function claimAdmissionRequest(id: string): Promise<{ ok: boolean; reason?: string }> {
  const cfg = await getAttendanceConfig();
  const d = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_claim', id, by: await claimName() }, 30000);
  return { ok: !!d.ok, reason: d.reason };
}

export async function releaseAdmissionRequest(id: string): Promise<void> {
  try {
    const cfg = await getAttendanceConfig();
    await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_unclaim', id, by: await claimName() }, 30000);
  } catch { /* claim 10 min me apne aap khatam ho jata hai */ }
}

async function deleteOnSheet(id: string): Promise<boolean> {
  const cfg = await getAttendanceConfig();
  const d = await scriptPost(cfg.webAppUrl, cfg.adminKey, { action: 'adm_delete', id, by: await claimName() }, 30000);
  return !!d.ok;
}

/** Reject ya "admission save ho gayi" ke baad: request CMS se TURANT hat jati hai, Google Sheet se background me delete hoti hai.
 *  Net na ho to delete queue me rehta hai aur baad me apne aap dobara koshish hoti hai. */
export async function removeAdmissionRequest(id: string): Promise<void> {
  store.items = store.items.filter((i) => i.id !== id);
  emit();
  await saveCache();
  const q = ((await getSetting(KEY_DELETE_QUEUE)) || []) as string[];
  if (!q.includes(id)) await saveSetting(KEY_DELETE_QUEUE, [...q, id]);
  flushDeleteQueue().catch(() => { /* agli baar */ });
}

let flushing = false;
async function flushDeleteQueue() {
  if (flushing) return;
  flushing = true;
  try {
    const q = ((await getSetting(KEY_DELETE_QUEUE)) || []) as string[];
    if (!q.length) return;
    const done: string[] = [];
    for (const id of q) {
      try { await deleteOnSheet(id); done.push(id); } catch { /* net nahi: queue me rehne do */ }
    }
    if (done.length) {
      // is dauraan naye id queue me aaye ho sakte hain, isliye dobara padhkar sirf done wale hatao
      const latest = ((await getSetting(KEY_DELETE_QUEUE)) || []) as string[];
      await saveSetting(KEY_DELETE_QUEUE, latest.filter((x) => !done.includes(x)));
    }
  } finally {
    flushing = false;
  }
}

// ---------- local copy of the list ----------

async function saveCache() {
  try { await saveSetting(KEY_CACHE, store.items); } catch { /* cache zaroori nahi */ }
}

/** App khulte hi last list local se dikha deta hai (Google ka wait nahi). Sheet se taza list baad me aati hai. */
async function loadCachedRequests() {
  if (store.items.length) return;
  try {
    const cached = ((await getSetting(KEY_CACHE)) || []) as AdmissionRequest[];
    const pending = new Set(((await getSetting(KEY_DELETE_QUEUE)) || []) as string[]);
    const items = cached.filter((i) => i && i.id && !pending.has(i.id));
    if (items.length && !store.items.length) { store.items = items; emit(); }
  } catch { /* koi baat nahi */ }
}

// ---------- prefill (Approve -> Admission Form) ----------

let pendingPrefill: { id: string; req: AdmissionRequest } | null = null;
export function setAdmissionPrefill(req: AdmissionRequest) { pendingPrefill = { id: req.id, req }; }
export function takeAdmissionPrefill() { const p = pendingPrefill; pendingPrefill = null; return p; }

// ---------- shared list (sidebar badge + requests page) ----------

interface Store { items: AdmissionRequest[]; ver: number; loading: boolean; error: string; loadedAt: number; }
const store: Store = { items: [], ver: -1, loading: false, error: '', loadedAt: 0 };
const listeners = new Set<() => void>();
function emit() { listeners.forEach((l) => l()); }

export async function refreshAdmissionRequests(): Promise<void> {
  if (store.loading) return;
  store.loading = true; emit();
  try {
    const r = await fetchAdmissionRequests();
    store.items = r.items; store.ver = r.ver; store.error = ''; store.loadedAt = Date.now();
    await saveCache();
  } catch (e: any) {
    store.error = friendlyError(e);
  } finally {
    store.loading = false; emit();
  }
}

export function useAdmissionRequests() {
  const [, force] = useState(0);
  useEffect(() => {
    const l = () => force((n) => n + 1);
    listeners.add(l);
    return () => { listeners.delete(l); };
  }, []);
  return { ...store, refresh: refreshAdmissionRequests };
}

export function useOnlineAdmissionEnabled(): boolean {
  const [on, setOn] = useState(false);
  useEffect(() => {
    let alive = true;
    const load = () => getOnlineAdmissionEnabled().then((v) => { if (alive) setOn(v); });
    load();
    window.addEventListener(ONLINE_ADMISSION_EVENT, load);
    return () => { alive = false; window.removeEventListener(ONLINE_ADMISSION_EVENT, load); };
  }, []);
  return on;
}

// ---------- background sync (AdminDashboard me ek baar mount hota hai) ----------
// 1) form layout / batch / category / location badle to config Sheet ko bhejta hai
// 2) naye requests ke liye har ~20 sec me sirf chhota "version" ping karta hai; badla ho tabhi poori list leta hai

export function useOnlineAdmissionSync() {
  useEffect(() => {
    let stopped = false;
    let running = false;
    let cfgTimer: any = null;

    loadCachedRequests();

    const pushSoon = () => {
      clearTimeout(cfgTimer);
      cfgTimer = setTimeout(async () => {
        try { if (await getOnlineAdmissionEnabled()) await pushOnlineAdmissionConfig(); } catch { /* agli baar phir koshish */ }
      }, 3000);
    };
    const evs = [FORM_LAYOUT_EVENT, 'batchesUpdated', 'locationsUpdated', 'categoriesUpdated'];
    evs.forEach((e) => window.addEventListener(e, pushSoon));
    pushSoon();

    const tick = async () => {
      if (stopped || running || document.hidden) return;
      running = true;
      try {
        if (await getOnlineAdmissionEnabled()) {
          const cfg = await getAttendanceConfig();
          if (cfg.webAppUrl) {
            await flushDeleteQueue();
            const v = await scriptGet(cfg.webAppUrl, cfg.adminKey, { action: 'adm_version' });
            if (Number(v.ver) !== store.ver) await refreshAdmissionRequests();
          }
        }
      } catch { /* net slow / band: agli baar */ }
      running = false;
    };
    tick();
    const iv = setInterval(tick, 20000);
    const onToggle = () => { store.ver = -1; tick(); };
    window.addEventListener(ONLINE_ADMISSION_EVENT, onToggle);

    return () => {
      stopped = true;
      clearInterval(iv);
      clearTimeout(cfgTimer);
      evs.forEach((e) => window.removeEventListener(e, pushSoon));
      window.removeEventListener(ONLINE_ADMISSION_EVENT, onToggle);
    };
  }, []);
}
