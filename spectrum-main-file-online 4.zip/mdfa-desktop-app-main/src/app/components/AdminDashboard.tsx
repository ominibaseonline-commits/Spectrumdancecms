import { useState, useEffect, useRef } from 'react';
import { Button } from './ui/button';
import { Dashboard } from './Dashboard';
import { OfflineAdmission } from './OfflineAdmission';
import { OnlineAdmissionRequests } from './OnlineAdmissionRequests';
import { useOnlineAdmissionEnabled, useOnlineAdmissionSync, useAdmissionRequests } from '../lib/onlineAdmission';
import { useQrEnquirySync } from '../lib/qrEnquiry';
import { EnquiryManagement } from './EnquiryManagement';
import { FeesManagement } from './FeesManagement';
import { StudentList } from './StudentList';
import { DeactivatedStudents } from './DeactivatedStudents';
import { CampaignManagement } from './CampaignManagement';
import { BatchManagement } from './BatchManagement';
import { AttendanceManagement } from './AttendanceManagement';
import { useAttendanceAutoSync, useAttendanceLiveSync } from '../lib/attendance';
import { TeacherManagement } from './TeacherManagement';
import { CategoryManagement } from './CategoryManagement';
import { LocationManagement } from './LocationManagement';
import { Settings } from './Settings';
import { EventsPage } from '../events/EventsPage';
import { useEventFormsEnabled, useEventsSync } from '../events/lib/eventSync';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { useBusinessName } from '../contexts/BusinessContext';
import { LocationFilterProvider } from '../contexts/LocationFilterContext';
import { getStoredLicenseData, getStoredLicenseKey, validateLicenseFromGoogleSheet, extractExpiryDate, isLifetimeLicense, formatExpiryDateDisplay } from '../lib/googleSheetLicense';
import { VERSION_INFO } from '../lib/version';
import { preloadStudentsLite } from '../lib/indexedDB';
import { MobileSettingsHub } from './MobileSettingsHub';
import {
  LayoutDashboard,
  UserPlus,
  CreditCard,
  Users,
  Clock,
  GraduationCap,
  Tag,
  Settings as SettingsIcon,
  LogOut,
  UserCircle,
  RefreshCw,
  UserX,
  Megaphone,
  MapPin,
  PhoneCall,
  CalendarCheck,
  Globe,
  CalendarDays,
  ChevronLeft,
  Home,
  Settings2,
} from 'lucide-react';

// Phone / chhoti screen (PWA) = app jaisa layout (neeche tab bar). Desktop app ki min width 1000 hai, isliye usse chhoti screen par hi badalta hai.
const COMPACT_QUERY = '(max-width: 999px)';
function useCompactLayout() {
  const [compact, setCompact] = useState(() => typeof window !== 'undefined' && window.matchMedia(COMPACT_QUERY).matches);
  useEffect(() => {
    const mq = window.matchMedia(COMPACT_QUERY);
    const on = () => setCompact(mq.matches);
    on();
    mq.addEventListener('change', on);
    return () => mq.removeEventListener('change', on);
  }, []);
  return compact;
}

interface AdminDashboardProps {
  user: any;
  onLogout: () => void;
}

export function AdminDashboard(props: AdminDashboardProps) {
  return (
    <LocationFilterProvider>
      <AdminDashboardInner {...props} />
    </LocationFilterProvider>
  );
}

function AdminDashboardInner({ user, onLogout }: AdminDashboardProps) {
  const { businessName, businessLogo } = useBusinessName();
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [showProfile, setShowProfile] = useState(false);
  const [appVersion, setAppVersion] = useState(VERSION_INFO.version);
  const [licenseData, setLicenseData] = useState(getStoredLicenseData());
  const [profileLoading, setProfileLoading] = useState(false);
  const compact = useCompactLayout();
  const mainRef = useRef<HTMLElement | null>(null);
  // Phone par page badalne par content hamesha upar se dikhe
  useEffect(() => { mainRef.current?.scrollTo({ top: 0 }); }, [currentPage]);

  // Fetch the real license from the sheet every time My Profile is opened
  useEffect(() => {
    if (!showProfile) return;
    const key = getStoredLicenseKey();
    if (!key) return;
    setProfileLoading(true);
    validateLicenseFromGoogleSheet(key)
      .then((fresh) => { if (fresh?.success) setLicenseData(fresh); })
      .catch(() => {})
      .finally(() => setProfileLoading(false));
  }, [showProfile]);

  // Keeps students' dues/expiry in the attendance Google Sheet up to date (no-op until connected)
  useAttendanceAutoSync();
  useAttendanceLiveSync();
  // Online Admission: form config Sheet ko bhejna + naye requests ka pata rakhna (toggle OFF ho to kuch nahi karta)
  useOnlineAdmissionSync();
  // QR Enquiry: course list Sheet ko bhejna + nayi QR enquiry turant local storage me lena (toggle OFF ho to kuch nahi karta)
  useQrEnquirySync();
  // Events: event forms Sheet ko bhejna + nayi registration turant local storage me lena (Settings -> Event Forms OFF ho to kuch nahi karta)
  useEventsSync();
  const eventFormsOn = useEventFormsEnabled();
  const onlineAdmissionOn = useOnlineAdmissionEnabled();
  const { items: onlineRequests } = useAdmissionRequests();
  useEffect(() => {
    if (!onlineAdmissionOn && currentPage === 'online-admission') setCurrentPage(compact ? 'settings-hub' : 'settings');
  }, [onlineAdmissionOn, currentPage, compact]);
  useEffect(() => {
    if (!eventFormsOn && currentPage === 'events') setCurrentPage(compact ? 'settings-hub' : 'settings');
  }, [eventFormsOn, currentPage, compact]);

  // Load the (photo-less) student list into memory in the background right after
  // login, so the Student List page opens instantly even with 10,000+ students.
  useEffect(() => {
    const t = setTimeout(() => preloadStudentsLite(), 800);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    const desktopApi = (window as any).desktopApp;
    if (desktopApi?.isElectron && typeof desktopApi.getAppVersion === 'function') {
      desktopApi.getAppVersion().then((v: string) => v && setAppVersion(v));
    }
  }, []);

  // Desktop par 'settings-hub' (sirf phone ka page) nahi hota
  useEffect(() => {
    if (!compact && currentPage === 'settings-hub') setCurrentPage('settings');
  }, [compact, currentPage]);

  const menuItems: { id: string; label: string; icon: any; badge?: number }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'enquiry', label: 'Enquiry', icon: PhoneCall },
    { id: 'attendance', label: 'QR Attendance', icon: CalendarCheck },
    { id: 'admission-form', label: 'Admission Form', icon: UserPlus },
    // Settings -> Online Admission toggle ON ho tabhi, Admission Form ke just niche
    ...(onlineAdmissionOn ? [{ id: 'online-admission', label: 'Online Admission', icon: Globe, badge: onlineRequests.length }] : []),
    { id: 'fees-management', label: 'Fees Management', icon: CreditCard },
    { id: 'student-list', label: 'Student List', icon: Users },
    { id: 'deactivated-students', label: 'Deactivated Students', icon: UserX },
    { id: 'batches', label: 'Batches', icon: Clock },
    { id: 'teacher', label: 'Teacher', icon: GraduationCap },
    { id: 'location', label: 'Location', icon: MapPin },
    { id: 'category', label: 'Category', icon: Tag },
    { id: 'campaign', label: 'Campaign', icon: Megaphone },
    // Settings -> Event Forms toggle ON ho tabhi
    ...(eventFormsOn ? [{ id: 'events', label: 'Events', icon: CalendarDays }] : []),
    { id: 'settings', label: 'Settings', icon: SettingsIcon },
  ];

  const pageContent = (
    <>
        {currentPage === 'dashboard' && <Dashboard onNavigate={setCurrentPage} />}
        {currentPage === 'enquiry' && <EnquiryManagement />}
        {currentPage === 'admission-form' && <OfflineAdmission />}
        {currentPage === 'online-admission' && <OnlineAdmissionRequests onOpenForm={() => setCurrentPage('admission-form')} />}
        {currentPage === 'fees-management' && <FeesManagement />}
        {currentPage === 'student-list' && <StudentList />}
        {currentPage === 'deactivated-students' && <DeactivatedStudents />}
        {currentPage === 'batches' && <BatchManagement />}
        {(currentPage === 'attendance' || currentPage === 'daily-attendance' || currentPage === 'reports') && (
          <AttendanceManagement key={currentPage} initialTab={currentPage === 'reports' ? 'reports' : currentPage === 'daily-attendance' ? 'daily' : 'attendance'} />
        )}
        {currentPage === 'teacher' && <TeacherManagement />}
        {currentPage === 'location' && <LocationManagement />}
        {currentPage === 'category' && <CategoryManagement />}
        {/* Kept mounted at all times (just hidden) so the typed message, selected
            batch, and sent status don't reset when the admin switches sections. */}
        <div style={{ display: currentPage === 'campaign' ? 'block' : 'none' }}>
          <CampaignManagement />
        </div>
        {currentPage === 'events' && eventFormsOn && <EventsPage />}
        {currentPage === 'settings' && <Settings />}
    </>
  );

  const profileDialog = (
    <>
      {/* My Profile Dialog — so the admin always has their license key handy */}
      <Dialog open={showProfile} onOpenChange={setShowProfile}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>My Profile</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between border-b pb-2">
              <span className="text-gray-500">Business Name</span>
              <span className="font-medium">{licenseData?.business || 'N/A'}</span>
            </div>
            {licenseData?.user_name && (
              <div className="flex justify-between border-b pb-2">
                <span className="text-gray-500">Name</span>
                <span className="font-medium">{licenseData.user_name}</span>
              </div>
            )}
            <div className="flex justify-between border-b pb-2">
              <span className="text-gray-500">Phone</span>
              <span className="font-medium">{licenseData?.phone || 'N/A'}</span>
            </div>
            <div className="flex justify-between border-b pb-2">
              <span className="text-gray-500">License Key</span>
              <span className="font-mono font-medium text-orange-600">{licenseData?.license_key || 'N/A'}</span>
            </div>
            {(extractExpiryDate(licenseData) || isLifetimeLicense(licenseData)) && (
              <div className="flex justify-between border-b pb-2">
                <span className="text-gray-500">Expiry Date</span>
                <span className="font-medium">{isLifetimeLicense(licenseData) ? 'Lifetime' : formatExpiryDateDisplay(extractExpiryDate(licenseData))}{profileLoading ? ' …' : ''}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-gray-500">App Version</span>
              <span className="font-medium">{appVersion}</span>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );

  // ---------- Phone / PWA: app jaisa layout ----------
  if (compact) {
    const TABS: { id: string; label: string; icon: any }[] = [
      { id: 'dashboard', label: 'Home', icon: Home },
      { id: 'admission-form', label: 'Admission', icon: UserPlus },
      { id: 'fees-management', label: 'Fees', icon: CreditCard },
      { id: 'student-list', label: 'Students', icon: Users },
      { id: 'settings-hub', label: 'Settings', icon: Settings2 },
    ];
    const tabIds = TABS.map((t) => t.id);
    const isTabPage = tabIds.includes(currentPage);
    const activeTab = isTabPage ? currentPage : 'settings-hub';
    const TITLES: Record<string, string> = {
      'settings-hub': 'Settings',
      settings: 'App Settings',
      'daily-attendance': 'Daily Attendance',
      reports: 'Attendance Reports',
      attendance: 'QR Attendance',
    };
    const title = TITLES[currentPage] || menuItems.find((m) => m.id === currentPage)?.label || 'Ominibase CMS';
    // Settings hub ke andar kholi gayi pages par back button
    const showBack = !isTabPage && currentPage !== 'settings-hub';

    return (
      <div className="flex flex-col w-full overflow-hidden" style={{ height: '100dvh', backgroundColor: 'var(--app-bg)' }}>
        {/* top app bar */}
        <header className="shrink-0 text-white shadow-sm z-10" style={{ backgroundColor: 'var(--brand)', paddingTop: 'env(safe-area-inset-top)' }}>
          <div className="h-14 px-2 flex items-center gap-1">
            {showBack ? (
              <button type="button" onClick={() => setCurrentPage('settings-hub')} aria-label="Wapas" className="w-10 h-10 rounded-full flex items-center justify-center active:bg-white/20">
                <ChevronLeft className="w-6 h-6" />
              </button>
            ) : (
              <div className="w-10 h-10 flex items-center justify-center">
                {businessLogo ? <img src={businessLogo} alt="" className="w-8 h-8 rounded-lg bg-white object-contain" /> : <LayoutDashboard className="w-5 h-5" />}
              </div>
            )}
            <div className="flex-1 min-w-0 px-1">
              <p className="font-semibold leading-tight truncate">{currentPage === 'dashboard' ? businessName : title}</p>
              {currentPage === 'dashboard' && <p className="text-[11px] opacity-90 leading-tight">Admin Panel</p>}
            </div>
            <button type="button" onClick={() => window.location.reload()} aria-label="Reload" className="w-10 h-10 rounded-full flex items-center justify-center active:bg-white/20">
              <RefreshCw className="w-5 h-5" />
            </button>
            <button type="button" onClick={() => setShowProfile(true)} aria-label="My Profile" className="w-10 h-10 rounded-full flex items-center justify-center active:bg-white/20">
              <UserCircle className="w-6 h-6" />
            </button>
          </div>
        </header>

        {/* content */}
        <main ref={mainRef} className="mobile-main flex-1 min-h-0 overflow-y-auto overscroll-contain scrollbar-hidden">
          {currentPage === 'settings-hub' && (
            <MobileSettingsHub
              businessName={businessName}
              businessLogo={businessLogo}
              version={appVersion}
              onlineAdmissionOn={onlineAdmissionOn}
              onlineRequestCount={onlineRequests.length}
              eventFormsOn={eventFormsOn}
              onNavigate={setCurrentPage}
              onProfile={() => setShowProfile(true)}
              onReload={() => window.location.reload()}
              onLogout={onLogout}
            />
          )}
          {/* pageContent hamesha lagta hai (Campaign ka typed message hub par jaane se reset na ho) */}
          {pageContent}
        </main>

        {/* bottom tab bar */}
        <nav className="shrink-0 bg-white border-t z-10 grid grid-cols-5" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
          {TABS.map((t) => {
            const Icon = t.icon;
            const active = activeTab === t.id;
            const badge = t.id === 'settings-hub' && onlineAdmissionOn ? onlineRequests.length : 0;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setCurrentPage(t.id)}
                className="relative flex flex-col items-center justify-center gap-0.5 py-2 active:bg-gray-50"
                aria-current={active ? 'page' : undefined}
              >
                <span className={`relative flex items-center justify-center h-7 w-14 rounded-full transition-colors ${active ? 'bg-orange-100 text-orange-600' : 'text-gray-500'}`}>
                  <Icon className="w-5 h-5" />
                  {badge > 0 && <span className="absolute -top-0.5 right-2 min-w-4 h-4 px-1 rounded-full bg-orange-500 text-white text-[10px] flex items-center justify-center">{badge}</span>}
                </span>
                <span className={`text-[11px] leading-none ${active ? 'text-orange-600 font-semibold' : 'text-gray-500'}`}>{t.label}</span>
              </button>
            );
          })}
        </nav>

        {profileDialog}
      </div>
    );
  }

  return (
    <div className="flex h-screen">
      {/* Sidebar */}
      <div className="w-56 shrink-0 h-screen border-r bg-white flex flex-col overflow-hidden">
        {/* Screen ki height ke hisaab se menu items chhote ho jate hain, footer (version / profile / logout) hamesha neeche fix rehta hai */}
        <style>{`
          .sb-nav{display:flex;flex-direction:column;gap:6px}
          .sb-item{padding-top:.75rem;padding-bottom:.75rem}
          .sb-foot{padding:.625rem}
          @media (max-height:900px){.sb-nav{gap:3px}.sb-item{padding-top:.5rem;padding-bottom:.5rem}}
          @media (max-height:780px){.sb-nav{gap:2px}.sb-item{padding-top:.375rem;padding-bottom:.375rem;font-size:.8125rem}.sb-foot{padding:.375rem}.sb-foot button{height:1.75rem}.sb-foot .sb-ver{padding-bottom:.25rem}}
        `}</style>
        <div className="shrink-0" style={{ backgroundColor: 'var(--brand)', padding: '14px 16px' }}>
          {/* Logo set hai to chota logo naam ke bagal mein; logo nahi hai to naam pehle ki tarah center mein */}
          <div className="flex items-center justify-center gap-2">
            {businessLogo && (
              <img
                src={businessLogo}
                alt="Studio logo"
                className="w-7 h-7 rounded-md bg-white object-contain flex-shrink-0"
              />
            )}
            <h2 className={`text-white ${businessLogo ? 'text-left leading-tight' : 'text-center'}`}>{businessName}</h2>
          </div>
        </div>
        
        <nav className="sb-nav flex-1 min-h-0 overflow-y-auto scrollbar-hidden p-2">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentPage(item.id)}
                className={`sb-item w-full shrink-0 flex items-center gap-2.5 px-3 text-sm rounded-lg transition-colors ${
                  currentPage === item.id || (item.id === 'attendance' && currentPage === 'daily-attendance')
                    ? 'bg-orange-100 text-orange-600'
                    : 'hover:bg-gray-100'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="flex-1 text-left">{item.label}</span>
                {!!item.badge && item.badge > 0 && (
                  <span className="min-w-5 h-5 px-1.5 rounded-full bg-orange-500 text-white text-xs flex items-center justify-center">{item.badge}</span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="sb-foot shrink-0 border-t space-y-1.5 bg-white">
          <div className="sb-ver text-center text-xs text-gray-600 pb-1.5 border-b">
            <div>Version {appVersion}</div>
            <div className="text-xs text-gray-500 mt-1">
              50,000+ Students Capacity
            </div>
          </div>
          <Button
            onClick={() => window.location.reload()}
            variant="outline"
            size="sm"
            className="w-full"
          >
            <RefreshCw className="w-4 h-4 mr-2" />
            Reload App
          </Button>
          <Button
            onClick={() => setShowProfile(true)}
            variant="outline"
            size="sm"
            className="w-full"
          >
            <UserCircle className="w-4 h-4 mr-2" />
            My Profile
          </Button>
          <Button 
            onClick={onLogout} 
            variant="outline" 
            size="sm"
            className="w-full"
          >
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {profileDialog}

      {/* Main Content */}
      <div className="flex-1 overflow-auto scrollbar-hidden" style={{ backgroundColor: 'var(--app-bg)' }}>
        {pageContent}
      </div>
    </div>
  );
}
