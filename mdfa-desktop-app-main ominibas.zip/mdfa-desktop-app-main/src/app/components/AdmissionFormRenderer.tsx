import { ReactNode } from 'react';
import { Upload } from 'lucide-react';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { FormFieldLayout, isInLockedBlock, widthClass } from '../lib/formLayout';

// Draws the admission form from the saved layout (Settings -> Admission Form Layout).
//  - "Free" fields (everything the owner can arrange) are drawn in one 6-column grid, in layout order.
//  - The fixed bottom block (Category ... Payment Mode) is drawn exactly like the old form and can't be changed.
// The parent keeps all state & save logic; this component only draws and reports changes.

export interface CategoryBlockProps {
  categories: any[];
  selectedCategory: string;
  selectedSubCategory: string;
  availableSubCategories: string[];
  filteredBatches: any[];
  locations: any[];
  onCategoryChange: (value: string) => void;
  onSubCategoryChange: (value: string) => void;
}

interface AdmissionFormRendererProps {
  fields: FormFieldLayout[];                       // resolved layout (see resolveFields)
  formData: any;
  onChange: (patch: Record<string, any>) => void;  // patch for top-level formData keys
  onCustomChange: (id: string, value: string) => void; // for formData.customFields[id]
  onAttachPhoto: () => void;
  block: CategoryBlockProps;
  extraChargesSlot?: ReactNode;                    // drawn between the Duration row and the Payment row
}

const PLACEHOLDERS: Record<string, string> = {
  name: 'Enter student name',
  gender: 'Select gender',
  mobile: '10-digit mobile number',
  alternateMobile: '10-digit mobile number',
  aadhaarNumber: '12-digit Aadhaar number',
  guardianName: 'Enter guardian name',
  guardianRelation: 'Select relation',
  learnedBefore: 'Select option',
  address: 'Enter address',
};

const TEXTAREA_CLASS =
  'flex w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-xs min-h-16';

export function AdmissionFormRenderer({
  fields, formData, onChange, onCustomChange, onAttachPhoto, block, extraChargesSlot,
}: AdmissionFormRendererProps) {
  const free = fields.filter((f) => f.visible && !isInLockedBlock(f.id));

  const getVal = (f: FormFieldLayout): string => {
    const v = f.kind === 'core' ? formData[f.id] : formData.customFields?.[f.id];
    return v === undefined || v === null ? '' : String(v);
  };
  const setVal = (f: FormFieldLayout, v: string) => {
    if (f.kind === 'core') onChange({ [f.id]: v });
    else onCustomChange(f.id, v);
  };

  const labelEl = (f: FormFieldLayout) => <Label>{f.label}{f.required ? ' *' : ''}</Label>;

  const renderControl = (f: FormFieldLayout) => {
    const value = getVal(f);
    const placeholder = PLACEHOLDERS[f.id];

    if (f.id === 'regNo') return <Input value={formData.regNo || ''} disabled />;

    if (f.type === 'photo') {
      return (
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onAttachPhoto}
            className="cursor-pointer flex items-center gap-2 px-4 py-2 border rounded-md hover:bg-gray-50"
          >
            <Upload className="w-4 h-4" />
            <span>{formData.photo ? 'Change Photo' : 'Attach Photo'}</span>
          </button>
          {formData.photo && (
            <img src={formData.photo} alt="Preview" className="w-10 h-10 rounded-full object-cover" />
          )}
        </div>
      );
    }

    if (f.type === 'select' || f.type === 'yesno') {
      const options = f.type === 'yesno' ? ['Yes', 'No'] : f.options || [];
      return (
        <Select value={value} onValueChange={(v) => setVal(f, v)}>
          <SelectTrigger>
            <SelectValue placeholder={placeholder || `Select ${f.label}`} />
          </SelectTrigger>
          <SelectContent>
            {options.map((opt) => (
              <SelectItem key={opt} value={opt}>{opt}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    if (f.type === 'textarea') {
      return (
        <textarea
          className={TEXTAREA_CLASS}
          value={value}
          onChange={(e) => setVal(f, e.target.value)}
          placeholder={`Enter ${f.label}`}
        />
      );
    }

    if (f.type === 'phone') {
      return (
        <Input
          type="tel"
          value={value}
          onChange={(e) => setVal(f, e.target.value.replace(/\D/g, '').slice(0, 10))}
          placeholder={placeholder || '10-digit mobile number'}
          maxLength={10}
          required={f.required}
        />
      );
    }

    if (f.id === 'aadhaarNumber') {
      return (
        <>
          <Input
            value={value}
            onChange={(e) => setVal(f, e.target.value.replace(/\D/g, '').slice(0, 12))}
            placeholder={placeholder}
            maxLength={12}
            required={f.required}
          />
          {value.length > 0 && value.length < 12 && (
            <p className="text-xs text-red-600 mt-1">Aadhaar must be 12 digits</p>
          )}
        </>
      );
    }

    const inputType = f.type === 'number' ? 'number' : f.type === 'date' ? 'date' : f.type === 'email' ? 'email' : 'text';
    const fallbackPlaceholder =
      f.id === 'email' ? (f.required ? 'Enter email' : 'Enter email (optional)') : `Enter ${f.label}`;
    return (
      <Input
        type={inputType}
        value={value}
        onChange={(e) => setVal(f, e.target.value)}
        placeholder={placeholder || fallbackPlaceholder}
        required={f.required}
      />
    );
  };

  // ---- free (owner-arranged) fields ----
  const freeNodes: ReactNode[] = [];
  let lastGroup: string | undefined;
  free.forEach((f) => {
    if (f.group && f.group !== lastGroup) {
      freeNodes.push(
        <p key={`group-${f.id}`} className="text-sm text-gray-500 md:col-span-6 -mb-3">{f.group}</p>
      );
    }
    lastGroup = f.group;
    freeNodes.push(
      <div key={f.id} className={widthClass(f.width)}>
        {labelEl(f)}
        {renderControl(f)}
      </div>
    );
  });

  // ---- fixed block (same look as the old form) ----
  const lockedLabel = (id: string) => {
    const f = fields.find((x) => x.id === id);
    return <Label>{f?.label}{f?.required ? ' *' : ''}</Label>;
  };

  return (
    <>
      <div className="grid grid-cols-1 md:grid-cols-6 gap-x-4 gap-y-6">{freeNodes}</div>

      {/* Category, Sub-Category, Batch Time */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          {lockedLabel('category')}
          <Select value={block.selectedCategory} onValueChange={block.onCategoryChange}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {block.categories.length > 0 ? (
                block.categories.map((category: any) => (
                  <SelectItem key={category.id} value={category.name}>{category.name}</SelectItem>
                ))
              ) : (
                <SelectItem value="no-categories" disabled>No categories available</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>

        <div>
          {lockedLabel('subCategory')}
          <Select
            value={block.selectedSubCategory}
            onValueChange={block.onSubCategoryChange}
            disabled={!block.selectedCategory || block.availableSubCategories.length === 0}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select sub-category" />
            </SelectTrigger>
            <SelectContent>
              {block.availableSubCategories.length > 0 ? (
                block.availableSubCategories.map((subCat: string, idx: number) => (
                  <SelectItem key={idx} value={subCat}>{subCat}</SelectItem>
                ))
              ) : (
                <SelectItem value="no-subcategories" disabled>Select category first</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>

        <div>
          {lockedLabel('batchTime')}
          <Select
            value={formData.batchTime}
            onValueChange={(value) => onChange({ batchTime: value })}
            disabled={!block.selectedSubCategory || block.filteredBatches.length === 0}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select batch time" />
            </SelectTrigger>
            <SelectContent>
              {block.filteredBatches.length > 0 ? (
                block.filteredBatches.map((batch: any) => (
                  <SelectItem key={batch.batchTime} value={batch.batchTime}>
                    {batch.batchTime} - {batch.batchName}
                  </SelectItem>
                ))
              ) : (
                <SelectItem value="no-batch" disabled>
                  {block.selectedSubCategory ? 'No batches for this sub-category' : 'Select sub-category first'}
                </SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Location */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          {lockedLabel('location')}
          <Select value={formData.location} onValueChange={(value) => onChange({ location: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select location" />
            </SelectTrigger>
            <SelectContent>
              {block.locations.length > 0 ? (
                block.locations.map((location: any) => (
                  <SelectItem key={location.name} value={location.name}>{location.name}</SelectItem>
                ))
              ) : (
                <SelectItem value="no-location" disabled>No locations available</SelectItem>
              )}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Duration */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          {lockedLabel('duration')}
          <Input
            type="number"
            value={formData.duration}
            onChange={(e) => onChange({ duration: e.target.value })}
            placeholder="Enter duration"
            min="1"
            required
          />
        </div>
        <div>
          {lockedLabel('durationType')}
          <Select value={formData.durationType} onValueChange={(value) => onChange({ durationType: value })}>
            <SelectTrigger>
              <SelectValue placeholder="Select duration type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Days">Days</SelectItem>
              <SelectItem value="Month">Month</SelectItem>
              <SelectItem value="Year">Year</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div>
          {lockedLabel('expiryDate')}
          <Input type="date" value={formData.expiryDate} disabled />
        </div>
      </div>

      {extraChargesSlot}

      {/* Payment Information */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div>
          {lockedLabel('totalAmount')}
          <div className="relative">
            <span className="absolute left-3 top-2.5">₹</span>
            <Input
              type="number"
              value={formData.totalAmount}
              onChange={(e) => onChange({ totalAmount: e.target.value })}
              placeholder="0"
              className="pl-8"
              min="0"
              required
            />
          </div>
        </div>
        <div>
          {lockedLabel('paidAmount')}
          <div className="relative">
            <span className="absolute left-3 top-2.5">₹</span>
            <Input
              type="number"
              value={formData.paidAmount}
              onChange={(e) => onChange({ paidAmount: e.target.value })}
              placeholder="0"
              className="pl-8"
              min="0"
              required
            />
          </div>
        </div>
        <div>
          {lockedLabel('dues')}
          <div className="relative">
            <span className="absolute left-3 top-2.5">₹</span>
            <Input type="number" value={formData.dues} disabled className="pl-8" />
          </div>
        </div>
      </div>

      {/* Payment Mode */}
      <div>
        {lockedLabel('paymentMode')}
        <Select value={formData.paymentMode} onValueChange={(value) => onChange({ paymentMode: value })}>
          <SelectTrigger>
            <SelectValue placeholder="Select payment mode" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="Cash">Cash</SelectItem>
            <SelectItem value="Online">Online</SelectItem>
          </SelectContent>
        </Select>
      </div>
    </>
  );
}
