import { useEffect, useState } from 'react';
import { Globe, Copy, Download, ExternalLink, RefreshCw, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { qrToDataUrl } from '../lib/qr';
import { isAttendanceConnected } from '../lib/attendance';
import {
  getOnlineAdmissionEnabled,
  getOnlineAdmissionLink,
  onlineAdmissionError,
  pushOnlineAdmissionConfig,
  setOnlineAdmissionEnabled,
} from '../lib/onlineAdmission';

// Settings -> Online Admission
// Ek toggle. ON karte hi sidebar me "Online Admission" section aa jata hai (Admission Form ke just niche)
// aur student QR / link se form bhar sakte hain. OFF karte hi form band ho jata hai.
export function OnlineAdmissionSettings() {
  const [enabled, setEnabled] = useState(false);
  const [connected, setConnected] = useState(true);
  const [link, setLink] = useState('');
  const [qr, setQr] = useState('');
  const [busy, setBusy] = useState(false);
  const [problem, setProblem] = useState('');
  const [loaded, setLoaded] = useState(false);

  const load = async () => {
    const [on, conn, l] = await Promise.all([getOnlineAdmissionEnabled(), isAttendanceConnected(), getOnlineAdmissionLink()]);
    setEnabled(on); setConnected(conn); setLink(l);
    setQr(l ? qrToDataUrl(l, 700) : '');
    setLoaded(true);
  };
  useEffect(() => { load(); }, []);

  const toggle = async (on: boolean) => {
    setBusy(true);
    setEnabled(on);
    const r = await setOnlineAdmissionEnabled(on);
    setBusy(false);
    if (r.error) {
      setProblem(r.error);
      toast.error(on ? 'Online Admission ON ho gaya, par Google Sheet ko abhi nahi bataya ja saka' : 'OFF ho gaya, par Google Sheet ko abhi nahi bataya ja saka');
    } else {
      setProblem('');
      toast.success(on ? 'Online Admission ON ho gaya. Sidebar me section aa gaya.' : 'Online Admission OFF ho gaya.');
    }
  };

  const resync = async () => {
    setBusy(true);
    try {
      await pushOnlineAdmissionConfig(true);
      setProblem('');
      toast.success('Form Google Sheet me update ho gaya');
    } catch (e: any) {
      setProblem(onlineAdmissionError(e));
      toast.error('Update nahi hua');
    } finally { setBusy(false); }
  };

  const copyLink = async () => {
    try { await navigator.clipboard.writeText(link); toast.success('Link copy ho gaya'); }
    catch { toast.error('Copy nahi hua'); }
  };

  const downloadQr = () => {
    const a = document.createElement('a');
    a.href = qr; a.download = 'online-admission-qr.png'; a.click();
  };

  if (!loaded) return <p className="text-sm text-gray-500">Loading...</p>;

  return (
    <div className="space-y-6">
      <Card className="p-4 bg-gradient-to-r from-orange-50 to-yellow-50 rounded-lg border-2 border-orange-200">
        <h3 className="flex items-center gap-2 mb-2"><Globe className="w-5 h-5 text-orange-600" /> Online Admission Form</h3>
        <p className="text-sm text-gray-600">
          Turn ON to add <strong>Online Admission</strong> in the sidebar. Students fill the form via QR / link, you <strong>Approve</strong> it, and the Admission Form opens pre-filled.
        </p>
      </Card>

      <div className="bg-white rounded-lg border p-4 flex items-center justify-between gap-4">
        <div>
          <p className="font-medium">Online Admission Form</p>
          <p className="text-sm text-gray-500">{enabled ? 'ON — students online form bhar sakte hain' : 'OFF — form band hai'}</p>
        </div>
        <Switch checked={enabled} onCheckedChange={toggle} disabled={busy} />
      </div>

      {!connected && (
        <div className="flex gap-2 rounded-lg border border-amber-300 bg-amber-50 p-3 text-sm text-amber-900">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>Setup: <strong>Settings → Management & Setup → Attendance Setup</strong> me system connect karein. Isi se sabhi modules chalte hain: Events, QR Enquiry, Online Admission, Attendance.</span>
        </div>
      )}

      {problem && (
        <div className="flex gap-2 rounded-lg border border-red-300 bg-red-50 p-3 text-sm text-red-800">
          <AlertTriangle className="w-4 h-4 mt-0.5 shrink-0" />
          <span>{problem}</span>
        </div>
      )}

      {enabled && connected && link && (
        <div className="bg-white rounded-lg border p-4 space-y-4">
          <h4 className="flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-600" /> Student ko ye link / QR dein</h4>
          <div className="flex flex-col md:flex-row gap-4 items-start">
            {qr && <img src={qr} alt="Online admission QR" className="w-44 h-44 border rounded-lg" />}
            <div className="flex-1 min-w-0 space-y-3">
              <div className="text-xs font-mono break-all rounded-md bg-gray-50 border p-2">{link}</div>
              <div className="flex flex-wrap gap-2">
                <Button size="sm" variant="outline" onClick={copyLink}><Copy className="w-4 h-4 mr-1" /> Link copy</Button>
                <Button size="sm" variant="outline" onClick={downloadQr}><Download className="w-4 h-4 mr-1" /> QR download</Button>
                <Button size="sm" variant="outline" onClick={() => window.open(link, '_blank')}><ExternalLink className="w-4 h-4 mr-1" /> Form dekhein</Button>
                <Button size="sm" variant="outline" onClick={resync} disabled={busy}><RefreshCw className={`w-4 h-4 mr-1 ${busy ? 'animate-spin' : ''}`} /> Form update karein</Button>
              </div>
              <p className="text-xs text-gray-500">
                Admission Form Layout, Category, Batch ya Location badalne par form apne aap update ho jata hai.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
