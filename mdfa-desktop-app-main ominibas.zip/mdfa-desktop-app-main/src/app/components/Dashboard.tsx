import { useState, useEffect, type ReactNode } from 'react';
import { getDashboardLayout, DashSectionId } from '../lib/theme';
import { getStoredLicenseData, parseLicenseDate, extractExpiryDate, isLifetimeLicense, validateLicenseFromGoogleSheet, getStoredLicenseKey } from '../lib/googleSheetLicense';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Users, IndianRupee, Wallet, Hourglass, UserX, Calendar, Clock, MapPin, AlertTriangle, Phone, Gift, CheckCircle2, Circle, GraduationCap, MessageCircle, Sun, Sunset, Moon, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { getStudents, getPayments, getBatches, getLocations, getTeachers } from '../lib/storageAdapter';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { buildDuesMessage, buildExpiryMessage, buildExpiredMessage } from '../lib/reminderMessages';
import { EnquiriesOverview } from './EnquiriesOverview';
import { DashboardAttendance } from './DashboardAttendance';
import { batchSortKey, batchStatus } from '../lib/batchTime';

// Time-based greeting: Morning (till 11:59), Afternoon (12:00-16:59), Evening (17:00 onwards)
function getGreeting(date: Date) {
  const h = date.getHours();
  if (h < 12) return { text: 'Good Morning', Icon: Sun, color: 'text-orange-500' };
  if (h < 17) return { text: 'Good Afternoon', Icon: Sun, color: 'text-amber-500' };
  if (h < 21) return { text: 'Good Evening', Icon: Sunset, color: 'text-orange-600' };
  return { text: 'Good Evening', Icon: Moon, color: 'text-indigo-500' };
}

// Module-level flag: Dashboard remount hone par (kisi section se wapas aane par) reset nahi hota.
// Sirf app reload / close karke dubara open karne par hi reset hoga -> popup app-open par ek hi baar dikhega.
let lastDayPopupShownThisSession = false;

// Live clock for the dashboard header (updates every second; only this tiny component re-renders)
function LiveClock() {
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 1000); return () => clearInterval(t); }, []);
  const time = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  return (
    <div className="flex items-center gap-2 px-3 py-2 border rounded-lg bg-white tabular-nums text-sm font-medium" title="Abhi ka samay">
      <Clock className="w-4 h-4 text-gray-500" /> {time}
    </div>
  );
}

export function Dashboard({ onNavigate }: { onNavigate?: (page: string) => void } = {}) {
  const { businessName } = useBusinessName();
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 60 * 1000); // keep greeting in sync with the clock
    return () => clearInterval(t);
  }, []);
  const greeting = getGreeting(now);
  const [students, setStudents] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const { selectedLocation, setSelectedLocation } = useLocationFilter();
  const [todayIncome, setTodayIncome] = useState(0);
  const [totalDues, setTotalDues] = useState(0);
  const [expiringSoon, setExpiringSoon] = useState<any[]>([]);
  const [expiredStudents, setExpiredStudents] = useState<any[]>([]);
  const [showStudentList, setShowStudentList] = useState(false);
  const [showIncomeReport, setShowIncomeReport] = useState(false);
  const [showDuesReport, setShowDuesReport] = useState(false);
  const [showExpiryReport, setShowExpiryReport] = useState(false);
  const [showExpiredReport, setShowExpiredReport] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date().toLocaleDateString('en-CA'));
  const [todayPayments, setTodayPayments] = useState<any[]>([]);
  const [liveBatches, setLiveBatches] = useState<any[]>([]);
  // null = not known yet; 0 = expires today; negative = already expired
  const [licenseDaysLeft, setLicenseDaysLeft] = useState<number | null>(null);
  const [licenseLifetime, setLicenseLifetime] = useState(false);
  const [licensePlan, setLicensePlan] = useState<string>('');
  const [showLastDayPopup, setShowLastDayPopup] = useState(false);
  const [selectedBatch, setSelectedBatch] = useState<any>(null);
  const [showBatchStudents, setShowBatchStudents] = useState(false);
  const [showAllBatches, setShowAllBatches] = useState(false); // "View All" of Today's Batch Activity (stays on the dashboard)
  const [batchStudentSearch, setBatchStudentSearch] = useState('');
  const [reportSearch, setReportSearch] = useState(''); // search bar for Dues / Expiry Soon / Expired dialogs
  const matchesReportSearch = (s: any) => {
    const q = reportSearch.trim().toLowerCase();
    if (!q) return true;
    return (
      String(s.regNo || '').toLowerCase().includes(q) ||
      String(s.name || '').toLowerCase().includes(q) ||
      String(s.mobile || '').toLowerCase().includes(q) ||
      String(s.alternateMobile || '').toLowerCase().includes(q) ||
      String(s.email || '').toLowerCase().includes(q) ||
      String(s.guardianName || '').toLowerCase().includes(q)
    );
  };
  const [allStudentsData, setAllStudentsData] = useState<any[]>([]);
  const [allPaymentsData, setAllPaymentsData] = useState<any[]>([]);

  useEffect(() => {
    loadDashboardData();
    // License validity: pehle saved data se turant dikhao, phir Google Sheet se fresh data aate hi update karo.
    // (Fresh response me expiry na ho — jaise EXPIRED/network error — to saved data hi dikhta rehta hai.)
    // Whole calendar days left (expiry day itself = 0, so the last day still shows a warning)
    const daysFromExpiry = (expiryStr: string): number | null => {
      const exp = parseLicenseDate(expiryStr);
      if (!exp) return null;
      const startExp = new Date(exp.getFullYear(), exp.getMonth(), exp.getDate()).getTime();
      const now = new Date();
      const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
      return Math.round((startExp - startToday) / 86400000);
    };
    // Returns true when this data had a usable expiry (and was applied)
    const applyLicense = (data: any): boolean => {
      if (!data) return false;
      const lifetime = isLifetimeLicense(data);
      const expiryDateStr = extractExpiryDate(data);
      const days = expiryDateStr ? daysFromExpiry(expiryDateStr) : null;
      if (!lifetime && days === null) return false;
      const isDemo = (data?.plan || '').toLowerCase() === 'demo';
      setLicensePlan(isDemo ? 'demo' : (data?.plan || ''));
      setLicenseLifetime(lifetime);
      if (days !== null) {
        setLicenseDaysLeft(days);
        // Demo licenses never show the "last day" lock warning popup (shown once per visit to the dashboard)
        if (!lifetime && !isDemo && days >= 0 && days <= 1 && !lastDayPopupShownThisSession) {
          lastDayPopupShownThisSession = true;
          setShowLastDayPopup(true);
        }
      }
      return true;
    };
    // Fresh data from the sheet is the source of truth. Saved data is used only as a
    // fallback when the fresh check fails (offline) — so a stale "Lifetime" never flashes first.
    const storedKey = getStoredLicenseKey();
    if (storedKey) {
      validateLicenseFromGoogleSheet(storedKey)
        .then((freshData) => { if (!applyLicense(freshData)) applyLicense(getStoredLicenseData()); })
        .catch(() => { applyLicense(getStoredLicenseData()); });
    } else {
      applyLicense(getStoredLicenseData());
    }
  }, [selectedDate]);

  const loadDashboardData = async () => {
    const studentsData = await getStudents();
    const paymentsData = await getPayments();
    const batchesData = await getBatches();
    const locationsData = await getLocations();
    const teachersData = await getTeachers();

    setAllStudentsData(studentsData);
    setAllPaymentsData(paymentsData);
    setLocations(locationsData);

    computeStats(studentsData, paymentsData, batchesData, locationsData, teachersData, selectedLocation);
  };

  const computeStats = (studentsData: any[], paymentsData: any[], batchesData: any[], locationsData: any[], teachersData: any[], locFilter: string) => {
    const filtered = locFilter === 'all' ? studentsData : studentsData.filter((s: any) => s.location === locFilter);
    const filteredPayments = locFilter === 'all' ? paymentsData : paymentsData.filter((p: any) => {
      const student = studentsData.find((s: any) => s.regNo === p.regNo);
      return student?.location === locFilter;
    });

    setStudents(filtered);
    setPayments(filteredPayments);

    const today = new Date(selectedDate).toDateString();
    const todayPaymentsList = filteredPayments.filter((p: any) => new Date(p.paymentDate).toDateString() === today);
    const todayAdmissions = filtered.filter((s: any) => new Date(s.admissionDate).toDateString() === today);

    let income = 0;
    todayPaymentsList.forEach((p: any) => { const a = parseFloat(p.paidAmount); if (!isNaN(a)) income += a; });
    todayAdmissions.forEach((s: any) => { const a = parseFloat(s.paidAmount); if (!isNaN(a)) income += a; });
    setTodayIncome(income);

    setTodayPayments([
      ...todayPaymentsList.map((p: any) => {
        const student = studentsData.find((s: any) => s.regNo === p.regNo);
        return { type: 'Fees Payment', name: p.name, regNo: p.regNo, amount: p.paidAmount, date: p.paymentDate, paymentMode: p.paymentMode, location: student?.location || 'N/A' };
      }),
      ...todayAdmissions.map((s: any) => ({ type: 'Admission', name: s.name, regNo: s.regNo, amount: s.paidAmount, date: s.admissionDate, paymentMode: s.paymentMode, location: s.location || 'N/A' }))
    ]);

    let dues = 0;
    filtered.forEach((s: any) => { const a = parseFloat(s.dues); if (!isNaN(a)) dues += a; });
    setTotalDues(dues);

    const fiveDaysFromNow = new Date();
    fiveDaysFromNow.setDate(fiveDaysFromNow.getDate() + 5);
    setExpiringSoon(filtered.filter((s: any) => { const e = new Date(s.expiryDate); const t = new Date(); return e >= t && e <= fiveDaysFromNow; }));
    setExpiredStudents(filtered.filter((s: any) => new Date(s.expiryDate) < new Date()));

    const currentTime = new Date();
    const currentHour = currentTime.getHours();
    const currentMinute = currentTime.getMinutes();
    const dayNames = ['sunday','monday','tuesday','wednesday','thursday','friday','saturday'];
    const currentDay = dayNames[currentTime.getDay()];

    const filteredBatches = locFilter === 'all' ? batchesData : batchesData.filter((b: any) => b.location === locFilter);

    const live = filteredBatches.filter((batch: any) => {
      // Show all batches scheduled for today's day (show all day)
      if (!batch.weeklySchedule || batch.weeklySchedule.length === 0) return true;
      return batch.weeklySchedule.includes(currentDay);
    }).map((batch: any) => {
      const batchStudents = filtered.filter((s: any) => s.batchTime === batch.batchTime);
      return { ...batch, students: batchStudents, teachers: teachersData.filter((t: any) => t.location === batch.location) };
    });

    setLiveBatches(live);
  };

  const handleLocationChange = (loc: string) => {
    // Stored globally — every other section reads the same value.
    setSelectedLocation(loc);
  };

  // Re-compute the cards whenever the globally selected location changes.
  useEffect(() => {
    if (allStudentsData.length === 0 && allPaymentsData.length === 0) return;
    (async () => {
      const batchesData = await getBatches();
      const locationsData = await getLocations();
      const teachersData = await getTeachers();
      computeStats(allStudentsData, allPaymentsData, batchesData, locationsData, teachersData, selectedLocation);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedLocation]);

  const parseTime = (timeStr: string) => {
    const trimmed = timeStr.trim().toUpperCase();
    const match = trimmed.match(/(\d+):(\d+)\s*(AM|PM)?/);
    if (!match) return 0;
    let hours = parseInt(match[1]);
    const minutes = parseInt(match[2]);
    const period = match[3];
    if (period === 'PM' && hours !== 12) hours += 12;
    if (period === 'AM' && hours === 12) hours = 0;
    return hours * 60 + minutes;
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  // Sends a WhatsApp reminder built from the admin's saved template for
  // this category. The Business Name signature is always appended
  // automatically inside buildXMessage() — it is never editable here.
  const handleSendReminder = async (student: any, type: 'dues' | 'expiry' | 'expired') => {
    if (!student.mobile) return;
    let message = '';
    if (type === 'dues') message = await buildDuesMessage(student, businessName);
    else if (type === 'expiry') message = await buildExpiryMessage(student, businessName, formatDate);
    else message = await buildExpiredMessage(student, businessName, formatDate);
    window.open(`https://wa.me/91${student.mobile}?text=${encodeURIComponent(message)}`, '_blank');
  };

  // Today's batches: running ones first, then upcoming, then finished (each group in time order)
  const statusOrder: Record<string, number> = { live: 0, today: 1, upcoming: 2, closed: 3 };
  const sortedBatches = liveBatches
    .map((batch) => ({ batch, st: batchStatus(batch.batchTime, now) }))
    .sort((a, b) => statusOrder[a.st] - statusOrder[b.st] || batchSortKey(a.batch.batchTime) - batchSortKey(b.batch.batchTime));

  const renderBatchTile = (batch: any, st: string) => {
    const badge =
      st === 'live' ? { text: 'Running', cls: 'bg-green-100 text-green-700', dot: true }
      : st === 'upcoming' ? { text: 'Upcoming', cls: 'bg-blue-100 text-blue-700', dot: false }
      : st === 'closed' ? { text: 'Closed', cls: 'bg-gray-100 text-gray-600', dot: false }
      : { text: 'Today', cls: 'bg-blue-100 text-blue-700', dot: false };
    return (
      <div
        className={`h-full rounded-lg border bg-white p-3 cursor-pointer hover:shadow-md transition-shadow ${st === 'live' ? 'border-green-300' : ''}`}
        onClick={() => { setSelectedBatch(batch); setBatchStudentSearch(''); setShowBatchStudents(true); }}
      >
        <p className="font-semibold text-sm truncate">{batch.batchName || batch.batchTime}</p>
        <p className="text-xs text-gray-500 truncate flex items-center gap-1"><Clock className="w-3 h-3 shrink-0" />{batch.batchTime}</p>
        <div className="flex items-center justify-between mt-2">
          <span className="text-xs text-gray-700 flex items-center gap-1"><Users className="w-3.5 h-3.5" />{batch.students.length} Students</span>
          <span className={`px-2 py-0.5 rounded-full text-[11px] font-semibold flex items-center gap-1 ${badge.cls}`}>
            {badge.dot && <Circle className="w-2 h-2 fill-current animate-pulse" />}{badge.text}
          </span>
        </div>
      </div>
    );
  };

  // Which dashboard sections show, and in what order (Settings > Theme)
  const [dashLayout] = useState(getDashboardLayout);
  const sectionNodes: Record<DashSectionId, ReactNode> = {
    stats: (
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-5 gap-3 shrink-0">
        <Card className="cursor-pointer hover:shadow-lg transition-shadow gap-1 px-4 py-3" onClick={() => setShowStudentList(true)}>
          <div className="flex items-center justify-between"><h4 className="text-sm leading-none">Total Students</h4><Users className="h-4 w-4 text-muted-foreground" /></div>
          <div className="text-2xl leading-tight">{students.length}</div>
          {selectedLocation !== 'all' && <p className="text-xs text-gray-500 flex items-center gap-1"><MapPin className="w-3 h-3" /> {selectedLocation}</p>}
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow gap-1 px-4 py-3" onClick={() => setShowIncomeReport(true)}>
          <div className="flex items-center justify-between"><h4 className="text-sm leading-none">Today's Income</h4><IndianRupee className="h-4 w-4 text-muted-foreground" /></div>
          <div className="text-2xl leading-tight">₹{todayIncome.toFixed(2)}</div>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow gap-1 px-4 py-3" onClick={() => { setReportSearch(''); setShowDuesReport(true); }}>
          <div className="flex items-center justify-between"><h4 className="text-sm leading-none">Total Dues</h4><Wallet className="h-4 w-4 text-muted-foreground" /></div>
          <div className="text-2xl leading-tight text-orange-600">₹{totalDues.toFixed(2)}</div>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow gap-1 px-4 py-3" onClick={() => { setReportSearch(''); setShowExpiryReport(true); }}>
          <div className="flex items-center justify-between"><h4 className="text-sm leading-none">Expiry Soon</h4><Hourglass className="h-4 w-4 text-muted-foreground" /></div>
          <div className="text-2xl leading-tight text-red-600">{expiringSoon.length}</div>
        </Card>

        <Card className="cursor-pointer hover:shadow-lg transition-shadow gap-1 px-4 py-3" onClick={() => { setReportSearch(''); setShowExpiredReport(true); }}>
          <div className="flex items-center justify-between"><h4 className="text-sm leading-none">Expired Students</h4><UserX className="h-4 w-4 text-muted-foreground" /></div>
          <div className="text-2xl leading-tight text-red-600">{expiredStudents.length}</div>
        </Card>
      </div>
    ),
    attendance: <DashboardAttendance date={selectedDate} onViewAll={() => onNavigate?.('daily-attendance')} onViewReport={() => onNavigate?.('reports')} />,
    enquiry: <EnquiriesOverview compact date={selectedDate} onViewAll={() => onNavigate?.('enquiry')} />,
    batch: (
      <Card className="shrink-0 gap-2 p-4">
        <div className="flex items-center justify-between">
          <h4 className="flex items-center gap-2 leading-none">
            <span className="w-8 h-8 rounded-lg bg-orange-100 flex items-center justify-center"><Clock className="w-5 h-5 text-orange-600" /></span>
            Today's Batch Activity
            <span className="text-xs font-normal text-gray-500">({sortedBatches.length} batches)</span>
          </h4>
          {sortedBatches.length > 0 && (
            <button type="button" onClick={() => setShowAllBatches(true)} className="text-sm text-blue-600 hover:underline flex items-center gap-1">
              View All <ArrowRight className="w-4 h-4" />
            </button>
          )}
        </div>
        {sortedBatches.length > 0 ? (
          <div className="flex gap-3 overflow-x-auto pb-1">
            {sortedBatches.map(({ batch, st }, index) => (
              <div key={index} className="w-[210px] shrink-0">{renderBatchTile(batch, st)}</div>
            ))}
          </div>
        ) : (
          <p className="text-center text-gray-500 py-3">No batches scheduled for today</p>
        )}
      </Card>
    ),
  };
  const visibleSections = dashLayout.order.filter((id) => !dashLayout.hidden.includes(id));
  const sectionOutput: ReactNode[] = [];
  for (let i = 0; i < visibleSections.length; i++) {
    const id = visibleSections[i];
    const next = visibleSections[i + 1];
    // Attendance + Enquiry placed one after the other sit side by side (like before); otherwise each is full width
    if ((id === 'attendance' && next === 'enquiry') || (id === 'enquiry' && next === 'attendance')) {
      sectionOutput.push(
        <div key={`${id}-${next}`} className={`grid grid-cols-1 ${id === 'attendance' ? 'lg:grid-cols-[1.25fr_1fr]' : 'lg:grid-cols-[1fr_1.25fr]'} gap-3 flex-1 min-h-0`}>
          {sectionNodes[id]}
          {sectionNodes[next]}
        </div>
      );
      i++;
    } else if (id === 'attendance' || id === 'enquiry') {
      sectionOutput.push(<div key={id} className="grid grid-cols-1 gap-3 flex-1 min-h-0">{sectionNodes[id]}</div>);
    } else {
      sectionOutput.push(<div key={id} className="shrink-0">{sectionNodes[id]}</div>);
    }
  }

  return (
    <div className="h-screen flex flex-col gap-3 p-4 overflow-hidden">

      {/* Last Day Popup */}
      {showLastDayPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-xl shadow-2xl p-6 max-w-sm w-full mx-4 border-4 border-red-500">
            <div className="text-center">
              <div className="flex justify-center mb-2"><AlertTriangle className="w-12 h-12 text-red-600" /></div>
              <h2 className="text-xl font-bold text-red-600 mb-2">Your plan expires today</h2>
              <p className="text-gray-700 mb-4 text-sm">
                Renewal: <strong>7323053397</strong> - Contact service provider
              </p>
              <button onClick={() => setShowLastDayPopup(false)} className="px-6 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold">OK</button>
            </div>
          </div>
        </div>
      )}

      {/* Plan expiry warning (last 2 days) - Demo licenses never show this */}
      {licensePlan !== 'demo' && !licenseLifetime && licenseDaysLeft !== null && licenseDaysLeft <= 2 && (
        <div className="bg-orange-50 border border-orange-400 rounded-lg px-4 py-2 flex items-center gap-2 text-sm text-orange-800 shrink-0">
          <AlertTriangle className="w-4 h-4 text-orange-600 flex-shrink-0" />
          <span>
            <strong>{licenseDaysLeft < 0 ? 'Plan expired.' : licenseDaysLeft === 0 ? 'Plan expires today.' : `Plan expires in ${licenseDaysLeft} day${licenseDaysLeft === 1 ? '' : 's'}.`}</strong>{' '}
            Renewal: <strong>7323053397</strong> - Contact service provider
          </span>
        </div>
      )}

      {/* Header with license + location + date */}
      <div className="flex flex-wrap justify-between items-center gap-3 shrink-0">
        <div className="flex items-center gap-3">
          <greeting.Icon className={`w-8 h-8 flex-shrink-0 ${greeting.color}`} />
          <div>
            <h1 className="leading-tight">{greeting.text}, Admin</h1>
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {/* License Days - topbar */}
          {licensePlan === 'demo' ? (
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold border-2 ${
              licenseDaysLeft !== null && licenseDaysLeft >= 0 && licenseDaysLeft <= 2 ? 'bg-orange-50 border-orange-400 text-orange-700' : 'bg-blue-50 border-blue-400 text-blue-700'
            }`}>
              <Clock className="w-4 h-4" />
              <Gift className="w-4 h-4" /> Demo{licenseDaysLeft !== null && licenseDaysLeft >= 0 ? ` · ${licenseDaysLeft} days remaining` : ''}
              {licenseDaysLeft !== null && licenseDaysLeft >= 0 && licenseDaysLeft <= 2 ? <AlertTriangle className="w-4 h-4 text-orange-600" /> : ''}
            </div>
          ) : licenseLifetime ? (
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold border-2 bg-green-50 border-green-400 text-green-700">
              <CheckCircle2 className="w-4 h-4" /> Lifetime License
            </div>
          ) : licenseDaysLeft !== null && (
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold border-2 ${licenseDaysLeft <= 7 ? 'bg-red-50 border-red-400 text-red-700' : 'bg-green-50 border-green-400 text-green-700'}`}>
              <Clock className="w-4 h-4" />
              {licenseDaysLeft < 0 ? 'License expired' : licenseDaysLeft === 0 ? 'Expires today' : `${licenseDaysLeft} days remaining`} {licenseDaysLeft <= 7 ? <AlertTriangle className="w-4 h-4 text-red-600" /> : <span className="flex items-center gap-1"><CheckCircle2 className="w-4 h-4" /> License Active</span>}
            </div>
          )}
          {/* Location Filter */}
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-gray-500" />
            <Select value={selectedLocation} onValueChange={handleLocationChange}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="All Locations" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                {locations.map((loc: any) => (
                  <SelectItem key={loc.name} value={loc.name}>{loc.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="px-3 py-2 border rounded-lg" />
          </div>
          {/* Live time - corner (location, calendar, then time) */}
          <LiveClock />
        </div>
      </div>

      {/* Dashboard sections — shown / hidden / ordered from Settings > Theme */}
      {sectionOutput}
      {sectionOutput.length === 0 && (
        <p className="text-center text-gray-500 py-10">Saare dashboard sections band hain. Settings → Theme mein jaake chalu karein.</p>
      )}

      {/* View All batches (stays inside the dashboard, does not open the Batches section) */}
      <Dialog open={showAllBatches} onOpenChange={setShowAllBatches}>
        <DialogContent className="w-[95vw] sm:max-w-5xl max-h-[88vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Today's Batch Activity — All Batches ({sortedBatches.length})</DialogTitle></DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {sortedBatches.map(({ batch, st }, index) => (
              <div key={index}>{renderBatchTile(batch, st)}</div>
            ))}
          </div>
        </DialogContent>
      </Dialog>

      {/* Batch Students Popup */}
      <Dialog open={showBatchStudents} onOpenChange={setShowBatchStudents}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{selectedBatch?.batchName || selectedBatch?.batchTime} — Students ({selectedBatch?.students?.length || 0})</DialogTitle>
          </DialogHeader>
          <div className="relative mb-2">
            <input
              type="text"
              placeholder="Search by Reg No, Name, Mobile, Alternate Mobile, Email, or Guardian Name..."
              value={batchStudentSearch}
              onChange={(e) => setBatchStudentSearch(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm"
            />
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reg No</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Mobile</TableHead>
                <TableHead>Batch Time</TableHead>
                <TableHead>Dues</TableHead>
                <TableHead>Expiry Date</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(selectedBatch?.students || [])
                .filter((s: any) => {
                  const q = batchStudentSearch.trim().toLowerCase();
                  if (!q) return true;
                  return (
                    String(s.regNo || '').toLowerCase().includes(q) ||
                    String(s.name || '').toLowerCase().includes(q) ||
                    String(s.mobile || '').toLowerCase().includes(q) ||
                    String(s.alternateMobile || '').toLowerCase().includes(q) ||
                    String(s.email || '').toLowerCase().includes(q) ||
                    String(s.guardianName || '').toLowerCase().includes(q)
                  );
                })
                .map((s: any, i: number) => (
                <TableRow key={i}>
                  <TableCell>{s.regNo}</TableCell>
                  <TableCell>{s.name}</TableCell>
                  <TableCell>{s.mobile}</TableCell>
                  <TableCell>{s.batchTime}</TableCell>
                  <TableCell className={Number(s.dues) > 0 ? 'text-orange-600' : 'text-green-600'}>₹{s.dues || 0}</TableCell>
                  <TableCell className={new Date(s.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>{formatDate(s.expiryDate)}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Student List Dialog */}
      <Dialog open={showStudentList} onOpenChange={setShowStudentList}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>All Students {selectedLocation !== 'all' ? `— ${selectedLocation}` : ''}</DialogTitle></DialogHeader>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead>
                <TableHead>Category</TableHead><TableHead>Location</TableHead><TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((s) => (
                <TableRow key={s.regNo}>
                  <TableCell>{s.regNo}</TableCell><TableCell>{s.name}</TableCell><TableCell>{s.mobile}</TableCell>
                  <TableCell>{s.category}</TableCell><TableCell>{s.location || 'N/A'}</TableCell>
                  <TableCell><span className={s.status === 'active' ? 'text-green-600' : 'text-red-600'}>{s.status}</span></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Income Report */}
      <Dialog open={showIncomeReport} onOpenChange={setShowIncomeReport}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Income Report — {formatDate(selectedDate)}</DialogTitle></DialogHeader>
          <div className="mb-4 p-4 bg-[var(--app-bg)] rounded-lg space-y-1">
            <p className="text-lg">Total: <span className="text-green-600 font-bold">₹{todayIncome.toFixed(2)}</span></p>
            <p>Cash: <span className="text-blue-600">₹{todayPayments.filter(p => p.paymentMode === 'Cash').reduce((s, p) => s + parseFloat(p.amount || 0), 0).toFixed(2)}</span></p>
            <p>Online: <span className="text-purple-600">₹{todayPayments.filter(p => p.paymentMode === 'Online').reduce((s, p) => s + parseFloat(p.amount || 0), 0).toFixed(2)}</span></p>
          </div>
          <Table>
            <TableHeader>
              <TableRow><TableHead>Type</TableHead><TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Amount</TableHead><TableHead>Mode</TableHead><TableHead>Location</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {todayPayments.map((p, i) => (
                <TableRow key={i}><TableCell>{p.type}</TableCell><TableCell>{p.regNo}</TableCell><TableCell>{p.name}</TableCell><TableCell>₹{p.amount}</TableCell><TableCell>{p.paymentMode}</TableCell><TableCell>{p.location}</TableCell></TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Dues Report */}
      <Dialog open={showDuesReport} onOpenChange={(o) => { setShowDuesReport(o); setReportSearch(''); }}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Students with Dues</DialogTitle></DialogHeader>
          <div className="relative mb-2">
            <input
              type="text"
              placeholder="Search by Reg No, Name, Mobile, Alternate Mobile, Email, or Guardian Name..."
              value={reportSearch}
              onChange={(e) => setReportSearch(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm"
            />
          </div>
          <Table>
            <TableHeader><TableRow><TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Location</TableHead><TableHead>Dues</TableHead><TableHead>Reminder</TableHead></TableRow></TableHeader>
            <TableBody>
              {students.filter(s => s.dues > 0).filter(matchesReportSearch).map((s) => (
                <TableRow key={s.regNo}>
                  <TableCell>{s.regNo}</TableCell><TableCell>{s.name}</TableCell><TableCell>{s.mobile}</TableCell><TableCell>{s.location || 'N/A'}</TableCell><TableCell className="text-orange-600">₹{s.dues}</TableCell>
                  <TableCell>
                    <Button size="sm" disabled={!s.mobile} onClick={() => handleSendReminder(s, 'dues')} className="flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white">
                      <MessageCircle className="w-3.5 h-3.5" /> Remind
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Expiry Report */}
      <Dialog open={showExpiryReport} onOpenChange={(o) => { setShowExpiryReport(o); setReportSearch(''); }}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Students Expiring Soon (Within 5 Days)</DialogTitle></DialogHeader>
          <div className="relative mb-2">
            <input
              type="text"
              placeholder="Search by Reg No, Name, Mobile, Alternate Mobile, Email, or Guardian Name..."
              value={reportSearch}
              onChange={(e) => setReportSearch(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm"
            />
          </div>
          <Table>
            <TableHeader><TableRow><TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Location</TableHead><TableHead>Expiry Date</TableHead><TableHead>Days Left</TableHead><TableHead>Reminder</TableHead></TableRow></TableHeader>
            <TableBody>
              {expiringSoon.filter(matchesReportSearch).map((s) => {
                const days = Math.ceil((new Date(s.expiryDate).getTime() - new Date().getTime()) / (1000*60*60*24));
                return (
                  <TableRow key={s.regNo}>
                    <TableCell>{s.regNo}</TableCell><TableCell>{s.name}</TableCell><TableCell>{s.mobile}</TableCell><TableCell>{s.location || 'N/A'}</TableCell><TableCell>{formatDate(s.expiryDate)}</TableCell><TableCell className="text-red-600">{days} days</TableCell>
                    <TableCell>
                      <Button size="sm" disabled={!s.mobile} onClick={() => handleSendReminder(s, 'expiry')} className="flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white">
                        <MessageCircle className="w-3.5 h-3.5" /> Remind
                      </Button>
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>

      {/* Expired Report */}
      <Dialog open={showExpiredReport} onOpenChange={(o) => { setShowExpiredReport(o); setReportSearch(''); }}>
        <DialogContent className="w-[95vw] sm:max-w-6xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Expired Students</DialogTitle></DialogHeader>
          <div className="relative mb-2">
            <input
              type="text"
              placeholder="Search by Reg No, Name, Mobile, Alternate Mobile, Email, or Guardian Name..."
              value={reportSearch}
              onChange={(e) => setReportSearch(e.target.value)}
              className="w-full px-3 py-2 border rounded-md text-sm"
            />
          </div>
          <Table>
            <TableHeader><TableRow><TableHead>Reg No</TableHead><TableHead>Name</TableHead><TableHead>Mobile</TableHead><TableHead>Location</TableHead><TableHead>Expiry Date</TableHead><TableHead>Reminder</TableHead></TableRow></TableHeader>
            <TableBody>
              {expiredStudents.filter(matchesReportSearch).map((s) => (
                <TableRow key={s.regNo}>
                  <TableCell>{s.regNo}</TableCell><TableCell>{s.name}</TableCell><TableCell>{s.mobile}</TableCell><TableCell>{s.location || 'N/A'}</TableCell><TableCell>{formatDate(s.expiryDate)}</TableCell>
                  <TableCell>
                    <Button size="sm" disabled={!s.mobile} onClick={() => handleSendReminder(s, 'expired')} className="flex items-center gap-1 bg-green-600 hover:bg-green-700 text-white">
                      <MessageCircle className="w-3.5 h-3.5" /> Remind
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </DialogContent>
      </Dialog>
    </div>
  );
}
