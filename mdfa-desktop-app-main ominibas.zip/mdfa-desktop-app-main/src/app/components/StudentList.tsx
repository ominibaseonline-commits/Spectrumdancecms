import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { Edit, FileText, MessageCircle, Trash2, Search, X, Calendar as CalendarIcon, UserX, Eye } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { Badge } from './ui/badge';
import { deleteStudent, getStudentsLite, getStudent, getAllBatches, getAllLocations, getAllCategories } from '../lib/indexedDB';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';
import { getFieldValue, getExtraChargesEnabled, sumExtraCharges } from '../lib/admissionFields';
import { useFormLayout } from '../lib/formLayout';
import { EditStudentDialog } from './EditStudentDialog';
import { StudentPhoto } from './StudentPhoto';
import { StudentDetailsDialog } from './StudentDetailsDialog';

export function StudentList() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const [students, setStudents] = useState<any[]>([]);
  // Admission Form Layout: hidden fields are skipped, renamed fields show the new name.
  // enabledFields = visible extra + custom fields (in layout order).
  const { extraDefs: enabledFields, isVisible, label: lbl } = useFormLayout();
  const altVisible = isVisible('alternateMobile');
  const guardianVisible = isVisible('guardianName');
  const searchParts = ['Reg No', 'Name', 'Mobile', ...(altVisible ? ['Alternate Mobile'] : []), ...(guardianVisible ? ['Guardian Name'] : [])];
  const searchPlaceholder = `Search by ${searchParts.length > 1 ? `${searchParts.slice(0, -1).join(', ')}, or ${searchParts[searchParts.length - 1]}` : searchParts[0]}...`;
  const hiddenColumnCount = ['alternateMobile', 'email', 'guardianName', 'address'].filter((id) => !isVisible(id)).length;
  const [extraChargesEnabled, setExtraChargesEnabled] = useState(false);
  const [filteredStudents, setFilteredStudents] = useState<any[]>([]);
  // searchInput updates instantly as the user types (so the box feels responsive);
  // searchTerm only updates ~250ms after typing pauses, and is what actually
  // triggers filtering the list. With tens of thousands of students, filtering
  // on literally every keystroke was doing far more work than needed — this
  // way a burst of typing filters once, not once per letter.
  const [searchInput, setSearchInput] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMonth, setSelectedMonth] = useState(''); // format: 'YYYY-MM'
  const [monthPickerOpen, setMonthPickerOpen] = useState(false);
  // Table is paginated instead of rendering every matching student at once —
  // with large student counts, mounting thousands of table rows in one go is
  // what actually froze the page (typing, scrolling, everything got sluggish).
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(50);
  const PAGE_SIZE = pageSize;
  const [loadProgress, setLoadProgress] = useState<{ loaded: number; total: number } | null>(null);
  const [batches, setBatches] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [editingStudent, setEditingStudent] = useState<any>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [viewingStudent, setViewingStudent] = useState<any>(null); // read-only details popup (View button)
  const [selectedPhoto, setSelectedPhoto] = useState<string>('');
  const [showPhotoDialog, setShowPhotoDialog] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deletingStudent, setDeletingStudent] = useState<any>(null);
  const [showDeactivateConfirm, setShowDeactivateConfirm] = useState(false);
  const [deactivatingStudent, setDeactivatingStudent] = useState<any>(null);
  // Data starts loading as soon as this screen mounts — without this flag the
  // table briefly renders "No students found" (since `students` starts as an
  // empty array) before the real data comes back from IndexedDB, which flashes
  // a wrong/confusing message for a moment on every visit to this page.
  const [loading, setLoading] = useState(true);

  const { matchesLocation, selectedLocation } = useLocationFilter();
  useEffect(() => { loadData(); }, [selectedLocation]);
  useEffect(() => {
    getExtraChargesEnabled().then(setExtraChargesEnabled);
  }, []);

  useEffect(() => {
    const timer = setTimeout(() => setSearchTerm(searchInput), 250);
    return () => clearTimeout(timer);
  }, [searchInput]);

  useEffect(() => {
    let result = students.filter((student) => !student.deactivated);

    if (searchTerm.trim() !== '') {
      const search = searchTerm.toLowerCase();
      result = result.filter((student) => (
        student.regNo?.toLowerCase().includes(search) ||
        student.name?.toLowerCase().includes(search) ||
        student.mobile?.includes(search) ||
        (altVisible && student.alternateMobile?.includes(search)) ||
        (guardianVisible && student.guardianName?.toLowerCase().includes(search))
      ));
    }

    if (selectedMonth) {
      result = result.filter((student) => student.admissionDate?.startsWith(selectedMonth));
    }

    // Newest admission first — otherwise a fresh admission just lands wherever
    // IndexedDB happens to store it (roughly regNo order) and can end up
    // buried on the last page instead of being visible right away.
    result.sort((a, b) => {
      const dateDiff = new Date(b.admissionDate || 0).getTime() - new Date(a.admissionDate || 0).getTime();
      if (dateDiff !== 0) return dateDiff;
      return (b.regNo || '').localeCompare(a.regNo || '');
    });

    setFilteredStudents(result);
  }, [searchTerm, selectedMonth, students, altVisible, guardianVisible]);

  // A new search/filter/page-size starts back at page 1. (Editing or deleting a
  // student does NOT jump the admin back to page 1 any more.)
  useEffect(() => { setCurrentPage(1); }, [searchTerm, selectedMonth, pageSize]);

  const totalPages = Math.max(1, Math.ceil(filteredStudents.length / PAGE_SIZE));
  const page = Math.min(currentPage, totalPages);
  const paginatedStudents = filteredStudents.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  const formatMonthLabel = (monthValue: string) => {
    if (!monthValue) return '';
    const [year, month] = monthValue.split('-');
    const date = new Date(parseInt(year), parseInt(month) - 1, 1);
    return date.toLocaleDateString('en-GB', { month: 'long', year: 'numeric' });
  };

  const loadData = async () => {
    setLoading(true);
    try {
      // Lite list (no photos) — cached in memory, so repeat visits/edits are instant
      const studentsData = await getStudentsLite((loaded, total) => setLoadProgress({ loaded, total }));
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      let categoriesData: any[] = [];
      try { categoriesData = await getAllCategories(); } catch (e) {}
      setStudents(studentsData.filter((s: any) => matchesLocation(s.location)));
      setBatches(batchesData);
      setLocations(locationsData);
      setCategories(categoriesData);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('Failed to load data');
    } finally {
      setLoading(false);
      setLoadProgress(null);
    }
  };

  // The list rows have no photo (to keep 10,000+ students light), so anything that
  // edits/saves/prints a student first loads the complete record. Saving a
  // photo-less row would otherwise wipe the student's photo.
  const getFullStudent = async (student: any) => (await getStudent(student.regNo)) || student;

  const handleEdit = async (student: any) => {
    const full = await getFullStudent(student);
    setEditingStudent({ ...full });
    setShowEditDialog(true);
  };

  const handleSaveEdit = async (updatedStudent: any) => {
    try {
      const { saveStudent } = await import('../lib/indexedDB');
      await saveStudent(updatedStudent);
      loadData();
      setShowEditDialog(false);
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      toast.success('Student updated successfully!');
    } catch (error) {
      console.error('Error updating student:', error);
      toast.error('Failed to update student');
    }
  };

  const handleDeleteClick = (student: any) => {
    setDeletingStudent(student);
    setShowDeleteConfirm(true);
  };

  const confirmDeleteStudent = async () => {
    if (!deletingStudent) return;
    try {
      await deleteStudent(deletingStudent.regNo);
      loadData();
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      toast.success(`${deletingStudent.name} deleted successfully!`);
    } catch (error) {
      console.error('Error deleting student:', error);
      toast.error('Failed to delete student');
    } finally {
      setShowDeleteConfirm(false);
      setDeletingStudent(null);
    }
  };

  const handleDeactivateClick = (student: any) => {
    setDeactivatingStudent(student);
    setShowDeactivateConfirm(true);
  };

  const confirmDeactivateStudent = async () => {
    if (!deactivatingStudent) return;
    try {
      const { saveStudent } = await import('../lib/indexedDB');
      const fullStudent = await getFullStudent(deactivatingStudent);
      await saveStudent({ ...fullStudent, deactivated: true });
      loadData();
      window.dispatchEvent(new CustomEvent('studentsUpdated'));
      toast.success(`${deactivatingStudent.name} moved to Deactivated Students!`);
    } catch (error) {
      console.error('Error deactivating student:', error);
      toast.error('Failed to deactivate student');
    } finally {
      setShowDeactivateConfirm(false);
      setDeactivatingStudent(null);
    }
  };

  const handlePrint = async (listStudent: any) => {
    const student = await getFullStudent(listStudent); // includes the photo for the PDF
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      return new Date(dateString).toLocaleDateString('en-GB');
    };
    const escapeHtml = (v: any) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    const extraChargesList: any[] = Array.isArray(student.extraCharges)
      ? student.extraCharges.filter((c: any) => c && (c.name || parseFloat(c.amount)))
      : [];
    const photoSection = student.photo ? `<div style="text-align:center;margin:15px 0;"><img src="${student.photo}" alt="Student Photo" style="width:120px;height:120px;object-fit:cover;border:2px solid #ccc;" /></div>` : '';
    const html = `
      <!DOCTYPE html><html><head><title>${student.name} - Student Details</title>
      <style>
        @page { size: A4; margin: 15mm; }
        * { margin:0; padding:0; box-sizing:border-box; }
        body { font-family:Arial,sans-serif; font-size:11px; line-height:1.4; max-width:210mm; margin:0 auto; }
        .header { background-color:#E8630A; padding:15px; text-align:center; margin-bottom:10px; color:white; }
        .header h1 { margin:0; color:white; font-size:18px; font-weight:bold; }
        .header p { margin:5px 0 0 0; color:white; font-size:12px; }
        .section { margin-bottom:12px; page-break-inside:avoid; }
        .section-title { background-color:#FCE6D4; padding:8px 12px; font-weight:bold; font-size:12px; }
        .section-content { border:1px solid #FCE6D4; border-top:none; }
        .info-row { display:flex; padding:6px 12px; border-bottom:1px solid #f0f0f0; }
        .info-row:last-child { border-bottom:none; }
        .label { font-weight:bold; width:150px; flex-shrink:0; color:#000; }
        .value { flex:1; color:#333; }
        .value.dues { color:#d32f2f; font-weight:bold; }
      </style></head><body>
        ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Student Admission Details')}
        ${photoSection}
        <div class="section">
          <div class="section-title">Personal Information</div>
          <div class="section-content">
            <div class="info-row"><div class="label">Registration No:</div><div class="value">${student.regNo || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Admission Date:</div><div class="value">${formatDate(student.admissionDate)}</div></div>
            <div class="info-row"><div class="label">Name:</div><div class="value">${student.name || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Mobile:</div><div class="value">${student.mobile || 'N/A'}</div></div>
            ${isVisible('alternateMobile') ? `<div class="info-row"><div class="label">${lbl('alternateMobile', 'Alternate Mobile')}:</div><div class="value">${student.alternateMobile || 'N/A'}</div></div>` : ''}
            ${isVisible('email') ? `<div class="info-row"><div class="label">${lbl('email', 'Email')}:</div><div class="value">${student.email || 'N/A'}</div></div>` : ''}
            ${isVisible('dob') ? `<div class="info-row"><div class="label">${lbl('dob', 'Date of Birth')}:</div><div class="value">${formatDate(student.dob)}</div></div>` : ''}
            ${isVisible('gender') ? `<div class="info-row"><div class="label">${lbl('gender', 'Gender')}:</div><div class="value">${student.gender || 'N/A'}</div></div>` : ''}
            ${isVisible('learnedBefore') ? `<div class="info-row"><div class="label">${lbl('learnedBefore', 'Learned Before')}:</div><div class="value">${student.learnedBefore || 'N/A'}</div></div>` : ''}
          </div>
        </div>
        ${enabledFields.length > 0 ? `
        <div class="section">
          <div class="section-title">Additional Information</div>
          <div class="section-content">
            ${enabledFields.map((field) => {
              const val = getFieldValue(student.customFields, field.id);
              return val ? `<div class="info-row"><div class="label">${field.label}:</div><div class="value">${val}</div></div>` : '';
            }).join('')}
          </div>
        </div>
        ` : ''}
        ${(isVisible('guardianName') || isVisible('guardianRelation') || isVisible('address')) ? `
        <div class="section">
          <div class="section-title">Guardian Information</div>
          <div class="section-content">
            ${isVisible('guardianName') ? `<div class="info-row"><div class="label">${lbl('guardianName', 'Guardian Name')}:</div><div class="value">${student.guardianName || 'N/A'}</div></div>` : ''}
            ${isVisible('guardianRelation') ? `<div class="info-row"><div class="label">${lbl('guardianRelation', 'Relation')}:</div><div class="value">${student.guardianRelation || 'N/A'}</div></div>` : ''}
            ${isVisible('address') ? `<div class="info-row"><div class="label">${lbl('address', 'Address')}:</div><div class="value">${student.address || 'N/A'}</div></div>` : ''}
          </div>
        </div>
        ` : ''}
        <div class="section">
          <div class="section-title">Course Information</div>
          <div class="section-content">
            <div class="info-row"><div class="label">Category:</div><div class="value">${student.category || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Sub Category:</div><div class="value">${student.subCategory || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Batch Time:</div><div class="value">${student.batchTime || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Location:</div><div class="value">${student.location || 'N/A'}</div></div>
            <div class="info-row"><div class="label">Duration:</div><div class="value">${student.duration || 'N/A'} ${student.durationType || ''}</div></div>
            <div class="info-row"><div class="label">Expiry Date:</div><div class="value">${formatDate(student.expiryDate)}</div></div>
          </div>
        </div>
        ${extraChargesList.length > 0 ? `
        <div class="section">
          <div class="section-title">Extra Charges</div>
          <div class="section-content">
            ${extraChargesList.map((c: any) => `<div class="info-row"><div class="label">${escapeHtml(c.name)}:</div><div class="value">₹${c.amount}</div></div>`).join('')}
            <div class="info-row"><div class="label">Total Extra Charges:</div><div class="value" style="font-weight:bold;">₹${sumExtraCharges(extraChargesList)} <span style="font-weight:normal;">(included in Grand Total)</span></div></div>
          </div>
        </div>
        ` : ''}
        <div class="section">
          <div class="section-title">Payment Information</div>
          <div class="section-content">
            <div class="info-row"><div class="label">Total Amount:</div><div class="value">₹${(parseFloat(String(student.totalAmount)) || 0) - (extraChargesList.length > 0 ? sumExtraCharges(extraChargesList) : 0)}</div></div>
            ${extraChargesList.length > 0 ? `<div class="info-row"><div class="label">Grand Total:</div><div class="value" style="font-weight:bold;">₹${student.totalAmount || 0} <span style="font-weight:normal;">(Total Amount + Extra Charges)</span></div></div>` : ''}
            <div class="info-row"><div class="label">Paid Amount:</div><div class="value">₹${student.paidAmount || 0}</div></div>
            <div class="info-row"><div class="label">Dues:</div><div class="value dues">₹${student.dues || 0}</div></div>
          </div>
        </div>
        ${buildBrandingFooter({ businessName, businessPhone })}
      </body></html>
    `;
    await printDocument(html, `${student.name}_Student_Details`, { fitOnePage: true });
  };

  const handleWhatsApp = (student: any) => {
    if (!student.mobile) { toast.error('Mobile number not found!'); return; }
    window.open(`https://wa.me/91${student.mobile}`, '_blank');
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    return new Date(dateString).toLocaleDateString('en-GB');
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between flex-wrap gap-2">
            <CardTitle>Student List</CardTitle>
            {selectedMonth && (
              <Badge variant="secondary" className="text-sm">
                {formatMonthLabel(selectedMonth)}: {filteredStudents.length} student{filteredStudents.length !== 1 ? 's' : ''} admitted
              </Badge>
            )}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
              <Input type="text" placeholder={searchPlaceholder} value={searchInput} onChange={(e) => setSearchInput(e.target.value)} className="pl-10" />
            </div>
            <Popover open={monthPickerOpen} onOpenChange={setMonthPickerOpen}>
              <PopoverTrigger asChild>
                <Button variant={selectedMonth ? 'default' : 'outline'} className="flex items-center gap-2 whitespace-nowrap">
                  <CalendarIcon className="h-4 w-4" />
                  {selectedMonth ? formatMonthLabel(selectedMonth) : 'Select Month'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-64" align="end">
                <div className="space-y-3">
                  <Label>Filter by Admission Month</Label>
                  <Input
                    type="month"
                    value={selectedMonth}
                    onChange={(e) => setSelectedMonth(e.target.value)}
                  />
                  {selectedMonth && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="w-full"
                      onClick={() => { setSelectedMonth(''); setMonthPickerOpen(false); }}
                    >
                      <X className="h-4 w-4 mr-1" /> Clear Filter
                    </Button>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="sticky left-0 z-20 bg-white" style={{ minWidth: '80px' }}>Photo</TableHead>
                  <TableHead className="sticky left-[80px] z-20 bg-white" style={{ minWidth: '120px' }}>Reg No</TableHead>
                  <TableHead className="sticky left-[200px] z-20 bg-white" style={{ minWidth: '140px' }}>Admission Date</TableHead>
                  <TableHead className="sticky left-[340px] z-20 bg-white" style={{ minWidth: '180px' }}>Name</TableHead>
                  <TableHead>{lbl('mobile', 'Mobile')}</TableHead>
                  {isVisible('alternateMobile') && <TableHead>{lbl('alternateMobile', 'Alternate Mobile')}</TableHead>}
                  {isVisible('email') && <TableHead>{lbl('email', 'Email')}</TableHead>}
                  {isVisible('guardianName') && <TableHead>{lbl('guardianName', 'Guardian Name')}</TableHead>}
                  {isVisible('address') && <TableHead>{lbl('address', 'Address')}</TableHead>}
                  <TableHead>Category</TableHead>
                  <TableHead>Sub Category</TableHead>
                  <TableHead>Batch Time</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Duration</TableHead>
                  <TableHead>Expiry Date</TableHead>
                  <TableHead>Total Amount</TableHead>
                  <TableHead>Paid Amount</TableHead>
                  <TableHead>Dues</TableHead>
                  {enabledFields.map((field) => (
                    <TableHead key={field.id}>{field.label}</TableHead>
                  ))}
                  <TableHead>Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {paginatedStudents.length > 0 ? (
                  paginatedStudents.map((student) => (
                    <TableRow key={student.regNo}>
                      <TableCell className="sticky left-0 z-10 bg-white" style={{ minWidth: '80px' }}>
                        <StudentPhoto regNo={student.regNo} name={student.name} hasPhoto={!!student.hasPhoto} onOpen={(photo) => { setSelectedPhoto(photo); setShowPhotoDialog(true); }} />
                      </TableCell>
                      <TableCell className="sticky left-[80px] z-10 bg-white" style={{ minWidth: '120px' }}>{student.regNo}</TableCell>
                      <TableCell className="sticky left-[200px] z-10 bg-white" style={{ minWidth: '140px' }}>{formatDate(student.admissionDate)}</TableCell>
                      <TableCell className="sticky left-[340px] z-10 bg-white" style={{ minWidth: '180px' }}>{student.name}</TableCell>
                      <TableCell>{student.mobile}</TableCell>
                      {isVisible('alternateMobile') && <TableCell>{student.alternateMobile || 'N/A'}</TableCell>}
                      {isVisible('email') && <TableCell>{student.email || 'N/A'}</TableCell>}
                      {isVisible('guardianName') && <TableCell>{student.guardianName || 'N/A'}</TableCell>}
                      {isVisible('address') && <TableCell>{student.address || 'N/A'}</TableCell>}
                      <TableCell>{student.category || 'N/A'}</TableCell>
                      <TableCell>{student.subCategory || 'N/A'}</TableCell>
                      <TableCell>{student.batchTime}</TableCell>
                      <TableCell>{student.location || 'N/A'}</TableCell>
                      <TableCell>{student.duration ? `${student.duration} ${student.durationType}` : 'N/A'}</TableCell>
                      <TableCell className={new Date(student.expiryDate) < new Date() ? 'text-red-600' : 'text-green-600'}>{formatDate(student.expiryDate)}</TableCell>
                      <TableCell>₹{student.totalAmount || 0}</TableCell>
                      <TableCell>₹{student.paidAmount || 0}</TableCell>
                      <TableCell className={(student.dues || 0) > 0 ? 'text-red-600' : 'text-green-600'}>₹{student.dues || 0}</TableCell>
                      {enabledFields.map((field) => (
                        <TableCell key={field.id}>{getFieldValue(student.customFields, field.id) || 'N/A'}</TableCell>
                      ))}
                      <TableCell>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="text-blue-600 border-blue-300 hover:bg-blue-50" onClick={() => setViewingStudent(student)} title="View all details"><Eye className="w-3 h-3" /></Button>
                          <Button size="sm" variant="outline" onClick={() => handleEdit(student)}><Edit className="w-3 h-3" /></Button>
                          <Button size="sm" variant="outline" onClick={() => handlePrint(student)}><FileText className="w-3 h-3" /></Button>
                          <Button size="sm" variant="outline" onClick={() => handleWhatsApp(student)}><MessageCircle className="w-3 h-3" /></Button>
                          <Button size="sm" variant="outline" className="text-orange-600 border-orange-300 hover:bg-orange-50" onClick={() => handleDeactivateClick(student)} title="Deactivate"><UserX className="w-3 h-3" /></Button>
                          <Button size="sm" variant="outline" onClick={() => handleDeleteClick(student)}><Trash2 className="w-3 h-3" /></Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={19 - hiddenColumnCount + enabledFields.length} className="text-center py-8 text-gray-500">
                      {loading
                        ? (loadProgress && loadProgress.total > 0
                            ? `Loading students... ${loadProgress.loaded.toLocaleString()} / ${loadProgress.total.toLocaleString()}`
                            : 'Loading students...')
                        : students.length === 0
                        ? 'No students found. Please add students from Admission Form.'
                        : 'No students match your search.'}
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
          {filteredStudents.length > 0 && (
            <div className="flex items-center justify-between mt-4 flex-wrap gap-2">
              <p className="text-sm text-gray-500">
                Showing {(page - 1) * PAGE_SIZE + 1}-{Math.min(page * PAGE_SIZE, filteredStudents.length)} of {filteredStudents.length.toLocaleString()} students
              </p>
              <div className="flex items-center gap-2 flex-wrap">
                <select
                  className="h-8 rounded-md border px-2 text-sm bg-white"
                  value={pageSize}
                  onChange={(e) => setPageSize(parseInt(e.target.value))}
                  title="Rows per page"
                >
                  <option value={25}>25 / page</option>
                  <option value={50}>50 / page</option>
                  <option value={100}>100 / page</option>
                </select>
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setCurrentPage(1)}>First</Button>
                <Button size="sm" variant="outline" disabled={page <= 1} onClick={() => setCurrentPage(Math.max(1, page - 1))}>Previous</Button>
                <span className="text-sm flex items-center gap-1">
                  Page
                  <input
                    key={page}
                    type="number"
                    min={1}
                    max={totalPages}
                    defaultValue={page}
                    className="w-16 h-8 rounded-md border px-2 text-sm text-center"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        const n = parseInt((e.target as HTMLInputElement).value);
                        if (!isNaN(n)) setCurrentPage(Math.min(totalPages, Math.max(1, n)));
                      }
                    }}
                    title="Type a page number and press Enter"
                  />
                  of {totalPages.toLocaleString()}
                </span>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setCurrentPage(Math.min(totalPages, page + 1))}>Next</Button>
                <Button size="sm" variant="outline" disabled={page >= totalPages} onClick={() => setCurrentPage(totalPages)}>Last</Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <EditStudentDialog
        open={showEditDialog}
        student={editingStudent}
        categories={categories}
        batches={batches}
        locations={locations}
        enabledFields={enabledFields}
        extraChargesEnabled={extraChargesEnabled}
        onClose={() => setShowEditDialog(false)}
        onSave={handleSaveEdit}
      />


      {/* View: profile + payment record + attendance record (read-only) */}
      <StudentDetailsDialog
        open={!!viewingStudent}
        student={viewingStudent}
        enabledFields={enabledFields}
        onClose={() => setViewingStudent(null)}
        onOpenPhoto={(photo) => { setSelectedPhoto(photo); setShowPhotoDialog(true); }}
      />

      {/* Photo Dialog */}
      <Dialog open={showPhotoDialog} onOpenChange={setShowPhotoDialog}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle>Student Photo</DialogTitle></DialogHeader>
          {selectedPhoto && (<div className="flex justify-center"><img src={selectedPhoto} alt="Student" className="w-full h-auto max-h-[80vh] object-contain" /></div>)}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={(open) => { setShowDeleteConfirm(open); if (!open) setDeletingStudent(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Delete Student</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-yellow-50 border border-yellow-300 rounded">
              <p className="text-sm text-yellow-800">
                Are you sure you want to delete <strong>{deletingStudent?.name}</strong> (Reg No: {deletingStudent?.regNo})? This action cannot be undone.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowDeleteConfirm(false); setDeletingStudent(null); }} className="flex-1">Cancel</Button>
              <Button onClick={confirmDeleteStudent} className="flex-1 bg-red-600 hover:bg-red-700 text-white">Yes, Delete</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      {/* Deactivate Confirmation Dialog */}
      <Dialog open={showDeactivateConfirm} onOpenChange={(open) => { setShowDeactivateConfirm(open); if (!open) setDeactivatingStudent(null); }}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Deactivate Student</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-4 bg-orange-50 border border-orange-300 rounded">
              <p className="text-sm text-orange-800">
                Are you sure you want to move <strong>{deactivatingStudent?.name}</strong> (Reg No: {deactivatingStudent?.regNo}) to Deactivated Students? They will no longer appear in the Student List, but you can reactivate them anytime from the Deactivated Students section.
              </p>
            </div>
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => { setShowDeactivateConfirm(false); setDeactivatingStudent(null); }} className="flex-1">Cancel</Button>
              <Button onClick={confirmDeactivateStudent} className="flex-1 bg-orange-600 hover:bg-orange-700 text-white">Yes, Deactivate</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
