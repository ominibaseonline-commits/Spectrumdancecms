import { useState, useEffect, useRef } from 'react';
import { useBusinessName } from '../contexts/BusinessContext';
import { useLocationFilter } from '../contexts/LocationFilterContext';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { toast } from 'sonner';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Save, FileText, MessageCircle, Upload, Camera, RotateCcw, Check, Plus, Trash2 } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import {
  saveStudent,
  getAllStudents,
  getAllBatches,
  getAllLocations,
  migrateFromLocalStorage,
  saveBatch,
  saveLocation,
  getAllCategories
} from '../lib/indexedDB';
import { buildBrandingHeader, buildBrandingFooter, printDocument } from '../lib/printReceipt';
import { getFieldValue, getExtraChargesEnabled, sumExtraCharges, MAX_EXTRA_CHARGES, ExtraCharge } from '../lib/admissionFields';
import { useFormLayout, validateRequired, blankHiddenFields } from '../lib/formLayout';
import { AdmissionFormRenderer } from './AdmissionFormRenderer';
import { AdmissionRequest, takeAdmissionPrefill, releaseAdmissionRequest, removeAdmissionRequest } from '../lib/onlineAdmission';

export function OfflineAdmission() {
  const { businessName, businessLogo, businessAddress, businessPhone } = useBusinessName();
  const { selectedLocation: activeLocation } = useLocationFilter();
  const defaultLocation = activeLocation === 'all' ? '' : activeLocation;
  const [batches, setBatches] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedSubCategory, setSelectedSubCategory] = useState('');
  // Online request ka Sub-Category / Batch: ye category ke baad, option list ban jaane par step-by-step lagta hai
  const pendingOnlineRef = useRef<{ sub: string; batchTime: string; subDone?: boolean } | null>(null);
  const [availableSubCategories, setAvailableSubCategories] = useState<string[]>([]);
  const [filteredBatches, setFilteredBatches] = useState<any[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const [savedStudent, setSavedStudent] = useState<any>(null);
  // Admission Form Layout (Settings -> Admission Form Layout). `enabledFields` = visible extra + custom fields.
  const { fields: layoutFields, extraDefs: enabledFields, isVisible, label: lbl } = useFormLayout();

  // Extra Charges (Settings -> Admission Fields -> Add Extra Charges)
  const [extraChargesEnabled, setExtraChargesEnabled] = useState(false);
  const [extraChargesChecked, setExtraChargesChecked] = useState(false);
  const [extraCharges, setExtraCharges] = useState<ExtraCharge[]>([{ name: '', amount: '' }]);
  const extraChargesTotal = extraChargesEnabled && extraChargesChecked ? sumExtraCharges(extraCharges) : 0;

  const [formData, setFormData] = useState({
    regNo: '',
    admissionDate: new Date().toISOString().split('T')[0],
    name: '',
    gender: '',
    dob: '',
    photo: '',
    mobile: '',
    alternateMobile: '',
    aadhaarNumber: '',
    guardianName: '',
    guardianRelation: '',
    learnedBefore: '',
    address: '',
    category: '',
    subCategory: '',
    batchTime: '',
    location: defaultLocation,
    duration: '',
    durationType: '',
    expiryDate: '',
    totalAmount: '',
    paidAmount: '',
    dues: 0,
    paymentMode: '',
    email: '',
    status: 'active',
    userId: '',
    password: '',
    customFields: {} as Record<string, string>
  });

  // Online Admission: Approve dabane par request ka data yaha pehle se bhar diya jata hai
  const [dataReady, setDataReady] = useState(false);
  const [onlineReq, setOnlineReq] = useState<AdmissionRequest | null>(null);
  const onlineReqRef = useRef<AdmissionRequest | null>(null);
  useEffect(() => { onlineReqRef.current = onlineReq; }, [onlineReq]);
  // Bina save kiye page chhod diya to request dusre computer / baad ke liye free kar do
  useEffect(() => () => { if (onlineReqRef.current) releaseAdmissionRequest(onlineReqRef.current.id); }, []);

  // Photo for preview only (not saved to localStorage)
  const [photoPreview, setPhotoPreview] = useState('');

  // Photo source chooser (Live Camera / Upload) + webcam capture
  const [showPhotoChoice, setShowPhotoChoice] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  const [capturedImage, setCapturedImage] = useState('');
  const [cameraError, setCameraError] = useState('');
  const photoFileInputRef = useRef<HTMLInputElement | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const attachVideo = (el: HTMLVideoElement | null) => {
    videoRef.current = el;
    if (el && streamRef.current && el.srcObject !== streamRef.current) {
      el.srcObject = streamRef.current;
    }
  };

  const startCamera = async () => {
    setCameraError('');
    stopCamera();
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error('Camera is not supported on this device');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 1280 }, height: { ideal: 720 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err: any) {
      console.error('Camera error:', err);
      setCameraError(
        err?.name === 'NotAllowedError'
          ? 'Camera permission denied. Please allow camera access and try again.'
          : err?.name === 'NotFoundError'
          ? 'No camera found. Please connect a webcam and try again. (Mac: System Settings → Privacy & Security → Camera mein Ominibase CMS ko allow karo.)'
          : 'Could not start the camera. Please check that no other app is using it.'
      );
    }
  };

  const openLiveCamera = () => {
    setShowPhotoChoice(false);
    setCapturedImage('');
    setShowCamera(true);
  };

  const closeCamera = () => {
    stopCamera();
    setCapturedImage('');
    setCameraError('');
    setShowCamera(false);
  };

  const capturePhoto = () => {
    const video = videoRef.current;
    if (!video || !video.videoWidth) {
      toast.error('Camera is not ready yet');
      return;
    }
    // Resize to max 800px so the saved photo stays light
    const maxSize = 800;
    const scale = Math.min(1, maxSize / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
    setCapturedImage(canvas.toDataURL('image/jpeg', 0.85));
    stopCamera();
  };

  const retakePhoto = () => {
    setCapturedImage('');
    startCamera();
  };

  const useCapturedPhoto = () => {
    if (!capturedImage) return;
    setFormData((prev: any) => ({ ...prev, photo: capturedImage }));
    setPhotoPreview(capturedImage);
    setTempPhoto(capturedImage);
    closeCamera();
  };

  // Start camera when the dialog opens (and no photo has been captured yet)
  useEffect(() => {
    if (showCamera && !capturedImage) startCamera();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [showCamera]);

  // Always release the camera on unmount
  useEffect(() => () => stopCamera(), []);

  // Photo for printing (temporary)
  const [tempPhoto, setTempPhoto] = useState('');

  useEffect(() => {
    // Load which extra fields are turned ON from Settings -> Admission Fields
    getExtraChargesEnabled().then(setExtraChargesEnabled);
  }, []);

  useEffect(() => {
    // Initialize IndexedDB and migrate data
    const initializeData = async () => {
      try {
        // Run migration from localStorage to IndexedDB
        await migrateFromLocalStorage();
        
        // Load batches from IndexedDB
        const batchesData = await getAllBatches();
        if (batchesData.length === 0) {
          // Fallback to localStorage if IndexedDB is empty
          const localBatches = localStorage.getItem('batches');
          if (localBatches) {
            const parsedBatches = JSON.parse(localBatches);
            setBatches(parsedBatches);
            // Save to IndexedDB for future use
            for (const batch of parsedBatches) {
              await saveBatch(batch);
            }
          }
        } else {
          setBatches(batchesData);
        }

        // Load locations from IndexedDB
        const locationsData = await getAllLocations();
        if (locationsData.length === 0) {
          // Fallback to localStorage if IndexedDB is empty
          const localLocations = localStorage.getItem('locations');
          if (localLocations) {
            const parsedLocations = JSON.parse(localLocations);
            setLocations(parsedLocations);
            // Save to IndexedDB for future use
            for (const location of parsedLocations) {
              await saveLocation(location);
            }
          }
        } else {
          setLocations(locationsData);
        }

        // Load categories from IndexedDB
        const categoriesData = await getAllCategories();
        setCategories(categoriesData);

        // Generate unique registration number
        generateRegNo();
        setDataReady(true);
      } catch (error) {
        console.error('Error initializing data:', error);
        // Fallback to localStorage in case of error
        const localBatches = localStorage.getItem('batches');
        const localLocations = localStorage.getItem('locations');
        if (localBatches) setBatches(JSON.parse(localBatches));
        if (localLocations) setLocations(JSON.parse(localLocations));
        generateRegNo();
        setDataReady(true);
      }
    };

    initializeData();

    // Listen for storage changes to reload batches and locations
    const handleStorageChange = async (e: StorageEvent) => {
      if (e.key === 'batches' || e.key === 'locations') {
        console.log('🔄 Storage changed, reloading batches and locations...');
        const batchesData = await getAllBatches();
        const locationsData = await getAllLocations();
        setBatches(batchesData);
        setLocations(locationsData);
      }
    };

    // Add custom event listener for batch/location updates
    const handleDataUpdate = async () => {
      console.log('🔄 Data updated, reloading batches and locations...');
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      setBatches(batchesData);
      setLocations(locationsData);
    };

    window.addEventListener('storage', handleStorageChange);
    window.addEventListener('batchesUpdated', handleDataUpdate);
    window.addEventListener('locationsUpdated', handleDataUpdate);

    // Poll for updates every 2 seconds to ensure sync
    const pollInterval = setInterval(async () => {
      const batchesData = await getAllBatches();
      const locationsData = await getAllLocations();
      
      // Only update if data changed
      if (JSON.stringify(batchesData) !== JSON.stringify(batches)) {
        console.log('🔄 Batches updated from polling');
        setBatches(batchesData);
      }
      if (JSON.stringify(locationsData) !== JSON.stringify(locations)) {
        console.log('🔄 Locations updated from polling');
        setLocations(locationsData);
      }
    }, 2000);

    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('batchesUpdated', handleDataUpdate);
      window.removeEventListener('locationsUpdated', handleDataUpdate);
      clearInterval(pollInterval);
    };
  }, []);

  // Batches / categories load hone ke baad prefill lagta hai. setTimeout isliye: data load hote hi category/batch ke
  // "reset" effects bhi ek baar chalte hain, wo prefill ke BAAD chalte to sub-category / batch khali kar dete the.
  useEffect(() => {
    if (!dataReady) return;
    const t = setTimeout(() => {
      const pre = takeAdmissionPrefill();
      if (!pre) return;
      const core = pre.req.data.core || {};
      const custom = pre.req.data.custom || {};
      const same = (a: any, b: any) => String(a ?? '').trim().toLowerCase() === String(b ?? '').trim().toLowerCase();
      // Online form me jo naam aaya use CMS ke exact naam se match karo (extra space / capital ka farak na pade)
      const catObj = categories.find((c: any) => same(c.name, core.category));
      const category = catObj ? catObj.name : String(core.category || '');
      const sub = (catObj?.subCategories || []).find((x: string) => same(x, core.subCategory)) || String(core.subCategory || '');
      const batchObj = batches.find((b: any) => same(b.batchTime, core.batchTime) && same(b.category, category) && same(b.subCategory, sub))
        || batches.find((b: any) => same(b.batchTime, core.batchTime));
      const batchTime = batchObj ? batchObj.batchTime : String(core.batchTime || '');
      const locObj = locations.find((l: any) => same(l.name, core.location));
      const location = locObj ? locObj.name : String(core.location || '');

      const KEYS = ['name', 'mobile', 'gender', 'dob', 'alternateMobile', 'aadhaarNumber', 'guardianName', 'guardianRelation', 'learnedBefore', 'address', 'email'];
      const patch: Record<string, any> = {};
      KEYS.forEach((k) => { if (core[k]) patch[k] = String(core[k]); });
      if (category) patch.category = category;
      if (location) patch.location = location;
      // Sub-Category aur Batch abhi nahi: dropdown ke options category chunne ke BAAD bante hain. Option bante hi
      // value set karte hain (neeche 2 effects), warna Select value ko khali kar deta tha.
      pendingOnlineRef.current = sub ? { sub, batchTime } : null;
      setSelectedCategory(category);
      setFormData((prev: any) => ({ ...prev, ...patch, customFields: { ...prev.customFields, ...custom } }));
      setOnlineReq(pre.req);
      toast.success('Online request ka data bhar diya gaya hai. Photo / fees bharke Save karein.');
    }, 0);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dataReady]);

  useEffect(() => {
    // Calculate expiry date based on duration
    if (formData.admissionDate && formData.duration && formData.durationType) {
      const startDate = new Date(formData.admissionDate);
      let expiryDate = new Date(startDate);

      const duration = parseInt(formData.duration);
      
      if (formData.durationType === 'Days') {
        expiryDate.setDate(expiryDate.getDate() + duration);
      } else if (formData.durationType === 'Month') {
        expiryDate.setMonth(expiryDate.getMonth() + duration);
      } else if (formData.durationType === 'Year') {
        expiryDate.setFullYear(expiryDate.getFullYear() + duration);
      }

      setFormData(prev => ({
        ...prev,
        expiryDate: expiryDate.toISOString().split('T')[0]
      }));
    }
  }, [formData.admissionDate, formData.duration, formData.durationType]);

  useEffect(() => {
    // Calculate dues
    // Final total = Total Amount typed by admin + Extra Charges (if any)
    const total = (parseFloat(formData.totalAmount) || 0) + extraChargesTotal;
    const paid = parseFloat(formData.paidAmount) || 0;
    setFormData(prev => ({
      ...prev,
      dues: total - paid
    }));
  }, [formData.totalAmount, formData.paidAmount, extraChargesTotal]);

  const updateExtraCharge = (index: number, field: 'name' | 'amount', value: string) => {
    setExtraCharges((prev) => prev.map((c, i) => (i === index ? { ...c, [field]: value } : c)));
  };

  const addExtraChargeRow = () => {
    setExtraCharges((prev) => (prev.length >= MAX_EXTRA_CHARGES ? prev : [...prev, { name: '', amount: '' }]));
  };

  const removeExtraChargeRow = (index: number) => {
    setExtraCharges((prev) => (prev.length <= 1 ? [{ name: '', amount: '' }] : prev.filter((_, i) => i !== index)));
  };

  // Handle category selection - update available sub-categories
  useEffect(() => {
    if (selectedCategory) {
      const category = categories.find(c => c.name === selectedCategory);
      if (category) {
        setAvailableSubCategories(category.subCategories || []);
        // Reset sub-category if current selection is invalid
        if (!category.subCategories.includes(selectedSubCategory)) {
          setSelectedSubCategory('');
          setFormData(prev => ({ ...prev, subCategory: '' }));
        }
      }
    } else {
      setAvailableSubCategories([]);
      setSelectedSubCategory('');
      setFormData(prev => ({ ...prev, category: '', subCategory: '' }));
    }
  }, [selectedCategory, categories]);

  // Handle sub-category selection - filter batches
  useEffect(() => {
    if (selectedCategory && selectedSubCategory) {
      // Filter batches by selected category and sub-category
      const filtered = batches.filter(
        batch => batch.category === selectedCategory && batch.subCategory === selectedSubCategory
      );
      setFilteredBatches(filtered);

      // Reset batch selection if current batch is not in filtered list
      const currentBatchValid = filtered.some(b => b.batchTime === formData.batchTime);
      if (!currentBatchValid) {
        setFormData(prev => ({ ...prev, batchTime: '' }));
      }
    } else {
      setFilteredBatches([]);
      setFormData(prev => ({ ...prev, batchTime: '' }));
    }
  }, [selectedCategory, selectedSubCategory, batches]);

  // Online request: sub-category options ban jaayein to sub-category lagao
  useEffect(() => {
    const p = pendingOnlineRef.current;
    if (!p || p.subDone || !selectedCategory) return;
    if (availableSubCategories.includes(p.sub)) {
      p.subDone = true;
      setSelectedSubCategory(p.sub);
      setFormData((prev: any) => ({ ...prev, subCategory: p.sub }));
    }
  }, [availableSubCategories, selectedCategory]);

  // ...phir batch options ban jaayein to batch lagao
  useEffect(() => {
    const p = pendingOnlineRef.current;
    if (!p || !p.subDone) return;
    if (!p.batchTime) { pendingOnlineRef.current = null; return; }
    if (filteredBatches.some((b: any) => b.batchTime === p.batchTime)) {
      pendingOnlineRef.current = null;
      setFormData((prev: any) => ({ ...prev, batchTime: p.batchTime }));
    }
  }, [filteredBatches]);

  const generateRegNo = () => {
    getAllStudents().then(students => {
      let regNo;
      do {
        // Generate 6-digit registration number (100000 to 999999) for 50,000+ students capacity
        regNo = Math.floor(100000 + Math.random() * 900000).toString();
      } while (students.some((s: any) => s.regNo === regNo));
      
      setFormData(prev => ({ ...prev, regNo }));
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validation — required flags come from the Admission Form Layout
    const requiredError = validateRequired(layoutFields, { ...formData, photo: tempPhoto || formData.photo });
    if (requiredError) {
      toast.error(requiredError);
      return;
    }

    if (formData.mobile.length !== 10) {
      toast.error('Mobile Number 10 digits का होना चाहिए');
      return;
    }

    if (!/^\d+$/.test(formData.mobile)) {
      toast.error('Mobile Number में केवल numbers होने चाहिए');
      return;
    }

    // Extra charges: ignore fully empty rows, but a half-filled row is an error
    let cleanedExtraCharges: { name: string; amount: number }[] = [];
    if (extraChargesEnabled && extraChargesChecked) {
      for (const c of extraCharges) {
        const name = String(c.name || '').trim();
        const amountStr = String(c.amount ?? '').trim();
        if (!name && !amountStr) continue;
        if (!name) {
          toast.error('कृपया Extra Charge का नाम भरें');
          return;
        }
        const amt = parseFloat(amountStr);
        if (!amountStr || isNaN(amt) || amt < 0) {
          toast.error(`कृपया "${name}" का सही amount भरें`);
          return;
        }
        cleanedExtraCharges.push({ name, amount: amt });
      }
    }
    const extrasTotalToSave = cleanedExtraCharges.reduce((sum, c) => sum + c.amount, 0);
    // Student's final Total Amount = typed Total Amount + Extra Charges
    const finalTotalAmount = String((parseFloat(formData.totalAmount) || 0) + extrasTotalToSave);

    // All validation passed - Save student
    try {
      // Create student data with photo
      const studentDataToSave = blankHiddenFields({
        ...formData,
        totalAmount: finalTotalAmount,
        extraCharges: cleanedExtraCharges,
        // Balance left at admission time = Admission Dues (Monthly Dues start at 0)
        admissionDues: Math.max(0, parseFloat(String(formData.dues)) || 0),
        monthlyDues: 0,
        photo: tempPhoto // Save photo in IndexedDB
      }, layoutFields);
      
      // Save to IndexedDB (will also sync to localStorage automatically)
      await saveStudent(studentDataToSave);
      window.dispatchEvent(new CustomEvent('studentsUpdated')); // Google Sheet ko jaldi sync ho
      toast.success('Student admission saved successfully!');
      // Online request se aayi admission thi to ab wo request Sheet se hata do
      if (onlineReq) {
        const doneId = onlineReq.id;
        onlineReqRef.current = null;
        setOnlineReq(null);
        removeAdmissionRequest(doneId);
      }
      
      // Save the complete data with photo for preview and print
      const savedStudentWithPhoto = blankHiddenFields({
        ...formData,
        totalAmount: finalTotalAmount,
        extraCharges: cleanedExtraCharges,
        photo: tempPhoto // Use temporary photo for print/preview
      }, layoutFields);
      setSavedStudent(savedStudentWithPhoto);
      setShowPreview(true);

      // Reset form
      setFormData({
        regNo: '',
        admissionDate: new Date().toISOString().split('T')[0],
        name: '',
        gender: '',
        dob: '',
        photo: '',
        mobile: '',
        alternateMobile: '',
        aadhaarNumber: '',
        guardianName: '',
        guardianRelation: '',
        learnedBefore: '',
        address: '',
        category: '',
        subCategory: '',
        batchTime: '',
        location: defaultLocation,
        duration: '',
        durationType: '',
        expiryDate: '',
        totalAmount: '',
        paidAmount: '',
        dues: 0,
        paymentMode: '',
        email: '',
        status: 'active',
        userId: '',
        password: '',
        customFields: {}
      });
      // Reset category/sub-category dropdown states too — otherwise the
      // dropdown keeps showing the old selection while formData.category
      // is actually empty, causing a false "select category" validation error
      setSelectedCategory('');
      setSelectedSubCategory('');
      setAvailableSubCategories([]);
      setFilteredBatches([]);
      setPhotoPreview('');
      setTempPhoto('');
      setExtraChargesChecked(false);
      setExtraCharges([{ name: '', amount: '' }]);
      generateRegNo();
    } catch (error) {
      console.error('Error saving student:', error);
      if (error instanceof DOMException && error.name === 'QuotaExceededError') {
        toast.error('Storage limit exceeded! कृपया Settings में जाकर पुराने data को export करें और delete करें।');
      } else {
        toast.error('Student save करते समय error आई। कृपया फिर से try करें।');
      }
    }
  };

  const escapeHtml = (v: any) => String(v ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

  const getSavedExtraCharges = (): { name: string; amount: number }[] =>
    Array.isArray(savedStudent?.extraCharges)
      ? savedStudent.extraCharges.filter((c: any) => c && (c.name || parseFloat(c.amount)))
      : [];

  const handlePrint = async () => {
    if (!savedStudent) return;
    const extraChargesList = getSavedExtraCharges();
    const extraChargesSum = extraChargesList.reduce((sum, c) => sum + (parseFloat(String(c.amount)) || 0), 0);
    // savedStudent.totalAmount already includes extra charges. Show the plain course/monthly
    // amount as "Total Amount" so students can see what they pay for the course itself.
    const baseTotalAmount = (parseFloat(String(savedStudent.totalAmount)) || 0) - extraChargesSum;

    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-GB');
    };

    const photoSection = savedStudent.photo ? `
      <div style="text-align: center; margin-bottom: 20px;">
        <img src="${savedStudent.photo}" alt="Student Photo" style="width: 150px; height: 150px; object-fit: cover; border-radius: 8px; border: 3px solid #F9CDAA;" />
      </div>
    ` : '';

    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>${savedStudent.name} - Admission Receipt</title>
        <style>
          @page { size: A4; margin: 15mm; }
          body { 
            font-family: Arial, sans-serif; 
            padding: 15px;
            max-width: 210mm;
            margin: 0 auto;
            font-size: 11pt;
          }
          .header { 
            background-color: #E8630A; 
            padding: 15px; 
            text-align: center;
            margin-bottom: 15px;
            color: white;
          }
          .header h1 { margin: 0; color: white; font-size: 18pt; }
          .header p { margin: 5px 0 0 0; color: white; font-size: 11pt; }
          .section { margin-bottom: 12px; }
          .section h2 { 
            background-color: #FCE6D4; 
            padding: 8px; 
            margin-bottom: 8px;
            font-size: 12pt;
          }
          .row { 
            display: flex; 
            padding: 4px 0; 
            border-bottom: 1px solid #eee;
          }
          .label { 
            font-weight: bold; 
            width: 180px; 
            font-size: 10pt;
          }
          .value { flex: 1; font-size: 10pt; }
          @media print {
            body { padding: 10px; }
          }
        </style>
      </head>
      <body>
        ${buildBrandingHeader({ businessName, businessLogo, businessAddress }, 'Admission Receipt')}
        
        ${photoSection}
        
        <div class="section">
          <h2>Personal Information</h2>
          <div class="row">
            <div class="label">${lbl('regNo', 'Registration No')}:</div>
            <div class="value">${savedStudent.regNo}</div>
          </div>
          <div class="row">
            <div class="label">${lbl('admissionDate', 'Admission Date')}:</div>
            <div class="value">${formatDate(savedStudent.admissionDate)}</div>
          </div>
          <div class="row">
            <div class="label">${lbl('name', 'Student Name')}:</div>
            <div class="value">${savedStudent.name}</div>
          </div>
          ${isVisible('gender') ? `
          <div class="row">
            <div class="label">${lbl('gender', 'Gender')}:</div>
            <div class="value">${savedStudent.gender}</div>
          </div>
          ` : ''}
          ${isVisible('dob') ? `
          <div class="row">
            <div class="label">${lbl('dob', 'Date of Birth')}:</div>
            <div class="value">${formatDate(savedStudent.dob)}</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">${lbl('mobile', 'Mobile')}:</div>
            <div class="value">${savedStudent.mobile}</div>
          </div>
          ${savedStudent.alternateMobile ? `
          <div class="row">
            <div class="label">${lbl('alternateMobile', 'Alternate Mobile')}:</div>
            <div class="value">${savedStudent.alternateMobile}</div>
          </div>
          ` : ''}
          ${savedStudent.aadhaarNumber ? `
          <div class="row">
            <div class="label">${lbl('aadhaarNumber', 'Aadhaar Number')}:</div>
            <div class="value">${savedStudent.aadhaarNumber}</div>
          </div>
          ` : ''}
          ${savedStudent.email ? `
          <div class="row">
            <div class="label">${lbl('email', 'Email')}:</div>
            <div class="value">${savedStudent.email}</div>
          </div>
          ` : ''}
          ${savedStudent.learnedBefore ? `
          <div class="row">
            <div class="label">${lbl('learnedBefore', 'Learned Before')}:</div>
            <div class="value">${savedStudent.learnedBefore}</div>
          </div>
          ` : ''}
        </div>

        ${enabledFields.length > 0 ? `
        <div class="section">
          <h2>Additional Information</h2>
          ${enabledFields.map((field) => {
            const val = getFieldValue(savedStudent.customFields, field.id);
            return val ? `
          <div class="row">
            <div class="label">${field.label}:</div>
            <div class="value">${val}</div>
          </div>
            ` : '';
          }).join('')}
        </div>
        ` : ''}

        ${(isVisible('guardianName') || isVisible('guardianRelation') || isVisible('address')) ? `
        <div class="section">
          <h2>Guardian Information</h2>
          ${isVisible('guardianName') ? `
          <div class="row">
            <div class="label">${lbl('guardianName', 'Guardian Name')}:</div>
            <div class="value">${savedStudent.guardianName}</div>
          </div>
          ` : ''}
          ${isVisible('guardianRelation') ? `
          <div class="row">
            <div class="label">${lbl('guardianRelation', 'Relation')}:</div>
            <div class="value">${savedStudent.guardianRelation}</div>
          </div>
          ` : ''}
          ${isVisible('address') ? `
          <div class="row">
            <div class="label">${lbl('address', 'Address')}:</div>
            <div class="value">${savedStudent.address}</div>
          </div>
          ` : ''}
        </div>
        ` : ''}

        <div class="section">
          <h2>Course Information</h2>
          <div class="row">
            <div class="label">Category:</div>
            <div class="value">${savedStudent.category}</div>
          </div>
          ${savedStudent.subCategory ? `
          <div class="row">
            <div class="label">Sub-Category:</div>
            <div class="value">${savedStudent.subCategory}</div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Batch Time:</div>
            <div class="value">${savedStudent.batchTime}</div>
          </div>
          <div class="row">
            <div class="label">Location:</div>
            <div class="value">${savedStudent.location}</div>
          </div>
          <div class="row">
            <div class="label">Duration:</div>
            <div class="value">${savedStudent.duration} ${savedStudent.durationType}</div>
          </div>
          <div class="row">
            <div class="label">Expiry Date:</div>
            <div class="value">${formatDate(savedStudent.expiryDate)}</div>
          </div>
        </div>

        ${extraChargesList.length > 0 ? `
        <div class="section">
          <h2>Extra Charges</h2>
          ${extraChargesList.map((c) => `
          <div class="row">
            <div class="label">${escapeHtml(c.name)}:</div>
            <div class="value">₹${c.amount}</div>
          </div>`).join('')}
          <div class="row">
            <div class="label">Total Extra Charges:</div>
            <div class="value" style="font-weight: bold;">₹${extraChargesSum} <span style="font-weight: normal;">(included in Grand Total)</span></div>
          </div>
        </div>
        ` : ''}

        <div class="section">
          <h2>Payment Information</h2>
          <div class="row">
            <div class="label">Total Amount:</div>
            <div class="value">₹${baseTotalAmount}</div>
          </div>
          ${extraChargesList.length > 0 ? `
          <div class="row">
            <div class="label">Grand Total:</div>
            <div class="value" style="font-weight: bold;">₹${savedStudent.totalAmount} <span style="font-weight: normal;">(Total Amount + Extra Charges)</span></div>
          </div>
          ` : ''}
          <div class="row">
            <div class="label">Paid Amount:</div>
            <div class="value">₹${savedStudent.paidAmount}</div>
          </div>
          <div class="row">
            <div class="label">Dues:</div>
            <div class="value" style="color: ${(savedStudent.dues || 0) > 0 ? 'red' : 'green'};">₹${savedStudent.dues}</div>
          </div>
          <div class="row">
            <div class="label">Payment Mode:</div>
            <div class="value">${savedStudent.paymentMode}</div>
          </div>
        </div>

        ${buildBrandingFooter({ businessName, businessPhone })}
      </body>
      </html>
    `;

    await printDocument(html, `${savedStudent.name}_Admission_Receipt`, { fitOnePage: true });
  };

  const handleWhatsApp = () => {
    if (!savedStudent) return;
    
    if (!savedStudent.mobile) {
      toast.error('Mobile number not found!');
      return;
    }
    
    const formatDate = (dateString: string) => {
      if (!dateString) return 'N/A';
      const date = new Date(dateString);
      return date.toLocaleDateString('en-GB');
    };

    const waExtraCharges = getSavedExtraCharges();
    const waExtraSum = waExtraCharges.reduce((sum, c) => sum + (parseFloat(String(c.amount)) || 0), 0);
    const waExtraSection = waExtraCharges.length > 0
      ? `\n*Extra Charges:*\n${waExtraCharges.map((c) => `${c.name}: ₹${c.amount}`).join('\n')}\nTotal Extra Charges: ₹${waExtraSum} (included in Grand Total)\n`
      : '';

    // Custom WhatsApp message format with proper encoding
    const message = 
`*${businessName.toUpperCase()}*
*Admission Successful!*

*Admission Details:*
Name: ${savedStudent.name}
Registration No: ${savedStudent.regNo}
Admission Date: ${formatDate(savedStudent.admissionDate)}
${enabledFields.filter((field) => getFieldValue(savedStudent.customFields, field.id)).map((field) => `${field.label}: ${getFieldValue(savedStudent.customFields, field.id)}`).join('\n')}
Location: ${savedStudent.location}
Batch Time: ${savedStudent.batchTime}
Category: ${savedStudent.category}${savedStudent.subCategory ? ` - ${savedStudent.subCategory}` : ''}
Duration: ${savedStudent.duration} ${savedStudent.durationType}
Expiry Date: ${formatDate(savedStudent.expiryDate)}
${waExtraSection}
*Payment Details:*
Total Amount: ₹${(parseFloat(String(savedStudent.totalAmount)) || 0) - waExtraSum}${waExtraCharges.length > 0 ? `\nGrand Total (with Extra Charges): ₹${savedStudent.totalAmount}` : ''}
Paid Amount: ₹${savedStudent.paidAmount}
Dues: ₹${savedStudent.dues}


Thank you for joining us!
For any queries, contact academy administration.`;

    // Encode the message for WhatsApp
    const encodedMessage = encodeURIComponent(message);
    
    window.open(`https://wa.me/91${savedStudent.mobile}?text=${encodedMessage}`, '_blank');
  };

  return (
    <div className="p-6">
      <Card>
        <CardHeader>
          <CardTitle>Admission Form</CardTitle>
        </CardHeader>
        <CardContent>
          {onlineReq && (
            <div className="mb-4 flex items-center justify-between gap-3 rounded-lg border border-green-300 bg-green-50 p-3 text-sm text-green-900">
              <span><strong>Online request:</strong> {onlineReq.data.core.name} ({onlineReq.data.core.mobile}). Save karte hi ye request apne aap hat jayegi.</span>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={() => {
                  releaseAdmissionRequest(onlineReq.id);
                  onlineReqRef.current = null;
                  setOnlineReq(null);
                  setSelectedCategory('');
                  setSelectedSubCategory('');
                  setFormData((prev: any) => ({
                    ...prev, name: '', gender: '', dob: '', mobile: '', alternateMobile: '', aadhaarNumber: '', guardianName: '',
                    guardianRelation: '', learnedBefore: '', address: '', email: '', category: '', subCategory: '', batchTime: '',
                    location: defaultLocation, customFields: {},
                  }));
                }}
              >
                Request wapas rakhein
              </Button>
            </div>
          )}
          <form onSubmit={handleSubmit} className="space-y-6">
            <AdmissionFormRenderer
              fields={layoutFields}
              formData={formData}
              onChange={(patch) => setFormData((prev: any) => ({ ...prev, ...patch }))}
              onCustomChange={(id, value) =>
                setFormData((prev: any) => ({ ...prev, customFields: { ...prev.customFields, [id]: value } }))
              }
              onAttachPhoto={() => setShowPhotoChoice(true)}
              block={{
                categories,
                selectedCategory,
                selectedSubCategory,
                availableSubCategories,
                filteredBatches,
                locations,
                onCategoryChange: (value) => {
                  setSelectedCategory(value);
                  setFormData((prev: any) => ({ ...prev, category: value, subCategory: '', batchTime: '' }));
                },
                onSubCategoryChange: (value) => {
                  setSelectedSubCategory(value);
                  setFormData((prev: any) => ({ ...prev, subCategory: value, batchTime: '' }));
                },
              }}
              extraChargesSlot={extraChargesEnabled ? (

              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="add-extra-charges"
                    checked={extraChargesChecked}
                    onCheckedChange={(checked) => setExtraChargesChecked(checked === true)}
                  />
                  <Label htmlFor="add-extra-charges" className="cursor-pointer">Add Extra Charges</Label>
                </div>

                {extraChargesChecked && (
                  <div className="p-4 border rounded-lg bg-orange-50/50 space-y-3">
                    <div className="grid grid-cols-[1fr_1fr_auto] gap-3 text-sm text-gray-600">
                      <span>Extra Charge Name</span>
                      <span>Amount</span>
                      <span className="w-9" />
                    </div>
                    {extraCharges.map((charge, index) => (
                      <div key={index} className="grid grid-cols-[1fr_1fr_auto] gap-3 items-center">
                        <Input
                          value={charge.name}
                          onChange={(e) => updateExtraCharge(index, 'name', e.target.value)}
                          placeholder="e.g. AC Charges"
                        />
                        <div className="relative">
                          <span className="absolute left-3 top-2.5">₹</span>
                          <Input
                            type="number"
                            value={charge.amount}
                            onChange={(e) => updateExtraCharge(index, 'amount', e.target.value)}
                            placeholder="0"
                            className="pl-8"
                            min="0"
                          />
                        </div>
                        <Button
                          type="button"
                          variant="outline"
                          size="icon"
                          onClick={() => removeExtraChargeRow(index)}
                          title="Remove"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}

                    <div className="flex items-center justify-between flex-wrap gap-3">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addExtraChargeRow}
                        disabled={extraCharges.length >= MAX_EXTRA_CHARGES}
                        className="flex items-center gap-2"
                      >
                        <Plus className="w-4 h-4" /> Add
                        <span className="text-xs text-gray-500">({extraCharges.length}/{MAX_EXTRA_CHARGES})</span>
                      </Button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t">
                      <div>
                        <Label>Total Extra Charges</Label>
                        <div className="relative">
                          <span className="absolute left-3 top-2.5">₹</span>
                          <Input type="number" value={extraChargesTotal} disabled className="pl-8" />
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              ) : null}
            />

            {/* NOTE: plain <input> on purpose — the shared <Input> component doesn't forward refs
                (React 18), so photoFileInputRef.current was null and .click() did nothing. */}
            <input
              type="file"
              accept="image/*"
              ref={photoFileInputRef}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) {
                  const reader = new FileReader();
                  reader.onloadend = () => {
                    setFormData((prev: any) => ({ ...prev, photo: reader.result as string }));
                    setPhotoPreview(reader.result as string);
                    setTempPhoto(reader.result as string);
                  };
                  reader.readAsDataURL(file);
                }
                e.target.value = '';
              }}
              className="hidden"
              id="photo-upload"
            />

            {/* Submit Button */}
            <div className="flex gap-4">
              <Button type="submit" className="flex items-center gap-2">
                <Save className="w-4 h-4" />
                Save Admission
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      {/* Photo Source Chooser Dialog */}
      <Dialog open={showPhotoChoice} onOpenChange={setShowPhotoChoice}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>Student Photo</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3">
            <button
              type="button"
              onClick={openLiveCamera}
              className="flex flex-col items-center gap-2 p-5 border rounded-lg hover:bg-orange-50 hover:border-orange-300 transition-colors"
            >
              <Camera className="w-8 h-8 text-orange-500" />
              <span className="font-medium">Live Camera</span>
              <span className="text-xs text-gray-500">Take photo now</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setShowPhotoChoice(false);
                photoFileInputRef.current?.click();
              }}
              className="flex flex-col items-center gap-2 p-5 border rounded-lg hover:bg-orange-50 hover:border-orange-300 transition-colors"
            >
              <Upload className="w-8 h-8 text-orange-500" />
              <span className="font-medium">Upload Photo</span>
              <span className="text-xs text-gray-500">Choose from device</span>
            </button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Live Camera Dialog */}
      <Dialog open={showCamera} onOpenChange={(open) => { if (!open) closeCamera(); }}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{capturedImage ? 'Preview Photo' : 'Live Camera'}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <div className="relative w-full aspect-video bg-black rounded-lg overflow-hidden flex items-center justify-center">
              {capturedImage ? (
                <img src={capturedImage} alt="Captured" className="w-full h-full object-contain" />
              ) : cameraError ? (
                <p className="text-sm text-red-300 px-6 text-center">{cameraError}</p>
              ) : (
                <video ref={attachVideo} autoPlay playsInline muted className="w-full h-full object-contain" />
              )}
            </div>
            <div className="flex justify-end gap-2">
              {capturedImage ? (
                <>
                  <Button type="button" variant="outline" onClick={retakePhoto} className="flex items-center gap-2">
                    <RotateCcw className="w-4 h-4" /> Retake
                  </Button>
                  <Button type="button" onClick={useCapturedPhoto} className="flex items-center gap-2">
                    <Check className="w-4 h-4" /> Use Photo
                  </Button>
                </>
              ) : (
                <>
                  <Button type="button" variant="outline" onClick={closeCamera}>Cancel</Button>
                  {cameraError ? (
                    <Button type="button" onClick={startCamera}>Try Again</Button>
                  ) : (
                    <Button type="button" onClick={capturePhoto} className="flex items-center gap-2">
                      <Camera className="w-4 h-4" /> Capture
                    </Button>
                  )}
                </>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Preview Dialog */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Admission Saved Successfully!</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p>Student has been successfully admitted with Registration No: <strong>{savedStudent?.regNo}</strong></p>
            {getSavedExtraCharges().length > 0 && (
              <div className="rounded-md border p-3 text-sm space-y-1">
                <p className="font-semibold">Extra Charges</p>
                {getSavedExtraCharges().map((c, i) => (
                  <div key={i} className="flex justify-between"><span>{c.name}</span><span>₹{c.amount}</span></div>
                ))}
                <div className="flex justify-between font-semibold border-t pt-1">
                  <span>Total Extra Charges</span>
                  <span>₹{getSavedExtraCharges().reduce((sum, c) => sum + (parseFloat(String(c.amount)) || 0), 0)}</span>
                </div>
              </div>
            )}
            <div className="flex gap-2">
              <Button onClick={handlePrint} variant="outline" className="flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Print
              </Button>
              <Button onClick={handleWhatsApp} variant="outline" className="flex items-center gap-2">
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
